extends "res://kit/mod_base.gd"

const MOTE_COUNT: int = 16

var _clock: float = 0.0
var _cd: Dictionary = {}
var _amb: CanvasLayer = null
var _tint: ColorRect = null
var _motes: Array[Polygon2D] = []
var _mote_vel: Array[Vector2] = []
var _shadow: Polygon2D = null
var _shadow_owner: Node = null
var _streak: int = 0
var _streak_t: float = -99.0


func _ready() -> void:
	_build_ambient()


func _build_ambient() -> void:
	if _amb != null and is_instance_valid(_amb):
		return
	_amb = CanvasLayer.new()
	_amb.layer = 48
	add_child(_amb)
	_tint = ColorRect.new()
	_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tint.set_anchors_preset(Control.PRESET_FULL_RECT)
	_tint.color = Color(1.0, 0.7, 0.4, 0.06)
	_amb.add_child(_tint)
	var size: Vector2 = get_viewport().get_visible_rect().size
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 4242
	for i in range(MOTE_COUNT):
		var m: Polygon2D = Polygon2D.new()
		var r: float = rng.randf_range(1.5, 3.2)
		m.polygon = PackedVector2Array([Vector2(-r, 0), Vector2(0, -r), Vector2(r, 0), Vector2(0, r)])
		m.color = Color(1.0, 0.85, 0.6, rng.randf_range(0.12, 0.3))
		m.position = Vector2(rng.randf_range(0.0, size.x), rng.randf_range(0.0, size.y))
		_amb.add_child(m)
		_motes.append(m)
		_mote_vel.append(Vector2(rng.randf_range(-14.0, -4.0), rng.randf_range(-8.0, 6.0)))


func _ready_shadow() -> void:
	var p: Node2D = player()
	if p == null:
		return
	if _shadow != null and is_instance_valid(_shadow) and _shadow_owner == p:
		return
	if _shadow != null and is_instance_valid(_shadow):
		_shadow.queue_free()
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(16):
		var a: float = TAU * float(i) / 16.0
		pts.append(Vector2(cos(a) * 15.0, sin(a) * 5.5))
	_shadow = Polygon2D.new()
	_shadow.polygon = pts
	_shadow.color = Color(0.0, 0.0, 0.0, 0.3)
	_shadow.position = Vector2(0, 16)
	_shadow.show_behind_parent = true
	p.add_child(_shadow)
	_shadow_owner = p


func _ok(key: String, gap: float) -> bool:
	var last: float = float(_cd.get(key, -99.0))
	if _clock - last < gap:
		return false
	_cd[key] = _clock
	return true


func _pos() -> Vector2:
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2(get_viewport().get_visible_rect().size * 0.5)


func on_level_start() -> void:
	_build_ambient()
	_streak = 0
	_ready_shadow()
	_cd.clear()
	toast("\u00a1A sobrevivir!", Color(1.0, 0.8, 0.4))
	burst(_pos(), Color(0.6, 0.85, 0.4), 18)
	flash_screen(Color(1.0, 0.85, 0.6, 0.25), 0.25)
	play_sound("power", 0.9)


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"coin":
			_streak = _streak + 1 if _clock - _streak_t < 3.0 else 1
			_streak_t = _clock
			burst(_pos(), Color(1.0, 0.85, 0.3), 8)
			if _streak == 5 or _streak == 10:
				if _ok("combo", 2.0):
					toast("\u00a1Buen bot\u00edn!", Color(1.0, 0.85, 0.3))
					flash_screen(Color(1.0, 0.9, 0.4, 0.2), 0.12)
					shake(3.0)
		"hit", "stomp", "boss_hit":
			if _ok("hit", 0.25):
				burst(_pos(), Color(1.0, 0.55, 0.2), 10)
				shake(2.5)
				if _ok("hittoast", 4.0):
					toast("\u00a1Zas!", Color(1.0, 0.6, 0.3))
		"hurt":
			if _ok("hurt", 0.6):
				burst(_pos(), Color(0.9, 0.2, 0.2), 12)
				shake(4.0)
				flash_screen(Color(0.9, 0.1, 0.1, 0.22), 0.15)
		"power", "checkpoint":
			if _ok("power", 1.0):
				burst(_pos(), Color(0.5, 0.9, 1.0), 14)
				toast("\u00a1Listo!", Color(0.6, 0.9, 1.0))
				play_sound("power", 1.1)
		"boss_spawn":
			if _ok("boss", 2.0):
				shake(6.0)
				toast("\u00a1Cuidado, bestia!", Color(1.0, 0.4, 0.3))
				flash_screen(Color(0.8, 0.1, 0.1, 0.25), 0.2)
		"boss_defeated", "wave_clear":
			if _ok("clear", 1.5):
				burst(_pos(), Color(1.0, 0.85, 0.3), 30)
				shake(5.0)
				toast("\u00a1Bestia vencida!", Color(1.0, 0.85, 0.3))
		"death":
			burst(_pos(), Color(0.8, 0.2, 0.2), 28)
			shake(8.0)
			flash_screen(Color(0.7, 0.0, 0.0, 0.4), 0.35)
			toast("\u00a1Ay! Otra vez...", Color(1.0, 0.5, 0.45))
		"level_complete":
			burst(_pos(), Color(1.0, 0.85, 0.3), 40)
			burst(_pos(), Color(0.6, 0.9, 0.5), 24)
			shake(5.0)
			flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.3)
			toast("\u00a1Rescate en camino!", Color(1.0, 0.9, 0.4))
			play_sound("win", 1.0)


func on_tick(delta: float) -> void:
	_clock += delta
	if _shadow == null or not is_instance_valid(_shadow) or _shadow_owner != player():
		_ready_shadow()
	if _tint != null and is_instance_valid(_tint):
		var k: float = 0.5 + 0.5 * sin(_clock * 0.03)
		var warm: Color = Color(1.0, 0.65, 0.35, 0.07)
		var cold: Color = Color(0.3, 0.4, 0.7, 0.12)
		_tint.color = warm.lerp(cold, k)
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i in range(_motes.size()):
		var m: Polygon2D = _motes[i]
		if not is_instance_valid(m):
			continue
		var v: Vector2 = _mote_vel[i]
		var np: Vector2 = m.position + v * delta
		np.y += sin(_clock * 0.8 + float(i)) * 6.0 * delta
		if np.x < -10.0:
			np.x = size.x + 10.0
		if np.y < -10.0:
			np.y = size.y + 10.0
		if np.y > size.y + 10.0:
			np.y = -10.0
		m.position = np
	if _shadow != null and is_instance_valid(_shadow):
		var s: float = 1.0 + 0.04 * sin(_clock * 3.0)
		_shadow.scale = Vector2(s, s)

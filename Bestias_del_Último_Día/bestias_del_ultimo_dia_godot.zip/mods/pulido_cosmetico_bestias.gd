extends "res://kit/mod_base.gd"

const COL_FUEGO: Color = Color(1.0, 0.6, 0.2)
const COL_ORO: Color = Color(1.0, 0.85, 0.3)
const COL_VERDE: Color = Color(0.5, 0.95, 0.5)
const COL_ROJO: Color = Color(1.0, 0.3, 0.25)
const COL_AZUL: Color = Color(0.5, 0.85, 1.0)

var _t: float = 0.0
var _cool: Dictionary = {}
var _combo: int = 0
var _combo_t: float = 0.0
var _mlayer: CanvasLayer = null
var _motes: Array[ColorRect] = []
var _vels: PackedVector2Array = PackedVector2Array()
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()


func _ready_cool(key: String, secs: float) -> bool:
	var last: float = float(_cool.get(key, -999.0))
	if _t - last < secs:
		return false
	_cool[key] = _t
	return true


func _where(data: Dictionary) -> Vector2:
	var p: Variant = data.get("pos", null)
	if p is Vector2:
		return p as Vector2
	var pl: Node2D = player()
	if pl != null:
		return pl.global_position
	return Vector2.ZERO


func _build_motes() -> void:
	if _mlayer != null and is_instance_valid(_mlayer):
		_mlayer.queue_free()
	_motes.clear()
	_vels = PackedVector2Array()
	_mlayer = CanvasLayer.new()
	_mlayer.layer = 4
	add_child(_mlayer)
	var size: Vector2 = get_viewport().get_visible_rect().size
	_rng.randomize()
	for i in range(18):
		var r: ColorRect = ColorRect.new()
		var s: float = _rng.randf_range(2.0, 4.5)
		r.size = Vector2(s, s)
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var warm: bool = i % 3 != 0
		if warm:
			r.color = Color(1.0, 0.75, 0.4, _rng.randf_range(0.18, 0.4))
		else:
			r.color = Color(0.7, 1.0, 0.7, _rng.randf_range(0.18, 0.35))
		r.position = Vector2(_rng.randf_range(0.0, size.x), _rng.randf_range(0.0, size.y))
		_mlayer.add_child(r)
		_motes.append(r)
		_vels.append(Vector2(_rng.randf_range(-10.0, 10.0), _rng.randf_range(-22.0, -6.0)))


func on_level_start() -> void:
	_combo = 0
	_cool.clear()
	_build_motes()
	var n: int = level() + 1
	var pl: Node2D = player()
	if pl != null:
		burst(pl.global_position, COL_FUEGO, 16)
	flash_screen(Color(1.0, 0.85, 0.6, 0.25), 0.25)
	if n <= 1:
		toast("\u00a1Sobrevive, Marta!", COL_FUEGO)
	else:
		toast("Nivel " + str(n) + ": \u00a1a por ello!", COL_FUEGO)


func on_tick(delta: float) -> void:
	_t += delta
	if _combo > 0:
		_combo_t -= delta
		if _combo_t <= 0.0:
			_combo = 0
	if _motes.is_empty():
		return
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i in range(_motes.size()):
		var m: ColorRect = _motes[i]
		if not is_instance_valid(m):
			continue
		var v: Vector2 = _vels[i]
		var p: Vector2 = m.position + (v + Vector2(sin(_t * 0.8 + float(i)) * 8.0, 0.0)) * delta
		if p.y < -8.0:
			p.y = size.y + 4.0
		if p.x < -8.0:
			p.x = size.x + 4.0
		elif p.x > size.x + 8.0:
			p.x = -4.0
		m.position = p


func _add_combo(at: Vector2) -> void:
	_combo += 1
	_combo_t = 3.0
	if _combo == 4 or _combo == 8 or _combo == 14:
		if _ready_cool("combo", 2.0):
			burst(at, COL_ORO, 22)
			play_sound("coin", 1.3)
			if _combo == 4:
				toast("\u00a1Racha!", COL_ORO)
			elif _combo == 8:
				toast("\u00a1Imparable!", COL_ORO)
			else:
				toast("\u00a1Chatarrera legendaria!", COL_ORO)


func on_event(event_name: String, data: Dictionary) -> void:
	var at: Vector2 = _where(data)
	match event_name:
		"coin", "pickup", "loot", "collect":
			if _ready_cool("coin", 0.12):
				burst(at, COL_ORO, 8)
			_add_combo(at)
			if _ready_cool("coin_toast", 6.0):
				toast("\u00a1Bot\u00edn!", COL_ORO)
		"hit", "stomp", "boss_hit":
			if _ready_cool("hit", 0.15):
				burst(at, COL_FUEGO, 10)
				shake(2.5)
			_add_combo(at)
		"hurt":
			if _ready_cool("hurt", 0.6):
				flash_screen(Color(1.0, 0.1, 0.1, 0.22), 0.18)
				shake(4.0)
				burst(at, COL_ROJO, 10)
		"power":
			burst(at, COL_AZUL, 18)
			flash_screen(Color(0.6, 0.9, 1.0, 0.25), 0.2)
			if _ready_cool("power", 3.0):
				toast("\u00a1Energ\u00eda!", COL_AZUL)
		"checkpoint":
			burst(at, COL_VERDE, 16)
			if _ready_cool("checkpoint", 3.0):
				toast("\u00a1Refugio a salvo!", COL_VERDE)
		"wave_start":
			shake(2.0)
			if _ready_cool("wave_start", 3.0):
				toast("\u00a1Se acercan!", COL_ROJO)
		"wave_clear":
			burst(at, COL_VERDE, 18)
			if _ready_cool("wave_clear", 3.0):
				toast("\u00a1Calma por ahora!", COL_VERDE)
		"boss_spawn":
			shake(7.0)
			flash_screen(Color(1.0, 0.2, 0.1, 0.25), 0.3)
			toast("\u00a1Cuidado, el oso!", COL_ROJO)
		"boss_defeated":
			burst(at, COL_ORO, 40)
			shake(8.0)
			flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.3)
			toast("\u00a1Oso derrotado!", COL_ORO)
		"death":
			flash_screen(Color(0.4, 0.0, 0.0, 0.45), 0.4)
			shake(6.0)
			burst(at, COL_ROJO, 24)
			toast("Ca\u00edste... \u00a1otra vez!", COL_ROJO)
		"level_complete":
			var pl: Node2D = player()
			var wp: Vector2 = at
			if pl != null:
				wp = pl.global_position
			burst(wp, COL_ORO, 50)
			burst(wp, COL_VERDE, 24)
			shake(5.0)
			flash_screen(Color(1.0, 1.0, 0.8, 0.4), 0.35)
			play_sound("coin", 1.2)
			toast("\u00a1Rescatada!", COL_ORO)

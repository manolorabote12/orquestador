extends "res://kit/mod_base.gd"

const MOTE_COUNT: int = 16

var _t: float = 0.0
var _last_fx: Dictionary = {}
var _combo: int = 0
var _combo_t: float = -10.0
var _fx_layer: CanvasLayer = null
var _motes: Array = []
var _speeds: Array = []
var _phases: Array = []


func _ready() -> void:
	pass


func _cooldown(key: String, secs: float) -> bool:
	var last: float = float(_last_fx.get(key, -100.0))
	if _t - last < secs:
		return false
	_last_fx[key] = _t
	return true


func _hero_pos() -> Vector2:
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2(240, 400)


func _clear_motes() -> void:
	for m in _motes:
		if is_instance_valid(m):
			(m as Node).queue_free()
	_motes.clear()
	_speeds.clear()
	_phases.clear()
	if _fx_layer != null and is_instance_valid(_fx_layer):
		_fx_layer.queue_free()
	_fx_layer = null


func _build_ambience() -> void:
	_clear_motes()
	_fx_layer = CanvasLayer.new()
	_fx_layer.layer = 4
	add_child(_fx_layer)
	var size: Vector2 = get_viewport().get_visible_rect().size
	var cols: Array = [
		Color(1.0, 0.85, 0.45, 0.35),
		Color(0.65, 0.95, 0.55, 0.28),
		Color(0.9, 0.95, 1.0, 0.22)
	]
	for i in range(MOTE_COUNT):
		var r: ColorRect = ColorRect.new()
		var s: float = 2.0 + float(i % 3)
		r.size = Vector2(s, s)
		r.color = cols[i % 3] as Color
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.position = Vector2(fmod(float(i) * 97.0, maxf(size.x, 1.0)), fmod(float(i) * 151.0, maxf(size.y, 1.0)))
		_fx_layer.add_child(r)
		_motes.append(r)
		_speeds.append(8.0 + float((i * 7) % 14))
		_phases.append(float(i) * 0.9)
	# vineta suave en los bordes para dar ambiente
	var top: ColorRect = ColorRect.new()
	top.color = Color(0.0, 0.05, 0.1, 0.18)
	top.size = Vector2(size.x, 26.0)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fx_layer.add_child(top)
	var bottom: ColorRect = ColorRect.new()
	bottom.color = Color(0.0, 0.05, 0.1, 0.22)
	bottom.size = Vector2(size.x, 34.0)
	bottom.position = Vector2(0.0, size.y - 34.0)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fx_layer.add_child(bottom)


func on_level_start() -> void:
	_combo = 0
	_combo_t = -10.0
	_build_ambience()
	flash_screen(Color(1.0, 0.9, 0.6, 0.25), 0.3)
	burst(_hero_pos(), Color(1.0, 0.8, 0.3), 16)
	toast("\u00a1Sobrevive y arregla la radio!", Color(1.0, 0.85, 0.35))
	_last_fx["start"] = _t


func on_tick(delta: float) -> void:
	_t += delta
	if _combo > 0 and _t - _combo_t > 3.0:
		_combo = 0
	if _fx_layer == null or not is_instance_valid(_fx_layer):
		return
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i in range(_motes.size()):
		var r: ColorRect = _motes[i] as ColorRect
		if r == null or not is_instance_valid(r):
			continue
		var sp: float = float(_speeds[i])
		var ph: float = float(_phases[i])
		var pos: Vector2 = r.position
		pos.y -= sp * delta
		pos.x += sin(_t * 0.8 + ph) * 12.0 * delta
		if pos.y < -8.0:
			pos.y = size.y + 4.0
		if pos.x < -8.0:
			pos.x = size.x
		elif pos.x > size.x + 8.0:
			pos.x = 0.0
		r.position = pos


func on_event(event_name: String, data: Dictionary) -> void:
	var at: Vector2 = _hero_pos()
	if data.has("pos") and data["pos"] is Vector2:
		at = data["pos"] as Vector2
	match event_name:
		"coin", "pickup", "collect", "loot":
			_combo += 1
			_combo_t = _t
			if _cooldown("coin", 0.12):
				burst(at, Color(1.0, 0.85, 0.2), 8)
				play_sound("coin", minf(1.0 + float(_combo) * 0.04, 1.4))
			if _combo == 3 and _cooldown("combo", 2.0):
				toast("\u00a1Buen saqueo!", Color(1.0, 0.9, 0.3))
			elif _combo == 6 and _cooldown("combo", 2.0):
				toast("\u00a1Racha de chatarra!", Color(1.0, 0.6, 0.2))
				flash_screen(Color(1.0, 0.85, 0.3, 0.2), 0.2)
				shake(3.0)
			elif _combo == 10 and _cooldown("combo", 2.0):
				toast("\u00a1Chatarrera imparable!", Color(1.0, 0.45, 0.2))
				burst(at, Color(1.0, 0.7, 0.2), 24)
				shake(4.0)
		"hit", "stomp":
			if _cooldown("hit", 0.2):
				burst(at, Color(0.95, 0.95, 0.9), 10)
				shake(2.5)
		"hurt":
			if _cooldown("hurt", 0.8):
				burst(at, Color(0.95, 0.2, 0.2), 12)
				flash_screen(Color(0.9, 0.1, 0.1, 0.22), 0.18)
				shake(5.0)
		"power", "craft", "build":
			if _cooldown("power", 0.8):
				burst(at, Color(0.4, 0.9, 1.0), 14)
				toast("\u00a1Manos a la obra!", Color(0.5, 0.9, 1.0))
		"checkpoint":
			if _cooldown("check", 1.5):
				burst(at, Color(0.5, 1.0, 0.6), 14)
				toast("\u00a1Refugio listo!", Color(0.5, 1.0, 0.6))
		"boss_spawn":
			if _cooldown("boss", 2.0):
				toast("\u00a1Llega el oso!", Color(1.0, 0.35, 0.25))
				flash_screen(Color(0.8, 0.1, 0.05, 0.25), 0.3)
				shake(8.0)
		"boss_hit":
			if _cooldown("bosshit", 0.25):
				burst(at, Color(1.0, 0.6, 0.2), 12)
				shake(3.5)
		"boss_defeated":
			toast("\u00a1Oso fuera de combate!", Color(1.0, 0.85, 0.3))
			burst(at, Color(1.0, 0.8, 0.2), 40)
			flash_screen(Color(1.0, 0.95, 0.7, 0.4), 0.3)
			shake(9.0)
		"wave_start":
			if _cooldown("wave", 2.0):
				toast("\u00a1Se acercan las bestias!", Color(1.0, 0.5, 0.3))
				shake(3.0)
		"wave_clear":
			if _cooldown("waveclear", 2.0):
				toast("\u00a1Noche superada!", Color(0.6, 1.0, 0.6))
				burst(at, Color(0.6, 1.0, 0.5), 20)
		"death":
			if _cooldown("death", 1.0):
				burst(at, Color(0.9, 0.15, 0.15), 24)
				flash_screen(Color(0.6, 0.0, 0.0, 0.35), 0.3)
				shake(8.0)
				toast("\u00a1Levanta, Marta!", Color(1.0, 0.5, 0.4))
		"level_complete":
			if _cooldown("win", 2.0):
				burst(at, Color(1.0, 0.85, 0.25), 36)
				burst(at, Color(0.5, 1.0, 0.7), 20)
				flash_screen(Color(1.0, 1.0, 0.8, 0.4), 0.35)
				shake(4.0)
				toast("\u00a1Rescate en camino!", Color(1.0, 0.9, 0.35))
				play_sound("win", 1.0)

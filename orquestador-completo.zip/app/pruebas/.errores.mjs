class ErrorApp extends Error {
}
const SIN_CONEXION = "Sin conexi\xF3n: revisa tu red e int\xE9ntalo de nuevo.";
function esSinConexion(e) {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return true;
  const nombre = e instanceof Error ? e.name : "";
  const texto = e instanceof Error ? e.message : typeof e === "string" ? e : "";
  return nombre === "FunctionsFetchError" || /failed to fetch|networkerror|load failed|network request failed|err_internet_disconnected/i.test(texto);
}
function mensajeError(e, porDefecto) {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return SIN_CONEXION;
  if (e instanceof ErrorApp) return e.message;
  if (esSinConexion(e)) return SIN_CONEXION;
  return porDefecto;
}
function vigilarErrores(avisar, consola = console) {
  const promesa = (ev) => {
    consola.error("[orquestador] promesa sin atender:", ev.reason);
    avisar(mensajeError(ev.reason, "Algo ha fallado. Int\xE9ntalo de nuevo."));
  };
  const codigo = (ev) => {
    if (!(ev.error instanceof Error)) return;
    consola.error("[orquestador] error:", ev.error);
    avisar(mensajeError(ev.error, "Algo ha fallado. Si se repite, cierra y vuelve a abrir la app."));
  };
  window.addEventListener("unhandledrejection", promesa);
  window.addEventListener("error", codigo);
  return () => {
    window.removeEventListener("unhandledrejection", promesa);
    window.removeEventListener("error", codigo);
  };
}
export {
  ErrorApp,
  SIN_CONEXION,
  esSinConexion,
  mensajeError,
  vigilarErrores
};

const MIN_INTENTOS = 15;
const pc = (x) => `${Math.round(x * 100)} %`;
function diagnosticar(filas, nombres) {
  if (!filas.length) return { version: null, niveles: [], consejos: [], suficiente: false, jugadores: 0 };
  const version = Math.max(...filas.map((f) => f.version));
  const deVersion = filas.filter((f) => f.version === version).sort((a, b) => a.nivel - b.nivel);
  const primero = deVersion.find((f) => f.nivel === 0);
  const niveles = deVersion.map((f) => ({
    nivel: f.nivel,
    nombre: nombres[f.nivel] ?? `Nivel ${f.nivel + 1}`,
    intentos: f.intentos,
    jugadores: f.sesiones,
    victoria: f.intentos ? f.ganados / f.intentos : 0,
    abandono: f.intentos ? f.salidas / f.intentos : 0,
    muertes: Number(f.muertes_medias),
    segundos: Number(f.segundos_medios),
    estrellas: f.estrellas_medias === null ? null : Number(f.estrellas_medias),
    llegan: primero && primero.sesiones ? f.sesiones / primero.sesiones : null
  }));
  const consejos = [];
  const total = nombres.length || niveles.length;
  for (const n of niveles) {
    if (n.intentos < MIN_INTENTOS) continue;
    const ultimo = n.nivel === total - 1;
    const etiqueta = `el nivel ${n.nivel + 1} (${n.nombre})`;
    if (n.abandono > 0.4 && n.victoria < 0.5) {
      consejos.push({
        nivel: n.nivel,
        tipo: "abandono",
        texto: `En ${etiqueta} se rinde mucha gente: lo deja a medias el ${pc(n.abandono)} y solo lo pasa el ${pc(n.victoria)}.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s f\xE1cil, que la gente lo abandona`
      });
    } else if (n.victoria < (ultimo ? 0.25 : 0.35) && n.muertes >= 2) {
      consejos.push({
        nivel: n.nivel,
        tipo: "dificil",
        texto: `${cap(etiqueta)} es demasiado dif\xEDcil: solo lo pasa el ${pc(n.victoria)} y se muere ${n.muertes.toFixed(1)} veces de media.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s f\xE1cil`
      });
    } else if (n.nivel > 0 && !ultimo && n.victoria > 0.95 && n.muertes < 0.2) {
      consejos.push({
        nivel: n.nivel,
        tipo: "facil",
        texto: `${cap(etiqueta)} no supone ning\xFAn reto: lo pasa el ${pc(n.victoria)} sin morir casi nunca.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s dif\xEDcil`
      });
    }
  }
  for (let i = 1; i < niveles.length; i++) {
    const a = niveles[i - 1];
    const b = niveles[i];
    if (a.jugadores >= MIN_INTENTOS && b.nivel === a.nivel + 1 && b.jugadores / a.jugadores < 0.4 && !consejos.some((c) => c.nivel === a.nivel)) {
      consejos.push({
        nivel: a.nivel,
        tipo: "embudo",
        texto: `Del nivel ${a.nivel + 1} al ${b.nivel + 1} solo sigue el ${pc(b.jugadores / a.jugadores)} de la gente.`,
        instruccion: `Rehaz el nivel ${a.nivel + 1} m\xE1s f\xE1cil`
      });
    }
  }
  const conDatos = niveles.filter((n) => n.intentos >= MIN_INTENTOS);
  const dificiles = consejos.filter((c) => c.tipo === "dificil" || c.tipo === "abandono").length;
  if (conDatos.length >= 3 && dificiles >= Math.ceil(conDatos.length * 0.6)) {
    consejos.unshift({
      nivel: null,
      tipo: "general",
      texto: "Casi todos los niveles se le atragantan a la gente.",
      instruccion: "Hazlo m\xE1s f\xE1cil"
    });
  }
  const orden = { general: 0, abandono: 1, dificil: 2, embudo: 3, facil: 4 };
  consejos.sort((a, b) => orden[a.tipo] - orden[b.tipo] || (a.nivel ?? -1) - (b.nivel ?? -1));
  const jugadores = primero?.sesiones ?? Math.max(0, ...niveles.map((n) => n.jugadores));
  return { version, niveles, consejos, suficiente: conDatos.length > 0, jugadores };
}
function cap(t) {
  return t.charAt(0).toUpperCase() + t.slice(1);
}
export {
  MIN_INTENTOS,
  diagnosticar
};

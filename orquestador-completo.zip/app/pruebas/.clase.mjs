const ATASCO = 5;
function atasco(a, totalNiveles) {
  const n = a.nivel_actual ?? 0, i = a.intentos ?? 0;
  if (n < 1 || i < ATASCO || totalNiveles > 0 && a.niveles >= totalNiveles) return "";
  return `Atascado en el nivel ${n} (${i} intentos)`;
}
function mensajeClase(m) {
  if (m.includes("bad_name")) return "Ponle a la clase un nombre de 1 a 40 letras (por ejemplo, 3\xBA B).";
  if (m.includes("too_many")) return "Ya tienes 10 clases en este juego: cierra alguna.";
  return "No se pudo crear la clase.";
}
function haceCuanto(iso, ahora = /* @__PURE__ */ new Date()) {
  const min = Math.max(0, Math.floor((ahora.getTime() - Date.parse(iso)) / 6e4));
  if (min < 60) return `hace ${min} min`;
  if (min < 1440) return `hace ${Math.floor(min / 60)} h`;
  return `hace ${Math.floor(min / 1440)} d\xEDas`;
}
function resumenClase(c, totalNiveles) {
  const n = c.alumnos.length;
  if (!n) return "A\xFAn no se ha unido nadie.";
  const media = c.alumnos.reduce((s, a) => s + a.niveles, 0) / n;
  const todo = totalNiveles > 0 ? c.alumnos.filter((a) => a.niveles >= totalNiveles).length : 0;
  const atascados = c.alumnos.filter((a) => atasco(a, totalNiveles)).length;
  return `${n} alumno${n === 1 ? "" : "s"} \xB7 media ${media.toFixed(1)} niveles` + (totalNiveles > 0 ? ` \xB7 ${todo} lo han terminado` : "") + (atascados ? ` \xB7 ${atascados} atascado${atascados === 1 ? "" : "s"}` : "");
}
function csvClase(c) {
  const filas = [
    ["Alumno", "Niveles", "Estrellas", "Minutos", "Nivel actual", "Intentos en \xE9l", "\xDAltima vez"],
    ...c.alumnos.map((a) => [a.alias, String(a.niveles), String(a.estrellas), String(a.minutos), String(a.nivel_actual ?? ""), String(a.intentos ?? ""), a.visto.slice(0, 10)])
  ];
  return filas.map((f) => f.map((x) => /[",;\n]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x).join(";")).join("\n");
}
export {
  ATASCO,
  atasco,
  csvClase,
  haceCuanto,
  mensajeClase,
  resumenClase
};

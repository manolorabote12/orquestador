function plano(s) {
  return s.toLowerCase().replace(/ñ/g, "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\u0001/g, "\xF1");
}
const FAMILIAS = {
  cartas: ["solitario", "cartas", "cartas_locas", "mazo", "domino"],
  mesa: ["ajedrez", "damas", "reversi", "conecta", "parchis", "domino", "flota", "billar"],
  coches: ["carreras", "karts", "conduccion", "aparcamiento", "autobus", "cruzar"],
  palabras: ["sopa", "palabra", "letras", "ahorcado", "preguntas"],
  ni\u00F1os: ["memoria", "pintar", "topos", "simon", "ahorcado", "burbujas", "buscar"],
  puzle: ["puzle", "rompecabezas", "deslizar", "tuberias", "flechas", "numeros", "sudoku", "nonograma", "bloques", "bloques_colores", "tubos", "tornillos", "hexas", "cajas", "laberinto", "diferencias", "buscar"],
  disparos: ["naves", "horda", "arena", "zombis", "arco", "royale", "torres", "arquero"],
  deportes: ["futbol", "penaltis", "baloncesto", "canasta", "tenis", "golf", "bolos", "billar"],
  relax: ["granja", "pesca", "cocina", "pintar", "tuberias", "buscar", "clicker", "tienda"]
};
function encaja(t, consulta) {
  const q = plano(consulta).trim();
  if (!q) return true;
  const fams = Object.entries(FAMILIAS).filter(([, ids]) => ids.includes(t.id)).map(([f]) => f);
  const texto = plano([t.nombre, t.que, t.id.replace(/_/g, " "), ...fams].join(" "));
  return q.split(/\s+/).every((p) => texto.includes(p) || p.length > 3 && p.endsWith("s") && texto.includes(p.slice(0, -1)));
}
function nuevos(ids, cuantos = 8) {
  return new Set(ids.slice(-cuantos));
}
export {
  FAMILIAS,
  encaja,
  nuevos,
  plano
};

const USOS = [
  {
    id: "publicar",
    nombre: "Para publicar",
    ejemplo: "Ej.: un gato ninja r\xE1pido que salta por tejados de noche y aplasta ratas robot",
    chispa: "\xA1Hola! Soy Chispa. Cu\xE9ntame tu juego: qui\xE9n es el h\xE9roe, d\xF3nde salta y contra qu\xE9.",
    consejo: "\xBFY ahora? Pru\xE9balo y, cuando te guste, en su ficha tienes el camino a Google Play paso a paso: anuncios, subida, probadores y producci\xF3n.",
    boton: "Ver el camino a Google Play",
    pestana: "publicar",
    seccion: ""
  },
  {
    id: "negocio",
    nombre: "Para mi negocio",
    ejemplo: "Ej.: un panadero que atrapa barras de pan al vuelo en una panader\xEDa de pueblo, con los colores de mi tienda",
    chispa: "Un juego para tu negocio: cu\xE9ntame qu\xE9 vendes y c\xF3mo es tu tienda. Al acabar, pones un premio real para quien supere un nivel.",
    consejo: "\xBFY ahora? Ponle un premio de verdad (un descuento, un caf\xE9 gratis) para quien supere un nivel: cada jugador recibe su c\xF3digo para canjearlo en tu tienda.",
    boton: "Poner el premio de mi negocio",
    pestana: "jugadores",
    seccion: "premio"
  },
  {
    id: "regalo",
    nombre: "Para regalar",
    ejemplo: "Ej.: Luc\xEDa, que adora los gatos y la playa, recoge conchas esquivando cangrejos",
    chispa: "Un juego regalo: cu\xE9ntame para qui\xE9n es y qu\xE9 le gusta. Al acabar, escribes tu mensaje secreto y se lo mandas con un enlace privado.",
    consejo: "\xBFY ahora? Escribe tu mensaje secreto (aparece al superar el nivel que elijas) y m\xE1ndale el enlace privado.",
    boton: "Escribir la dedicatoria",
    pestana: "compartir",
    seccion: "regalo"
  },
  {
    id: "clase",
    nombre: "Para mi clase",
    ejemplo: "Ej.: preguntas de las tablas de multiplicar con un cohete que sube a la Luna en cada acierto",
    chispa: "Un juego para tu clase: cu\xE9ntame qu\xE9 tienen que aprender (tablas, vocabulario, capitales...). Al acabar, creas la clase y ves c\xF3mo va cada alumno.",
    consejo: "\xBFY ahora? Crea la clase y dicta el c\xF3digo: cada alumno lo escribe en el juego y t\xFA ves sus niveles, estrellas y minutos.",
    boton: "Crear la clase",
    pestana: "jugadores",
    seccion: "clase"
  }
];
function infoUso(id) {
  return USOS.find((u) => u.id === id) ?? USOS[0];
}
export {
  USOS,
  infoUso
};

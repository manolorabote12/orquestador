const ETIQUETAS = {
  plataformas: ["#plataformas", "#pixelart"],
  runner: ["#runner", "#endlessrunner"],
  volador: ["#arcade", "#onetap"],
  horda: ["#survivor", "#roguelite"],
  puzle: ["#match3", "#puzzle"],
  torres: ["#towerdefense", "#estrategia"],
  carreras: ["#carreras", "#racing"],
  naves: ["#shootemup", "#arcade"],
  rompebloques: ["#breakout", "#arcade"],
  bloques: ["#blockpuzzle", "#puzzle"],
  cajas: ["#sokoban", "#puzzle"],
  serpiente: ["#snake", "#retro"],
  memoria: ["#memoria", "#juegosparani\xF1os"],
  preguntas: ["#trivia", "#quiz"],
  apilar: ["#stack", "#hypercasual"],
  topos: ["#whackamole", "#arcade"],
  corredor: ["#runner3d", "#subway"],
  arena: ["#battle", "#online"],
  aldea: ["#estrategia", "#clanes"],
  ritmo: ["#ritmo", "#musica"],
  clicker: ["#idle", "#clicker"],
  cartas: ["#solitario", "#cartas"],
  rpg: ["#rpg", "#turnos"],
  laberinto: ["#laberinto", "#puzzle"],
  golf: ["#minigolf", "#relax"],
  pesca: ["#pesca", "#relax"],
  fusion: ["#merge", "#2048"],
  tubos: ["#watersort", "#puzzle"],
  burbujas: ["#bubbleshooter", "#arcade"],
  imperio: ["#estrategia", "#rts"],
  minas: ["#idle", "#idleminer"],
  mazmorras: ["#rpg", "#roguelike"],
  granja: ["#cozygames", "#farming"],
  mazo: ["#deckbuilder", "#cardgame"],
  aventura: ["#visualnovel", "#historias"],
  cocina: ["#cookinggame", "#juegosdecocina"],
  mahjong: ["#mahjong", "#puzzle"],
  aparcamiento: ["#parkingjam", "#puzzle"],
  sopa: ["#wordsearch", "#sopadeletras"],
  sudoku: ["#sudoku", "#puzzle"],
  nonograma: ["#nonogram", "#picross"],
  cortar: ["#fruitninja", "#arcade"],
  penaltis: ["#penalty", "#football"],
  agujero: ["#holeio", "#arcade"],
  ciudad: ["#citybuilder", "#simulation"],
  espiral: ["#helixjump", "#arcade"],
  canasta: ["#basketball", "#sports"],
  buscaminas: ["#minesweeper", "#puzzle"],
  conecta: ["#connect4", "#boardgames"],
  damas: ["#checkers", "#boardgames"],
  billar: ["#8ballpool", "#billiards"],
  solitario: ["#solitaire", "#cardgames"],
  parchis: ["#ludo", "#boardgames"],
  caida: ["#blockpuzzle", "#retrogaming"],
  bolos: ["#bowling", "#sports"],
  mundo: ["#sandbox", "#survivalgame"],
  royale: ["#battleroyale", "#mobilegaming"],
  arco: ["#archery", "#sportsgame"],
  cubos: ["#voxel", "#sandbox3d"],
  parkour: ["#obby", "#parkour"],
  tienda: ["#supermarketsimulator", "#idlegame"],
  futbol: ["#football", "#futbol"],
  terror: ["#horrorgame", "#scary"],
  conduccion: ["#drivinggame", "#delivery"],
  zombis: ["#zombiegame", "#fpsgame"],
  baloncesto: ["#streetball", "#basketball"],
  tenis: ["#tennis", "#tenis"],
  karts: ["#kartracing", "#drift"],
  cruzar: ["#crossyroad", "#arcade"],
  saltos: ["#doodlejump", "#arcade"]
};
function planRedes(d) {
  const t = d.titulo.trim();
  const tipo = (d.generoNombre ?? d.genero ?? "juego").toLowerCase();
  const enlace = d.tienda ?? d.jugar ?? "";
  const donde = d.tienda ? "Gratis en Google Play" : d.jugar ? "Ju\xE9galo gratis en el navegador" : "Muy pronto en Google Play";
  const cierre = enlace ? `${donde}: ${enlace}` : donde;
  const tags = ["#indiegame", "#gamedev", ...ETIQUETAS[d.genero ?? ""] ?? ["#juegosmoviles"]].join(" ");
  const giro = d.giros?.length ? d.giros[0] : "";
  const niveles = d.niveles && d.niveles > 1 ? `${d.niveles} niveles` : "niveles";
  const recortar = (s) => s.length <= 300 ? s : s.slice(0, 297).replace(/\s+\S*$/, "") + "\u2026";
  const dias = [
    {
      dia: 1,
      objetivo: "Presentarlo",
      idea: "El clip vertical de 15 s (pesta\xF1a Compartir \u2192 Hacer v\xEDdeos).",
      texto: `Os presento \xAB${t}\xBB, mi nuevo ${tipo} \u{1F3AE} ${giro ? `Con un giro: ${giro.toLowerCase()}. ` : ""}${cierre} ${tags}`
    },
    {
      dia: 2,
      objetivo: "Ense\xF1ar c\xF3mo se juega",
      idea: "Graba la pantalla jugando el primer nivel, sin cortes.",
      texto: `As\xED se juega a \xAB${t}\xBB: lo aprendes en 5 segundos y luego no hay quien pare \u{1F605} ${cierre} ${tags}`
    },
    {
      dia: 3,
      objetivo: "Retar",
      idea: "Graba tu mejor partida del nivel m\xE1s dif\xEDcil y para justo antes del final.",
      texto: `Reto: \xBFqui\xE9n se pasa el \xFAltimo nivel de \xAB${t}\xBB a la primera? Yo no pude \u{1F643} Deja tu r\xE9cord en comentarios. ${cierre} ${tags}`
    },
    {
      dia: 4,
      objetivo: "Contar c\xF3mo lo hiciste",
      idea: "Muestra la app Orquestador escribiendo la idea y el juego saliendo.",
      texto: `Hice \xAB${t}\xBB describiendo la idea con mis palabras y en minutos ten\xEDa ${niveles} probados. \xBFQu\xE9 juego har\xEDas t\xFA? ${tags} #ia`
    },
    {
      dia: 5,
      objetivo: "Momento \xE9pico",
      idea: "El instante m\xE1s dif\xEDcil o divertido: un salto al l\xEDmite, un combo, un fallo absurdo.",
      texto: `Ese momento en \xAB${t}\xBB en el que todo sale bien\u2026 o todo sale mal \u{1F602} ${cierre} ${tags}`
    },
    {
      dia: 6,
      objetivo: "Pedir opini\xF3n",
      idea: "Una captura del juego y una pregunta directa.",
      texto: `Estoy mejorando \xAB${t}\xBB: \xBFqu\xE9 le a\xF1adir\xEDas? Leo todos los comentarios y lo mejor entra en la pr\xF3xima versi\xF3n \u{1F64C} ${tags}`
    },
    {
      dia: 7,
      objetivo: "Lanzamiento",
      idea: "Repite el clip del d\xEDa 1 con el resultado de la semana (partidas, comentarios).",
      texto: `Una semana de \xAB${t}\xBB y gracias a vosotros ya tiene mejoras. Si a\xFAn no lo has probado, es ahora \u{1F447} ${cierre} ${tags}`
    }
  ];
  if (d.idioma === "en") return planEn(d, t, enlace, tags.replace("#juegosmoviles", "#mobilegames"), giro, recortar);
  return dias.map((x) => ({ ...x, texto: recortar(x.texto) }));
}
function planEn(d, t, enlace, tags, giro, recortar) {
  const donde = d.tienda ? "Free on Google Play" : d.jugar ? "Play it free in your browser" : "Coming soon to Google Play";
  const cierre = enlace ? `${donde}: ${enlace}` : donde;
  const niveles = d.niveles && d.niveles > 1 ? `${d.niveles} levels` : "levels";
  const dias = [
    {
      dia: 1,
      objetivo: "Introduce it",
      idea: "The 15-second vertical clip (Share tab \u2192 Make videos).",
      texto: `Meet \xAB${t}\xBB, my new game \u{1F3AE} ${giro ? `With a twist: ${giro.toLowerCase()}. ` : ""}${cierre} ${tags}`
    },
    {
      dia: 2,
      objetivo: "Show how to play",
      idea: "Record the screen playing the first level, no cuts.",
      texto: `This is how you play \xAB${t}\xBB: you learn it in 5 seconds and then you can't stop \u{1F605} ${cierre} ${tags}`
    },
    {
      dia: 3,
      objetivo: "Challenge",
      idea: "Record your best run of the hardest level and stop just before the end.",
      texto: `Challenge: who can beat the last level of \xAB${t}\xBB on the first try? I couldn't \u{1F643} Drop your record in the comments. ${cierre} ${tags}`
    },
    {
      dia: 4,
      objetivo: "Tell how you made it",
      idea: "Show the Orquestador app writing the idea and the game coming out.",
      texto: `I made \xAB${t}\xBB by describing the idea in my own words and minutes later I had ${niveles} tested. What game would you make? ${tags} #ai`
    },
    {
      dia: 5,
      objetivo: "Epic moment",
      idea: "The hardest or funniest moment: a last-second jump, a combo, a silly fail.",
      texto: `That moment in \xAB${t}\xBB when everything goes right\u2026 or everything goes wrong \u{1F602} ${cierre} ${tags}`
    },
    {
      dia: 6,
      objetivo: "Ask for feedback",
      idea: "A screenshot of the game and a direct question.",
      texto: `I'm improving \xAB${t}\xBB: what would you add? I read every comment and the best ideas make the next version \u{1F64C} ${tags}`
    },
    {
      dia: 7,
      objetivo: "Launch",
      idea: "Repeat the day-1 clip with the week's results (plays, comments).",
      texto: `One week of \xAB${t}\xBB and thanks to you it already has improvements. If you haven't tried it yet, now's the time \u{1F447} ${cierre} ${tags}`
    }
  ];
  return dias.map((x) => ({ ...x, texto: recortar(x.texto) }));
}
export {
  planRedes
};

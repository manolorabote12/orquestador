function quedan(termina, ahora = /* @__PURE__ */ new Date()) {
  const ms = Math.max(0, new Date(termina).getTime() - ahora.getTime());
  const d = Math.floor(ms / 864e5);
  const hrs = Math.floor(ms % 864e5 / 36e5);
  if (d > 0) return `${d} d ${hrs} h`;
  const min = Math.floor(ms % 36e5 / 6e4);
  return hrs > 0 ? `${hrs} h` : `${min} min`;
}
export {
  quedan
};

// src/aprendizaje.ts
var MIN_INTENTOS = 15;
var pc = (x) => `${Math.round(x * 100)} %`;
function diagnosticar(filas, nombres) {
  if (!filas.length) return { version: null, niveles: [], consejos: [], suficiente: false, jugadores: 0 };
  const version = Math.max(...filas.map((f) => f.version));
  const deVersion = filas.filter((f) => f.version === version).sort((a, b) => a.nivel - b.nivel);
  const primero = deVersion.find((f) => f.nivel === 0);
  const niveles = deVersion.map((f) => ({
    nivel: f.nivel,
    nombre: nombres[f.nivel] ?? `Nivel ${f.nivel + 1}`,
    intentos: f.intentos,
    jugadores: f.sesiones,
    victoria: f.intentos ? f.ganados / f.intentos : 0,
    abandono: f.intentos ? f.salidas / f.intentos : 0,
    muertes: Number(f.muertes_medias),
    segundos: Number(f.segundos_medios),
    estrellas: f.estrellas_medias === null ? null : Number(f.estrellas_medias),
    llegan: primero && primero.sesiones ? f.sesiones / primero.sesiones : null
  }));
  const consejos = [];
  const total = nombres.length || niveles.length;
  for (const n of niveles) {
    if (n.intentos < MIN_INTENTOS) continue;
    const ultimo = n.nivel === total - 1;
    const etiqueta = `el nivel ${n.nivel + 1} (${n.nombre})`;
    if (n.abandono > 0.4 && n.victoria < 0.5) {
      consejos.push({
        nivel: n.nivel,
        tipo: "abandono",
        texto: `En ${etiqueta} se rinde mucha gente: lo deja a medias el ${pc(n.abandono)} y solo lo pasa el ${pc(n.victoria)}.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s f\xE1cil, que la gente lo abandona`
      });
    } else if (n.victoria < (ultimo ? 0.25 : 0.35) && n.muertes >= 2) {
      consejos.push({
        nivel: n.nivel,
        tipo: "dificil",
        texto: `${cap(etiqueta)} es demasiado dif\xEDcil: solo lo pasa el ${pc(n.victoria)} y se muere ${n.muertes.toFixed(1)} veces de media.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s f\xE1cil`
      });
    } else if (n.nivel > 0 && !ultimo && n.victoria > 0.95 && n.muertes < 0.2) {
      consejos.push({
        nivel: n.nivel,
        tipo: "facil",
        texto: `${cap(etiqueta)} no supone ning\xFAn reto: lo pasa el ${pc(n.victoria)} sin morir casi nunca.`,
        instruccion: `Rehaz el nivel ${n.nivel + 1} m\xE1s dif\xEDcil`
      });
    }
  }
  for (let i = 1; i < niveles.length; i++) {
    const a = niveles[i - 1];
    const b = niveles[i];
    if (a.jugadores >= MIN_INTENTOS && b.nivel === a.nivel + 1 && b.jugadores / a.jugadores < 0.4 && !consejos.some((c) => c.nivel === a.nivel)) {
      consejos.push({
        nivel: a.nivel,
        tipo: "embudo",
        texto: `Del nivel ${a.nivel + 1} al ${b.nivel + 1} solo sigue el ${pc(b.jugadores / a.jugadores)} de la gente.`,
        instruccion: `Rehaz el nivel ${a.nivel + 1} m\xE1s f\xE1cil`
      });
    }
  }
  const conDatos = niveles.filter((n) => n.intentos >= MIN_INTENTOS);
  const dificiles = consejos.filter((c) => c.tipo === "dificil" || c.tipo === "abandono").length;
  if (conDatos.length >= 3 && dificiles >= Math.ceil(conDatos.length * 0.6)) {
    consejos.unshift({
      nivel: null,
      tipo: "general",
      texto: "Casi todos los niveles se le atragantan a la gente.",
      instruccion: "Hazlo m\xE1s f\xE1cil"
    });
  }
  const orden = { general: 0, abandono: 1, dificil: 2, embudo: 3, facil: 4 };
  consejos.sort((a, b) => orden[a.tipo] - orden[b.tipo] || (a.nivel ?? -1) - (b.nivel ?? -1));
  const jugadores = primero?.sesiones ?? Math.max(0, ...niveles.map((n) => n.jugadores));
  return { version, niveles, consejos, suficiente: conDatos.length > 0, jugadores };
}
function cap(t) {
  return t.charAt(0).toUpperCase() + t.slice(1);
}

// src/asesor.ts
var ONLINE_CLAVE = ["arena", "aldea", "carreras", "corredor"];
var DIARIOS = ["aldea", "clicker", "rpg", "puzle", "cartas", "torres"];
var MIN_JUGADORES = 30;
function aconsejar(d) {
  const ninos = d.publico === "infantil";
  const tiene = (f) => !(ninos && ["tienda", "avisos", "online"].includes(f)) && d.funciones?.[f] !== false;
  const puede = (f) => !ninos || !["tienda", "avisos", "online"].includes(f);
  const out = [];
  const add = (c) => out.push(c);
  const jugadores = d.ingresos?.jugadores_total ?? 0;
  if (!d.publicado) {
    add({
      id: "publicar",
      peso: 100,
      titulo: "Publ\xEDcalo en prueba interna",
      texto: "Sube el juego a Google Play en prueba interna: es gratis, tarda unos minutos y te da el enlace para tus primeros probadores.",
      boton: "Ir a publicar",
      accion: { tipo: "ir", pestana: "publicar" }
    });
    if (!d.anuncios) {
      add({
        id: "anuncios",
        peso: 60,
        titulo: "Activa los anuncios antes de salir",
        texto: "Un juego sin anuncios no gana nada desde el primer d\xEDa. Con premio por ver un anuncio, el jugador elige y no molesta.",
        boton: "Configurar anuncios",
        accion: { tipo: "ir", pestana: "publicar" }
      });
    }
    add({
      id: "video",
      peso: 40,
      titulo: "Prepara un v\xEDdeo corto",
      texto: "Los v\xEDdeos de 15 segundos para TikTok, Reels o Shorts son la forma m\xE1s barata de conseguir los primeros jugadores.",
      boton: "Hacer v\xEDdeos",
      accion: { tipo: "ir", pestana: "compartir" }
    });
  } else if (jugadores < MIN_JUGADORES) {
    add({
      id: "primeros",
      peso: 90,
      titulo: "Consigue tus primeros 30 jugadores",
      texto: `Ahora mismo lo han jugado ${jugadores}. Comparte el enlace, s\xFAbelo al Escaparate y publica un v\xEDdeo: con 30 jugadores ya sabremos qu\xE9 mejorar.`,
      boton: "Compartir",
      accion: { tipo: "ir", pestana: "compartir" }
    });
  }
  if (d.informe?.length) {
    const diag = diagnosticar(d.informe, d.niveles);
    const peor = diag.consejos.find((c) => c.tipo !== "facil") ?? diag.consejos[0];
    if (diag.suficiente && peor) {
      add({
        id: "nivel",
        peso: peor.tipo === "facil" ? 45 : 80,
        titulo: peor.nivel !== null ? `Arregla el nivel ${peor.nivel + 1}` : "Ajusta los niveles",
        texto: peor.texto,
        boton: "Que Chispa lo arregle",
        accion: { tipo: "arreglar", instruccion: peor.instruccion }
      });
      if (peor.nivel !== null && peor.tipo !== "facil" && !d.pruebaAb && jugadores >= 2 * MIN_JUGADORES) {
        add({
          id: "ab",
          peso: 72,
          titulo: "\xBFM\xE1s f\xE1cil o no? Pru\xE9balo con jugadores",
          texto: `Antes de cambiar el nivel ${peor.nivel + 1} para todos, haz una prueba A/B: la mitad juega una versi\xF3n m\xE1s f\xE1cil y los datos dicen cu\xE1l va mejor.`,
          boton: "Preparar la prueba",
          accion: { tipo: "ir", pestana: "jugadores" }
        });
      }
    }
  }
  const hayDatos = jugadores >= MIN_JUGADORES;
  if (hayDatos && d.ingresos?.d1 !== null && d.ingresos?.d1 !== void 0 && d.ingresos.d1 < 25) {
    if (puede("avisos") && !tiene("avisos")) {
      add({
        id: "avisos",
        peso: 75,
        titulo: "Recu\xE9rdales que vuelvan",
        texto: `Solo vuelve el ${d.ingresos.d1} % al d\xEDa siguiente. Enciende los avisos: el juego les recuerda su premio diario (una vez al d\xEDa, nada de spam).`,
        boton: "Encender avisos",
        accion: { tipo: "funcion", op: { op: "funciones", avisos: true } }
      });
    } else if (!tiene("pase") && DIARIOS.includes(d.genero ?? "")) {
      add({
        id: "pase",
        peso: 70,
        titulo: "Dales un motivo para volver",
        texto: `Solo vuelve el ${d.ingresos.d1} % al d\xEDa siguiente. Las misiones diarias y el pase de temporada son lo que m\xE1s hace volver en este tipo de juego.`,
        boton: "Encender misiones y pase",
        accion: { tipo: "funcion", op: { op: "funciones", pase: true } }
      });
    } else {
      add({
        id: "primer_nivel",
        peso: 65,
        titulo: "Engancha en el primer minuto",
        texto: `Solo vuelve el ${d.ingresos.d1} % al d\xEDa siguiente. Suele ser el arranque: un primer nivel m\xE1s corto y vistoso y un premio al terminarlo.`,
        boton: "Que Chispa lo mejore",
        accion: { tipo: "arreglar", instruccion: "Haz el primer nivel m\xE1s corto, f\xE1cil y vistoso, con un premio de monedas al terminarlo, para enganchar en el primer minuto" }
      });
    }
  }
  if (hayDatos && d.ingresos?.d7 !== null && d.ingresos?.d7 !== void 0 && d.ingresos.d7 < 8 && d.eventosProgramados === 0) {
    add({
      id: "evento",
      peso: 55,
      titulo: "Programa un evento de fin de semana",
      texto: `A la semana sigue el ${d.ingresos.d7} %. Un fin de semana de monedas dobles o un regalo trae de vuelta a los que se fueron, sin publicar otra versi\xF3n.`,
      boton: "Programar evento",
      accion: { tipo: "ir", pestana: "jugadores" }
    });
  }
  if (hayDatos && puede("tienda") && !tiene("tienda")) {
    add({
      id: "tienda",
      peso: jugadores >= 100 ? 62 : 35,
      titulo: "Abre la tienda",
      texto: `Ya tienes ${jugadores} jugadores. Una tienda con monedas, pase premium y \xABsin anuncios\xBB es lo que m\xE1s ingresa despu\xE9s de los anuncios.`,
      boton: "Encender tienda",
      accion: { tipo: "funcion", op: { op: "funciones", tienda: true } }
    });
  } else if (jugadores >= 150 && tiene("tienda") && (d.ingresos?.compras ?? 0) === 0 && d.eventosProgramados === 0) {
    add({
      id: "oferta",
      peso: 50,
      titulo: "Nadie ha comprado a\xFAn",
      texto: `Con ${jugadores} jugadores y ninguna compra, un evento de monedas dobles ense\xF1a lo que vale la tienda. Prueba un fin de semana.`,
      boton: "Programar evento",
      accion: { tipo: "ir", pestana: "jugadores" }
    });
  }
  if (puede("online") && !tiene("online") && ONLINE_CLAVE.includes(d.genero ?? "")) {
    add({
      id: "online",
      peso: d.publicado ? 58 : 30,
      titulo: "Este juego brilla online",
      texto: "Las partidas contra gente de verdad, la liga y las clasificaciones son lo que hace durar a este tipo de juego.",
      boton: "Encender online",
      accion: { tipo: "funcion", op: { op: "funciones", online: true } }
    });
  }
  if (hayDatos && !tiene("nube") && (d.ingresos?.d7 ?? 0) >= 15) {
    add({
      id: "nube",
      peso: 30,
      titulo: "Que no pierdan su partida",
      texto: "Tienes jugadores fieles. Con el guardado en la nube se llevan su progreso a otro m\xF3vil en vez de empezar de cero.",
      boton: "Encender nube",
      accion: { tipo: "funcion", op: { op: "funciones", nube: true } }
    });
  }
  return out.sort((a, b) => b.peso - a.peso).slice(0, 3);
}
export {
  MIN_JUGADORES,
  aconsejar
};

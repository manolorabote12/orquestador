function pasosLanzamiento(d) {
  const enPlay = d.play !== null && d.play !== "primer_aab";
  const produccion = enPlay && d.pista === "production";
  const cerrada = enPlay && (d.pista === "alpha" || d.pista === "beta" || produccion);
  return [
    {
      id: "jugar",
      titulo: "Ju\xE9galo t\xFA",
      ayuda: "Pru\xE9balo entero antes de ense\xF1arlo: si algo no te gusta, p\xEDdeselo a Chispa.",
      hecho: d.jugado,
      boton: "Jugar ya",
      accion: "jugar"
    },
    {
      id: "anuncios",
      titulo: d.infantil ? "Anuncios para familias" : "Activa los anuncios",
      ayuda: "Pega tus ids de AdMob para que el juego gane dinero desde el primer d\xEDa (sin ellos se publica sin anuncios).",
      hecho: d.anuncios,
      boton: "Poner anuncios",
      accion: "anuncios"
    },
    {
      id: "preparar",
      titulo: "Prep\xE1ralo para Google Play",
      ayuda: "Chispa hace el .aab firmado, las im\xE1genes, los textos y las respuestas de cada formulario.",
      hecho: d.play !== null,
      boton: "Preparar",
      accion: "preparar"
    },
    {
      id: "subir",
      titulo: "S\xFAbelo a la prueba cerrada",
      ayuda: "Crea el juego en Play Console siguiendo la gu\xEDa y pulsa \xABsubir a prueba cerrada\xBB.",
      hecho: cerrada,
      boton: "Ir a publicar",
      accion: "publicar"
    },
    {
      id: "probadores",
      titulo: "Pide probadores en la Lanzadera",
      ayuda: "Google pide 12 probadores durante 14 d\xEDas a las cuentas nuevas: la comunidad te ayuda.",
      hecho: d.campana !== null || produccion,
      boton: "Ir a la Lanzadera",
      accion: "lanzadera"
    },
    {
      id: "catorce",
      titulo: "12 probadores, 14 d\xEDas",
      ayuda: "Mientras tanto, mejora el juego con sus opiniones: cada versi\xF3n se sube sola.",
      hecho: d.campana === "lista" || produccion,
      boton: "Ver la campa\xF1a",
      accion: "lanzadera"
    },
    {
      id: "produccion",
      titulo: "Pide producci\xF3n y publ\xEDcalo",
      ayuda: "En la Lanzadera tienes las respuestas para Google ya escritas con los datos de tu prueba.",
      hecho: produccion,
      boton: d.campana === "lista" ? "Ver respuestas" : "Ir a publicar",
      accion: d.campana === "lista" ? "lanzadera" : "publicar"
    }
  ];
}
function siguientePaso(pasos) {
  return pasos.find((p) => !p.hecho) ?? null;
}
export {
  pasosLanzamiento,
  siguientePaso
};

function limpiarCodigo(t) {
  return t.replace(/\s+/g, "").toUpperCase();
}
function codigoValido(t) {
  return /^[A-Z0-9]{3,16}-[0-9A-F]{4}$/.test(limpiarCodigo(t));
}
function textoCanje(c) {
  if (c.estado === "ok") return { ok: true, texto: "V\xE1lido: dale el premio. Ya queda marcado como usado." };
  if (c.estado === "ya_usado") {
    const f = c.canjeado_en ? new Date(c.canjeado_en).toLocaleString("es-ES", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
    return { ok: false, texto: `Ya se us\xF3${f ? " el " + f : ""}. No vale otra vez.` };
  }
  return { ok: false, texto: "Ese c\xF3digo no existe en este juego. Revisa que est\xE9 bien escrito." };
}
function mensajePremio(m) {
  if (m.includes("bad_text")) return "El premio no vale: de 3 a 80 letras, sin s\xEDmbolos raros ni palabrotas.";
  if (m.includes("bad_place")) return "La direcci\xF3n no vale: hasta 80 letras, sin s\xEDmbolos raros.";
  if (m.includes("bad_code")) return "El c\xF3digo va de 3 a 16 letras o n\xFAmeros, sin espacios.";
  if (m.includes("bad_level")) return "El nivel va del 1 al 50.";
  if (m.includes("bad_web")) return "La web tiene que empezar por https://";
  if (m.includes("bad_date")) return "La fecha de caducidad ya ha pasado.";
  return "No se pudo guardar el premio.";
}
function validarPremio(p, hoy = /* @__PURE__ */ new Date()) {
  const texto = p.texto.trim();
  if (texto.length < 3 || texto.length > 80 || /[<>{}\\]/.test(texto)) return mensajePremio("bad_text");
  if (p.donde.trim().length > 80 || /[<>{}\\]/.test(p.donde)) return mensajePremio("bad_place");
  if (!/^[A-Z0-9]{3,16}$/.test(p.codigo.trim().toUpperCase())) return mensajePremio("bad_code");
  if (!Number.isInteger(p.tras_nivel) || p.tras_nivel < 1 || p.tras_nivel > 50) return mensajePremio("bad_level");
  const web = p.web.trim();
  if (web !== "" && !/^https:\/\/[^ <>"]{4,200}$/.test(web)) return mensajePremio("bad_web");
  if (p.caduca && p.caduca < hoy.toISOString().slice(0, 10)) return mensajePremio("bad_date");
  return "";
}
const IDEAS_PREMIO = [
  { negocio: "Cafeter\xEDa o panader\xEDa", texto: "Caf\xE9 gratis con tu desayuno", codigo: "CAFE", nivel: 3 },
  { negocio: "Tienda", texto: "10 % de descuento en tu pr\xF3xima compra", codigo: "JUEGO10", nivel: 5 },
  { negocio: "Restaurante", texto: "Postre gratis en tu pr\xF3xima comida", codigo: "POSTRE", nivel: 5 },
  { negocio: "Peluquer\xEDa o est\xE9tica", texto: "5 \u20AC de descuento en tu pr\xF3xima cita", codigo: "CITA5", nivel: 4 },
  { negocio: "Gimnasio o academia", texto: "Una clase de prueba gratis", codigo: "PRUEBA", nivel: 3 },
  { negocio: "Tienda online", texto: "Env\xEDo gratis en tu pr\xF3ximo pedido", codigo: "ENVIO", nivel: 5 }
];
function resumenPremio(p) {
  if (!p) return "Sin premio. Los jugadores no ven nada.";
  const hasta = p.caduca ? ` \xB7 hasta el ${p.caduca.split("-").reverse().join("/")}` : "";
  return `Al superar el nivel ${p.tras_nivel}: \xAB${p.texto}\xBB \xB7 c\xF3digo ${p.codigo}-XXXX${hasta} \xB7 ganado ${p.ganados ?? 0} veces \xB7 canjeado ${p.canjeados ?? 0}`;
}
export {
  IDEAS_PREMIO,
  codigoValido,
  limpiarCodigo,
  mensajePremio,
  resumenPremio,
  textoCanje,
  validarPremio
};

const NOMBRE_MERCADO = {
  espana: "Espa\xF1a y Europa",
  latam: "Latinoam\xE9rica",
  tier1: "EE. UU., Reino Unido y norte de Europa",
  mundo: "Todo el mundo"
};
const ECPM = {
  inter: { tier1: 9, espana: 5, latam: 1.6, mundo: 3 },
  bonif: { tier1: 14, espana: 8, latam: 2.5, mundo: 5 }
};
const IAP_DIA = { corto: 4e-3, largo: 0.012, idle: 0.01 };
const IAP_MERCADO = { tier1: 1.6, espana: 1, latam: 0.35, mundo: 0.6 };
const USO = {
  corto: { sesiones: 1.6, minutos: 6, nivel: 75, bonif: 0.6 },
  largo: { sesiones: 1.4, minutos: 11, nivel: 180, bonif: 1 },
  idle: { sesiones: 3, minutos: 4, nivel: 300, bonif: 2.5 }
};
const GRACIA = 60, ESPERA = 90, MAX_SESION = 6;
const RELLENO = 0.9;
const VISTO = 0.7;
const IDLE = /* @__PURE__ */ new Set(["clicker", "minas", "tycoon", "imperio", "ciudad", "reino", "granja", "aldea", "tienda", "tragaperras", "pedidos"]);
const LARGO = /* @__PURE__ */ new Set(["rpg", "mazmorras", "mazo", "aventura", "supervivencia", "mundo", "royale", "duelo", "arena", "conduccion", "terror", "a_medida"]);
function tipoDeGenero(genero) {
  const g = genero ?? "";
  return IDLE.has(g) ? "idle" : LARGO.has(g) ? "largo" : "corto";
}
function retencion(d1, d7, t) {
  if (t <= 0) return 1;
  const r1 = Math.min(0.95, Math.max(0.01, d1 / 100));
  const r7 = Math.min(r1, Math.max(2e-3, d7 / 100));
  const b = Math.log(r1 / r7) / Math.log(7);
  return r1 * Math.pow(t, -b);
}
function redondeo(n) {
  return Math.round(n * 100) / 100;
}
function estimar(e) {
  const descargas = Math.max(0, e.descargasDia);
  let vida = 0;
  for (let t = 0; t < 30; t++) vida += retencion(e.d1, e.d7, t);
  const jugadores = descargas * vida;
  const u = USO[e.tipo];
  const porSesion = Math.max(0, Math.min(MAX_SESION, Math.floor((u.minutos * 60 - GRACIA) / Math.max(ESPERA, u.nivel)) + 1));
  const conAnuncios = e.anuncios !== false;
  const inter = conAnuncios ? u.sesiones * porSesion : 0;
  const bonif = conAnuncios ? u.bonif : 0;
  const ninos = e.infantil ? 0.45 : 1;
  const anuncioDia = (inter * ECPM.inter[e.mercado] + bonif * ECPM.bonif[e.mercado]) / 1e3 * RELLENO * VISTO * ninos;
  const anunciosMes = jugadores * anuncioDia * 30;
  const tiendaMes = e.tienda && !e.infantil ? jugadores * IAP_DIA[e.tipo] * IAP_MERCADO[e.mercado] * 30 * 0.85 : 0;
  const med = anunciosMes + tiendaMes;
  const porDescarga = vida * (anuncioDia + (e.tienda && !e.infantil ? IAP_DIA[e.tipo] * IAP_MERCADO[e.mercado] * 0.85 : 0));
  const porDescargaDiaMes = descargas > 0 ? med / descargas : porDescarga * 30;
  return {
    jugadoresDia: Math.round(jugadores),
    intersticialesDia: redondeo(inter),
    bonificadosDia: redondeo(bonif),
    anunciosMes: { min: redondeo(anunciosMes * 0.5), med: redondeo(anunciosMes), max: redondeo(anunciosMes * 1.6) },
    tiendaMes: { min: redondeo(tiendaMes * 0.4), med: redondeo(tiendaMes), max: redondeo(tiendaMes * 2) },
    totalMes: { min: redondeo(anunciosMes * 0.5 + tiendaMes * 0.4), med: redondeo(med), max: redondeo(anunciosMes * 1.6 + tiendaMes * 2) },
    porDescarga: Math.round(porDescarga * 1e4) / 1e4,
    descargasPara100: porDescargaDiaMes > 0 ? Math.ceil(100 / porDescargaDiaMes) : Infinity
  };
}
function consejosGanancias(e, g) {
  const out = [];
  if (e.anuncios === false) out.push("Sin anuncios activados el juego no gana nada con la publicidad: act\xEDvalos en \xABAnuncios\xBB.");
  if (e.d1 < 25) out.push(`Solo vuelve el ${Math.round(e.d1)} % al d\xEDa siguiente: mejorar el primer nivel y encender los avisos sube m\xE1s los ingresos que conseguir descargas.`);
  else if (e.d7 < 8) out.push("Mucha gente lo deja en la primera semana: un evento o un reto semanal hace que vuelvan.");
  if (e.mercado === "latam") out.push("En Latinoam\xE9rica los anuncios pagan menos: traducir el juego al ingl\xE9s abre mercados que pagan de 3 a 5 veces m\xE1s.");
  if (!e.tienda && !e.infantil && e.anuncios !== false) out.push("Con la tienda (quitar anuncios, monedas) suele sumarse otro 10-40 %.");
  if (Number.isFinite(g.descargasPara100)) out.push(`Para unos 100 \u20AC al mes har\xEDan falta unas ${g.descargasPara100.toLocaleString("es-ES")} descargas al d\xEDa.`);
  return out.slice(0, 3);
}
export {
  NOMBRE_MERCADO,
  consejosGanancias,
  estimar,
  retencion,
  tipoDeGenero
};

function proyeccion(c, hoy = /* @__PURE__ */ new Date()) {
  const vivos = c.probadores.filter((p) => p.estado !== "abandonado").map((p) => p.estado === "completado" ? c.dias : Math.min(p.dias, c.dias)).sort((a, b) => b - a);
  const faltan = Math.max(0, c.objetivo - vivos.length);
  if (c.estado === "lista") return { riesgo: false, faltan: 0, dias_restantes: 0, fecha: fechaISO(hoy) };
  if (faltan > 0) return { riesgo: true, faltan, dias_restantes: c.dias, fecha: null };
  const peor = vivos[c.objetivo - 1];
  const dias = Math.max(0, c.dias - peor);
  const f = new Date(hoy.getTime() + dias * 864e5);
  return { riesgo: false, faltan: 0, dias_restantes: dias, fecha: fechaISO(f) };
}
function fechaISO(d) {
  return d.toISOString().slice(0, 10);
}
function textoRacha(dias, objetivo) {
  if (dias <= 0) return "Empieza hoy tu racha";
  if (dias >= objetivo) return `Racha completa: ${objetivo} d\xEDas`;
  const quedan = objetivo - dias;
  return `Racha de ${dias} d\xEDa${dias === 1 ? "" : "s"} \xB7 ${quedan === 1 ? "queda 1" : `quedan ${quedan}`}`;
}
function temas(opiniones, max = 4) {
  const vacias = new Set("el la los las un una unos unas de del al a en y o que es muy mas m\xE1s pero me mi se lo le les con por para no si s\xED ya hay esta est\xE1 este esto eso como cuando todo toda nivel juego juegos the and to of it is".split(" "));
  const cuenta = /* @__PURE__ */ new Map();
  for (const o of opiniones) {
    const vistas = /* @__PURE__ */ new Set();
    for (const w of o.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").match(/[a-zñ]{4,}/g) ?? []) {
      if (vacias.has(w) || vistas.has(w)) continue;
      vistas.add(w);
      cuenta.set(w, (cuenta.get(w) ?? 0) + 1);
    }
  }
  return [...cuenta.entries()].filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, max).map(([w]) => w);
}
function respuestasProduccion(c, j) {
  const total = c.probadores.length;
  const cumplidos = c.completados;
  const ops = c.opiniones.map((o) => o.opinion.trim()).filter(Boolean);
  const citas = [...ops].sort((a, b) => b.length - a.length).slice(0, 3);
  const tem = temas(ops);
  const cambios = j.cambios.map((x) => x.trim()).filter(Boolean).slice(0, 5);
  const nivelTxt = c.nivel_medio ? ` Llegaron de media al nivel ${String(c.nivel_medio).replace(".", ",")}${c.nivel_max ? ` (el que m\xE1s, al ${c.nivel_max})` : ""}.` : "";
  const checkTxt = c.checkins ? ` En total registraron ${c.checkins} d\xEDas de juego.` : "";
  return [
    {
      pregunta: "\xBFC\xF3mo has reclutado a los usuarios para la prueba cerrada?",
      respuesta: `Mediante la Lanzadera de Orquestador, una comunidad de creadores de juegos que prueban los juegos de los dem\xE1s. Cada probador se uni\xF3 por su cuenta al Grupo de Google de la prueba y se hizo probador desde el enlace de Google Play. Nadie recibi\xF3 dinero ni recompensas por rese\xF1as.`
    },
    {
      pregunta: "\xBFHa sido f\xE1cil reclutar probadores?",
      respuesta: `Se unieron ${total} probadores; ${cumplidos} completaron los ${c.dias} d\xEDas` + (c.abandonos ? ` y ${c.abandonos} lo dejaron antes, por eso abrimos plazas de reserva.` : ".")
    },
    {
      pregunta: "Describe la participaci\xF3n de los probadores durante la prueba cerrada",
      respuesta: `Los probadores jugaron cada d\xEDa y lo registraron en la app con el nivel al que llegaron y, si quer\xEDan, una opini\xF3n privada.` + checkTxt + nivelTxt
    },
    {
      pregunta: "Resume los comentarios de los probadores y c\xF3mo los recogiste",
      respuesta: ops.length ? `Recogimos ${ops.length === 1 ? "una opini\xF3n privada" : `${ops.length} opiniones privadas`} dentro de la app (solo las ve el autor).` + (tem.length ? ` Lo que m\xE1s se repiti\xF3: ${tem.join(", ")}.` : "") + ` Algunas: ${citas.map((x) => `\xAB${x.slice(0, 140)}\xBB`).join(" ")}` : "Los probadores registraron su progreso cada d\xEDa; no dejaron comentarios escritos."
    },
    {
      pregunta: "\xBFA qui\xE9n va dirigida tu aplicaci\xF3n?",
      respuesta: j.publico === "infantil" ? `Es un juego de ${j.tipo} pensado para ni\xF1os: sin compras, sin avisos y sin funciones en l\xEDnea, con anuncios aptos para familias.` : `Es un juego de ${j.tipo} para cualquier persona que quiera partidas cortas en el m\xF3vil.`
    },
    {
      pregunta: "\xBFC\xF3mo aporta valor tu aplicaci\xF3n a los usuarios?",
      respuesta: `\xAB${j.titulo}\xBB ofrece partidas r\xE1pidas de ${j.tipo} con niveles que aumentan de dificultad, funciona sin conexi\xF3n y guarda el progreso.`
    },
    {
      pregunta: "\xBFQu\xE9 cambios hiciste en la aplicaci\xF3n gracias a la prueba cerrada?",
      respuesta: cambios.length ? `Publicamos ${cambios.length === 1 ? "una versi\xF3n nueva" : `${cambios.length} versiones nuevas`} durante la prueba: ${cambios.map((x) => x.replace(/\.$/, "")).join("; ")}.` : "Revisamos cada opini\xF3n y no hizo falta cambiar nada importante: no hubo errores ni bloqueos."
    },
    {
      pregunta: "\xBFC\xF3mo decidiste que la aplicaci\xF3n est\xE1 lista para producci\xF3n?",
      respuesta: `${cumplidos} probadores la usaron ${c.dias} d\xEDas seguidos sin errores que impidieran jugar` + (cambios.length ? ", y las mejoras que pidieron ya est\xE1n en la \xFAltima versi\xF3n." : ".") + " Adem\xE1s, cada versi\xF3n la juegan bots autom\xE1ticos de principio a fin antes de publicarla."
    }
  ];
}
function textoRespuestas(rs) {
  return rs.map((r) => `${r.pregunta}
${r.respuesta}`).join("\n\n");
}
export {
  proyeccion,
  respuestasProduccion,
  temas,
  textoRacha,
  textoRespuestas
};

function mensajeRegalo(m) {
  if (m.includes("bad_name")) return "Los nombres van de 1 a 20 letras, sin s\xEDmbolos raros.";
  if (m.includes("bad_message")) return "El mensaje va de 1 a 400 letras, sin los s\xEDmbolos < > { } \\.";
  if (m.includes("bad_level")) return "El nivel va del 0 (al final) al 50.";
  if (m.includes("no_gift")) return "Primero guarda para qui\xE9n es el regalo y el mensaje.";
  return "No se pudo guardar el regalo.";
}
const RARO = /[<>{}\\]/;
function validarRegalo(r) {
  const para = r.para.trim(), de = r.de.trim(), msg = r.mensaje.trim();
  if (!para || !de || para.length > 20 || de.length > 20 || RARO.test(para) || RARO.test(de)) return mensajeRegalo("bad_name");
  if (!msg || msg.length > 400 || RARO.test(msg)) return mensajeRegalo("bad_message");
  if (!Number.isInteger(r.tras_nivel) || r.tras_nivel < 0 || r.tras_nivel > 50) return mensajeRegalo("bad_level");
  return "";
}
const OCASIONES = [
  { ocasion: "Cumplea\xF1os", mensaje: "\xA1Feliz cumplea\xF1os! Este juego lo he hecho solo para ti. Que cumplas muchos m\xE1s." },
  { ocasion: "Aniversario", mensaje: "Un a\xF1o m\xE1s a tu lado. Gracias por cada d\xEDa. Te quiero." },
  { ocasion: "San Valent\xEDn", mensaje: "Has llegado al final... y yo sigo eligi\xE9ndote. \xBFCena el s\xE1bado?" },
  { ocasion: "D\xEDa de la madre o del padre", mensaje: "Gracias por todo lo que haces. Eres el mejor jugador de esta familia." },
  { ocasion: "Navidad", mensaje: "\xA1Feliz Navidad! Tu regalo de verdad est\xE1 escondido debajo del sof\xE1." },
  { ocasion: "Pedir algo especial", mensaje: "\xBFQuieres ser mi pareja de baile en la boda?" }
];
function estadoRegalo(r, ahora = /* @__PURE__ */ new Date()) {
  if (!r) return "Sin regalo: es un juego normal.";
  const cuando = (iso) => {
    const d = new Date(iso);
    const dias = Math.floor((ahora.getTime() - d.getTime()) / 864e5);
    return dias <= 0 ? "hoy" : dias === 1 ? "ayer" : `hace ${dias} d\xEDas`;
  };
  if (r.leido_en) return `${r.para} ya ha le\xEDdo tu mensaje (${cuando(r.leido_en)}).`;
  if (r.abierto_en) return `${r.para} abri\xF3 el regalo ${cuando(r.abierto_en)}; a\xFAn no ha llegado al mensaje.`;
  return `Listo para ${r.para}. A\xFAn no lo ha abierto.`;
}
export {
  OCASIONES,
  estadoRegalo,
  mensajeRegalo,
  validarRegalo
};

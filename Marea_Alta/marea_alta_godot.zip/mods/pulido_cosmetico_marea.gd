extends "res://kit/mod_base.gd"

const SAND: Color = Color(1.0, 0.85, 0.5)
const SEA: Color = Color(0.2, 0.65, 1.0)
const FOAM: Color = Color(0.85, 0.97, 1.0)
const CORAL: Color = Color(1.0, 0.4, 0.3)
const GOLD: Color = Color(1.0, 0.85, 0.2)

var _t: float = 0.0
var _last: Dictionary = {}
var _combo: int = 0
var _combo_time: float = -99.0
var _ambient: float = 3.0


func on_level_start() -> void:
	_t = 0.0
	_last.clear()
	_combo = 0
	_combo_time = -99.0
	_ambient = 3.0
	var p: Node2D = player()
	if p != null:
		burst(p.position, SEA, 22)
		burst(p.position, FOAM, 10)
	flash_screen(Color(0.3, 0.7, 1.0, 0.25), 0.25)
	toast("\u00a1Marea alta!", FOAM)


func _ready_ok(key: String, gap: float) -> bool:
	var prev: float = float(_last.get(key, -99.0))
	if _t - prev < gap:
		return false
	_last[key] = _t
	return true


func _at(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.position
	return Vector2.ZERO


func on_tick(delta: float) -> void:
	_t += delta
	_ambient -= delta
	if _ambient <= 0.0:
		_ambient = 4.0
		var p: Node2D = player()
		if p != null:
			var off: Vector2 = Vector2(sin(_t * 1.7) * 90.0, cos(_t * 1.3) * 70.0)
			burst(p.position + off, FOAM, 3)


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"arena_live_start", "arena_live_match":
			if _ready_ok("live", 6.0):
				flash_screen(Color(1, 1, 1, 0.18), 0.12)
		"super":
			if _ready_ok("super", 1.0):
				burst(_at(data), GOLD, 30)
				shake(7.0)
				flash_screen(Color(1.0, 0.9, 0.4, 0.3), 0.18)
				toast("\u00a1S\u00daPER!", GOLD)
				play_sound("power", 1.1)
		"rival_out":
			if _t - _combo_time < 4.0:
				_combo += 1
			else:
				_combo = 1
			_combo_time = _t
			burst(_at(data), CORAL, 24)
			shake(4.0)
			if _combo >= 2:
				if _ready_ok("combo", 1.0):
					flash_screen(Color(1.0, 0.5, 0.3, 0.2), 0.12)
					toast("\u00a1Combo x" + str(mini(_combo, 9)) + "!", CORAL)
			elif _ready_ok("out", 2.5):
				toast("\u00a1Fuera de la arena!", SAND)
		"coop_wave", "survival_wave":
			if _ready_ok("wave", 2.0):
				burst(_at(data), SEA, 20)
				shake(3.0)
				toast("\u00a1Nueva oleada!", SEA)
		"overtime":
			if _ready_ok("overtime", 5.0):
				flash_screen(Color(1.0, 0.3, 0.2, 0.25), 0.2)
				shake(5.0)
				toast("\u00a1Pr\u00f3rroga!", CORAL)
		"turret_down":
			if _ready_ok("turret", 1.0):
				burst(_at(data), SAND, 26)
				shake(5.0)
				toast("\u00a1Torreta fuera!", SAND)
		"kick":
			if _ready_ok("kick", 0.4):
				burst(_at(data), FOAM, 8)
				shake(2.0)
		"goal":
			if _ready_ok("goal", 2.0):
				burst(_at(data), GOLD, 36)
				burst(_at(data), FOAM, 18)
				shake(8.0)
				flash_screen(Color(1, 1, 0.7, 0.35), 0.25)
				toast("\u00a1GOOOL!", GOLD)
				play_sound("power", 1.2)
		"brawler_upgrade":
			if _ready_ok("upgrade", 1.5):
				var p: Node2D = player()
				if p != null:
					burst(p.position, GOLD, 18)
				toast("\u00a1Mejora!", GOLD)
		"death":
			if _ready_ok("death", 1.5):
				shake(5.0)
				flash_screen(Color(0.8, 0.1, 0.1, 0.25), 0.2)
				toast("\u00a1Ay, esa marea!", CORAL)
		"level_complete":
			if _ready_ok("win", 2.0):
				var p2: Node2D = player()
				if p2 != null:
					burst(p2.position, GOLD, 40)
					burst(p2.position, SEA, 24)
				shake(6.0)
				flash_screen(Color(1, 0.95, 0.6, 0.4), 0.3)
				toast("\u00a1Victoria, Pinzas!", GOLD)
				play_sound("win", 1.0)

extends "res://kit/mod_base.gd"

const AZUL: Color = Color(0.15, 0.6, 0.95)
const TURQUESA: Color = Color(0.2, 0.9, 0.85)
const CORAL: Color = Color(1.0, 0.45, 0.35)
const ARENA: Color = Color(1.0, 0.85, 0.45)
const BLANCO: Color = Color(1.0, 1.0, 1.0)

var _clock: float = 0.0
var _last: Dictionary = {}
var _combo: int = 0
var _combo_time: float = -10.0
var _starts: Array[String] = [
	"\u00a1A la arena!",
	"\u00a1Sube la marea!",
	"\u00a1Pinzas listas!",
	"\u00a1Que empiece la ola!"
]
var _kos: Array[String] = [
	"\u00a1Pinzazo!",
	"\u00a1Fuera de la isla!",
	"\u00a1Crac!",
	"\u00a1Al agua!"
]
var _wins: Array[String] = [
	"\u00a1Rey de la playa!",
	"\u00a1Victoria crujiente!",
	"\u00a1Marea a tu favor!"
]
var _pick: int = 0


func _ready_ok(key: String, gap: float) -> bool:
	var last: float = float(_last.get(key, -100.0))
	if _clock - last < gap:
		return false
	_last[key] = _clock
	return true


func _pos(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.position
	return Vector2.ZERO


func _phrase(list: Array[String]) -> String:
	_pick += 1
	return list[_pick % list.size()]


func on_level_start() -> void:
	_combo = 0
	_combo_time = -10.0
	_last.clear()
	var p: Node2D = player()
	if p != null:
		burst(p.position, TURQUESA, 24)
	flash_screen(Color(0.2, 0.7, 1.0, 0.3), 0.25)
	toast(_phrase(_starts), TURQUESA)
	play_sound("coin", 1.2)


func on_tick(delta: float) -> void:
	_clock += delta
	if _combo > 0 and _clock - _combo_time > 4.0:
		_combo = 0


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"hit", "boss_hit":
			if _ready_ok("hit", 0.18):
				burst(_pos(data), ARENA, 8)
				shake(2.5)
		"hurt":
			if _ready_ok("hurt", 0.6):
				burst(_pos(data), CORAL, 12)
				shake(4.0)
				flash_screen(Color(1.0, 0.2, 0.2, 0.18), 0.12)
		"kick":
			if _ready_ok("kick", 0.4):
				burst(_pos(data), BLANCO, 10)
				shake(2.0)
		"super":
			if _ready_ok("super", 1.0):
				burst(_pos(data), ARENA, 30)
				shake(6.0)
				flash_screen(Color(1.0, 0.9, 0.4, 0.3), 0.2)
				toast("\u00a1S\u00fcper!", ARENA)
				play_sound("power", 1.1)
		"rival_out":
			if _clock - _combo_time <= 4.0:
				_combo += 1
			else:
				_combo = 1
			_combo_time = _clock
			burst(_pos(data), CORAL, 26)
			shake(5.0)
			if _combo >= 2 and _ready_ok("combo", 1.0):
				toast("\u00a1Combo x" + str(_combo) + "!", CORAL)
				flash_screen(Color(1.0, 0.5, 0.3, 0.22), 0.15)
			elif _ready_ok("ko", 1.5):
				toast(_phrase(_kos), CORAL)
		"goal":
			if _ready_ok("goal", 1.5):
				burst(_pos(data), ARENA, 40)
				shake(7.0)
				flash_screen(Color(1.0, 1.0, 1.0, 0.35), 0.2)
				toast("\u00a1GOOOL!", ARENA)
				play_sound("coin", 1.3)
		"turret_down":
			if _ready_ok("turret", 1.0):
				burst(_pos(data), AZUL, 28)
				shake(6.0)
				toast("\u00a1Torreta fuera!", AZUL)
		"coop_wave", "survival_wave", "wave_start":
			if _ready_ok("wave", 2.0):
				flash_screen(Color(0.2, 0.6, 1.0, 0.2), 0.2)
				toast("\u00a1Nueva oleada!", AZUL)
				shake(3.0)
		"wave_clear":
			if _ready_ok("clear", 2.0):
				burst(_pos(data), TURQUESA, 24)
				toast("\u00a1Oleada limpia!", TURQUESA)
		"overtime":
			if _ready_ok("overtime", 3.0):
				flash_screen(Color(1.0, 0.4, 0.3, 0.25), 0.25)
				shake(4.0)
				toast("\u00a1Pr\u00f3rroga!", CORAL)
		"brawler_upgrade":
			if _ready_ok("upgrade", 1.5):
				var p: Node2D = player()
				if p != null:
					burst(p.position, TURQUESA, 22)
				toast("\u00a1Mejora!", TURQUESA)
				play_sound("power", 1.2)
		"arena_live_start":
			if _ready_ok("live", 3.0):
				flash_screen(Color(1.0, 1.0, 1.0, 0.2), 0.15)
		"death":
			if _ready_ok("death", 1.5):
				burst(_pos(data), AZUL, 20)
				shake(6.0)
				flash_screen(Color(0.1, 0.2, 0.5, 0.3), 0.3)
				toast("\u00a1Ups, a la marea!", AZUL)
		"level_complete":
			if _ready_ok("win", 2.0):
				var q: Node2D = player()
				if q != null:
					burst(q.position, ARENA, 50)
					burst(q.position, TURQUESA, 30)
				shake(5.0)
				flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.4)
				toast(_phrase(_wins), ARENA)
				play_sound("win", 1.0)

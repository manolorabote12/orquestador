extends "res://kit/mod_base.gd"

const SEA: Color = Color(0.2, 0.7, 1.0)
const CORAL: Color = Color(1.0, 0.4, 0.35)
const SAND: Color = Color(1.0, 0.85, 0.45)
const LEAF: Color = Color(0.45, 0.9, 0.5)

var _t: float = 0.0
var _last: Dictionary = {}
var _combo: int = 0
var _combo_time: float = -10.0
var _fx_layer: CanvasLayer = null
var _bubble_timer: float = 0.0
var _bubbles: int = 0


func _gap_ok(key: String, gap: float) -> bool:
	var prev: float = float(_last.get(key, -100.0))
	if _t - prev < gap:
		return false
	_last[key] = _t
	return true


func _pos(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.position
	return Vector2.ZERO


func _ensure_layer() -> void:
	if _fx_layer == null or not is_instance_valid(_fx_layer):
		_fx_layer = CanvasLayer.new()
		_fx_layer.layer = 3
		add_child(_fx_layer)


func on_level_start() -> void:
	_combo = 0
	_bubbles = 0
	_bubble_timer = 0.0
	if _gap_ok("start", 1.0):
		toast("\u00a1A la marea!", SEA)
		flash_screen(Color(0.4, 0.8, 1.0, 0.25), 0.25)
		var p: Node2D = player()
		if p != null:
			burst(p.position, SEA, 18)


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"arena_live_start":
			if _gap_ok("live", 3.0):
				toast("\u00a1Que empiece la batalla!", SAND)
		"rival_out":
			if _t - _combo_time < 4.0:
				_combo += 1
			else:
				_combo = 1
			_combo_time = _t
			burst(_pos(data), CORAL, 16)
			shake(3.0)
			if _combo == 2 and _gap_ok("combo2", 2.0):
				toast("\u00a1Doble pinzazo!", CORAL)
			elif _combo >= 3 and _gap_ok("combo3", 2.5):
				toast("\u00a1Racha x" + str(_combo) + "!", SAND)
				flash_screen(Color(1.0, 0.7, 0.3, 0.25), 0.2)
			elif _combo == 1 and _gap_ok("out", 5.0):
				toast("\u00a1Fuera de juego!", CORAL)
		"super":
			burst(_pos(data), SAND, 28)
			shake(5.0)
			flash_screen(Color(1.0, 0.9, 0.5, 0.3), 0.18)
			if _gap_ok("super", 4.0):
				toast("\u00a1Superpinza!", SAND)
		"kick":
			if _gap_ok("kick", 0.4):
				burst(_pos(data), Color.WHITE, 8)
				shake(2.0)
		"goal":
			burst(_pos(data), SAND, 40)
			shake(6.0)
			flash_screen(Color(1.0, 1.0, 1.0, 0.4), 0.25)
			if _gap_ok("goal", 2.0):
				toast("\u00a1GOOOL de cangrejo!", SAND)
		"turret_down":
			burst(_pos(data), CORAL, 26)
			shake(5.0)
			if _gap_ok("turret", 2.0):
				toast("\u00a1Torreta fuera!", CORAL)
		"coop_wave", "survival_wave":
			if _gap_ok("wave", 3.0):
				toast("\u00a1Llega otra oleada!", SEA)
				flash_screen(Color(0.3, 0.7, 1.0, 0.2), 0.2)
		"overtime":
			if _gap_ok("over", 5.0):
				toast("\u00a1Tiempo extra!", CORAL)
				flash_screen(Color(1.0, 0.4, 0.3, 0.25), 0.25)
				shake(4.0)
		"brawler_upgrade":
			burst(_pos(data), LEAF, 24)
			if _gap_ok("upg", 2.0):
				toast("\u00a1Pinzas mejoradas!", LEAF)
				play_sound("coin", 1.2)
		"death":
			if _gap_ok("death", 2.0):
				burst(_pos(data), CORAL, 22)
				shake(7.0)
				flash_screen(Color(1.0, 0.2, 0.2, 0.25), 0.3)
				toast("\u00a1Ay, qu\u00e9 pinchazo!", CORAL)
		"level_complete":
			if _gap_ok("win", 2.0):
				var at: Vector2 = _pos(data)
				burst(at, SAND, 40)
				burst(at, SEA, 30)
				burst(at, LEAF, 20)
				shake(5.0)
				flash_screen(Color(1.0, 0.95, 0.7, 0.4), 0.4)
				toast("\u00a1Rey de la playa!", SAND)


func on_tick(delta: float) -> void:
	_t += delta
	_bubble_timer -= delta
	if _bubble_timer <= 0.0 and _bubbles < 7:
		_bubble_timer = 1.1
		_spawn_bubble()


func _spawn_bubble() -> void:
	_ensure_layer()
	var size: Vector2 = get_viewport().get_visible_rect().size
	var r: float = 4.0 + float(randi() % 7)
	var poly: Polygon2D = Polygon2D.new()
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(10):
		var a: float = TAU * float(i) / 10.0
		pts.append(Vector2(cos(a), sin(a)) * r)
	poly.polygon = pts
	poly.color = Color(0.7, 0.92, 1.0, 0.22)
	poly.position = Vector2(randf() * size.x, size.y + 10.0)
	_fx_layer.add_child(poly)
	_bubbles += 1
	var dur: float = 5.0 + randf() * 3.0
	var tw: Tween = poly.create_tween()
	tw.set_parallel(true)
	tw.tween_property(poly, "position:y", size.y * 0.2, dur)
	tw.tween_property(poly, "position:x", poly.position.x + (randf() - 0.5) * 80.0, dur)
	tw.tween_property(poly, "color:a", 0.0, dur)
	tw.chain().tween_callback(_bubble_done.bind(poly))


func _bubble_done(poly: Polygon2D) -> void:
	_bubbles = maxi(0, _bubbles - 1)
	if is_instance_valid(poly):
		poly.queue_free()

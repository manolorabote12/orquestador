extends "res://kit/mod_base.gd"

const SEA: Color = Color(0.2, 0.75, 1.0)
const FOAM: Color = Color(0.85, 0.97, 1.0)
const CORAL: Color = Color(1.0, 0.45, 0.35)
const SAND: Color = Color(1.0, 0.85, 0.4)
const LIME: Color = Color(0.5, 1.0, 0.55)

var _t: float = 0.0
var _last: Dictionary = {}
var _combo: int = 0
var _combo_time: float = -99.0
var _ambient: float = 0.0


func _ok(key: String, gap: float) -> bool:
	var prev: float = float(_last.get(key, -999.0))
	if _t - prev < gap:
		return false
	_last[key] = _t
	return true


func _pos(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2.ZERO


func on_level_start() -> void:
	_combo = 0
	_combo_time = -99.0
	_ambient = 0.0
	_last["start"] = _t
	var p: Node2D = player()
	if p != null:
		burst(p.global_position, SEA, 22)
		burst(p.global_position, FOAM, 10)
	flash_screen(Color(0.4, 0.85, 1.0, 0.35), 0.25)
	toast("\u00a1A la marea!", SEA)
	play_sound("coin", 1.2)


func on_tick(delta: float) -> void:
	_t += delta
	_ambient += delta
	if _ambient >= 10.0:
		_ambient = 0.0
		var p: Node2D = player()
		if p != null:
			burst(p.global_position + Vector2(0, -10), FOAM, 4)


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"arena_live_start":
			if _ok("start", 3.0):
				flash_screen(Color(0.4, 0.85, 1.0, 0.3), 0.2)
				toast("\u00a1Que suba la marea!", SEA)
		"rival_out":
			_on_rival_out(data)
		"super":
			if _ok("super", 1.0):
				var at: Vector2 = _pos(data)
				burst(at, SAND, 30)
				burst(at, CORAL, 14)
				shake(5.0)
				flash_screen(Color(1.0, 0.9, 0.5, 0.3), 0.15)
				toast("\u00a1S\u00daPER!", SAND)
				play_sound("power", 1.1)
		"kick":
			if _ok("kick", 0.5):
				burst(_pos(data), FOAM, 8)
				shake(2.0)
		"goal":
			if _ok("goal", 1.5):
				var g: Vector2 = _pos(data)
				burst(g, SAND, 40)
				burst(g, LIME, 20)
				shake(7.0)
				flash_screen(Color(1.0, 1.0, 0.7, 0.4), 0.25)
				toast("\u00a1GOOOL!", SAND)
				play_sound("coin", 1.4)
		"turret_down":
			if _ok("turret", 1.0):
				burst(_pos(data), CORAL, 26)
				shake(5.0)
				flash_screen(Color(1.0, 0.5, 0.4, 0.25), 0.12)
				toast("\u00a1Torreta fuera!", CORAL)
		"coop_wave", "survival_wave":
			if _ok("wave", 2.0):
				burst(_pos(data), SEA, 18)
				flash_screen(Color(0.4, 0.8, 1.0, 0.25), 0.15)
				toast("\u00a1Nueva oleada!", SEA)
		"overtime":
			if _ok("overtime", 3.0):
				shake(4.0)
				flash_screen(Color(1.0, 0.6, 0.3, 0.3), 0.2)
				toast("\u00a1Pr\u00f3rroga!", CORAL)
		"brawler_upgrade":
			if _ok("upgrade", 1.0):
				var u: Vector2 = _pos(data)
				burst(u, LIME, 22)
				burst(u, FOAM, 8)
				toast("\u00a1M\u00e1s fuerte!", LIME)
				play_sound("power", 1.3)
		"death":
			if _ok("death", 1.5):
				burst(_pos(data), CORAL, 20)
				shake(6.0)
				flash_screen(Color(0.2, 0.4, 0.8, 0.35), 0.25)
				toast("\u00a1Ay, Pinzas!", CORAL)
		"level_complete":
			if _ok("win", 2.0):
				var w: Vector2 = _pos(data)
				burst(w, SAND, 45)
				burst(w + Vector2(-40, -20), SEA, 25)
				burst(w + Vector2(40, -20), LIME, 25)
				shake(6.0)
				flash_screen(Color(1.0, 0.95, 0.7, 0.45), 0.35)
				toast("\u00a1VICTORIA!", SAND)
				play_sound("coin", 1.5)


func _on_rival_out(data: Dictionary) -> void:
	if _t - _combo_time <= 5.0:
		_combo += 1
	else:
		_combo = 1
	_combo_time = _t
	var at: Vector2 = _pos(data)
	burst(at, CORAL, 16)
	burst(at, FOAM, 8)
	shake(3.0 + minf(float(_combo), 4.0))
	if _combo == 1:
		if _ok("rival", 1.0):
			toast("\u00a1Fuera!", CORAL)
	elif _combo == 2:
		toast("\u00a1Doble!", SAND)
		flash_screen(Color(1.0, 0.9, 0.5, 0.25), 0.12)
	elif _combo == 3:
		toast("\u00a1Triple!", SAND)
		flash_screen(Color(1.0, 0.8, 0.4, 0.3), 0.15)
	elif _combo >= 4 and _combo % 2 == 0:
		toast("\u00a1Imparable!", LIME)
		burst(at, LIME, 24)
		flash_screen(Color(0.6, 1.0, 0.6, 0.3), 0.15)

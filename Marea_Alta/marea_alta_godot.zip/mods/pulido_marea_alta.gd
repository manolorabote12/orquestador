extends "res://kit/mod_base.gd"

const COL_SEA: Color = Color(0.2, 0.7, 1.0)
const COL_FOAM: Color = Color(0.9, 1.0, 1.0)
const COL_SAND: Color = Color(1.0, 0.85, 0.45)
const COL_CRAB: Color = Color(1.0, 0.4, 0.3)
const COL_GOLD: Color = Color(1.0, 0.9, 0.3)
const COL_GREEN: Color = Color(0.4, 1.0, 0.5)

var _t: float = 0.0
var _last_hit_fx: float = -10.0
var _last_toast: float = -10.0
var _last_ambient: float = 0.0
var _combo: int = 0
var _combo_time: float = -10.0
var _upgrades: int = 0


func on_level_start() -> void:
	_t = 0.0
	_last_hit_fx = -10.0
	_last_toast = -10.0
	_last_ambient = 0.0
	_combo = 0
	_combo_time = -10.0
	_upgrades = 0
	var p: Node2D = player()
	if p != null:
		burst(p.position, COL_FOAM, 24)
		burst(p.position, COL_SEA, 16)
	flash_screen(Color(0.3, 0.7, 1.0, 0.35), 0.3)
	toast("\u00a1Marea alta, Pinzas!", COL_FOAM)
	play_sound("start", 1.1)


func on_tick(delta: float) -> void:
	_t += delta
	if _t - _last_ambient > 3.0:
		_last_ambient = _t
		var p: Node2D = player()
		if p != null:
			var off: Vector2 = Vector2(sin(_t * 1.7) * 140.0, cos(_t * 1.3) * 90.0)
			burst(p.position + off, COL_FOAM, 3)


func _pos_of(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.position
	return Vector2.ZERO


func _say(text: String, col: Color, gap: float = 1.2) -> void:
	if _t - _last_toast < gap:
		return
	_last_toast = _t
	toast(text, col)


func _register_kill(at: Vector2) -> void:
	if _t - _combo_time <= 4.0:
		_combo += 1
	else:
		_combo = 1
	_combo_time = _t
	if _combo == 2:
		_last_toast = -10.0
		_say("\u00a1Doble pinzazo!", COL_GOLD, 0.0)
		burst(at, COL_GOLD, 26)
		flash_screen(Color(1.0, 0.9, 0.3, 0.22), 0.15)
	elif _combo == 3:
		_last_toast = -10.0
		_say("\u00a1Triple! \u00a1Imparable!", COL_CRAB, 0.0)
		burst(at, COL_CRAB, 34)
		shake(7.0)
	elif _combo >= 5 and _combo % 2 == 1:
		_last_toast = -10.0
		_say("\u00a1Combo x" + str(_combo) + "!", COL_GOLD, 0.0)
		burst(at, COL_GOLD, 40)
		shake(8.0)


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"hit", "hurt", "boss_hit":
			if _t - _last_hit_fx > 0.25:
				_last_hit_fx = _t
				var col: Color = COL_CRAB if event_name == "hurt" else COL_FOAM
				burst(_pos_of(data), col, 8)
				shake(2.5 if event_name == "hurt" else 1.5)
		"rival_out":
			var at: Vector2 = _pos_of(data)
			burst(at, COL_CRAB, 30)
			burst(at, COL_FOAM, 12)
			shake(4.0)
			play_sound("hit", 1.2)
			_say("\u00a1Rival fuera!", COL_CRAB)
			_register_kill(at)
		"turret_down":
			var at2: Vector2 = _pos_of(data)
			burst(at2, COL_SAND, 30)
			shake(4.5)
			_say("\u00a1Torreta derribada!", COL_SAND)
			_register_kill(at2)
		"super":
			var at3: Vector2 = _pos_of(data)
			burst(at3, COL_GOLD, 40)
			burst(at3, COL_SEA, 20)
			shake(6.0)
			flash_screen(Color(1.0, 0.95, 0.5, 0.3), 0.2)
			_say("\u00a1S\u00daPER!", COL_GOLD)
		"kick":
			burst(_pos_of(data), COL_FOAM, 12)
			shake(2.0)
			play_sound("hit", 1.3)
		"goal":
			var at4: Vector2 = _pos_of(data)
			burst(at4, COL_GOLD, 50)
			burst(at4, COL_FOAM, 30)
			shake(8.0)
			flash_screen(Color(1.0, 1.0, 0.8, 0.4), 0.25)
			_last_toast = -10.0
			_say("\u00a1GOOOL de cangrejo!", COL_GOLD, 0.0)
			_register_kill(at4)
		"coop_wave", "survival_wave", "wave_start":
			flash_screen(Color(0.2, 0.6, 1.0, 0.25), 0.2)
			shake(3.0)
			_say("\u00a1Llega la oleada!", COL_SEA)
		"wave_clear":
			burst(_pos_of(data), COL_GREEN, 28)
			_say("\u00a1Oleada superada!", COL_GREEN)
		"overtime":
			flash_screen(Color(1.0, 0.5, 0.3, 0.3), 0.25)
			shake(5.0)
			_say("\u00a1Pr\u00f3rroga!", COL_CRAB)
		"brawler_upgrade":
			_upgrades += 1
			var p: Node2D = player()
			if p != null:
				burst(p.position, COL_GREEN, 26)
			_say("\u00a1Pinzas mejoradas!", COL_GREEN)
			play_sound("power", 1.2)
		"coin", "power":
			var p2: Node2D = player()
			if p2 != null:
				burst(p2.position, COL_GOLD, 12)
		"checkpoint":
			burst(_pos_of(data), COL_GREEN, 16)
		"death":
			var p3: Node2D = player()
			if p3 != null:
				burst(p3.position, COL_SEA, 30)
			shake(7.0)
			flash_screen(Color(1.0, 0.2, 0.2, 0.3), 0.3)
			_last_toast = -10.0
			_say("\u00a1Arrastrado por la marea!", COL_CRAB, 0.0)
		"arena_live_end":
			flash_screen(Color(1.0, 1.0, 1.0, 0.2), 0.2)
		"level_complete":
			var p4: Node2D = player()
			if p4 != null:
				burst(p4.position, COL_GOLD, 50)
				burst(p4.position, COL_FOAM, 30)
				burst(p4.position, COL_SEA, 24)
			shake(6.0)
			flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.4)
			_last_toast = -10.0
			_say("\u00a1Rey de la playa!", COL_GOLD, 0.0)
			play_sound("win", 1.0)

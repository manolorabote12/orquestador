extends "res://kit/mod_base.gd"

const C_SEA: Color = Color(0.15, 0.65, 0.95)
const C_FOAM: Color = Color(0.85, 0.97, 1.0)
const C_CORAL: Color = Color(1.0, 0.42, 0.35)
const C_SAND: Color = Color(1.0, 0.85, 0.5)
const C_GOLD: Color = Color(1.0, 0.8, 0.2)
const C_PALM: Color = Color(0.35, 0.85, 0.45)

var _t: float = 0.0
var _cd: Dictionary = {}
var _combo: int = 0
var _combo_t: float = -10.0
var _dust_t: float = 0.0
var _sparkle_t: float = 5.0


func _can(key: String, gap: float) -> bool:
	var last: float = float(_cd.get(key, -100.0))
	if _t - last < gap:
		return false
	_cd[key] = _t
	return true


func _pick(arr: Array) -> String:
	return str(arr[randi() % arr.size()])


func _where(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v
	v = data.get("position", null)
	if v is Vector2:
		return v
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2.ZERO


func on_level_start() -> void:
	_t = 0.0
	_cd.clear()
	_combo = 0
	_combo_t = -10.0
	_sparkle_t = 5.0
	var p: Node2D = player()
	if p != null:
		burst(p.global_position, C_FOAM, 24)
		burst(p.global_position, C_SEA, 16)
	flash_screen(Color(0.6, 0.9, 1.0, 0.3), 0.25)
	toast(_pick(["\u00a1Sube la marea!", "\u00a1A la arena, Pinzas!", "\u00a1Pinzas arriba!"]), C_FOAM)


func on_event(event_name: String, data: Dictionary) -> void:
	var at: Vector2 = _where(data)
	match event_name:
		"arena_live_start":
			if _can("live_start", 3.0):
				burst(at, C_SEA, 20)
				flash_screen(Color(0.5, 0.85, 1.0, 0.25), 0.2)
		"super":
			if _can("super", 0.8):
				burst(at, C_GOLD, 30)
				burst(at, C_CORAL, 14)
				shake(5.0)
				flash_screen(Color(1.0, 0.9, 0.5, 0.3), 0.15)
				toast(_pick(["\u00a1SUPER!", "\u00a1Pinzazo!", "\u00a1Qu\u00e9 fuerza!"]), C_GOLD)
		"rival_out":
			if _t - _combo_t < 4.0:
				_combo += 1
			else:
				_combo = 1
			_combo_t = _t
			burst(at, C_CORAL, 24)
			burst(at, C_SAND, 10)
			shake(4.0)
			if _combo >= 2:
				flash_screen(Color(1.0, 0.5, 0.4, 0.22), 0.15)
				if _can("combo", 1.2):
					toast("\u00a1Combo x" + str(_combo) + "!", C_CORAL)
			elif _can("ko", 1.5):
				toast(_pick(["\u00a1Fuera de juego!", "\u00a1Al agua!", "\u00a1Cangrejo noqueado!"]), C_SAND)
		"goal":
			if _can("goal", 1.5):
				burst(at, C_GOLD, 40)
				burst(at, C_FOAM, 24)
				shake(8.0)
				flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.3)
				toast(_pick(["\u00a1GOOOL!", "\u00a1Golazo!", "\u00a1Bal\u00f3n a la red!"]), C_GOLD)
		"kick":
			if _can("kick", 0.3):
				burst(at, C_SAND, 8)
				shake(2.0)
		"coop_wave", "survival_wave":
			if _can("wave", 2.0):
				burst(at, C_PALM, 20)
				shake(3.0)
				flash_screen(Color(0.4, 0.9, 0.5, 0.18), 0.2)
				toast(_pick(["\u00a1Nueva oleada!", "\u00a1Llegan m\u00e1s!", "\u00a1Aguanta, Pinzas!"]), C_PALM)
		"turret_down":
			if _can("turret", 0.6):
				burst(at, C_GOLD, 26)
				burst(at, C_CORAL, 12)
				shake(5.0)
				toast(_pick(["\u00a1Torreta fuera!", "\u00a1Chatarra!"]), C_GOLD)
		"overtime":
			if _can("overtime", 4.0):
				flash_screen(Color(1.0, 0.4, 0.3, 0.3), 0.3)
				shake(5.0)
				toast("\u00a1Pr\u00f3rroga!", C_CORAL)
		"brawler_upgrade":
			if _can("upgrade", 1.0):
				burst(at, C_PALM, 22)
				burst(at, C_FOAM, 10)
				flash_screen(Color(0.7, 1.0, 0.7, 0.2), 0.15)
				toast(_pick(["\u00a1M\u00e1s fuerte!", "\u00a1Mejora lista!"]), C_PALM)
		"death":
			if _can("death", 1.5):
				burst(at, C_SEA, 22)
				shake(6.0)
				flash_screen(Color(0.1, 0.3, 0.6, 0.35), 0.3)
				toast(_pick(["\u00a1Ay, la marea!", "\u00a1Otra vez!"]), C_SEA)
		"arena_live_end":
			if _can("live_end", 3.0):
				burst(at, C_FOAM, 16)
		"level_complete":
			if _can("win", 3.0):
				var p: Node2D = player()
				var wp: Vector2 = at
				if p != null:
					wp = p.global_position
				burst(wp, C_GOLD, 50)
				burst(wp, C_CORAL, 30)
				burst(wp, C_FOAM, 30)
				shake(7.0)
				flash_screen(Color(1.0, 0.95, 0.7, 0.45), 0.4)
				toast(_pick(["\u00a1Victoria!", "\u00a1Rey de la isla!", "\u00a1Cangrejo campe\u00f3n!"]), C_GOLD)


func on_tick(delta: float) -> void:
	_t += delta
	var p: Node2D = player()
	if p == null:
		return
	_dust_t -= delta
	if _dust_t <= 0.0:
		var vel: Variant = p.get("velocity")
		if vel is Vector2 and (vel as Vector2).length() > 140.0:
			_dust_t = 0.45
			burst(p.global_position + Vector2(0, 14), C_SAND, 3)
		else:
			_dust_t = 0.1
	_sparkle_t -= delta
	if _sparkle_t <= 0.0:
		_sparkle_t = 6.0 + randf() * 3.0
		var off: Vector2 = Vector2(randf_range(-220.0, 220.0), randf_range(-140.0, 140.0))
		burst(p.global_position + off, C_FOAM, 3)

class_name Datos
extends RefCounted
## La Posada del Último Camino: salas, aventureros, personal, mazmorras, rangos y logros.

const ALTO_SALA: float = 300.0
const SUELO_Y: float = 0.0
const T_DIA: float = 100.0
const T_NOCHE: float = 50.0
const NIVEL_MAX: int = 25

## Salas en el orden en que se construyen. «piso»: 0 = planta baja; negativo = bajo tierra.
## base: oro por servicio; t: segundos de servicio; coste: construir; fama: fama necesaria.
const SALAS: Array = [
	{"id": "taberna", "nombre": "Taberna", "texto": "Cerveza, risas y propinas. Aquí llega todo el mundo.", "piso": 0, "base": 3.0, "t": 4.0, "coste": 0, "fama": 0},
	{"id": "tablon", "nombre": "Tablón de misiones", "texto": "Los aventureros forman grupo y bajan a la mazmorra. Vuelven con botín... o no vuelven.", "piso": 1, "base": 2.0, "t": 3.0, "coste": 40, "fama": 0},
	{"id": "cocina", "nombre": "Cocina", "texto": "Guiso caliente antes de la batalla. Pagan bien por comer.", "piso": 2, "base": 6.0, "t": 6.0, "coste": 150, "fama": 4},
	{"id": "dormitorio", "nombre": "Dormitorios", "texto": "Una cama limpia. De noche se paga a precio de oro.", "piso": 3, "base": 9.0, "t": 9.0, "coste": 900, "fama": 25},
	{"id": "herreria", "nombre": "Herrería", "texto": "Espadas afiladas: los que pasan por aquí mueren menos.", "piso": 4, "base": 14.0, "t": 7.0, "coste": 4000, "fama": 120},
	{"id": "alquimista", "nombre": "Alquimista", "texto": "Pociones de curación: menos muertes y más vuelven a casa.", "piso": 5, "base": 18.0, "t": 7.0, "coste": 18000, "fama": 400},
	{"id": "templo", "nombre": "Capilla", "texto": "Bendiciones. A veces los caídos vuelven del más allá.", "piso": 6, "base": 26.0, "t": 8.0, "coste": 70000, "fama": 1200},
	{"id": "bodega", "nombre": "Bodega", "texto": "Barricas de la casa: todo vale más y la posada gana más mientras duermes.", "piso": -1, "base": 30.0, "t": 6.0, "coste": 250000, "fama": 3000},
]

## Personal: cada uno trabaja en su sala.
const PERSONAL: Array = [
	{"id": "posadera", "nombre": "Marta la posadera", "sala": "taberna", "tex": "p_posadera", "texto": "Recoge sola las propinas de todas las salas.", "costes": [120, 1500, 12000, 90000]},
	{"id": "cocinero", "nombre": "Bruno el cocinero", "sala": "cocina", "tex": "p_cocinero", "texto": "La cocina sirve más rápido y cobra más.", "costes": [400, 4000, 30000, 200000]},
	{"id": "herrero", "nombre": "Ulf el herrero", "sala": "herreria", "tex": "p_herrero", "texto": "Mejores armas: los aventureros mueren mucho menos.", "costes": [3000, 25000, 150000, 900000]},
	{"id": "alquimista_pj", "nombre": "Maese Ortiga", "sala": "alquimista", "tex": "p_alquimista_pj", "texto": "Pociones mejores: menos muertes y más oro por servicio.", "costes": [9000, 70000, 400000, 2000000]},
]

## Clases de aventurero: cada una aporta algo al grupo.
const CLASES: Dictionary = {
	"guerrero": {"nombre": "Guerrero", "tex": "p_guerrero", "texto": "Protege al grupo: menos riesgo.", "riesgo": -0.03},
	"maga": {"nombre": "Maga", "tex": "p_maga", "texto": "Más daño, más botín.", "oro": 0.3},
	"picaro": {"nombre": "Pícaro", "tex": "p_picaro", "texto": "Encuentra gemas escondidas.", "gemas": 0.15},
	"cleriga": {"nombre": "Clériga", "tex": "p_cleriga", "texto": "Cura al grupo: mucho menos riesgo.", "riesgo": -0.05},
	"cazador": {"nombre": "Cazador", "tex": "p_cazador", "texto": "Conoce atajos: misiones más cortas.", "rapido": 0.25},
	"bardo": {"nombre": "Bardo", "tex": "p_bardo", "texto": "Anima la taberna: propinas dobles mientras está.", "oro": 0.15},
}

const NOMBRES: Array = ["Aldo", "Brenna", "Cael", "Dara", "Edric", "Fiona", "Gareth", "Hilda", "Iker", "Jora", "Kael", "Lena", "Moro", "Nadia", "Orrin",
	"Pia", "Quino", "Runa", "Sven", "Tilda", "Ulises", "Vera", "Wulf", "Xenia", "Yago", "Zoe", "Bastian", "Celia", "Dorian", "Elsa", "Fermín", "Greta",
	"Hugo", "Inés", "Joan", "Kira", "Lucas", "Mara", "Nico", "Olga", "Pau", "Rosa", "Tomás", "Ugo", "Valia", "Yara"]
const APODOS: Array = ["el Valiente", "la Roja", "Mano de Hierro", "el Tuerto", "la Sombra", "Corazón de León", "el Breve", "la Sabia", "el Callado",
	"Pies Ligeros", "la Implacable", "el Afortunado", "Barba Gris", "la Estrella", "el Torpe", "Ojo de Halcón", "la Bendita", "el Cantor", "la Temida", "el Novato"]

## Mazmorras: el tablón elige a dónde van los grupos. Más hondo = más oro y más riesgo.
const MAZMORRAS: Array = [
	{"id": "cueva", "nombre": "Cueva de los Goblins", "fama": 0, "riesgo": 0.04, "oro": 30.0, "dur": 35.0, "fama_da": 1, "nivel": 1},
	{"id": "cripta", "nombre": "Cripta Olvidada", "fama": 30, "riesgo": 0.07, "oro": 90.0, "dur": 60.0, "fama_da": 2, "nivel": 3},
	{"id": "aranas", "nombre": "Bosque de las Arañas", "fama": 150, "riesgo": 0.1, "oro": 260.0, "dur": 95.0, "fama_da": 5, "nivel": 5},
	{"id": "minas", "nombre": "Minas Enanas", "fama": 500, "riesgo": 0.13, "oro": 750.0, "dur": 140.0, "fama_da": 10, "nivel": 7},
	{"id": "torre", "nombre": "Torre de la Bruja", "fama": 1500, "riesgo": 0.16, "oro": 2100.0, "dur": 200.0, "fama_da": 20, "nivel": 9},
	{"id": "hidra", "nombre": "Pantano de la Hidra", "fama": 4000, "riesgo": 0.19, "oro": 6000.0, "dur": 280.0, "fama_da": 40, "nivel": 11},
	{"id": "dragon", "nombre": "Nido del Dragón", "fama": 10000, "riesgo": 0.22, "oro": 17000.0, "dur": 380.0, "fama_da": 80, "nivel": 13},
	{"id": "abismo", "nombre": "El Abismo sin Fondo", "fama": 24000, "riesgo": 0.26, "oro": 50000.0, "dur": 520.0, "fama_da": 160, "nivel": 15},
]

## Rangos de la posada por fama.
const RANGOS: Array = [
	{"fama": 0, "nombre": "Chabola del camino"},
	{"fama": 15, "nombre": "Venta humilde"},
	{"fama": 100, "nombre": "Posada"},
	{"fama": 400, "nombre": "Mesón con fama"},
	{"fama": 1500, "nombre": "Hostería"},
	{"fama": 4500, "nombre": "Gran Posada"},
	{"fama": 12000, "nombre": "Fortaleza del Camino"},
	{"fama": 30000, "nombre": "Leyenda del Camino"},
]

## Encargos que se pagan con gemas.
const ENCARGOS: Array = [
	{"id": "fiesta", "nombre": "Barril de fiesta", "texto": "Todo cobra el doble durante 3 minutos.", "gemas": 5},
	{"id": "pregon", "nombre": "Pregón en el camino", "texto": "Llegan 8 aventureros de golpe.", "gemas": 3},
	{"id": "heroe", "nombre": "Contratar a un veterano", "texto": "Llega un aventurero de nivel alto.", "gemas": 8},
]

const LOGROS: Array = [
	{"id": "primer", "nombre": "Primer cliente", "texto": "Sirve tu primera cerveza.", "premio": 1},
	{"id": "mision", "nombre": "A la aventura", "texto": "Un grupo vuelve de la mazmorra.", "premio": 2},
	{"id": "leyenda", "nombre": "Que la tierra le sea leve", "texto": "Un aventurero entra en el Libro de Leyendas.", "premio": 2},
	{"id": "salas4", "nombre": "Cuatro pisos", "texto": "Construye cuatro salas.", "premio": 3},
	{"id": "salas8", "nombre": "La posada entera", "texto": "Construye todas las salas.", "premio": 10},
	{"id": "personal", "nombre": "Buena plantilla", "texto": "Contrata a todo el personal.", "premio": 6},
	{"id": "nivel10", "nombre": "Veterano", "texto": "Un aventurero llega a nivel 10.", "premio": 4},
	{"id": "nivel20", "nombre": "Héroe de canción", "texto": "Un aventurero llega a nivel 20.", "premio": 8},
	{"id": "resucita", "nombre": "Milagro", "texto": "La capilla devuelve a alguien de entre los muertos.", "premio": 3},
	{"id": "dragon", "nombre": "Matadragones", "texto": "Un grupo vuelve del Nido del Dragón.", "premio": 8},
	{"id": "abismo", "nombre": "Hasta el fondo", "texto": "Un grupo vuelve del Abismo sin Fondo.", "premio": 15},
	{"id": "rata", "nombre": "Cazarratas", "texto": "Echa a 10 bichos de la posada.", "premio": 3},
	{"id": "oro1m", "nombre": "Millonario", "texto": "Gana un millón de oro en total.", "premio": 10},
	{"id": "fortaleza", "nombre": "Fortaleza", "texto": "Alcanza el rango de Fortaleza del Camino.", "premio": 15},
	{"id": "visitas500", "nombre": "Casa llena", "texto": "Recibe a 500 aventureros.", "premio": 5},
]


static func sala(id: String) -> Dictionary:
	for s: Variant in SALAS:
		if str((s as Dictionary)["id"]) == id:
			return s as Dictionary
	return {}


static func personal(id: String) -> Dictionary:
	for s: Variant in PERSONAL:
		if str((s as Dictionary)["id"]) == id:
			return s as Dictionary
	return {}


static func rango(fama: int) -> int:
	var r: int = 0
	for i: int in RANGOS.size():
		if fama >= int((RANGOS[i] as Dictionary)["fama"]):
			r = i
	return r


## Coste de subir una sala del nivel nv al nv+1.
static func coste_subir(id: String, nv: int) -> int:
	var base: float = maxf(25.0, float(sala(id)["coste"]) * 0.5)
	return int(round(base * pow(1.42, nv - 1)))


static func precio(id: String, nv: int) -> float:
	return float(sala(id)["base"]) * (1.0 + 0.32 * (nv - 1))

extends Control
## Portada de La Posada del Último Camino: abrir la posada, regalo del día, logros y ajustes.

const JUEGO: String = "res://libre/juego.tscn"

var _t: float = 0.0
var _titulo: Label
var _brillo: Node2D
var _chispas: Array = []
var _modal: Dictionary = {}


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	var cobrado: int = Estado.cobrar_monedero()
	Audio.play_track("menu")
	var vs: Vector2 = get_viewport_rect().size
	Estilo.fondo_cubrir(self, "p_titulo", 1.03)
	var vel: ColorRect = ColorRect.new()
	vel.size = vs
	vel.color = Color(0.05, 0.02, 0.0, 0.18)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	## Luciérnagas y chispas de la chimenea.
	_brillo = Node2D.new()
	_brillo.draw.connect(_dibujar_brillo)
	add_child(_brillo)
	for i: int in 34:
		_chispas.append(Vector3(randf() * vs.x, randf() * vs.y, randf_range(0.4, 1.0)))
	_titulo = Estilo.etiqueta(Idioma.t("La Posada"), 92, Color("ffe7b0"))
	_titulo.position = Vector2(0, 90)
	_titulo.size = Vector2(vs.x, 110)
	_titulo.add_theme_constant_override("outline_size", 16)
	_titulo.add_theme_color_override("font_outline_color", Color(0.22, 0.1, 0.02, 0.95))
	add_child(_titulo)
	var sub: Label = Estilo.etiqueta(Idioma.t("del Último Camino"), 44, Color("f6d48a"))
	sub.position = Vector2(0, 196)
	sub.size = Vector2(vs.x, 60)
	sub.add_theme_constant_override("outline_size", 10)
	sub.add_theme_color_override("font_outline_color", Color(0.2, 0.08, 0.02, 0.95))
	add_child(sub)
	var lema: Label = Estilo.etiqueta(Idioma.t("La última cerveza antes de la mazmorra."), 26, Color("f3e2bf"))
	lema.position = Vector2(0, 262)
	lema.size = Vector2(vs.x, 40)
	lema.add_theme_constant_override("outline_size", 8)
	lema.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	add_child(lema)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.position = Vector2((vs.x - 520.0) / 2.0, vs.y - 560.0)
	vb.size = Vector2(520, 500)
	vb.add_theme_constant_override("separation", 14)
	add_child(vb)
	var r: int = Datos.rango(Estado.n("fama"))
	var info: Label = Estilo.etiqueta("%s  ·  ★ %d  ·  %d %s" % [Idioma.t(str((Datos.RANGOS[r] as Dictionary)["nombre"])), Estado.n("fama"), Estado.salas_hechas(), Idioma.t("salas")],
		24, Color("ffe2a0"), HORIZONTAL_ALIGNMENT_CENTER, true)
	info.add_theme_constant_override("outline_size", 8)
	info.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	vb.add_child(info)
	var nueva: bool = Estado.n("visitas") == 0
	var bj: Button = Estilo.boton(Idioma.t("Abrir la posada") if nueva else Idioma.t("Volver a la posada"), true, 108)
	bj.add_theme_font_size_override("font_size", 38)
	bj.pressed.connect(jugar)
	vb.add_child(bj)
	Estilo.pulso(bj)
	if Estado.n("regalo") != Estado.dia_de_hoy():
		var br: Button = Estilo.boton(Idioma.t("Regalo del día: 2 gemas"), false, 84)
		br.pressed.connect(func() -> void:
			Estado.d["regalo"] = Estado.dia_de_hoy()
			Estado.d["gemas"] = Estado.n("gemas") + 2
			Estado.guardar()
			Audio.play("ui_reward")
			br.queue_free())
		vb.add_child(br)
		Estilo.pulso(br)
	var bl: Button = Estilo.boton(Idioma.t("Libro de Leyendas") + "  (%d)" % (Estado.d["leyendas"] as Array).size(), false, 84)
	bl.pressed.connect(abrir_leyendas)
	vb.add_child(bl)
	if Store.available() or Store.showcase():
		var bt: Button = Estilo.boton(Idioma.t("Tienda"), false, 84)
		bt.pressed.connect(abrir_tienda)
		vb.add_child(bt)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 84)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	vb.add_child(ba)
	if cobrado > 0:
		Estilo.confirmar(self, Idioma.t("¡Gracias!"), Idioma.t("Han llegado %d gemas.") % cobrado, Idioma.t("Vale"), Idioma.t("Cerrar"), func() -> void: pass)


func _dibujar_brillo() -> void:
	for b: Vector3 in _chispas:
		var a: float = 0.5 + 0.5 * sin(_t * 2.5 + b.x)
		var p: Vector2 = Vector2(b.x + sin(_t + b.y * 0.01) * 14.0, b.y)
		_brillo.draw_circle(p, 2.5 * b.z, Color(1.0, 0.85, 0.4, a * b.z))
		_brillo.draw_circle(p, 7.0 * b.z, Color(1.0, 0.7, 0.3, a * b.z * 0.18))


func _process(dt: float) -> void:
	_t += dt
	var vs: Vector2 = get_viewport_rect().size
	for i: int in _chispas.size():
		var b: Vector3 = _chispas[i]
		b.y -= dt * 22.0 * b.z
		b.x += sin(_t * 0.7 + i) * dt * 8.0
		if b.y < -10.0:
			b = Vector3(randf() * vs.x, vs.y + 10.0, randf_range(0.4, 1.0))
		_chispas[i] = b
	_brillo.queue_redraw()
	_titulo.modulate = Color(1, 0.94 + 0.06 * sin(_t * 1.5), 0.9 + 0.1 * sin(_t * 1.5))


func jugar() -> void:
	Estado.partida = {}
	Kit.change_scene(JUEGO)


func abrir_leyendas() -> void:
	_modal = Estilo.modal(self, Idioma.t("Libro de Leyendas"), 660.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(620, 560)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.add_theme_constant_override("separation", 12)
	sc.add_child(lista)
	var ls: Array = Estado.d["leyendas"] as Array
	if ls.is_empty():
		lista.add_child(Estilo.etiqueta(Idioma.t("Todavía no ha caído nadie. Que dure."), 24, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for x: Variant in ls:
		var l: Dictionary = x as Dictionary
		var et: Label = Estilo.etiqueta(Idioma.t("%s, %s de nivel %d.\nCayó en %s tras %d misiones.") % [str(l["nombre"]), Idioma.t(str((Datos.CLASES[str(l["clase"])] as Dictionary)["nombre"])).to_lower(),
			int(l["nivel"]), Idioma.t(str(l["donde"])), int(l["misiones"])], 22, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
		et.custom_minimum_size = Vector2(600, 0)
		lista.add_child(et)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(func() -> void:
		Estilo.cerrar(_modal)
		_modal = {})
	vb.add_child(bc)


func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func abrir_tienda() -> void:
	_modal = Estilo.modal(self, Idioma.t("Tienda"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var ps: Dictionary = Store.products()
	for id: Variant in ps.keys():
		var pid: String = str(id)
		var kind: String = str((ps[pid] as Dictionary).get("kind", ""))
		if kind in ["pass", "vip"] or Store.owns(pid) or (kind in ["no_ads", "bundle"] and Store.no_ads()):
			continue
		var b: Button = Estilo.boton("%s   ·   %s" % [Idioma.t(Store.label(pid)), Store.price(pid)], false, 76)
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(func() -> void: Store.buy(pid))
		vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 76)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)

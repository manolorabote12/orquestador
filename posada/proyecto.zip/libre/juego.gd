extends Node2D
## La Posada del Último Camino: la posada vista en corte, piso a piso. Llegan aventureros, beben, comen,
## duermen, se equipan y forman grupo en el tablón para bajar a la mazmorra. Vuelven con botín o no vuelven.
## Toda la lógica va en paso(dt) para que el bot pueda jugar horas sin pantalla.

const ANCHO: float = 720.0
## Alto visible (en móviles altos se ve más posada).
var ALTO: float = 1280.0
var _abajo: HBoxContainer
const H: float = Datos.ALTO_SALA
const X_ESCALERA: float = 38.0
const X_PUERTA: float = 770.0
const X_SALA: float = 70.0
const VEL: float = 150.0
const VEL_ESCALERA: float = 1.5
const HUD_ARRIBA: float = 128.0
const HUD_ABAJO: float = 150.0

var bot: bool = false
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var reloj: float = 0.0
var visitas: Array = []
var rt: Dictionary = {}
var ratas: Array = []
var t_llegada: float = 3.0
var t_evento: float = 150.0
var t_guardar: float = 10.0
var t_posadera: float = 0.0
var t_media: float = 0.0
var ganado_tramo: float = 0.0
var noble_t: float = 0.0
var stats: Dictionary = {"servicios": 0, "misiones": 0, "muertos": 0, "resucitados": 0, "grupos": 0, "oro": 0.0}

var cam: float = -1000.0
var _cam_obj: float = -1000.0
var _arrastre: bool = false
var _toque0: Vector2 = Vector2.ZERO
var _cam0: float = 0.0
var _movido: bool = false
var _tex: Dictionary = {}
var _particulas: Array = []
var _textos: Array = []
var _hud: CanvasLayer
var _raiz: Control
var _l_oro: Label
var _l_gemas: Label
var _l_fama: Label
var _l_rango: Label
var _l_hora: Label
var _l_aviso: Label
var _l_guia: Label
var _barra_rango: ProgressBar
var _modal: Dictionary = {}
var _t_aviso: float = 0.0
var _noche_f: float = 0.0
var _tiempo: float = 0.0
var pausa: bool = false


func _ready() -> void:
	Estado.cargar()
	bot = bool(Estado.partida.get("bot", false))
	if bot:
		Estado.reiniciar()
		rng.seed = int(Estado.partida.get("semilla", 7))
	else:
		rng.randomize()
		for id: String in ["p_fondo_dia", "p_fondo_noche", "p_oro", "p_gema", "p_cofre", "p_calavera"]:
			_tex[id] = Estilo.tex(id)
		for s: Variant in Datos.SALAS:
			_tex["p_" + str((s as Dictionary)["id"])] = Estilo.tex("p_" + str((s as Dictionary)["id"]))
		for c: Variant in Datos.CLASES.values():
			_tex[str((c as Dictionary)["tex"])] = Estilo.tex(str((c as Dictionary)["tex"]))
		for p: Variant in Datos.PERSONAL:
			_tex[str((p as Dictionary)["tex"])] = Estilo.tex(str((p as Dictionary)["tex"]))
	reloj = float(Estado.d["reloj"])
	for s: Variant in Datos.SALAS:
		rt[str((s as Dictionary)["id"])] = {"slots": [null, null, null, null], "caja": 0.0, "cola": []}
	cam = _cam_inicial()
	_cam_obj = cam
	if not bot:
		_hacer_hud()
		_fuera_de_casa()
		Audio.play_track("dia")
		if Consejo.mostrar(_raiz, "inicio"):
			pass


func _cam_inicial() -> float:
	## La planta baja (piso 0) se ve abajo, con sitio para los pisos de arriba.
	return -ALTO + HUD_ABAJO + 120.0


# ------------------------------------------------------------------ bucle

func _process(dt: float) -> void:
	if bot:
		return
	_tiempo += dt
	var vy: float = get_viewport_rect().size.y
	if vy != ALTO:
		_cam_obj += ALTO - vy if _cam_obj == cam else 0.0
		ALTO = vy
		if _abajo != null:
			_abajo.position.y = ALTO - 120.0
			_l_guia.position.y = ALTO - 220.0
	if not pausa:
		paso(dt)
	cam = lerpf(cam, _cam_obj, minf(1.0, dt * 10.0))
	_actualizar_particulas(dt)
	_hud_refrescar(dt)
	queue_redraw()


func paso(dt: float) -> void:
	reloj += dt
	var nf: float = 1.0 if es_noche() else 0.0
	_noche_f = lerpf(_noche_f, nf, minf(1.0, dt * 0.8))
	_llegadas(dt)
	for v: Variant in visitas:
		_visitante(v as Dictionary, dt)
	visitas = visitas.filter(func(v: Variant) -> bool: return not bool((v as Dictionary).get("fin", false)))
	_tablon(dt)
	_misiones()
	_personal(dt)
	_eventos(dt)
	_ratas(dt)
	## Media de oro por segundo (para lo que gana la posada mientras no juegas).
	t_media += dt
	if t_media >= 30.0:
		Estado.d["oro_seg"] = lerpf(float(Estado.d["oro_seg"]), ganado_tramo / t_media, 0.35)
		ganado_tramo = 0.0
		t_media = 0.0
	t_guardar -= dt
	if t_guardar <= 0.0:
		t_guardar = 10.0
		Estado.d["reloj"] = reloj
		Estado.guardar()


func es_noche() -> bool:
	return fmod(reloj, Datos.T_DIA + Datos.T_NOCHE) > Datos.T_DIA


func fiesta() -> bool:
	return float(Estado.d.get("fiesta", 0.0)) > reloj


# ------------------------------------------------------------------ llegadas

func _capacidad(id: String) -> int:
	var nv: int = Estado.nivel(id)
	return 0 if nv <= 0 else mini(4, 2 + int((nv - 1) / 6.0))


func _llegadas(dt: float) -> void:
	t_llegada -= dt
	if t_llegada > 0.0:
		return
	var fama: float = float(Estado.n("fama"))
	t_llegada = 8.0 / (1.0 + log(1.0 + fama / 20.0) * 0.35) * (2.2 if es_noche() else 1.0) * rng.randf_range(0.7, 1.3)
	var cap: int = 6
	for s: Variant in Datos.SALAS:
		cap += _capacidad(str((s as Dictionary)["id"]))
	if visitas.size() >= cap:
		return
	llega_alguien()


## Llega un aventurero: a veces uno conocido del registro, a veces uno nuevo.
func llega_alguien(nivel_min: int = 1, noble: bool = false) -> void:
	var h: Dictionary = {}
	var libres: Array = Estado.heroes().filter(func(x: Variant) -> bool:
		var y: Dictionary = x as Dictionary
		return not bool(y.get("fuera", false)) and not _presente(int(y["id"])))
	if nivel_min <= 1 and not libres.is_empty() and rng.randf() < 0.5:
		h = libres[rng.randi() % libres.size()] as Dictionary
	else:
		h = Estado.nuevo_heroe(rng, nivel_min)
	var v: Dictionary = {"h": h, "x": X_PUERTA + rng.randf_range(0, 40), "piso": 0.0, "plan": _plan(), "estado": "ir", "t": 0.0, "slot": -1,
		"dir": -1, "anim": rng.randf() * 3.0, "noble": noble, "sala": ""}
	h["equipo"] = 0.0
	visitas.append(v)
	Estado.d["visitas"] = Estado.n("visitas") + 1
	if Estado.n("visitas") >= 500:
		_logro("visitas500")


func _presente(id: int) -> bool:
	for v: Variant in visitas:
		if int(((v as Dictionary)["h"] as Dictionary)["id"]) == id:
			return true
	return false


func _plan() -> Array:
	var p: Array = ["taberna"]
	var probs: Dictionary = {"cocina": 0.8, "bodega": 0.45, "dormitorio": 0.95 if es_noche() else 0.4, "herreria": 0.7, "alquimista": 0.6, "templo": 0.5}
	for id: String in ["cocina", "bodega", "dormitorio", "herreria", "alquimista", "templo"]:
		if Estado.nivel(id) > 0 and rng.randf() < float(probs[id]):
			p.append(id)
	if Estado.nivel("tablon") > 0:
		p.append("tablon")
	return p


# ------------------------------------------------------------------ visitantes

func piso_de(id: String) -> float:
	return float(Datos.sala(id)["piso"])


func _x_slot(i: int) -> float:
	return 215.0 + i * 140.0


## Camina hacia (piso, x) usando la escalera de la izquierda. Devuelve true al llegar.
func _andar(v: Dictionary, piso: float, x: float, dt: float) -> bool:
	var p: float = float(v["piso"])
	if absf(p - piso) > 0.001:
		if float(v["x"]) > X_ESCALERA + 2.0:
			v["x"] = maxf(X_ESCALERA, float(v["x"]) - VEL * dt)
			v["dir"] = -1
		else:
			v["piso"] = move_toward(p, piso, VEL_ESCALERA * dt)
		return false
	var dx: float = x - float(v["x"])
	if absf(dx) < 3.0:
		return true
	v["dir"] = 1 if dx > 0.0 else -1
	v["x"] = float(v["x"]) + signf(dx) * minf(absf(dx), VEL * dt)
	return false


func _visitante(v: Dictionary, dt: float) -> void:
	v["anim"] = float(v["anim"]) + dt
	match str(v["estado"]):
		"ir":
			var plan: Array = v["plan"] as Array
			if plan.is_empty():
				v["estado"] = "salir"
				return
			var id: String = str(plan[0])
			var r: Dictionary = rt[id] as Dictionary
			if int(v["slot"]) < 0:
				var slots: Array = r["slots"] as Array
				for i: int in _capacidad(id):
					if slots[i] == null:
						slots[i] = v
						v["slot"] = i
						break
			var xo: float = _x_slot(int(v["slot"])) if int(v["slot"]) >= 0 else 110.0 + float((r["cola"] as Array).size() % 3) * 24.0
			if _andar(v, piso_de(id), xo, dt):
				if int(v["slot"]) >= 0:
					v["estado"] = "servir" if id != "tablon" else "esperar"
					v["sala"] = id
					v["t"] = _duracion(id)
					v["dir"] = 1 if rng.randf() < 0.5 else -1
				else:
					## No hay sitio: se salta esta sala (o espera un poco si es la última).
					if plan.size() > 1 and float(v["t"]) > 4.0:
						plan.pop_front()
						v["t"] = 0.0
					v["t"] = float(v["t"]) + dt
		"servir":
			v["t"] = float(v["t"]) - dt
			if float(v["t"]) <= 0.0:
				_cobrar(v)
				_soltar_slot(v)
				(v["plan"] as Array).pop_front()
				v["estado"] = "ir"
				v["t"] = 0.0
		"esperar":
			v["t"] = float(v["t"]) + dt
		"salir":
			if _andar(v, 0.0, X_PUERTA + 40.0, dt):
				v["fin"] = true
				if not bool(v.get("a_mision", false)):
					var h: Dictionary = v["h"] as Dictionary
					if int(h["nivel"]) >= 2 or int(h["misiones"]) > 0:
						Estado.registrar(h)


func _soltar_slot(v: Dictionary) -> void:
	var id: String = str(v["sala"])
	if id != "" and int(v["slot"]) >= 0:
		((rt[id] as Dictionary)["slots"] as Array)[int(v["slot"])] = null
	v["slot"] = -1
	v["sala"] = ""


func _duracion(id: String) -> float:
	var t: float = float(Datos.sala(id)["t"]) / (1.0 + 0.06 * (Estado.nivel(id) - 1))
	if id == "cocina":
		t /= 1.0 + 0.35 * Estado.nivel_personal("cocinero")
	return t * rng.randf_range(0.85, 1.2)


func multiplicador(id: String) -> float:
	var m: float = 1.0 + 0.05 * Estado.nivel("bodega")
	if fiesta():
		m *= 2.0
	if id == "dormitorio" and es_noche():
		m *= 1.6
	if id == "cocina":
		m *= 1.0 + 0.2 * Estado.nivel_personal("cocinero")
	if id == "alquimista":
		m *= 1.0 + 0.2 * Estado.nivel_personal("alquimista_pj")
	if id == "taberna" and _hay_bardo():
		m *= 1.5
	return m


func _hay_bardo() -> bool:
	for v: Variant in visitas:
		var d: Dictionary = v as Dictionary
		if str((d["h"] as Dictionary)["clase"]) == "bardo" and str(d["sala"]) == "taberna":
			return true
	return false


func _cobrar(v: Dictionary) -> void:
	var id: String = str(v["sala"])
	var h: Dictionary = v["h"] as Dictionary
	var oro: float = Datos.precio(id, Estado.nivel(id)) * multiplicador(id) * (1.0 + 0.03 * (int(h["nivel"]) - 1))
	if bool(v.get("noble", false)):
		oro *= 5.0
	_a_caja(id, oro, Vector2(float(v["x"]), _y_suelo(float(v["piso"])) - 140.0))
	stats["servicios"] = int(stats["servicios"]) + 1
	if int(stats["servicios"]) == 1:
		_logro("primer")
	## Equipo para la mazmorra.
	var eq: float = float(h.get("equipo", 0.0))
	match id:
		"herreria":
			eq += 0.012 * Estado.nivel(id) * (1.0 + 0.6 * Estado.nivel_personal("herrero"))
		"alquimista":
			eq += 0.01 * Estado.nivel(id) * (1.0 + 0.5 * Estado.nivel_personal("alquimista_pj"))
		"templo":
			eq += 0.006 * Estado.nivel(id)
	h["equipo"] = minf(eq, 0.22)


func _a_caja(id: String, oro: float, p: Vector2) -> void:
	var r: Dictionary = rt[id] as Dictionary
	r["caja"] = float(r["caja"]) + oro
	ganado_tramo += oro
	if not bot and _visible(p.y):
		_textos.append({"s": "+" + num(oro), "p": p, "t": 1.0, "c": Color("ffd75e")})
		Audio.play("ui_coin", 0.2, -16.0, 1.4)


## Recoge las monedas de una sala.
func recoger(id: String) -> float:
	var r: Dictionary = rt[id] as Dictionary
	var o: float = float(r["caja"])
	if o <= 0.0:
		return 0.0
	r["caja"] = 0.0
	Estado.d["oro"] = Estado.oro() + o
	Estado.d["oro_total"] = float(Estado.d["oro_total"]) + o
	stats["oro"] = float(stats["oro"]) + o
	if float(Estado.d["oro_total"]) >= 1000000.0:
		_logro("oro1m")
	if not bot:
		var y: float = _y_suelo(piso_de(id)) - H + 50.0 - cam
		for i: int in mini(14, 3 + int(log(o + 1.0))):
			_particulas.append({"p": Vector2(620.0, y), "v": Vector2(rng.randf_range(-160, 60), rng.randf_range(-260, -60)), "t": rng.randf_range(0.5, 0.9),
				"c": Color("ffd75e"), "r": rng.randf_range(4, 7), "g": 0.0, "a": Vector2(60.0, 60.0)})
		Audio.play("ui_coin", 0.1, -6.0)
		Juice.vibrate(10)
	return o


func recoger_todo() -> float:
	var t: float = 0.0
	for id: String in rt.keys():
		t += recoger(id) if bot else 0.0
	if not bot:
		for id: String in rt.keys():
			t += recoger(id)
	return t


# ------------------------------------------------------------------ tablón y misiones

func mazmorra() -> Dictionary:
	return Datos.MAZMORRAS[clampi(Estado.n("mazmorra"), 0, Datos.MAZMORRAS.size() - 1)] as Dictionary


func _tablon(_dt: float) -> void:
	var esperan: Array = visitas.filter(func(v: Variant) -> bool: return str((v as Dictionary)["estado"]) == "esperar")
	if esperan.is_empty():
		return
	var viejo: float = 0.0
	for v: Variant in esperan:
		viejo = maxf(viejo, float((v as Dictionary)["t"]))
	if esperan.size() < 3 and viejo < 9.0:
		return
	var grupo: Array = esperan.slice(0, 4)
	var hs: Array = []
	for v: Variant in grupo:
		var d: Dictionary = v as Dictionary
		_soltar_slot(d)
		d["estado"] = "salir"
		d["a_mision"] = true
		var h: Dictionary = d["h"] as Dictionary
		h["fuera"] = true
		Estado.registrar(h)
		hs.append(int(h["id"]))
	var mz: Dictionary = mazmorra()
	var rapido: float = 0.0
	for id: Variant in hs:
		var h2: Dictionary = _heroe(int(id))
		rapido += float((Datos.CLASES[str(h2["clase"])] as Dictionary).get("rapido", 0.0))
	var dur: float = float(mz["dur"]) * (1.0 - minf(0.5, rapido))
	(Estado.d["en_mision"] as Array).append({"heroes": hs, "mz": Estado.n("mazmorra"), "fin": reloj + dur, "dur": dur})
	stats["grupos"] = int(stats["grupos"]) + 1
	if not bot:
		_avisar(Idioma.t("¡Un grupo parte hacia %s!") % Idioma.t(str(mz["nombre"])))
		Audio.play("ui_whoosh", 0.1, -6.0)
		Consejo.mostrar(_raiz, "mision")


func _heroe(id: int) -> Dictionary:
	for x: Variant in Estado.heroes():
		if int((x as Dictionary)["id"]) == id:
			return x as Dictionary
	return {}


## Resuelve las misiones que han acabado: quién muere, cuánto oro y fama traen.
func _misiones() -> void:
	var ms: Array = Estado.d["en_mision"] as Array
	if ms.is_empty():
		return
	var quedan: Array = []
	var vueltas: int = 0
	for m: Variant in ms:
		var md: Dictionary = m as Dictionary
		if float(md["fin"]) > reloj:
			quedan.append(md)
			continue
		vueltas += 1
		_resolver(md, vueltas > 6)
	Estado.d["en_mision"] = quedan


func _resolver(md: Dictionary, sin_visita: bool) -> void:
	var idx: int = int(md["mz"])
	var mz: Dictionary = Datos.MAZMORRAS[idx] as Dictionary
	var hs: Array = []
	for id: Variant in (md["heroes"] as Array):
		var h: Dictionary = _heroe(int(id))
		if not h.is_empty():
			hs.append(h)
	if hs.is_empty():
		return
	var mod_riesgo: float = 0.0
	var mod_oro: float = 0.0
	var mod_gemas: float = 0.0
	for h: Variant in hs:
		var c: Dictionary = Datos.CLASES[str((h as Dictionary)["clase"])] as Dictionary
		mod_riesgo += float(c.get("riesgo", 0.0))
		mod_oro += float(c.get("oro", 0.0))
		mod_gemas += float(c.get("gemas", 0.0))
	## Cuantos más van juntos, más seguros.
	mod_riesgo -= 0.015 * (hs.size() - 1)
	var vivos: Array = []
	for x: Variant in hs:
		var h: Dictionary = x as Dictionary
		var falta: int = maxi(0, int(mz["nivel"]) - int(h["nivel"]))
		var riesgo: float = clampf(float(mz["riesgo"]) + 0.05 * falta - 0.004 * int(h["nivel"]) + mod_riesgo - float(h.get("equipo", 0.0)), 0.01, 0.75)
		h["equipo"] = 0.0
		h["fuera"] = false
		if rng.randf() < riesgo:
			## La capilla a veces los devuelve.
			if Estado.nivel("templo") > 0 and rng.randf() < 0.025 * Estado.nivel("templo"):
				stats["resucitados"] = int(stats["resucitados"]) + 1
				_logro("resucita")
				if not bot:
					_avisar(Idioma.t("¡Milagro! %s vuelve de entre los muertos.") % str(h["nombre"]))
			else:
				Estado.leyenda(h, str(mz["nombre"]))
				Estado.quitar_heroe(int(h["id"]))
				Estado.d["muertos"] = Estado.n("muertos") + 1
				stats["muertos"] = int(stats["muertos"]) + 1
				_logro("leyenda")
				if not bot:
					_avisar(Idioma.t("%s no volvió de %s.") % [str(h["nombre"]), Idioma.t(str(mz["nombre"]))])
					Consejo.mostrar(_raiz, "leyenda")
				continue
		vivos.append(h)
		h["misiones"] = int(h["misiones"]) + 1
		if Estado.ganar_xp(h, 2 + idx * 2):
			if int(h["nivel"]) >= 10:
				_logro("nivel10")
			if int(h["nivel"]) >= 20:
				_logro("nivel20")
	if vivos.is_empty():
		return
	var nivel_medio: float = 0.0
	for h: Variant in vivos:
		nivel_medio += float((h as Dictionary)["nivel"])
	nivel_medio /= vivos.size()
	var oro: float = float(mz["oro"]) * vivos.size() * 0.5 * (1.0 + mod_oro) * (1.0 + 0.04 * nivel_medio)
	var fama: int = int(mz["fama_da"])
	Estado.d["fama"] = Estado.n("fama") + fama
	Estado.d["misiones"] = Estado.n("misiones") + 1
	stats["misiones"] = int(stats["misiones"]) + 1
	_logro("mision")
	if str(mz["id"]) == "dragon":
		_logro("dragon")
	if str(mz["id"]) == "abismo":
		_logro("abismo")
	if Datos.rango(Estado.n("fama")) >= 6:
		_logro("fortaleza")
	var gemas: int = 0
	if rng.randf() < 0.07 * (1.0 + idx * 0.35) + mod_gemas:
		gemas = 1 + int(idx / 3.0)
		Estado.d["gemas"] = Estado.n("gemas") + gemas
	if sin_visita or bot:
		## Llegan demasiados a la vez: el botín va directo a la caja.
		_a_caja("taberna", oro, Vector2(400, -150))
		for h: Variant in vivos:
			if bot and rng.randf() < 0.6:
				continue
		if bot:
			_volver(vivos, oro, gemas, true)
		return
	_volver(vivos, oro, gemas, false)


## El grupo vuelve por la puerta con el botín.
func _volver(vivos: Array, oro: float, gemas: int, ya_pagado: bool) -> void:
	for i: int in vivos.size():
		var h: Dictionary = vivos[i] as Dictionary
		if _presente(int(h["id"])):
			continue
		var plan: Array = ["taberna"]
		if Estado.nivel("dormitorio") > 0 and rng.randf() < 0.6:
			plan.append("dormitorio")
		visitas.append({"h": h, "x": X_PUERTA + i * 36.0, "piso": 0.0, "plan": plan, "estado": "ir", "t": 0.0, "slot": -1, "dir": -1,
			"anim": rng.randf() * 3.0, "noble": false, "sala": "", "botin": i == 0, "vuelta": true})
	if not ya_pagado:
		_a_caja("taberna", oro, Vector2(560.0, _y_suelo(0.0) - 200.0))
	if not bot:
		var s: String = Idioma.t("¡Vuelven de la mazmorra! +%s oro") % num(oro)
		if gemas > 0:
			s += "  +%d ◆" % gemas
		_avisar(s)
		Audio.play("ui_reward", 0.0, -4.0)
		Juice.vibrate(25)


# ------------------------------------------------------------------ personal, eventos y bichos

func _personal(dt: float) -> void:
	var nv: int = Estado.nivel_personal("posadera")
	if nv <= 0:
		return
	t_posadera -= dt
	if t_posadera > 0.0:
		return
	t_posadera = 14.0 / nv
	for id: String in rt.keys():
		if float((rt[id] as Dictionary)["caja"]) > 0.0:
			recoger(id)


func _eventos(dt: float) -> void:
	t_evento -= dt
	if t_evento > 0.0:
		return
	t_evento = rng.randf_range(110.0, 190.0)
	var r: float = rng.randf()
	if r < 0.4 and Estado.salas_hechas() >= 2:
		var hechas: Array = (Estado.d["salas"] as Dictionary).keys()
		var id: String = str(hechas[rng.randi() % hechas.size()])
		ratas.append({"sala": id, "x": rng.randf_range(200, 620), "dir": 1, "vida": 3, "t": 0.0})
		if not bot:
			_avisar(Idioma.t("¡Un bicho en %s! Tócalo para echarlo.") % Idioma.t(str(Datos.sala(id)["nombre"])))
	elif r < 0.75:
		for i: int in 5 + rng.randi() % 3:
			llega_alguien()
		if not bot:
			_avisar(Idioma.t("¡Una caravana para en la posada!"))
	else:
		llega_alguien(1, true)
		if not bot:
			_avisar(Idioma.t("¡Llega un noble! Paga cinco veces más."))


func _ratas(dt: float) -> void:
	for r: Variant in ratas:
		var d: Dictionary = r as Dictionary
		d["t"] = float(d["t"]) + dt
		d["x"] = float(d["x"]) + int(d["dir"]) * 90.0 * dt
		if float(d["x"]) > 660.0 or float(d["x"]) < 110.0 or rng.randf() < dt * 0.4:
			d["dir"] = -int(d["dir"])
		## Si nadie la echa, se come parte de la caja.
		if float(d["t"]) > 35.0:
			var c: Dictionary = rt[str(d["sala"])] as Dictionary
			c["caja"] = float(c["caja"]) * 0.7
			d["fin"] = true
			if not bot:
				_avisar(Idioma.t("El bicho se ha comido parte de las propinas."))
	ratas = ratas.filter(func(r: Variant) -> bool: return not bool((r as Dictionary).get("fin", false)))


func golpear_rata(i: int) -> void:
	var d: Dictionary = ratas[i] as Dictionary
	d["vida"] = int(d["vida"]) - 1
	d["dir"] = -int(d["dir"])
	d["x"] = float(d["x"]) + int(d["dir"]) * 40.0
	if not bot:
		Juice.vibrate(20)
		Audio.play("ui_tick", 0.2, -4.0, 0.7)
		_chispas(Vector2(float(d["x"]), _y_suelo(piso_de(str(d["sala"]))) - 20.0 - cam), Color(0.6, 0.5, 0.4), 8)
	if int(d["vida"]) <= 0:
		d["fin"] = true
		ratas.remove_at(i)
		Estado.d["gemas"] = Estado.n("gemas") + 1
		Estado.d["ratas"] = Estado.n("ratas") + 1
		if Estado.n("ratas") >= 10:
			_logro("rata")
		if not bot:
			_texto_mundo("+1 ◆", Vector2(float(d["x"]), _y_suelo(piso_de(str(d["sala"]))) - 80.0), Color("8fd3ff"))
			Audio.play("ui_reward", 0.0, -6.0)


func encargo(id: String) -> bool:
	var e: Dictionary = {}
	for x: Variant in Datos.ENCARGOS:
		if str((x as Dictionary)["id"]) == id:
			e = x as Dictionary
	if e.is_empty() or Estado.n("gemas") < int(e["gemas"]):
		return false
	Estado.d["gemas"] = Estado.n("gemas") - int(e["gemas"])
	match id:
		"fiesta":
			Estado.d["fiesta"] = maxf(float(Estado.d.get("fiesta", 0.0)), reloj) + 180.0
			if not bot:
				_avisar(Idioma.t("¡Fiesta! Todo cobra el doble."))
		"pregon":
			for i: int in 8:
				llega_alguien()
		"heroe":
			var mejor: int = 3
			for x: Variant in Estado.heroes():
				mejor = maxi(mejor, int((x as Dictionary)["nivel"]))
			llega_alguien(maxi(4, mejor - 1))
	Estado.guardar()
	return true


func _logro(id: String) -> void:
	var l: Dictionary = Estado.logro(id)
	if l.is_empty() or bot:
		return
	_avisar(Idioma.t("Logro: %s  (+%d ◆)") % [Idioma.t(str(l["nombre"])), int(l["premio"])])
	Audio.play("ui_reward")


## Lo que ha ganado la posada mientras no jugabas.
func _fuera_de_casa() -> void:
	var antes: int = int(Estado.d.get("guardado_unix", 0))
	if antes <= 0:
		return
	var seg: float = float(int(Time.get_unix_time_from_system()) - antes)
	if seg < 60.0:
		return
	var tope: float = (2.0 + 0.5 * Estado.nivel("bodega")) * 3600.0
	var oro: float = float(Estado.d["oro_seg"]) * minf(seg, tope) * 0.6
	var grupos: int = 0
	for m: Variant in (Estado.d["en_mision"] as Array):
		if float((m as Dictionary)["fin"]) <= reloj + seg:
			grupos += 1
	reloj += seg
	Estado.d["oro"] = Estado.oro() + oro
	Estado.d["oro_total"] = float(Estado.d["oro_total"]) + oro
	var m2: Dictionary = Estilo.modal(_raiz, Idioma.t("Mientras no estabas"), 600.0)
	var vb: VBoxContainer = m2["vb"] as VBoxContainer
	var txt: String = Idioma.t("La posada ha ganado %s de oro.") % num(oro)
	if grupos > 0:
		txt += "\n" + Idioma.t("%d grupos vuelven de la mazmorra.") % grupos
	var l: Label = Estilo.etiqueta(txt, 28, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(540, 0)
	vb.add_child(l)
	var b: Button = Estilo.boton(Idioma.t("¡A trabajar!"), true, 84)
	b.pressed.connect(func() -> void: Estilo.cerrar(m2))
	vb.add_child(b)


# ------------------------------------------------------------------ entrada

func _unhandled_input(e: InputEvent) -> void:
	if bot or not _modal.is_empty() or pausa:
		return
	if e is InputEventScreenTouch or e is InputEventMouseButton:
		var pulsado: bool = e.pressed if e is InputEventScreenTouch else (e as InputEventMouseButton).pressed and (e as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT
		var pos: Vector2 = (e as InputEventScreenTouch).position if e is InputEventScreenTouch else (e as InputEventMouseButton).position
		if e is InputEventMouseButton and (e as InputEventMouseButton).button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
			_cam_obj = _limitar(_cam_obj + (-80.0 if (e as InputEventMouseButton).button_index == MOUSE_BUTTON_WHEEL_UP else 80.0))
			return
		if pulsado:
			_arrastre = true
			_movido = false
			_toque0 = pos
			_cam0 = _cam_obj
		elif _arrastre:
			_arrastre = false
			if not _movido:
				_tocar(pos)
	elif (e is InputEventScreenDrag or e is InputEventMouseMotion) and _arrastre:
		var pos2: Vector2 = (e as InputEventScreenDrag).position if e is InputEventScreenDrag else (e as InputEventMouseMotion).position
		if absf(pos2.y - _toque0.y) > 14.0:
			_movido = true
		if _movido:
			_cam_obj = _limitar(_cam0 - (pos2.y - _toque0.y))


func _limitar(c: float) -> float:
	var arriba: float = -(_piso_max() + 2.0) * H - 260.0 - HUD_ARRIBA
	var abajo: float = (H + 60.0 if _bodega_visible() else 160.0) - ALTO + HUD_ABAJO
	return clampf(c, arriba, maxf(arriba, abajo))


func _piso_max() -> float:
	var m: float = 0.0
	for s: Variant in Datos.SALAS:
		var sd: Dictionary = s as Dictionary
		if Estado.nivel(str(sd["id"])) > 0:
			m = maxf(m, float(sd["piso"]))
	return m


func _bodega_visible() -> bool:
	var sig: Dictionary = Estado.siguiente_sala()
	return Estado.nivel("bodega") > 0 or (not sig.is_empty() and str(sig["id"]) == "bodega")


func _tocar(pos: Vector2) -> void:
	if pos.y < HUD_ARRIBA or pos.y > ALTO - HUD_ABAJO:
		return
	var wy: float = pos.y + cam
	## Bichos primero.
	for i: int in ratas.size():
		var d: Dictionary = ratas[i] as Dictionary
		var ry: float = _y_suelo(piso_de(str(d["sala"]))) - 20.0
		if Vector2(float(d["x"]), ry).distance_to(Vector2(pos.x, wy)) < 70.0:
			golpear_rata(i)
			return
	var piso: float = floor(-wy / H)
	for s: Variant in Datos.SALAS:
		var sd: Dictionary = s as Dictionary
		if float(sd["piso"]) != piso:
			continue
		var id: String = str(sd["id"])
		if Estado.nivel(id) <= 0:
			if not Estado.siguiente_sala().is_empty() and str(Estado.siguiente_sala()["id"]) == id:
				abrir_construir(id)
			return
		## Monedas: arriba a la derecha de la sala.
		var top: float = _y_suelo(piso) - H
		if float((rt[id] as Dictionary)["caja"]) > 0.0 and Vector2(620.0, top + 50.0).distance_to(Vector2(pos.x, wy)) < 90.0:
			recoger(id)
			return
		if float((rt[id] as Dictionary)["caja"]) > 0.0 and Estado.nivel_personal("posadera") == 0:
			recoger(id)
			return
		abrir_sala(id)
		return


# ------------------------------------------------------------------ dibujo

func _y_suelo(piso: float) -> float:
	## Línea del suelo de un piso (coordenadas del mundo): la planta baja acaba en y=0.
	return -piso * H


func _visible(wy: float) -> bool:
	return wy - cam > -100.0 and wy - cam < ALTO + 100.0


func _draw() -> void:
	_dibujar_cielo()
	var pm: float = _piso_max()
	## Tierra bajo la posada.
	var ys: float = _y_suelo(0.0) - cam
	draw_rect(Rect2(0, ys, ANCHO, ALTO), Color("2a1d14"))
	for i: int in 30:
		var px: float = fmod(i * 137.0, ANCHO)
		var py: float = ys + 20.0 + fmod(i * 71.0, 700.0)
		draw_circle(Vector2(px, py), 4.0 + fmod(i * 13.0, 9.0), Color("3a2a1e"))
	## Camino y hierba a ras de suelo.
	draw_rect(Rect2(0, ys - 4.0, ANCHO, 10.0), Color("4b6b2f").lerp(Color("1d2a1a"), _noche_f))
	## Salas.
	for s: Variant in Datos.SALAS:
		var sd: Dictionary = s as Dictionary
		var id: String = str(sd["id"])
		if Estado.nivel(id) > 0:
			_dibujar_sala(sd)
	var sig: Dictionary = Estado.siguiente_sala()
	if not sig.is_empty():
		_dibujar_obra(sig)
	_dibujar_escalera(pm)
	_dibujar_tejado(pm + (1.0 if not sig.is_empty() and float(sig["piso"]) > pm else 0.0))
	## Gente.
	var orden: Array = visitas.duplicate()
	orden.sort_custom(func(a: Variant, b: Variant) -> bool: return float((a as Dictionary)["x"]) < float((b as Dictionary)["x"]))
	for v: Variant in orden:
		_dibujar_visitante(v as Dictionary)
	for r: Variant in ratas:
		_dibujar_rata(r as Dictionary)
	for s: Variant in Datos.SALAS:
		var sd2: Dictionary = s as Dictionary
		if Estado.nivel(str(sd2["id"])) > 0:
			_dibujar_caja(sd2)
	_dibujar_particulas()


func _dibujar_cielo() -> void:
	var dia: Texture2D = _tex.get("p_fondo_dia") as Texture2D
	var noche: Texture2D = _tex.get("p_fondo_noche") as Texture2D
	var desp: float = clampf(-cam * 0.08, -200.0, 200.0)
	var r: Rect2 = Rect2(-20, -120 + desp * 0.3, ANCHO + 40, ALTO + 240)
	if dia != null:
		draw_texture_rect(dia, r, false)
	if noche != null and _noche_f > 0.01:
		draw_texture_rect(noche, r, false, Color(1, 1, 1, _noche_f))
	draw_rect(Rect2(0, 0, ANCHO, ALTO), Color(0.02, 0.02, 0.06, 0.25 * _noche_f))


func _dibujar_sala(sd: Dictionary) -> void:
	var id: String = str(sd["id"])
	var piso: float = float(sd["piso"])
	var top: float = _y_suelo(piso) - H - cam
	if top > ALTO or top + H < 0.0:
		return
	var tx: Texture2D = _tex.get("p_" + id) as Texture2D
	var r: Rect2 = Rect2(X_SALA, top, ANCHO - X_SALA, H)
	if tx != null:
		draw_texture_rect(tx, r, false, Color(1, 1, 1).lerp(Color(0.85, 0.72, 0.6), _noche_f * 0.6))
	else:
		draw_rect(r, Color("5a3b26"))
	## Luz de velas que tiembla (más cálida de noche).
	var parpadeo: float = 0.05 + 0.025 * sin(_tiempo * 7.0 + piso * 2.0) + 0.015 * sin(_tiempo * 13.0)
	draw_circle(Vector2(400.0, top + 120.0), 260.0, Color(1.0, 0.65, 0.3, parpadeo * (0.6 + _noche_f)))
	## Vigas de madera entre pisos.
	draw_rect(Rect2(X_SALA - 6.0, top - 8.0, ANCHO - X_SALA + 12.0, 14.0), Color("3b2414"))
	draw_rect(Rect2(X_SALA - 6.0, top + H - 6.0, ANCHO - X_SALA + 12.0, 14.0), Color("3b2414"))
	draw_rect(Rect2(ANCHO - 10.0, top, 10.0, H), Color("3b2414"))
	## Placa con el nombre.
	var f: Font = Estilo.fuente()
	var nom: String = Idioma.t(str(sd["nombre"])) + "  ·  " + Idioma.t("Nv %d") % Estado.nivel(id)
	var an_nom: float = f.get_string_size(nom, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x + 24.0
	draw_rect(Rect2(X_SALA + 10.0, top + 12.0, an_nom, 34.0), Color(0.12, 0.07, 0.04, 0.78))
	draw_string(f, Vector2(X_SALA + 22.0, top + 37.0), nom, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("f6e2b8"))
	## Personal trabajando en su sala.
	for p: Variant in Datos.PERSONAL:
		var pd: Dictionary = p as Dictionary
		if str(pd["sala"]) == id and Estado.nivel_personal(str(pd["id"])) > 0:
			var bote: float = sin(_tiempo * 2.0 + piso) * 2.0
			_sombra(110.0, top + H - 14.0, 30.0)
			_sprite(str(pd["tex"]), 110.0, top + H - 12.0 - bote, 128.0, false)
	## Efectos de cada sala.
	if not bot and rng.randf() < 0.15:
		match id:
			"cocina":
				_particulas.append({"p": Vector2(rng.randf_range(380, 520), top + 150.0), "v": Vector2(rng.randf_range(-8, 8), -40.0), "t": 1.4, "c": Color(1, 1, 1, 0.18), "r": rng.randf_range(10, 18), "g": -6.0, "mundo": true, "wy": top + cam + 150.0})
			"herreria":
				if rng.randf() < 0.4:
					_chispas(Vector2(rng.randf_range(450, 560), top + 190.0), Color(1.0, 0.6, 0.2), 3)
			"alquimista":
				_particulas.append({"p": Vector2(rng.randf_range(300, 420), top + 200.0), "v": Vector2(0, -30.0), "t": 1.2, "c": Color(0.5, 1.0, 0.6, 0.35), "r": rng.randf_range(3, 6), "g": -10.0, "mundo": true, "wy": top + cam + 200.0})
			"templo":
				_particulas.append({"p": Vector2(rng.randf_range(300, 520), top + 120.0), "v": Vector2(0, 14.0), "t": 1.5, "c": Color(1.0, 0.95, 0.7, 0.3), "r": 3.0, "g": 0.0, "mundo": true, "wy": top + cam + 120.0})


func _dibujar_obra(sd: Dictionary) -> void:
	var piso: float = float(sd["piso"])
	var top: float = _y_suelo(piso) - H - cam
	if top > ALTO or top + H < 0.0:
		return
	var r: Rect2 = Rect2(X_SALA, top, ANCHO - X_SALA, H)
	draw_rect(r, Color(0.16, 0.1, 0.06, 0.55))
	## Andamio.
	for i: int in 6:
		var x: float = X_SALA + 20.0 + i * 110.0
		draw_line(Vector2(x, top + 10.0), Vector2(x, top + H - 10.0), Color("8a6239"), 8.0)
	for j: int in 3:
		draw_line(Vector2(X_SALA, top + 40.0 + j * 100.0), Vector2(ANCHO, top + 40.0 + j * 100.0), Color("6e4b2a"), 6.0)
	draw_line(Vector2(X_SALA, top + H - 10.0), Vector2(ANCHO, top + 10.0), Color("6e4b2a"), 5.0)
	var puede: bool = Estado.n("fama") >= int(sd["fama"])
	var f: Font = Estilo.fuente()
	draw_rect(Rect2(150, top + 90.0, 470, 120), Color(0.1, 0.06, 0.03, 0.88))
	draw_rect(Rect2(150, top + 90.0, 470, 120), Color("c79a4a"), false, 3.0)
	draw_string(f, Vector2(150, top + 135.0), Idioma.t("Construir: %s") % Idioma.t(str(sd["nombre"])), HORIZONTAL_ALIGNMENT_CENTER, 470, 28, Color("ffe2a8"))
	var linea: String = (Idioma.t("%s oro") % num(float(sd["coste"]))) if puede else Idioma.t("Necesitas %d de fama") % int(sd["fama"])
	var ok: bool = puede and Estado.oro() >= float(sd["coste"])
	draw_string(f, Vector2(150, top + 180.0), linea, HORIZONTAL_ALIGNMENT_CENTER, 470, 24, Color("9be07a") if ok else Color("e0b080"))


func _dibujar_escalera(pm: float) -> void:
	var arriba: float = _y_suelo(pm + 1.0) - cam
	var abajo: float = _y_suelo(-1.0 if Estado.nivel("bodega") > 0 else 0.0) - cam
	draw_rect(Rect2(0, arriba, X_SALA, abajo - arriba), Color("2e1c10"))
	var y: float = arriba
	while y < abajo:
		draw_line(Vector2(6, y), Vector2(X_SALA - 6, y + 14.0), Color("5b3a22"), 6.0)
		y += 34.0
	draw_rect(Rect2(X_SALA - 8.0, arriba, 8.0, abajo - arriba), Color("1e120a"))


func _dibujar_tejado(pm: float) -> void:
	var base: float = _y_suelo(pm) - H - cam
	if base < -200.0 or base > ALTO + 200.0:
		return
	var pts: PackedVector2Array = PackedVector2Array([Vector2(-20, base + 6.0), Vector2(ANCHO + 20, base + 6.0), Vector2(ANCHO - 120, base - 150.0), Vector2(120, base - 150.0)])
	draw_colored_polygon(pts, Color("6b2f22").lerp(Color("2d1712"), _noche_f * 0.6))
	for i: int in 6:
		var y: float = base - 20.0 - i * 24.0
		var a: float = 20.0 + i * 17.0
		draw_line(Vector2(a - 20.0, y), Vector2(ANCHO - a + 20.0, y), Color("4b1f16"), 3.0)
	## Chimenea con humo.
	draw_rect(Rect2(520, base - 210.0, 54, 90), Color("5a4a44"))
	draw_rect(Rect2(512, base - 216.0, 70, 14), Color("3e322e"))
	if not bot and rng.randf() < 0.2:
		_particulas.append({"p": Vector2(547, base - 220.0), "v": Vector2(rng.randf_range(10, 30), -50.0), "t": 2.2, "c": Color(0.75, 0.75, 0.78, 0.25), "r": rng.randf_range(10, 20), "g": -4.0, "mundo": true, "wy": base + cam - 220.0})
	## Letrero.
	var f: Font = Estilo.fuente()
	draw_rect(Rect2(170, base - 118.0, 380, 64), Color("2a1a0e"))
	draw_rect(Rect2(170, base - 118.0, 380, 64), Color("c79a4a"), false, 3.0)
	draw_string(f, Vector2(170, base - 76.0), Idioma.t(str((Datos.RANGOS[Datos.rango(Estado.n("fama"))] as Dictionary)["nombre"])), HORIZONTAL_ALIGNMENT_CENTER, 380, 28, Color("ffd98a"))


func _dibujar_visitante(v: Dictionary) -> void:
	var h: Dictionary = v["h"] as Dictionary
	var y: float = _y_suelo(float(v["piso"])) - 12.0 - cam
	if y < -50.0 or y > ALTO + 200.0:
		return
	var x: float = float(v["x"])
	var anda: bool = str(v["estado"]) in ["ir", "salir"]
	var a: float = float(v["anim"])
	var bote: float = absf(sin(a * 9.0)) * 6.0 if anda else sin(a * 2.0) * 1.5
	var alto: float = 132.0
	var inclina: float = sin(a * 9.0) * 0.05 if anda else 0.0
	var mod: Color = Color.WHITE
	if bool(v.get("noble", false)):
		mod = Color(1.25, 1.15, 0.8)
	if str(v["sala"]) == "dormitorio":
		mod = mod.darkened(0.25)
	_sombra(x, y, 28.0)
	_sprite(str((Datos.CLASES[str(h["clase"])] as Dictionary)["tex"]), x, y - bote, alto, int(v["dir"]) < 0, mod, inclina)
	## Detalles según lo que hacen.
	if str(v["estado"]) == "servir" and not bot:
		match str(v["sala"]):
			"dormitorio":
				if fmod(a, 1.2) < 0.02:
					_texto_mundo("z", Vector2(x + 20.0, y + cam - alto), Color(0.8, 0.85, 1.0))
			"taberna":
				if fmod(a, 2.5) < 0.02:
					_texto_mundo("♪" if str(h["clase"]) == "bardo" else "¡Ja!", Vector2(x, y + cam - alto - 10.0), Color(1, 0.9, 0.6))
	if bool(v.get("botin", false)) and str(v["estado"]) == "ir":
		var c: Texture2D = _tex.get("p_cofre") as Texture2D
		if c != null:
			draw_texture_rect(c, Rect2(x - 22.0, y - alto - 50.0 - bote, 44, 40), false)
	## Nombre y nivel al pasar cerca de la cámara.
	if str(v["estado"]) in ["esperar", "servir"]:
		var f: Font = Estilo.fuente()
		draw_string(f, Vector2(x - 70.0, y - alto - 8.0), "%s · %d" % [str(h["nombre"]).get_slice(" ", 0), int(h["nivel"])], HORIZONTAL_ALIGNMENT_CENTER, 140, 16, Color(1, 0.95, 0.85, 0.85))


func _dibujar_rata(r: Dictionary) -> void:
	var y: float = _y_suelo(piso_de(str(r["sala"]))) - 14.0 - cam
	var x: float = float(r["x"])
	var b: float = absf(sin(float(r["t"]) * 14.0)) * 4.0
	_sombra(x, y + 6.0, 26.0)
	draw_circle(Vector2(x, y - 16.0 - b), 22.0, Color("2a2020"))
	draw_circle(Vector2(x + int(r["dir"]) * 20.0, y - 22.0 - b), 13.0, Color("2a2020"))
	draw_circle(Vector2(x + int(r["dir"]) * 26.0, y - 26.0 - b), 3.5, Color(1.0, 0.2, 0.15))
	draw_line(Vector2(x - int(r["dir"]) * 20.0, y - 12.0), Vector2(x - int(r["dir"]) * 48.0, y - 24.0 + sin(float(r["t"]) * 10.0) * 6.0), Color("4a3a3a"), 3.0)
	## Aviso que late encima.
	draw_circle(Vector2(x, y - 70.0), 14.0 + 3.0 * sin(_tiempo * 8.0), Color(1.0, 0.3, 0.2, 0.8))
	draw_string(Estilo.fuente(), Vector2(x - 10.0, y - 62.0), "!", HORIZONTAL_ALIGNMENT_CENTER, 20, 22, Color.WHITE)


func _dibujar_caja(sd: Dictionary) -> void:
	var id: String = str(sd["id"])
	var o: float = float((rt[id] as Dictionary)["caja"])
	if o <= 0.0:
		return
	var top: float = _y_suelo(float(sd["piso"])) - H - cam
	if top > ALTO or top + H < 0.0:
		return
	var b: float = sin(_tiempo * 3.0 + float(sd["piso"])) * 4.0
	var c: Vector2 = Vector2(620.0, top + 52.0 + b)
	draw_circle(c + Vector2(0, 4), 40.0, Color(0, 0, 0, 0.3))
	draw_circle(c, 40.0, Color("4a2c12"))
	draw_circle(c, 36.0, Color("ffd75e").darkened(0.1))
	var t: Texture2D = _tex.get("p_oro") as Texture2D
	if t != null:
		draw_texture_rect(t, Rect2(c.x - 26.0, c.y - 30.0, 52, 46), false)
	draw_string(Estilo.fuente(), Vector2(c.x - 70.0, c.y + 64.0), num(o), HORIZONTAL_ALIGNMENT_CENTER, 140, 24, Color("fff1b8"))


func _sombra(x: float, y: float, r: float) -> void:
	draw_set_transform(Vector2(x, y), 0.0, Vector2(1.0, 0.28))
	draw_circle(Vector2.ZERO, r, Color(0, 0, 0, 0.35))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _sprite(id: String, x: float, y_pie: float, alto: float, flip: bool, mod: Color = Color.WHITE, inclina: float = 0.0) -> void:
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		draw_rect(Rect2(x - alto * 0.2, y_pie - alto, alto * 0.4, alto), Color(0.5, 0.4, 0.3))
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	draw_set_transform(Vector2(x, y_pie), inclina, Vector2(-1.0 if flip else 1.0, 1.0))
	draw_texture_rect(tx, Rect2(-ancho / 2.0, -alto, ancho, alto), false, mod)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ------------------------------------------------------------------ partículas y textos

func _chispas(p: Vector2, c: Color, n: int) -> void:
	for i: int in n:
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": p, "v": Vector2(cos(a), sin(a)) * rng.randf_range(60, 200), "t": rng.randf_range(0.3, 0.6), "c": c, "r": rng.randf_range(2, 4), "g": 400.0})


func _texto_mundo(s: String, p: Vector2, c: Color) -> void:
	_textos.append({"s": s, "p": p, "t": 1.2, "c": c})


func _actualizar_particulas(dt: float) -> void:
	for p: Variant in _particulas:
		var d: Dictionary = p as Dictionary
		d["t"] = float(d["t"]) - dt
		if d.has("a"):
			## Vuela hacia el contador de oro.
			var obj: Vector2 = d["a"] as Vector2
			d["v"] = (d["v"] as Vector2).lerp((obj - (d["p"] as Vector2)) * 4.0, minf(1.0, dt * 5.0))
		d["v"] = (d["v"] as Vector2) + Vector2(0, float(d["g"]) * dt)
		d["p"] = (d["p"] as Vector2) + (d["v"] as Vector2) * dt
	_particulas = _particulas.filter(func(p: Variant) -> bool: return float((p as Dictionary)["t"]) > 0.0)
	if _particulas.size() > 400:
		_particulas = _particulas.slice(_particulas.size() - 400)
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		d2["t"] = float(d2["t"]) - dt
		d2["p"] = (d2["p"] as Vector2) + Vector2(0, -40.0 * dt)
	_textos = _textos.filter(func(t: Variant) -> bool: return float((t as Dictionary)["t"]) > 0.0)


func _dibujar_particulas() -> void:
	for p: Variant in _particulas:
		var d: Dictionary = p as Dictionary
		var c: Color = d["c"] as Color
		var pos: Vector2 = d["p"] as Vector2
		if bool(d.get("mundo", false)):
			## Partículas pegadas al mundo: se mueven con la cámara.
			pos.y = float(d["wy"]) - cam + (pos.y - (float(d["wy"]) - cam))
		draw_circle(pos, float(d["r"]), Color(c.r, c.g, c.b, c.a * clampf(float(d["t"]) * 2.0, 0.0, 1.0)))
	var f: Font = Estilo.fuente()
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		var c2: Color = d2["c"] as Color
		var pp: Vector2 = (d2["p"] as Vector2) - Vector2(60, cam)
		draw_string_outline(f, pp, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 120, 24, 5, Color(0.1, 0.05, 0.02, c2.a * minf(1.0, float(d2["t"]) * 2.0)))
		draw_string(f, pp, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 120, 24, Color(c2.r, c2.g, c2.b, minf(1.0, float(d2["t"]) * 2.0)))


# ------------------------------------------------------------------ HUD

static func num(x: float) -> String:
	if x >= 1000000000.0:
		return "%.1fB" % (x / 1000000000.0)
	if x >= 1000000.0:
		return "%.1fM" % (x / 1000000.0)
	if x >= 10000.0:
		return "%.1fk" % (x / 1000.0)
	return str(int(round(x)))


func _hacer_hud() -> void:
	_hud = CanvasLayer.new()
	add_child(_hud)
	_raiz = Control.new()
	_raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(_raiz)
	var arriba: PanelContainer = Estilo.panel(Color(0.1, 0.06, 0.03, 0.9), Color("c79a4a"))
	arriba.position = Vector2(10, 10)
	arriba.size = Vector2(700, 108)
	arriba.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(arriba)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	arriba.add_child(vb)
	var fila: HBoxContainer = HBoxContainer.new()
	fila.add_theme_constant_override("separation", 8)
	vb.add_child(fila)
	for par: Array in [["p_oro", "oro"], ["p_gema", "gemas"]]:
		var ic: TextureRect = TextureRect.new()
		ic.texture = Estilo.tex(str(par[0]))
		ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.custom_minimum_size = Vector2(44, 44)
		fila.add_child(ic)
		var l: Label = Estilo.etiqueta("", 30, Color("ffe2a0"), HORIZONTAL_ALIGNMENT_LEFT)
		l.custom_minimum_size = Vector2(150 if str(par[1]) == "oro" else 70, 44)
		fila.add_child(l)
		if str(par[1]) == "oro":
			_l_oro = l
		else:
			_l_gemas = l
	_l_fama = Estilo.etiqueta("", 26, Color("ffd0a0"), HORIZONTAL_ALIGNMENT_LEFT)
	_l_fama.custom_minimum_size = Vector2(150, 44)
	fila.add_child(_l_fama)
	_l_hora = Estilo.etiqueta("", 24, Color("d9c7a8"), HORIZONTAL_ALIGNMENT_RIGHT)
	_l_hora.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(_l_hora)
	var fila2: HBoxContainer = HBoxContainer.new()
	fila2.add_theme_constant_override("separation", 10)
	vb.add_child(fila2)
	_l_rango = Estilo.etiqueta("", 22, Color("f6e2b8"), HORIZONTAL_ALIGNMENT_LEFT)
	_l_rango.custom_minimum_size = Vector2(300, 34)
	fila2.add_child(_l_rango)
	_barra_rango = Estilo.barra(Color("e8b84b"), 16.0)
	_barra_rango.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_barra_rango.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fila2.add_child(_barra_rango)
	## Botones de abajo.
	var abajo: HBoxContainer = HBoxContainer.new()
	_abajo = abajo
	abajo.position = Vector2(10, ALTO - 120.0)
	abajo.size = Vector2(700, 104)
	abajo.add_theme_constant_override("separation", 8)
	_raiz.add_child(abajo)
	for par: Array in [[Idioma.t("Misiones"), abrir_misiones], [Idioma.t("Héroes"), abrir_heroes], [Idioma.t("Encargos"), abrir_encargos], ["II", abrir_pausa]]:
		var b: Button = Estilo.boton(str(par[0]), str(par[0]) == Idioma.t("Misiones"), 100)
		b.add_theme_font_size_override("font_size", 26)
		if str(par[0]) == "II":
			b.custom_minimum_size = Vector2(100, 100)
		else:
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(par[1] as Callable)
		abajo.add_child(b)
	_l_aviso = Estilo.etiqueta("", 28, Color("fff1d0"), HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_aviso.position = Vector2(30, 140)
	_l_aviso.size = Vector2(660, 90)
	_l_aviso.add_theme_constant_override("outline_size", 10)
	_l_aviso.add_theme_color_override("font_outline_color", Color(0.12, 0.05, 0.02, 0.95))
	_l_aviso.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_l_aviso)
	_l_guia = Estilo.etiqueta("", 24, Color("ffe8b0"), HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_guia.position = Vector2(40, ALTO - 220.0)
	_l_guia.size = Vector2(640, 90)
	_l_guia.add_theme_constant_override("outline_size", 9)
	_l_guia.add_theme_color_override("font_outline_color", Color(0.1, 0.05, 0.02, 0.95))
	_l_guia.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_l_guia)


func _hud_refrescar(dt: float) -> void:
	_l_oro.text = num(Estado.oro())
	_l_gemas.text = str(Estado.n("gemas"))
	_l_fama.text = "★ " + num(float(Estado.n("fama")))
	var ciclo: float = fmod(reloj, Datos.T_DIA + Datos.T_NOCHE)
	_l_hora.text = (Idioma.t("Noche") if es_noche() else Idioma.t("Día")) + ("  ·  " + Idioma.t("¡Fiesta!") if fiesta() else "")
	var r: int = Datos.rango(Estado.n("fama"))
	_l_rango.text = Idioma.t(str((Datos.RANGOS[r] as Dictionary)["nombre"]))
	if r + 1 < Datos.RANGOS.size():
		var a: float = float((Datos.RANGOS[r] as Dictionary)["fama"])
		var b: float = float((Datos.RANGOS[r + 1] as Dictionary)["fama"])
		_barra_rango.value = (Estado.n("fama") - a) / (b - a) * 100.0
	else:
		_barra_rango.value = 100.0
	_t_aviso -= dt
	_l_aviso.modulate.a = clampf(_t_aviso, 0.0, 1.0)
	_l_guia.text = _guia()
	_l_guia.modulate.a = 0.75 + 0.25 * sin(_tiempo * 3.0)
	if ciclo < 0.05 and not es_noche():
		pass


## Pistas para los primeros minutos.
func _guia() -> String:
	if Estado.nivel("tablon") <= 0:
		if float((rt["taberna"] as Dictionary)["caja"]) > 0.0 and Estado.oro() < 40.0:
			return Idioma.t("Toca las monedas de la taberna para cobrar.")
		return Idioma.t("Sube un poco y construye el Tablón de misiones.") if Estado.oro() >= 40.0 else ""
	if Estado.n("misiones") == 0:
		return Idioma.t("En el tablón se forman grupos que bajan a la mazmorra.")
	if Estado.nivel("cocina") <= 0 and Estado.oro() >= 150.0 and Estado.n("fama") >= 4:
		return Idioma.t("Ya puedes construir la cocina: desliza hacia arriba.")
	if Estado.nivel("taberna") < 3 and Estado.n("misiones") < 4:
		return Idioma.t("Toca una sala para mejorarla: cobrará más.")
	return ""


func _avisar(s: String) -> void:
	if bot or _l_aviso == null:
		return
	_l_aviso.text = s
	_t_aviso = 3.5


# ------------------------------------------------------------------ ventanas

func _abrir(titulo: String, ancho: float = 660.0) -> VBoxContainer:
	_cerrar()
	_modal = Estilo.modal(_raiz, titulo, ancho)
	return _modal["vb"] as VBoxContainer


func _cerrar() -> void:
	if not _modal.is_empty():
		Estilo.cerrar(_modal)
	_modal = {}


func _lista(vb: VBoxContainer, alto: float) -> VBoxContainer:
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(620, alto)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var l: VBoxContainer = VBoxContainer.new()
	l.add_theme_constant_override("separation", 12)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(l)
	return l


func _boton_cerrar(vb: VBoxContainer) -> void:
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), false, 76)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func _fila(lista: VBoxContainer, texto: String, boton: String, activo: bool, al_pulsar: Callable, icono: String = "") -> void:
	var fila: HBoxContainer = HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	lista.add_child(fila)
	if icono != "":
		var ic: TextureRect = TextureRect.new()
		ic.texture = Estilo.tex(icono)
		ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.custom_minimum_size = Vector2(64, 84)
		fila.add_child(ic)
	var l: Label = Estilo.etiqueta(texto, 21, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
	l.custom_minimum_size = Vector2(400 if icono == "" else 330, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fila.add_child(l)
	if boton != "":
		var b: Button = Estilo.boton(boton, activo, 70)
		b.custom_minimum_size = Vector2(190, 70)
		b.add_theme_font_size_override("font_size", 22)
		b.disabled = not activo
		b.pressed.connect(al_pulsar)
		fila.add_child(b)


func abrir_sala(id: String) -> void:
	var sd: Dictionary = Datos.sala(id)
	var nv: int = Estado.nivel(id)
	var vb: VBoxContainer = _abrir(Idioma.t(str(sd["nombre"])) + "  ·  " + Idioma.t("Nv %d") % nv)
	var l: Label = Estilo.etiqueta(Idioma.t(str(sd["texto"])), 23, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(600, 0)
	vb.add_child(l)
	var info: String = Idioma.t("Cobra %s por cliente  ·  %d sitios") % [num(Datos.precio(id, nv) * multiplicador(id)), _capacidad(id)]
	vb.add_child(Estilo.etiqueta(info, 24, Color("7a3e0a"), HORIZONTAL_ALIGNMENT_CENTER, true))
	var c: int = Estado.coste_subir(id)
	var lista: VBoxContainer = _lista(vb, 250.0)
	if c > 0:
		_fila(lista, Idioma.t("Mejorar a nivel %d: cobra %s") % [nv + 1, num(Datos.precio(id, nv + 1) * multiplicador(id))], num(float(c)), Estado.oro() >= c, func() -> void:
			if Estado.subir(id):
				Audio.play("ui_reward", 0.0, -4.0)
				Juice.vibrate(20)
				_chispas(Vector2(400, _y_suelo(piso_de(id)) - H * 0.5 - cam), Color("ffd75e"), 24)
				abrir_sala(id), "p_oro")
	else:
		_fila(lista, Idioma.t("Nivel máximo."), "", false, func() -> void: pass)
	for p: Variant in Datos.PERSONAL:
		var pd: Dictionary = p as Dictionary
		if str(pd["sala"]) != id:
			continue
		var pid: String = str(pd["id"])
		var pnv: int = Estado.nivel_personal(pid)
		var pc: int = Estado.coste_personal(pid)
		var txt: String = "%s  %s\n%s" % [Idioma.t(str(pd["nombre"])), "●".repeat(pnv) + "○".repeat((pd["costes"] as Array).size() - pnv), Idioma.t(str(pd["texto"]))]
		_fila(lista, txt, (Idioma.t("Contratar") if pnv == 0 else Idioma.t("Formar")) + "\n" + num(float(pc)) if pc > 0 else "", pc > 0 and Estado.oro() >= pc, func() -> void:
			if Estado.contratar(pid):
				Audio.play("ui_reward")
				_comprobar_personal()
				abrir_sala(id), str(pd["tex"]))
	if id == "tablon":
		var bm: Button = Estilo.boton(Idioma.t("Elegir mazmorra"), true, 80)
		bm.pressed.connect(abrir_misiones)
		vb.add_child(bm)
	_boton_cerrar(vb)


func _comprobar_personal() -> void:
	for p: Variant in Datos.PERSONAL:
		if Estado.nivel_personal(str((p as Dictionary)["id"])) <= 0:
			return
	_logro("personal")


func abrir_construir(id: String) -> void:
	var sd: Dictionary = Datos.sala(id)
	var vb: VBoxContainer = _abrir(Idioma.t("Construir: %s") % Idioma.t(str(sd["nombre"])))
	var l: Label = Estilo.etiqueta(Idioma.t(str(sd["texto"])), 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(600, 0)
	vb.add_child(l)
	var tx: TextureRect = TextureRect.new()
	tx.texture = Estilo.tex("p_" + id)
	tx.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tx.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tx.custom_minimum_size = Vector2(600, 262)
	vb.add_child(tx)
	var puede: bool = Estado.n("fama") >= int(sd["fama"])
	var b: Button = Estilo.boton(Idioma.t("Construir por %s oro") % num(float(sd["coste"])) if puede else Idioma.t("Necesitas %d de fama") % int(sd["fama"]), true, 84)
	b.disabled = not puede or Estado.oro() < float(sd["coste"])
	b.pressed.connect(func() -> void:
		if Estado.construir(id):
			Audio.play("ui_big")
			Juice.vibrate(40)
			_avisar(Idioma.t("¡%s construida!") % Idioma.t(str(sd["nombre"])))
			_chispas(Vector2(400, _y_suelo(piso_de(id)) - H * 0.5 - cam), Color("ffd75e"), 40)
			if Estado.salas_hechas() >= 4:
				_logro("salas4")
			if Estado.salas_hechas() >= Datos.SALAS.size():
				_logro("salas8")
			if id == "tablon":
				Consejo.mostrar(_raiz, "tablon")
			_cerrar())
	vb.add_child(b)
	_boton_cerrar(vb)


func abrir_misiones() -> void:
	var vb: VBoxContainer = _abrir(Idioma.t("Mazmorras"))
	if Estado.nivel("tablon") <= 0:
		vb.add_child(Estilo.etiqueta(Idioma.t("Primero construye el Tablón de misiones."), 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true))
		_boton_cerrar(vb)
		return
	var lista: VBoxContainer = _lista(vb, 560.0)
	for i: int in Datos.MAZMORRAS.size():
		var mz: Dictionary = Datos.MAZMORRAS[i] as Dictionary
		var abierta: bool = Estado.n("fama") >= int(mz["fama"])
		var txt: String = "%s\n%s" % [Idioma.t(str(mz["nombre"])), Idioma.t("Riesgo %d%%  ·  Oro %s  ·  %d s  ·  Nivel %d+") % [int(float(mz["riesgo"]) * 100.0), num(float(mz["oro"])), int(mz["dur"]), int(mz["nivel"])]]
		if not abierta:
			txt = "%s\n%s" % [Idioma.t(str(mz["nombre"])), Idioma.t("Se abre con %d de fama") % int(mz["fama"])]
		var elegida: bool = Estado.n("mazmorra") == i
		_fila(lista, txt, Idioma.t("Elegida") if elegida else Idioma.t("Elegir"), abierta and not elegida, func() -> void:
			Estado.d["mazmorra"] = i
			Estado.guardar()
			abrir_misiones(), "p_calavera" if i >= 4 else "p_cofre")
	var ms: Array = Estado.d["en_mision"] as Array
	if not ms.is_empty():
		lista.add_child(Estilo.etiqueta(Idioma.t("Grupos en la mazmorra"), 26, Color("6a2c0c")))
		for m: Variant in ms:
			var md: Dictionary = m as Dictionary
			var nombres: Array = []
			for id: Variant in (md["heroes"] as Array):
				var h: Dictionary = _heroe(int(id))
				if not h.is_empty():
					nombres.append(str(h["nombre"]).get_slice(" ", 0))
			var falta: int = maxi(0, int(float(md["fin"]) - reloj))
			lista.add_child(Estilo.etiqueta("%s  →  %s  (%d s)" % [", ".join(nombres), Idioma.t(str((Datos.MAZMORRAS[int(md["mz"])] as Dictionary)["nombre"])), falta], 20, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true))
	_boton_cerrar(vb)


func abrir_heroes() -> void:
	var vb: VBoxContainer = _abrir(Idioma.t("Aventureros"))
	var hs: Array = Estado.heroes().duplicate()
	hs.sort_custom(func(a: Variant, b: Variant) -> bool: return int((a as Dictionary)["nivel"]) > int((b as Dictionary)["nivel"]))
	var lista: VBoxContainer = _lista(vb, 520.0)
	if hs.is_empty():
		lista.add_child(Estilo.etiqueta(Idioma.t("Los que vuelvan de la mazmorra se quedarán aquí como habituales."), 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for x: Variant in hs:
		var h: Dictionary = x as Dictionary
		var c: Dictionary = Datos.CLASES[str(h["clase"])] as Dictionary
		var txt: String = "%s  ·  %s %d\n%s  ·  %d %s%s" % [str(h["nombre"]), Idioma.t(str(c["nombre"])), int(h["nivel"]), Idioma.t(str(c["texto"])), int(h["misiones"]),
			Idioma.t("misiones"), ("  ·  " + Idioma.t("en la mazmorra")) if bool(h.get("fuera", false)) else ""]
		_fila(lista, txt, "", false, func() -> void: pass, str(c["tex"]))
	var bl: Button = Estilo.boton(Idioma.t("Libro de Leyendas") + "  (%d)" % (Estado.d["leyendas"] as Array).size(), true, 80)
	bl.pressed.connect(abrir_leyendas)
	vb.add_child(bl)
	_boton_cerrar(vb)


func abrir_leyendas() -> void:
	var vb: VBoxContainer = _abrir(Idioma.t("Libro de Leyendas"))
	var lista: VBoxContainer = _lista(vb, 560.0)
	var ls: Array = Estado.d["leyendas"] as Array
	if ls.is_empty():
		lista.add_child(Estilo.etiqueta(Idioma.t("Todavía no ha caído nadie. Que dure."), 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for x: Variant in ls:
		var l: Dictionary = x as Dictionary
		var txt: String = Idioma.t("%s, %s de nivel %d.\nCayó en %s tras %d misiones.") % [str(l["nombre"]), Idioma.t(str((Datos.CLASES[str(l["clase"])] as Dictionary)["nombre"])).to_lower(),
			int(l["nivel"]), Idioma.t(str(l["donde"])), int(l["misiones"])]
		_fila(lista, txt, "", false, func() -> void: pass, "p_calavera")
	var bv: Button = Estilo.boton(Idioma.t("Volver"), false, 76)
	bv.pressed.connect(abrir_heroes)
	vb.add_child(bv)


func abrir_encargos() -> void:
	var vb: VBoxContainer = _abrir(Idioma.t("Encargos"))
	vb.add_child(Estilo.etiqueta(Idioma.t("Gemas: %d   (de misiones, bichos y logros)") % Estado.n("gemas"), 24, Color("1f4f7a"), HORIZONTAL_ALIGNMENT_CENTER, true))
	var lista: VBoxContainer = _lista(vb, 340.0)
	for x: Variant in Datos.ENCARGOS:
		var e: Dictionary = x as Dictionary
		var eid: String = str(e["id"])
		_fila(lista, "%s\n%s" % [Idioma.t(str(e["nombre"])), Idioma.t(str(e["texto"]))], "◆ %d" % int(e["gemas"]), Estado.n("gemas") >= int(e["gemas"]), func() -> void:
			if encargo(eid):
				Audio.play("ui_reward")
				_cerrar(), "p_gema")
	var bl: Button = Estilo.boton(Idioma.t("Logros") + "  %d/%d" % [(Estado.d["logros"] as Array).size(), Datos.LOGROS.size()], false, 76)
	bl.pressed.connect(abrir_logros)
	vb.add_child(bl)
	_boton_cerrar(vb)


func abrir_logros() -> void:
	var vb: VBoxContainer = _abrir(Idioma.t("Logros"))
	var lista: VBoxContainer = _lista(vb, 600.0)
	for x: Variant in Datos.LOGROS:
		var l: Dictionary = x as Dictionary
		var hecho: bool = (Estado.d["logros"] as Array).has(str(l["id"]))
		var et: Label = Estilo.etiqueta(("✔ " if hecho else "○ ") + "%s  (+%d ◆)\n%s" % [Idioma.t(str(l["nombre"])), int(l["premio"]), Idioma.t(str(l["texto"]))], 21,
			Color("2e5a12") if hecho else Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		et.custom_minimum_size = Vector2(600, 0)
		lista.add_child(et)
	_boton_cerrar(vb)


func abrir_pausa() -> void:
	pausa = true
	var vb: VBoxContainer = _abrir(Idioma.t("Pausa"), 560.0)
	var b1: Button = Estilo.boton(Idioma.t("Seguir"), true, 84)
	b1.pressed.connect(func() -> void:
		pausa = false
		_cerrar())
	vb.add_child(b1)
	var b2: Button = Estilo.boton(Idioma.t("Ajustes"), false, 76)
	b2.pressed.connect(func() -> void:
		_cerrar()
		pausa = false
		Consejo.ajustes(_raiz))
	vb.add_child(b2)
	var b3: Button = Estilo.boton(Idioma.t("Salir al menú"), false, 76)
	b3.pressed.connect(func() -> void:
		Estado.d["reloj"] = reloj
		Estado.guardar()
		Kit.change_scene("res://libre/main.tscn"))
	vb.add_child(b3)


func _notification(what: int) -> void:
	if bot:
		return
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_GO_BACK_REQUEST:
		Estado.d["reloj"] = reloj
		Estado.guardar()

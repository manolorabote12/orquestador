class_name Estado
extends RefCounted
## Partida guardada de La Posada: oro, gemas, fama, salas, personal, aventureros, misiones en curso y leyendas.

const CLAVE: String = "posada"
const MAX_HEROES: int = 40

static var d: Dictionary = {}
static var _cargado: bool = false
## Paso entre escenas ({"bot": true} para el bot).
static var partida: Dictionary = {}


static func cargar() -> void:
	if _cargado:
		return
	_cargado = true
	Idioma.iniciar()
	var v: Variant = Save.get_setting(CLAVE, {})
	d = (v as Dictionary).duplicate(true) if v is Dictionary else {}
	_completar()


static func _completar() -> void:
	var base: Dictionary = {"oro": 20.0, "gemas": 3, "fama": 0, "salas": {"taberna": 1}, "personal": {}, "mazmorra": 0, "heroes": [], "leyendas": [],
		"en_mision": [], "reloj": 0.0, "guardado_unix": 0, "oro_seg": 0.0, "oro_total": 0.0, "visitas": 0, "misiones": 0, "muertos": 0, "ratas": 0,
		"logros": [], "consejos": {}, "regalo": -1, "fiesta": 0.0}
	for k: String in base.keys():
		if not d.has(k):
			d[k] = base[k]


## Partida nueva en memoria (para el bot).
static func reiniciar() -> void:
	d = {}
	_cargado = true
	_completar()


static func guardar() -> void:
	if bool(partida.get("bot", false)):
		return
	d["guardado_unix"] = int(Time.get_unix_time_from_system())
	Save.set_setting(CLAVE, d)


static func n(k: String) -> int:
	return int(d.get(k, 0))


static func oro() -> float:
	return float(d.get("oro", 0.0))


static func dia_de_hoy() -> int:
	var t: Dictionary = Time.get_date_dict_from_system()
	return int(t["year"]) * 10000 + int(t["month"]) * 100 + int(t["day"])


# ------------------------------------------------------------------ salas y personal

static func nivel(sala: String) -> int:
	return int((d["salas"] as Dictionary).get(sala, 0))


static func nivel_personal(id: String) -> int:
	return int((d["personal"] as Dictionary).get(id, 0))


static func salas_hechas() -> int:
	return (d["salas"] as Dictionary).size()


## Siguiente sala por construir (o {} si ya están todas).
static func siguiente_sala() -> Dictionary:
	for s: Variant in Datos.SALAS:
		if nivel(str((s as Dictionary)["id"])) == 0:
			return s as Dictionary
	return {}


static func gastar(c: float) -> bool:
	if oro() < c:
		return false
	d["oro"] = oro() - c
	return true


static func construir(id: String) -> bool:
	var s: Dictionary = Datos.sala(id)
	if s.is_empty() or nivel(id) > 0 or n("fama") < int(s["fama"]):
		return false
	if not gastar(float(s["coste"])):
		return false
	(d["salas"] as Dictionary)[id] = 1
	guardar()
	return true


static func coste_subir(id: String) -> int:
	var nv: int = nivel(id)
	return -1 if nv <= 0 or nv >= Datos.NIVEL_MAX else Datos.coste_subir(id, nv)


static func subir(id: String) -> bool:
	var c: int = coste_subir(id)
	if c < 0 or not gastar(float(c)):
		return false
	(d["salas"] as Dictionary)[id] = nivel(id) + 1
	guardar()
	return true


static func coste_personal(id: String) -> int:
	var p: Dictionary = Datos.personal(id)
	var nv: int = nivel_personal(id)
	var cs: Array = p["costes"] as Array
	if nv >= cs.size() or nivel(str(p["sala"])) <= 0:
		return -1
	return int(cs[nv])


static func contratar(id: String) -> bool:
	var c: int = coste_personal(id)
	if c < 0 or not gastar(float(c)):
		return false
	(d["personal"] as Dictionary)[id] = nivel_personal(id) + 1
	guardar()
	return true


# ------------------------------------------------------------------ aventureros

static func nuevo_heroe(rng: RandomNumberGenerator, nivel_min: int = 1) -> Dictionary:
	var clases: Array = Datos.CLASES.keys()
	var nombre: String = str(Datos.NOMBRES[rng.randi() % Datos.NOMBRES.size()])
	if rng.randf() < 0.5:
		nombre += " " + str(Datos.APODOS[rng.randi() % Datos.APODOS.size()])
	var nv: int = nivel_min + rng.randi() % 2
	return {"id": rng.randi(), "nombre": nombre, "clase": str(clases[rng.randi() % clases.size()]), "nivel": nv, "xp": 0, "misiones": 0, "fuera": false}


static func heroes() -> Array:
	return d["heroes"] as Array


## Los que sobreviven se quedan en el registro y vuelven otro día.
static func registrar(h: Dictionary) -> void:
	var hs: Array = heroes()
	for x: Variant in hs:
		if int((x as Dictionary)["id"]) == int(h["id"]):
			return
	hs.append(h)
	if hs.size() > MAX_HEROES:
		## Se retira el de menos nivel que no esté de misión.
		var peor: int = -1
		for i: int in hs.size():
			var y: Dictionary = hs[i] as Dictionary
			if not bool(y.get("fuera", false)) and (peor < 0 or int(y["nivel"]) < int((hs[peor] as Dictionary)["nivel"])):
				peor = i
		if peor >= 0:
			hs.remove_at(peor)


static func quitar_heroe(id: int) -> void:
	d["heroes"] = heroes().filter(func(x: Variant) -> bool: return int((x as Dictionary)["id"]) != id)


## Experiencia: nivel = 1 + raíz de la experiencia acumulada (rápido al principio, lento después).
static func ganar_xp(h: Dictionary, xp: int) -> bool:
	h["xp"] = int(h["xp"]) + xp
	var nv: int = 1 + int(sqrt(float(h["xp"]) * 0.8))
	if nv > int(h["nivel"]):
		h["nivel"] = nv
		return true
	return false


static func leyenda(h: Dictionary, donde: String) -> void:
	var l: Array = d["leyendas"] as Array
	l.push_front({"nombre": str(h["nombre"]), "clase": str(h["clase"]), "nivel": int(h["nivel"]), "misiones": int(h["misiones"]), "donde": donde})
	if l.size() > 60:
		l.resize(60)


# ------------------------------------------------------------------ logros

static func logro(id: String) -> Dictionary:
	if (d["logros"] as Array).has(id):
		return {}
	for l: Variant in Datos.LOGROS:
		if str((l as Dictionary)["id"]) == id:
			(d["logros"] as Array).append(id)
			d["gemas"] = n("gemas") + int((l as Dictionary)["premio"])
			guardar()
			return l as Dictionary
	return {}


## Compras con dinero real (tienda del kit): llegan como gemas.
static func cobrar_monedero() -> int:
	var w: int = Save.wallet()
	if w <= 0:
		return 0
	Save.add_wallet(-w)
	d["gemas"] = n("gemas") + w
	guardar()
	return w

extends RefCounted
## Bot de La Posada: juega horas de partida sin pantalla como un jugador atento (cobra, construye, mejora,
## contrata y elige mazmorra según el nivel de sus aventureros) y apunta cuándo llega a cada hito.
## Sirve para medir el ritmo: que haya algo nuevo cada pocos minutos y para diez horas o más.

const HORAS: float = 10.0
const AVISO: bool = true
const DT: float = 1.0


static func jugar(tree: SceneTree) -> Dictionary:
	var t0: int = Time.get_ticks_msec()
	Estado.partida = {"bot": true, "semilla": 77}
	tree.change_scene_to_file("res://libre/juego.tscn")
	for _i: int in 3:
		await tree.process_frame
	var j: Node = tree.current_scene
	if j == null or not j.has_method("paso"):
		return {"ok": false, "error": "no cargo la posada"}
	var hitos: Dictionary = {}
	var rango_visto: int = 0
	var pasos: int = int(HORAS * 3600.0 / DT)
	var gastos: Dictionary = {"construir": 0, "mejorar": 0, "personal": 0}
	for k: int in pasos:
		j.call("paso", DT)
		var mins: float = k * DT / 60.0
		if k % 5 == 0:
			## Cobra como un jugador que mira la pantalla de vez en cuando.
			for id: Variant in (j.get("rt") as Dictionary).keys():
				j.call("recoger", str(id))
			## Bichos: el jugador los echa.
			var ratas: Array = j.get("ratas") as Array
			while not ratas.is_empty():
				j.call("golpear_rata", 0)
				ratas = j.get("ratas") as Array
			_decidir(j, gastos, hitos, mins)
		var r: int = Datos.rango(Estado.n("fama"))
		if r > rango_visto:
			rango_visto = r
			hitos["rango_%d" % r] = int(mins)
		if k % 1800 == 0:
			print("[POSADA] min=%d fama=%d oro=%d salas=%d visitas=%d grupos=%d muertos=%d t=%ds" % [int(mins), Estado.n("fama"), int(Estado.oro()), Estado.salas_hechas(),
				(j.get("visitas") as Array).size(), int((j.get("stats") as Dictionary)["grupos"]), int((j.get("stats") as Dictionary)["muertos"]), (Time.get_ticks_msec() - t0) / 1000])
			await tree.process_frame
	var st: Dictionary = j.get("stats") as Dictionary
	var niveles: Dictionary = (Estado.d["salas"] as Dictionary).duplicate()
	var mejor_heroe: int = 0
	for h: Variant in Estado.heroes():
		mejor_heroe = maxi(mejor_heroe, int((h as Dictionary)["nivel"]))
	return {"ok": Estado.salas_hechas() >= 6 and Datos.rango(Estado.n("fama")) >= 5, "hitos": hitos, "fama": Estado.n("fama"), "oro_total": int(float(Estado.d["oro_total"])),
		"salas": niveles, "personal": Estado.d["personal"], "mazmorra": Estado.n("mazmorra"), "misiones": int(st["misiones"]), "muertos": int(st["muertos"]),
		"grupos": int(st["grupos"]), "heroes": Estado.heroes().size(), "mejor_heroe": mejor_heroe, "gemas": Estado.n("gemas"), "gastos": gastos,
		"segundos": (Time.get_ticks_msec() - t0) / 1000.0}


static func _decidir(j: Node, gastos: Dictionary, hitos: Dictionary, mins: float) -> void:
	## 1) Construir la siguiente sala en cuanto se pueda.
	var sig: Dictionary = Estado.siguiente_sala()
	if not sig.is_empty() and Estado.construir(str(sig["id"])):
		hitos["sala_" + str(sig["id"])] = int(mins)
		gastos["construir"] = int(gastos["construir"]) + 1
		return
	## Si falta poco para la siguiente sala, ahorra.
	if not sig.is_empty() and Estado.n("fama") >= int(sig["fama"]) and Estado.oro() > float(sig["coste"]) * 0.6:
		return
	## 2) Personal.
	for p: Variant in Datos.PERSONAL:
		var pid: String = str((p as Dictionary)["id"])
		var c: int = Estado.coste_personal(pid)
		if c > 0 and Estado.oro() >= c * 1.5 and Estado.contratar(pid):
			hitos["personal_%s_%d" % [pid, Estado.nivel_personal(pid)]] = int(mins)
			gastos["personal"] = int(gastos["personal"]) + 1
			return
	## 3) Mejorar la sala más barata.
	var mejor: String = ""
	var mc: int = 1 << 60
	for id: Variant in (Estado.d["salas"] as Dictionary).keys():
		var c2: int = Estado.coste_subir(str(id))
		if c2 > 0 and c2 < mc:
			mc = c2
			mejor = str(id)
	if mejor != "" and Estado.subir(mejor):
		gastos["mejorar"] = int(gastos["mejorar"]) + 1
	## 4) Mazmorra: la más honda a la que llega el nivel medio de sus aventureros.
	var media: float = 1.0
	var hs: Array = Estado.heroes()
	if not hs.is_empty():
		var tot: float = 0.0
		for h: Variant in hs:
			tot += float((h as Dictionary)["nivel"])
		media = tot / hs.size()
	var elegida: int = 0
	for i: int in Datos.MAZMORRAS.size():
		var mz: Dictionary = Datos.MAZMORRAS[i] as Dictionary
		if Estado.n("fama") >= int(mz["fama"]) and media + 1.5 >= float(mz["nivel"]):
			elegida = i
	if elegida != Estado.n("mazmorra"):
		Estado.d["mazmorra"] = elegida
		hitos["mazmorra_%d" % elegida] = int(mins)
	## 5) Gemas: fiesta en cuanto haya.
	if Estado.n("gemas") >= 5:
		j.call("encargo", "fiesta")

extends Control
## La Taberna del Ahogado: fichajes (héroes que solo están aquí y héroes de la historia que puedes
## adelantar) e insignias para subir estrellas. Las ofertas cambian cada día. Sin azar: ves lo que compras.

const ISLA: String = "res://libre/isla.tscn"

var _lista: VBoxContainer
var _chips: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estilo.fondo_cubrir(self, "bg_faro" if Estilo.tex("bg_faro") != null else "bg_isla", 1.05)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.06, 0.03, 0.02, 0.66)
	vel.size = Vector2(720, 1280)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	var t: Label = Estilo.etiqueta(Idioma.t("La Taberna del Ahogado"), 40, Estilo.ORO)
	t.position = Vector2(0, 22)
	t.size = Vector2(720, 56)
	add_child(t)
	var s: Label = Estilo.etiqueta(Idioma.t("«Aquí recalan los que la niebla no quiso. Hoy tengo esto, mañana ya veremos.»"), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	s.position = Vector2(40, 80)
	s.size = Vector2(640, 60)
	add_child(s)
	_chips = Estilo.etiqueta("", 22, Estilo.TEXTO)
	_chips.position = Vector2(0, 146)
	_chips.size = Vector2(720, 32)
	add_child(_chips)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.position = Vector2(16, 186)
	sc.size = Vector2(688, 976)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	sc.add_child(_lista)
	var bv: Button = Estilo.boton(Idioma.t("Volver a la isla"), true, 88)
	bv.position = Vector2(20, 1176)
	bv.size = Vector2(680, 88)
	bv.pressed.connect(func() -> void: Kit.change_scene(ISLA))
	add_child(bv)
	_llenar()


func _llenar() -> void:
	for c: Node in _lista.get_children():
		c.queue_free()
	_chips.text = "%s %d   %s %d" % [Idioma.t("Ámbar"), Estado.n("ambar"), Idioma.t("Hierro"), Estado.n("hierro")]
	var ofs: Array = Estado.ofertas_taberna()
	if ofs.is_empty():
		_lista.add_child(Estilo.etiqueta(Idioma.t("La taberna está vacía hoy. Vuelve mañana."), 22, Estilo.NIEBLA))
	for i: int in ofs.size():
		_oferta(i, ofs[i] as Dictionary)
	_lista.add_child(Estilo.etiqueta(Idioma.t("Las ofertas cambian cada día."), 20, Estilo.NIEBLA))


func _oferta(i: int, o: Dictionary) -> void:
	var id: String = str(o["id"])
	var hd: Dictionary = Estado.HEROES[id] as Dictionary
	var card: PanelContainer = Estilo.panel(Color(0.14, 0.1, 0.07, 0.95), Color(str(hd["col"])).darkened(0.2))
	_lista.add_child(card)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	card.add_child(hb)
	hb.add_child(Estilo.sprite(str(hd["tex"]), Vector2(110, 140)))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(vb)
	var comprado: bool = Estado.oferta_comprada(i)
	if str(o["tipo"]) == "fichar":
		vb.add_child(Estilo.etiqueta(Idioma.t("Fichar a %s") % Idioma.t(hd["nombre"]), 24, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT))
		vb.add_child(Estilo.etiqueta("%s · %s" % [Idioma.t(hd["rol"]), Idioma.t(hd["hab"])], 19, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
		var d: Label = Estilo.etiqueta(Idioma.t(hd["desc"]), 17, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		d.custom_minimum_size = Vector2(300, 0)
		vb.add_child(d)
		if int(hd["llega"]) > 0:
			vb.add_child(Estilo.etiqueta(Idioma.t("Llegaría con la niebla en %s: aquí lo adelantas.") % Estado.titulo_noche(int(hd["llega"])), 16, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
	else:
		vb.add_child(Estilo.etiqueta(Idioma.t("%d insignias de %s") % [int(o["cantidad"]), Idioma.t(hd["nombre"])], 24, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT))
		var c: Dictionary = Estado.coste_estrella(id)
		vb.add_child(Estilo.etiqueta(Idioma.t("Tiene %d · próxima estrella: %d") % [Estado.insignias(id), int(c["insignias"])] if Estado.estrellas(id) < Estado.ESTRELLAS_MAX else Idioma.t("Estrellas al máximo"), 19, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
		vb.add_child(Estilo.etiqueta("★".repeat(Estado.estrellas(id)) + "☆".repeat(Estado.ESTRELLAS_MAX - Estado.estrellas(id)), 24, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT))
	var coste: Dictionary = o["coste"] as Dictionary
	var b: Button = Estilo.boton(Idioma.t("Comprado") if comprado else Estado.texto_coste(coste), not comprado, 72)
	b.custom_minimum_size = Vector2(160, 72)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.add_theme_font_size_override("font_size", 19)
	b.disabled = comprado or not Estado.puede_pagar(coste)
	b.pressed.connect(func() -> void:
		if Estado.comprar_oferta(i):
			Audio.play("coin")
			Juice.vibrate(30)
		_llenar())
	hb.add_child(b)

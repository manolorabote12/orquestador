class_name Estado
extends RefCounted
## Reglas y progreso guardado: campaña por mareas, faro por plantas, héroes con talentos y reliquias,
## y los modos (Niebla eterna, Cacerías, Reto del día). El contenido está en datos.gd.

const NOCHE_FINAL: int = 60
const NIVEL_MAX: int = 30
const HEROES: Dictionary = Datos.HEROES
const ENEMIGOS: Dictionary = Datos.ENEMIGOS
const RECURSOS: Array[String] = Datos.RECURSOS
const DIARIOS: Array[String] = Datos.DIARIOS

static var d: Dictionary = {}
static var rng: RandomNumberGenerator = RandomNumberGenerator.new()
## Lo que se juega esta noche: {"modo": "campana"|"eterna"|"caceria"|"reto", ...}
static var partida: Dictionary = {"modo": "campana"}


static func nuevo() -> void:
	d = {
		"empezada": false, "noche": 1, "dia": 1, "horas": 3,
		"aceite": 3, "madera": 2, "hierro": 2, "ambar": 4, "faro_hp": 30,
		"heroes": {"ibsen": {"lvl": 1}}, "guardia": ["ibsen"], "plantas": {},
		"reliquias": [], "jefes": [], "caceria": {}, "eterna_mejor": 0, "reto_dia": 0,
		"final_visto": false, "mejor": 0, "diario": "", "ganadas": 0, "visto_marea": 0,
	}
	d["faro_hp"] = faro_max()
	guardar()


static func cargar() -> void:
	Idioma.iniciar()
	if not d.is_empty():
		return
	var s: Variant = Save.data.get("farero", null)
	if s is Dictionary and (s as Dictionary).has("heroes"):
		d = s as Dictionary
		_migrar()
	else:
		nuevo()


## Partidas de la primera versión (7 noches, una sola lente).
static func _migrar() -> void:
	for k: String in ["ambar", "eterna_mejor", "reto_dia", "visto_marea"]:
		if not d.has(k):
			d[k] = 0
	for k: String in ["reliquias", "jefes"]:
		if not d.has(k):
			d[k] = []
	if not d.has("caceria"):
		d["caceria"] = {}
	if not d.has("plantas"):
		d["plantas"] = {"linterna": maxi(0, int(d.get("lente", 1)) - 1)}
	d.erase("lente")


static func guardar() -> void:
	Save.data["farero"] = d
	Save.save_data()


static func n(k: String) -> int:
	return int(d.get(k, 0))


static func tiene_partida() -> bool:
	return bool(d.get("empezada", false))


# ------------------------------------------------------------------ campaña
static func marea_de(g: int) -> int:
	return clampi((g - 1) / Datos.NOCHES_POR_MAREA + 1, 1, Datos.MAREAS.size())


static func noche_en_marea(g: int) -> int:
	return (g - 1) % Datos.NOCHES_POR_MAREA + 1


static func marea() -> int:
	return marea_de(mini(n("noche"), NOCHE_FINAL))


static func datos_marea(m: int) -> Dictionary:
	return Datos.MAREAS[clampi(m, 1, Datos.MAREAS.size()) - 1] as Dictionary


static func campana_terminada() -> bool:
	return n("noche") > NOCHE_FINAL


static func titulo_noche(g: int) -> String:
	var k: int = noche_en_marea(g)
	if k == Datos.NOCHES_POR_MAREA:
		return Idioma.t("%s · Noche final") % Idioma.t(datos_marea(marea_de(g))["nombre"])
	return Idioma.t("%s · Noche %d") % [Idioma.t(datos_marea(marea_de(g))["nombre"]), k]


# ------------------------------------------------------------------ plantas del faro
static func planta(id: String) -> int:
	return int((d["plantas"] as Dictionary).get(id, 0))


static func def_planta(id: String) -> Dictionary:
	for p: Dictionary in Datos.PLANTAS:
		if str(p["id"]) == id:
			return p
	return {}


static func coste_planta(id: String) -> Dictionary:
	var p: Dictionary = def_planta(id)
	var lv: int = planta(id)
	var out: Dictionary = {}
	var base: Dictionary = p["coste"] as Dictionary
	for k: Variant in base.keys():
		out[str(k)] = int(base[k]) * (lv + 1) + lv * lv
	if lv + 1 >= int(p["ambar_desde"]):
		out["ambar"] = lv + 2 - int(p["ambar_desde"])
	return out


static func mejorar_planta(id: String) -> bool:
	var p: Dictionary = def_planta(id)
	if p.is_empty() or planta(id) >= int(p["max"]) or not pagar(coste_planta(id)):
		return false
	var fm0: int = faro_max()
	(d["plantas"] as Dictionary)[id] = planta(id) + 1
	d["faro_hp"] = mini(n("faro_hp") + maxi(0, faro_max() - fm0), faro_max())
	guardar()
	return true


static func faro_max() -> int:
	return 30 + 12 * planta("muros")


static func luz_max() -> int:
	return 5 + planta("linterna")


static func luz_turno() -> int:
	return 2 + planta("maquinas") / 2


static func destello_dano() -> int:
	return int(round((10.0 + 5.0 * planta("linterna")) * (1.0 + 0.06 * float(n("noche")))))


static func horas_dia() -> int:
	var m: int = planta("muelle")
	return 3 + (1 if m >= 1 else 0) + (1 if m >= 3 else 0) + (1 if m >= 5 else 0)


static func guardia_max() -> int:
	return 4 if planta("senales") >= 2 else 3


static func turnos_barrera() -> int:
	return 0 if planta("campanario") == 0 else (1 if planta("campanario") < 3 else 2)


static func cura_entre_oleadas() -> float:
	return 0.08 * float(planta("enfermeria"))


# ------------------------------------------------------------------ héroes
static func h(id: String) -> Dictionary:
	return (d["heroes"] as Dictionary).get(id, {}) as Dictionary


static func nivel(id: String) -> int:
	return int(h(id).get("lvl", 1))


## Suma de talentos elegidos y de la reliquia equipada.
static func mods(id: String) -> Dictionary:
	var out: Dictionary = {}
	var tal: Dictionary = h(id).get("tal", {}) as Dictionary
	for t: Dictionary in Datos.TALENTOS:
		var k: String = str(t["nivel"])
		if tal.has(k):
			var tid: String = str((t[str(tal[k])] as Dictionary)["id"])
			match tid:
				"vida": out["vida"] = float(out.get("vida", 0.0)) + 0.2
				"fuerza": out["fuerza"] = float(out.get("fuerza", 0.0)) + 0.2
				"fuerza2": out["fuerza"] = float(out.get("fuerza", 0.0)) + 0.3
				"critico": out["critico"] = float(out.get("critico", 0.0)) + 0.25
				"robo": out["robo"] = float(out.get("robo", 0.0)) + 0.25
				"escudo": out["escudo"] = float(out.get("escudo", 0.0)) + 0.25
				"regen": out["regen"] = float(out.get("regen", 0.0)) + 0.06
				_: out[tid] = float(out.get(tid, 0.0)) + 1.0
	var rel: String = str(h(id).get("rel", ""))
	if Datos.RELIQUIAS.has(rel):
		var m: Dictionary = (Datos.RELIQUIAS[rel] as Dictionary)["m"] as Dictionary
		for k: Variant in m.keys():
			out[str(k)] = float(out.get(str(k), 0.0)) + float(m[k])
	return out


static func hp_heroe(id: String, lvl: int = -1) -> int:
	var lv: int = nivel(id) if lvl < 0 else lvl
	var m: Dictionary = mods(id)
	return int(round(float((HEROES[id] as Dictionary)["hp"]) * (1.0 + 0.12 * float(lv - 1)) * (1.0 + float(m.get("vida", 0.0))) * (1.0 + 0.12 * float(estrellas(id)))))


static func atk_heroe(id: String, lvl: int = -1) -> float:
	var lv: int = nivel(id) if lvl < 0 else lvl
	var m: Dictionary = mods(id)
	var bib: float = 0.1 * float(maxi(0, planta("biblioteca") - 1))
	return float((HEROES[id] as Dictionary)["atk"]) * (1.0 + 0.1 * float(lv - 1)) * (1.0 + float(m.get("fuerza", 0.0)) + bib) * (1.0 + 0.12 * float(estrellas(id)))


static func coste_nivel(id: String) -> Dictionary:
	var lv: int = nivel(id)
	var rebaja: float = 1.0 - 0.06 * float(planta("taller"))
	var out: Dictionary = {"hierro": maxi(1, int(round(float(2 + lv + lv * lv / 6) * rebaja)))}
	if lv >= 4:
		out["madera"] = maxi(1, int(round(float(lv / 2) * rebaja)))
	if lv >= 15:
		out["aceite"] = maxi(1, int(round(float(lv / 3) * rebaja)))
	return out


static func subir_heroe(id: String) -> bool:
	if nivel(id) >= NIVEL_MAX or not pagar(coste_nivel(id)):
		return false
	h(id)["lvl"] = nivel(id) + 1
	guardar()
	return true


static func talentos_abiertos() -> bool:
	return planta("biblioteca") >= 1


static func talento_pendiente(id: String) -> Dictionary:
	if not talentos_abiertos():
		return {}
	var tal: Dictionary = h(id).get("tal", {}) as Dictionary
	for t: Dictionary in Datos.TALENTOS:
		if nivel(id) >= int(t["nivel"]) and not tal.has(str(t["nivel"])):
			return t
	return {}


static func elegir_talento(id: String, nv: int, cual: String) -> void:
	if not h(id).has("tal"):
		h(id)["tal"] = {}
	(h(id)["tal"] as Dictionary)[str(nv)] = cual
	guardar()


static func equipar(id: String, rel: String) -> void:
	for k: Variant in (d["heroes"] as Dictionary).keys():
		if str(h(str(k)).get("rel", "")) == rel:
			h(str(k)).erase("rel")
	if rel != "":
		h(id)["rel"] = rel
	else:
		h(id).erase("rel")
	guardar()


static func guardia() -> Array[String]:
	var out: Array[String] = []
	for g: Variant in (d["guardia"] as Array):
		var id: String = str(g)
		if (d["heroes"] as Dictionary).has(id) and out.size() < guardia_max():
			out.append(id)
	return out


static func alternar_guardia(id: String) -> bool:
	var g: Array = d["guardia"] as Array
	if g.has(id):
		if g.size() <= 1:
			return false
		g.erase(id)
		return true
	if guardia().size() >= guardia_max():
		return false
	g.append(id)
	return true


static func fichar(id: String) -> bool:
	var hs: Dictionary = d["heroes"] as Dictionary
	if hs.has(id):
		return false
	var mx: int = 1
	for k: Variant in hs.keys():
		mx = maxi(mx, nivel(str(k)))
	hs[id] = {"lvl": maxi(1, mx - 2)}
	if guardia().size() < guardia_max():
		(d["guardia"] as Array).append(id)
		return true
	return false


static func llegada_de_la_noche(g: int) -> String:
	for id: Variant in HEROES.keys():
		if int((HEROES[id] as Dictionary)["llega"]) == g and not (d["heroes"] as Dictionary).has(id):
			return str(id)
	return ""


static func orden_heroes() -> Array[String]:
	var ids: Array[String] = []
	for id: Variant in HEROES.keys():
		ids.append(str(id))
	var k: Callable = func(x: String) -> int:
		var l: int = int((HEROES[x] as Dictionary)["llega"])
		return 1000 + int((HEROES[x] as Dictionary).get("taberna", 0)) if l < 0 else l
	ids.sort_custom(func(a: String, b: String) -> bool: return k.call(a) < k.call(b))
	return ids


# ------------------------------------------------------------------ recursos
static func puede_pagar(c: Dictionary) -> bool:
	for k: Variant in c.keys():
		if n(str(k)) < int(c[k]):
			return false
	return true


static func pagar(c: Dictionary) -> bool:
	if not puede_pagar(c):
		return false
	for k: Variant in c.keys():
		d[str(k)] = n(str(k)) - int(c[k])
	return true


static func sumar(botin: Dictionary) -> void:
	for k: Variant in botin.keys():
		d[str(k)] = n(str(k)) + int(botin[k])


static func reparar() -> bool:
	if n("faro_hp") >= faro_max() or n("madera") < 1:
		return false
	d["madera"] = n("madera") - 1
	d["faro_hp"] = mini(n("faro_hp") + 6 + planta("muros") * 2, faro_max())
	guardar()
	return true


static func reliquia_nueva() -> String:
	var libres: Array[String] = []
	for r: Variant in Datos.RELIQUIAS.keys():
		if not (d["reliquias"] as Array).has(r):
			libres.append(str(r))
	if libres.is_empty():
		return ""
	var r: String = libres[rng.randi() % libres.size()]
	(d["reliquias"] as Array).append(r)
	return r


# ------------------------------------------------------------------ día
static func lugares() -> Array:
	var out: Array = []
	for l: Dictionary in Datos.LUGARES:
		if int(l["marea"]) <= marea():
			out.append(l)
	return out


static func explorar(i: int) -> Dictionary:
	var ls: Array = lugares()
	if n("horas") <= 0 or i < 0 or i >= ls.size():
		return {}
	var lug: Dictionary = ls[i] as Dictionary
	var botin: Dictionary = {}
	var bt: Dictionary = lug["botin"] as Dictionary
	var extra: int = (1 if planta("muelle") >= 2 else 0) + (1 if planta("muelle") >= 4 else 0) + marea() - 1
	for k: Variant in bt.keys():
		var r: Array = bt[k] as Array
		var cant: int = rng.randi_range(int(r[0]), int(r[1]))
		if cant > 0 and str(k) != "ambar":
			cant += extra
		if cant > 0:
			botin[str(k)] = cant
	sumar(botin)
	d["horas"] = n("horas") - 1
	d["empezada"] = true
	var ev: Array = lug["eventos"] as Array
	var texto: String = str(ev[rng.randi() % ev.size()])
	var rel: String = ""
	if rng.randf() < 0.04:
		rel = reliquia_nueva()
	d["diario"] = texto
	guardar()
	return {"texto": texto, "botin": botin, "reliquia": rel}


# ------------------------------------------------------------------ noche
## Ajustado con el bot (21 nov): con +0,10/+0,07 por noche ganó las 60 a la primera.
static func escala_hp(g: float) -> float:
	return 1.0 + 0.22 * (g - 1.0) + 0.0005 * pow(g - 1.0, 2.0)


## Dentro de cada marea la dificultad sube poco a poco hasta el jefe (bot: las noches 7-11 eran un paseo).
static func rampa(g: int) -> float:
	var k: int = noche_en_marea(g)
	return 1.0 if k == Datos.NOCHES_POR_MAREA else 0.9 + 0.028 * float(k)


static func escala_atk(g: float) -> float:
	return 1.0 + 0.125 * (g - 1.0) + 0.0003 * pow(g - 1.0, 2.0)


static func _pool_hasta(m: int) -> Array[String]:
	var out: Array[String] = []
	for i: int in m:
		for id: Variant in (Datos.MAREAS[i] as Dictionary)["pool"]:
			if not out.has(str(id)):
				out.append(str(id))
	return out


static func _ola(r: RandomNumberGenerator, pool: Array[String], cuantos: int, elite: float) -> Array:
	var ola: Array = []
	for j: int in cuantos:
		var id: String = pool[r.randi() % pool.size()]
		ola.append(("!" + id) if r.randf() < elite else id)
	return ola


## Oleadas de una noche de campaña. "!id" = monstruo antiguo (más fuerte).
static func oleadas(g: int) -> Array:
	match g:
		1: return [["sombra", "sombra"]]
		2: return [["sombra", "rondador"]]
		3: return [["espectro"], ["sombra", "sombra"]]
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = g * 7919 + 13
	var m: int = marea_de(g)
	var k: int = noche_en_marea(g)
	var dm: Dictionary = datos_marea(m)
	var pool: Array[String] = []
	for id: Variant in dm["pool"]:
		pool.append(str(id))
	var viejos: Array[String] = _pool_hasta(m - 1)
	var out: Array = []
	if k == Datos.NOCHES_POR_MAREA:
		out.append(_ola(r, pool, 3, 0.3))
		var esc: Array[String] = [pool[r.randi() % pool.size()], pool[r.randi() % pool.size()]]
		out.append([esc[0], str(dm["jefe"]), esc[1]])
		return out
	var n_olas: int = 2 if k < 4 else (3 if k < 10 else 4)
	var elite: float = 1.0 if k == 6 else (0.04 * float(m - 1) if k < 6 else 0.14 + 0.04 * float(m))
	for w: int in n_olas:
		var p: Array[String] = pool
		if not viejos.is_empty() and r.randf() < 0.25:
			p = viejos
		var cuantos: int = 2 if (k <= 2 and w == 0 and m == 1) else (3 if r.randf() < 0.3 + 0.05 * float(k) + 0.1 * float(m - 1) else 2)
		out.append(_ola(r, p, cuantos, elite))
	return out


## Oleadas de los modos. g_eq es la "noche equivalente" para la fuerza de los monstruos.
static func oleadas_modo() -> Array:
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	var mx: int = clampi(marea_de(mini(n("mejor") + 1, NOCHE_FINAL)), 1, 5)
	match str(partida["modo"]):
		"eterna":
			r.seed = int(Time.get_unix_time_from_system())
			var out: Array = []
			var pool: Array[String] = _pool_hasta(mx)
			for w: int in 300:
				var cuantos: int = 2 if w < 2 else 3
				out.append(_ola(r, pool, cuantos, minf(0.6, 0.04 * float(w))))
			return out
		"caceria":
			var jefe: String = str(partida["jefe"])
			var mj: int = 1
			for i: int in Datos.MAREAS.size():
				if str((Datos.MAREAS[i] as Dictionary)["jefe"]) == jefe:
					mj = i + 1
			r.seed = int(partida["rango"]) * 31 + mj
			var pool2: Array[String] = []
			for id: Variant in datos_marea(mj)["pool"]:
				pool2.append(str(id))
			return [_ola(r, pool2, 3, 0.5), ["!" + pool2[r.randi() % pool2.size()], jefe, "!" + pool2[r.randi() % pool2.size()]]]
		"arena":
			## La guardia del rival: hasta 3 delante y, si son 4, el cuarto en una segunda oleada.
			var eq: Array = partida.get("equipo", []) as Array
			var w1: Array = []
			var w2: Array = []
			for i: int in eq.size():
				(w1 if i < 3 else w2).append("@%d" % i)
			return [w1] if w2.is_empty() else [w1, w2]
		"reto":
			r.seed = dia_de_hoy()
			var pool3: Array[String] = _pool_hasta(mx)
			var el: float = 1.0 if str(partida.get("reto", "")) == "elite" else 0.2
			return [_ola(r, pool3, 3, el), _ola(r, pool3, 3, el), _ola(r, pool3, 3, el)]
	return oleadas(n("noche"))


static func noche_equivalente(oleada: int = 0) -> float:
	match str(partida["modo"]):
		"eterna": return 6.0 + 1.6 * float(oleada)
		"caceria":
			var jefe: String = str(partida["jefe"])
			var mj: int = 1
			for i: int in Datos.MAREAS.size():
				if str((Datos.MAREAS[i] as Dictionary)["jefe"]) == jefe:
					mj = i + 1
			return float(mj * 12) + 4.0 * float(partida["rango"])
		"reto": return float(maxi(4, n("mejor")))
	return float(n("noche"))


static func dia_de_hoy() -> int:
	var t: Dictionary = Time.get_date_dict_from_system()
	return int(t["year"]) * 10000 + int(t["month"]) * 100 + int(t["day"])


static func reto_de_hoy() -> Dictionary:
	return Datos.RETOS[dia_de_hoy() % Datos.RETOS.size()] as Dictionary


static func botin_noche(g: int) -> Dictionary:
	var f: float = 1.0 + 0.1 * float(planta("senales"))
	var b: Dictionary = {
		"aceite": int(round((2.0 + float(g) * 0.35) * f)),
		"madera": int(round((2.0 + float(g) * 0.5) * f)),
		"hierro": int(round((2.0 + float(g) * 0.6) * f)),
	}
	var k: int = noche_en_marea(g)
	if k == 6:
		b["ambar"] = 1
	if k == Datos.NOCHES_POR_MAREA:
		b["ambar"] = 3
	return b


static func bonus_reliquias_botin() -> int:
	var t: int = 0
	for id: String in guardia():
		t += int(mods(id).get("botin", 0.0))
	return t


static func amanecer(victoria: bool) -> Dictionary:
	var g: int = n("noche")
	var botin: Dictionary = botin_noche(g) if victoria else {"aceite": 1 + g / 6, "madera": 1 + g / 6, "hierro": 1 + g / 6}
	if victoria and bool((d.get("noche_mod", {}) as Dictionary).get("dura", false)):
		for k: String in ["aceite", "madera", "hierro"]:
			botin[k] = int(round(float(botin[k]) * 1.6))
	d["noche_mod"] = {}
	if victoria:
		var extra: int = bonus_reliquias_botin()
		for k: String in ["aceite", "madera", "hierro"]:
			botin[k] = int(botin[k]) + extra
	sumar(botin)
	if victoria:
		d["ganadas"] = n("ganadas") + 1
		d["mejor"] = maxi(n("mejor"), g)
		Save.submit_best("noche", g)
		var k: int = noche_en_marea(g)
		if k == 6 or k == Datos.NOCHES_POR_MAREA:
			var rel: String = reliquia_nueva()
			if rel != "":
				botin["reliquia"] = rel
		if k == Datos.NOCHES_POR_MAREA:
			var jefe: String = str(datos_marea(marea_de(g))["jefe"])
			if not (d["jefes"] as Array).has(jefe):
				(d["jefes"] as Array).append(jefe)
		d["noche"] = g + 1
	d["dia"] = n("dia") + 1
	d["horas"] = horas_dia()
	var cura: int = int(ceil(float(faro_max()) * 0.3))
	d["faro_hp"] = clampi(n("faro_hp") + cura, ceili(faro_max() * 0.3), faro_max())
	d["diario"] = DIARIOS[rng.randi() % DIARIOS.size()]
	d["empezada"] = true
	guardar()
	return botin


## Premio de los modos (no gastan día). Devuelve el botín.
static func premio_modo(victoria: bool, oleadas_ganadas: int) -> Dictionary:
	var botin: Dictionary = {}
	match str(partida["modo"]):
		"eterna":
			var g: float = noche_equivalente(oleadas_ganadas)
			botin = {"aceite": oleadas_ganadas * 2, "madera": oleadas_ganadas * 2, "hierro": oleadas_ganadas * 2 + int(g / 4.0), "ambar": oleadas_ganadas / 5}
			if oleadas_ganadas > n("eterna_mejor"):
				if oleadas_ganadas >= 10 and n("eterna_mejor") < 10:
					var r: String = reliquia_nueva()
					if r != "":
						botin["reliquia"] = r
				d["eterna_mejor"] = oleadas_ganadas
				Save.submit_best("eterna", oleadas_ganadas)
		"caceria":
			if victoria:
				var jefe: String = str(partida["jefe"])
				var rango: int = int(partida["rango"])
				var cz: Dictionary = d["caceria"] as Dictionary
				var primera: bool = int(cz.get(jefe, 0)) < rango
				botin = {"hierro": 8 + rango * 4, "madera": 6 + rango * 3, "ambar": (2 + rango / 2) if primera else 1}
				if primera:
					cz[jefe] = rango
					if rango % 3 == 0:
						var r2: String = reliquia_nueva()
						if r2 != "":
							botin["reliquia"] = r2
		"reto":
			if victoria and n("reto_dia") != dia_de_hoy():
				d["reto_dia"] = dia_de_hoy()
				botin = {"aceite": 10, "madera": 10, "hierro": 12, "ambar": 3}
			elif victoria:
				botin = {"hierro": 4}
	var rel: String = str(botin.get("reliquia", ""))
	botin.erase("reliquia")
	sumar(botin)
	if rel != "":
		botin["reliquia"] = rel
	guardar()
	return botin


static func texto_coste(c: Dictionary) -> String:
	var t: Array[String] = []
	for k: Variant in c.keys():
		t.append(Idioma.t("%d %s") % [int(c[k]), str(Idioma.t(Datos.NOMBRE_RECURSO[str(k)])).to_lower()])
	return ", ".join(t)


# ------------------------------------------------------------------ sucesos del día
## Al explorar, a veces pasa algo y hay que decidir. Devuelve el índice del suceso o -1.
static func suceso_al_explorar() -> int:
	if rng.randf() > 0.45:
		return -1
	var vistos: Array = d.get("sucesos_vistos", []) as Array
	var cand: Array[int] = []
	for i: int in Datos.SUCESOS.size():
		var s: Dictionary = Datos.SUCESOS[i] as Dictionary
		if int(s["marea"]) <= marea() and not vistos.has(i):
			cand.append(i)
	if cand.is_empty():
		d["sucesos_vistos"] = []
		return -1
	return cand[rng.randi() % cand.size()]


static func _factor() -> float:
	return 1.0 + 0.5 * float(marea() - 1)


## Lo que cuesta de verdad una opción (los recursos en negativo), ya multiplicado por la marea.
static func coste_opcion(op: Dictionary) -> Dictionary:
	var c: Dictionary = {}
	for r: Variant in (op["r"] as Array):
		for k: Variant in ((r as Dictionary)["e"] as Dictionary).keys():
			var v: int = int(((r as Dictionary)["e"] as Dictionary)[k])
			if Datos.RECURSOS.has(str(k)) and v < 0:
				c[str(k)] = maxi(int(c.get(str(k), 0)), int(round(float(-v) * (_factor() if str(k) != "ambar" else 1.0))))
	if int(c.get("horas", 0)) > 0:
		c.erase("horas")
	return c


static func resolver_suceso(si: int, oi: int) -> Dictionary:
	var s: Dictionary = Datos.SUCESOS[si] as Dictionary
	var op: Dictionary = (s["opciones"] as Array)[oi] as Dictionary
	var tirada: float = rng.randf()
	var res: Dictionary = (op["r"] as Array)[-1] as Dictionary
	var acc: float = 0.0
	for r: Variant in (op["r"] as Array):
		acc += float((r as Dictionary)["p"])
		if tirada <= acc:
			res = r as Dictionary
			break
	var vistos: Array = d.get("sucesos_vistos", []) as Array
	vistos.append(si)
	d["sucesos_vistos"] = vistos.slice(maxi(0, vistos.size() - 8))
	var hecho: Array[String] = []
	var e: Dictionary = res["e"] as Dictionary
	var mod: Dictionary = d.get("noche_mod", {}) as Dictionary
	for k: Variant in e.keys():
		var v: int = int(e[k])
		match str(k):
			"aceite", "madera", "hierro", "ambar":
				var cant: int = int(round(float(v) * (_factor() if str(k) != "ambar" else 1.0)))
				d[str(k)] = maxi(0, n(str(k)) + cant)
				hecho.append(Idioma.t("%+d %s") % [cant, str(Idioma.t(Datos.NOMBRE_RECURSO[str(k)])).to_lower()])
			"faro":
				var f: int = int(round(float(v) * _factor()))
				d["faro_hp"] = clampi(n("faro_hp") + f, 1, faro_max())
				hecho.append(Idioma.t("%+d integridad del faro") % f)
			"horas":
				d["horas"] = maxi(0, n("horas") + v)
				hecho.append(Idioma.t("%+d hora") % v)
			"reliquia":
				var rel: String = reliquia_nueva()
				if rel != "":
					hecho.append(Idioma.t("reliquia: ") + str(Idioma.t((Datos.RELIQUIAS[rel] as Dictionary)["nombre"])))
				else:
					d["ambar"] = n("ambar") + 2
					hecho.append(Idioma.t("+2 ámbar"))
			"nivel":
				var ids: Array[String] = guardia()
				var id: String = ids[rng.randi() % ids.size()]
				if nivel(id) < NIVEL_MAX:
					h(id)["lvl"] = nivel(id) + 1
					hecho.append(Idioma.t("%s sube a nivel %d") % [str(Idioma.t((HEROES[id] as Dictionary)["nombre"])), nivel(id)])
			"luz_noche":
				mod["luz"] = int(mod.get("luz", 0)) + v
				hecho.append(Idioma.t("%+d de luz esta noche") % v)
			"escudo_noche":
				mod["escudo"] = true
				hecho.append(Idioma.t("la guardia empezará con escudo"))
			"noche_dura":
				mod["dura"] = true
				hecho.append(Idioma.t("noche más dura, con más botín"))
	d["noche_mod"] = mod
	guardar()
	return {"texto": str(Idioma.t(res["x"])), "hecho": hecho}


# ------------------------------------------------------------------ arena
const ARENA_DESDE: int = 4
const ARENA_TICKETS: int = 5


static func arena_abierta() -> bool:
	return n("mejor") >= ARENA_DESDE


static func arena_dia() -> void:
	if n("arena_dia") != dia_de_hoy():
		d["arena_dia"] = dia_de_hoy()
		d["arena_tickets"] = ARENA_TICKETS
		d["arena_ganadas_hoy"] = 0
	if not d.has("arena_puntos"):
		d["arena_puntos"] = 1000


## Tu guardia tal como la verán los demás: id, nivel, vida y fuerza ya calculadas (con talentos y reliquia).
static func equipo_defensa() -> Array:
	var out: Array = []
	for id: String in guardia():
		out.append({"id": id, "lvl": nivel(id), "hp": hp_heroe(id), "atk": snappedf(atk_heroe(id), 0.1)})
	return out


## Equipo que llega del servidor (otro jugador): solo héroes que existen y números con límites, para que
## un dato roto o trucado no rompa ni desequilibre el combate.
static func equipo_remoto(v: Variant) -> Array:
	var out: Array = []
	if not v is Dictionary or not (v as Dictionary).get("heroes", null) is Array:
		return out
	for h: Variant in ((v as Dictionary)["heroes"] as Array):
		if not h is Dictionary or not HEROES.has(str((h as Dictionary).get("id", ""))):
			continue
		var d: Dictionary = h as Dictionary
		out.append({"id": str(d["id"]), "lvl": clampi(str(d.get("lvl", 1)).to_int(), 1, 200),
			"hp": clampf(str(d.get("hp", 100)).to_float(), 1.0, 60000.0), "atk": clampf(str(d.get("atk", 10)).to_float(), 1.0, 6000.0)})
		if out.size() >= 4:
			break
	return out


static func poder(equipo: Array) -> int:
	var t: float = 0.0
	for e: Variant in equipo:
		t += float((e as Dictionary)["hp"]) + float((e as Dictionary)["atk"]) * 6.0
	return int(t)


## Un farero rival de la historia con un equipo de fuerza parecida a la tuya (cambia cada día).
static func rival_npc(i: int) -> Dictionary:
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = dia_de_hoy() * 31 + i * 7 + n("arena_puntos") / 50
	var f: Dictionary = Datos.RIVALES[(dia_de_hoy() + i * 3) % Datos.RIVALES.size()] as Dictionary
	var mio: Array = equipo_defensa()
	var lv: float = 0.0
	for e: Variant in mio:
		lv += float((e as Dictionary)["lvl"])
	lv = lv / maxf(1.0, float(mio.size()))
	var ids: Array = HEROES.keys()
	var eq: Array = []
	var dif: float = [0.85, 1.0, 1.15][i % 3]
	for k: int in mini(4, maxi(3, mio.size())):
		var id: String = str(ids[r.randi() % ids.size()])
		var lvl: int = clampi(int(round(lv * dif)) + r.randi_range(-1, 1), 1, NIVEL_MAX)
		var base: Dictionary = HEROES[id] as Dictionary
		eq.append({"id": id, "lvl": lvl, "hp": int(round(float(base["hp"]) * (1.0 + 0.12 * float(lvl - 1)) * (1.0 + 0.1 * dif))),
			"atk": snappedf(float(base["atk"]) * (1.0 + 0.1 * float(lvl - 1)) * (1.0 + 0.1 * dif), 0.1)})
	return {"alias": Idioma.t(f["nombre"]), "retrato": str(f["id"]), "lema": Idioma.t(f["lema"]), "equipo": eq,
		"puntos": n("arena_puntos") + int((dif - 1.0) * 300.0) + r.randi_range(-20, 20), "npc": true}


static func premio_arena(gano: bool, delta: int) -> Dictionary:
	var b: Dictionary = {}
	if gano:
		var hoy: int = n("arena_ganadas_hoy")
		b = {"hierro": 6 + n("mejor") / 2, "madera": 4 + n("mejor") / 3}
		if hoy < 3:
			b["ambar"] = 1
		d["arena_ganadas_hoy"] = hoy + 1
		d["arena_victorias"] = n("arena_victorias") + 1
	else:
		b = {"hierro": 2}
	if delta != 0:
		d["arena_puntos"] = maxi(0, n("arena_puntos") + delta)
	sumar(b)
	guardar()
	return b



# ------------------------------------------------------------------ taberna y estrellas
## Estrellas: cada una da +12% de vida y fuerza. Se suben con insignias del héroe (taberna) y hierro.
const ESTRELLAS_MAX: int = 5


static func estrellas(id: String) -> int:
	return int(h(id).get("est", 0))


static func insignias(id: String) -> int:
	return int(h(id).get("ins", 0))


static func coste_estrella(id: String) -> Dictionary:
	var e: int = estrellas(id)
	return {"insignias": 10 * (e + 1), "hierro": 25 * (e + 1)}


static func puede_ascender(id: String) -> bool:
	var c: Dictionary = coste_estrella(id)
	return estrellas(id) < ESTRELLAS_MAX and insignias(id) >= int(c["insignias"]) and n("hierro") >= int(c["hierro"])


static func ascender(id: String) -> bool:
	if not puede_ascender(id):
		return false
	var c: Dictionary = coste_estrella(id)
	h(id)["ins"] = insignias(id) - int(c["insignias"])
	d["hierro"] = n("hierro") - int(c["hierro"])
	h(id)["est"] = estrellas(id) + 1
	guardar()
	return true


## Ofertas de hoy en la taberna (cambian cada día): fichajes e insignias.
static func ofertas_taberna() -> Array:
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = dia_de_hoy() * 13 + 5
	var out: Array = []
	var hs: Dictionary = d["heroes"] as Dictionary
	## Fichajes: los de la taberna y los de la historia que llegarán pronto (adelantarlos cuesta ámbar).
	var fich: Array[String] = []
	for id: Variant in HEROES.keys():
		var hd: Dictionary = HEROES[id] as Dictionary
		if hs.has(id):
			continue
		var l: int = int(hd["llega"])
		if (l < 0 and n("mejor") >= 3) or (l > 0 and l <= n("mejor") + 10):
			fich.append(str(id))
	fich.sort()
	for i: int in mini(2, fich.size()):
		var id2: String = fich[(r.randi() + i) % fich.size()]
		if out.any(func(o: Dictionary) -> bool: return str(o["id"]) == id2):
			continue
		var hd2: Dictionary = HEROES[id2] as Dictionary
		var precio: int = int(hd2.get("taberna", 0)) if int(hd2["llega"]) < 0 else 3 + int(hd2["llega"]) / 8
		out.append({"tipo": "fichar", "id": id2, "coste": {"ambar": precio}})
	var propios: Array = hs.keys()
	propios.sort()
	for i: int in 3:
		if propios.is_empty():
			break
		var idp: String = str(propios[r.randi() % propios.size()])
		var cant: int = [5, 8, 12][i]
		var coste: Dictionary = {"ambar": 1} if i == 0 else ({"hierro": 30 + 3 * n("mejor")} if i == 1 else {"ambar": 2})
		out.append({"tipo": "insignias", "id": idp, "cantidad": cant, "coste": coste})
	return out


static func oferta_comprada(i: int) -> bool:
	return n("taberna_dia") == dia_de_hoy() and (d.get("taberna_compras", []) as Array).has(i)


static func comprar_oferta(i: int) -> bool:
	var ofs: Array = ofertas_taberna()
	if i < 0 or i >= ofs.size() or oferta_comprada(i):
		return false
	var o: Dictionary = ofs[i] as Dictionary
	if not pagar(o["coste"] as Dictionary):
		return false
	if n("taberna_dia") != dia_de_hoy():
		d["taberna_dia"] = dia_de_hoy()
		d["taberna_compras"] = []
	(d["taberna_compras"] as Array).append(i)
	if str(o["tipo"]) == "fichar":
		fichar(str(o["id"]))
	else:
		h(str(o["id"]))["ins"] = insignias(str(o["id"])) + int(o["cantidad"])
	guardar()
	return true



# ------------------------------------------------------------------ tienda
## Lo comprado en la tienda del kit llega al monedero (Save.wallet); aquí se convierte en ámbar.
static func cobrar_monedero() -> int:
	var w: int = Save.wallet()
	if w <= 0:
		return 0
	Save.add_wallet(-w)
	d["ambar"] = n("ambar") + w
	guardar()
	return w

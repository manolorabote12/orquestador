class_name Estado
extends RefCounted
## Reglas y datos del juego: heroes, enemigos, recursos, progreso guardado.

const NOCHE_FINAL: int = 7
const LENTE_MAX: int = 6
const NIVEL_MAX: int = 8
const HORAS_DIA: int = 3
const GUARDIA_MAX: int = 3
const LLEGADAS: Array[String] = ["alba", "koji", "tumo", "lyra", "nerea"]
const RECURSOS: Array[String] = ["aceite", "madera", "hierro"]

const HEROES: Dictionary = {
	"ibsen": {
		"nombre": "Capitán Ibsen", "mundo": "los Mares de Hierro", "rol": "Guardián",
		"hp": 42, "atk": 7, "tex": "h_ibsen", "col": "#c9a24a",
		"hab": "Ancla de hierro", "desc": "Golpea y atrae todos los ataques hacia él (recibe un 30% menos).",
		"frase": "«He cruzado mil mares y ninguno olía tanto a despedida como este.»",
	},
	"alba": {
		"nombre": "Sor Alba", "mundo": "el Convento de las Estrellas", "rol": "Sanadora",
		"hp": 32, "atk": 5, "tex": "h_alba", "col": "#8fb4d8",
		"hab": "Plegaria de estrellas", "desc": "Cura al héroe más herido y repara un poco el faro.",
		"frase": "«Vi apagarse mi cielo. Déjame ayudarte a cuidar el tuyo.»",
	},
	"koji": {
		"nombre": "Koji", "mundo": "el Valle de los Arces", "rol": "Duelista",
		"hp": 28, "atk": 10, "tex": "h_koji", "col": "#c2573a",
		"hab": "Corte de papel", "desc": "Un tajo certero: 2,2 veces su fuerza sobre un enemigo.",
		"frase": "«Mi espada recuerda a quienes ya no están.»",
	},
	"tumo": {
		"nombre": "Tumo", "mundo": "la Ciudad de los Relojes", "rol": "Autómata",
		"hp": 46, "atk": 5, "tex": "h_tumo", "col": "#b8a05a",
		"hab": "Cúpula de horas", "desc": "Una barrera reduce a la mitad el daño de la próxima embestida, a héroes y faro.",
		"frase": "«Mi cuerda se agota... pero aún me quedan horas para ti.»",
	},
	"lyra": {
		"nombre": "Lyra", "mundo": "el Archipiélago Volador", "rol": "Aeronauta",
		"hp": 30, "atk": 8, "tex": "h_lyra", "col": "#6fa6a0",
		"hab": "Tormenta de brújula", "desc": "Un estallido que alcanza a todos los enemigos.",
		"frase": "«Perdí mi globo entre las nubes. Tu luz es el único norte que me queda.»",
	},
	"nerea": {
		"nombre": "Nerea", "mundo": "la Tierra del Ocaso", "rol": "Cazadora",
		"hp": 31, "atk": 9, "tex": "h_nerea", "col": "#9a8fb8",
		"hab": "Saeta eclipsada", "desc": "Dispara al más débil: daño doble contra enemigos iluminados.",
		"frase": "«Cazo lo que vive en lo oscuro. Enséñamelo con tu luz.»",
	},
}

const ENEMIGOS: Dictionary = {
	"sombra": {"nombre": "Sombra de bruma", "hp": 16, "atk": 4, "tex": "m_sombra", "rasgo": "",
		"desc": "Frágil, pero llega en grupo."},
	"rondador": {"nombre": "Rondador de niebla", "hp": 30, "atk": 6, "tex": "m_rondador", "rasgo": "coraza",
		"desc": "Coraza de niebla: sin luz recibe un 35% menos de daño."},
	"espectro": {"nombre": "Espectro del naufragio", "hp": 22, "atk": 7, "tex": "m_espectro", "rasgo": "intangible",
		"desc": "Intangible: sin luz no se le puede herir."},
	"leviatan": {"nombre": "Leviatán de la Niebla", "hp": 110, "atk": 8, "tex": "m_leviatan2", "rasgo": "velo",
		"desc": "Ataca dos veces. Sin luz recibe un 40% menos de daño."},
}

const LUGARES: Array = [
	{"id": "playa", "nombre": "Playa de los Restos", "desc": "Barriles y maderos que arrastra la marea.",
		"botin": {"aceite": [2, 4], "madera": [0, 2], "hierro": [0, 1]},
		"eventos": ["Entre las algas hallas un violín sin cuerdas. Alguien lo echó de menos.",
			"La marea ha dejado un barril intacto y una bota de niño. Solo te llevas el barril.",
			"Un mascarón de proa te mira desde la arena. Parece querer decirte algo."]},
	{"id": "bosque", "nombre": "Bosque Gris", "desc": "Pinos doblados por un viento que ya no sopla.",
		"botin": {"madera": [2, 4], "aceite": [0, 2], "hierro": [0, 0]},
		"eventos": ["Los árboles susurran en un idioma de ramas. Cortas lo justo y pides perdón.",
			"Hay un columpio colgado de un pino. Se mece, aunque no hay brisa.",
			"Encuentras un hacha oxidada clavada en un tronco, como una promesa sin cumplir."]},
	{"id": "acantilado", "nombre": "Acantilado Roto", "desc": "Vetas de hierro y nidos que nadie habita.",
		"botin": {"hierro": [2, 3], "madera": [0, 1], "aceite": [0, 1]},
		"eventos": ["Desde lo alto, la niebla parece un mar de leche. Algo se mueve dentro.",
			"Rascas el hierro de una veta antigua. Suena a campana lejana.",
			"Un nido vacío, perfectamente cuidado. Esperan a alguien que no volverá."]},
	{"id": "ruinas", "nombre": "Ruinas Sumergidas", "desc": "Algo habitó aquí. Algo todavía susurra.",
		"botin": {"hierro": [1, 3], "aceite": [1, 3], "madera": [1, 2]},
		"eventos": ["Un reloj de pared marca una hora que no existe. Te llevas sus engranajes.",
			"En las paredes, mapas de mundos que nunca has visto. Todos acaban en un faro.",
			"Una mesa puesta para siete. Nadie ha tocado la sopa en cien años."]},
]

const DIARIOS: Array[String] = [
	"La niebla se ha retirado un poco. No te fíes: solo toma impulso.",
	"El faro cruje cuando el viento cambia. Es su forma de conversar contigo.",
	"Alguien ha dibujado una estrella en la ventana, por dentro. Nadie más vive aquí.",
	"Las gaviotas ya no vuelan hacia el mar abierto. Se quedan, como tú.",
	"Un día más. La lámpara brilla; eso es lo único que importa.",
]

static var d: Dictionary = {}
static var rng: RandomNumberGenerator = RandomNumberGenerator.new()


static func nuevo() -> void:
	d = {
		"empezada": false, "noche": 1, "dia": 1, "horas": HORAS_DIA,
		"aceite": 3, "madera": 2, "hierro": 2, "lente": 1, "faro_hp": 32,
		"heroes": {"ibsen": {"lvl": 1}}, "guardia": ["ibsen"],
		"final_visto": false, "mejor": 0, "diario": "", "ganadas": 0,
	}
	d["faro_hp"] = faro_max()
	guardar()


static func cargar() -> void:
	if not d.is_empty():
		return
	var s: Variant = Save.data.get("farero", null)
	if s is Dictionary and (s as Dictionary).has("heroes"):
		d = s as Dictionary
	else:
		nuevo()


static func guardar() -> void:
	Save.data["farero"] = d
	Save.save_data()


static func n(k: String) -> int:
	return int(d.get(k, 0))


static func tiene_partida() -> bool:
	return bool(d.get("empezada", false))


## Heroes y estadisticas
static func nivel(id: String) -> int:
	var h: Dictionary = (d["heroes"] as Dictionary).get(id, {})
	return int(h.get("lvl", 1))


static func hp_heroe(id: String, lvl: int) -> int:
	return int(round(float((HEROES[id] as Dictionary)["hp"]) * (1.0 + 0.22 * float(lvl - 1))))


static func atk_heroe(id: String, lvl: int) -> float:
	return float((HEROES[id] as Dictionary)["atk"]) * (1.0 + 0.2 * float(lvl - 1))


static func guardia() -> Array[String]:
	var out: Array[String] = []
	for g: Variant in (d["guardia"] as Array):
		var id: String = str(g)
		if (d["heroes"] as Dictionary).has(id):
			out.append(id)
	return out


static func alternar_guardia(id: String) -> bool:
	var g: Array = d["guardia"] as Array
	if g.has(id):
		if g.size() <= 1:
			return false
		g.erase(id)
		return true
	if g.size() >= GUARDIA_MAX:
		return false
	g.append(id)
	return true


static func fichar(id: String) -> bool:
	## Llega un nuevo heroe. Devuelve true si entra en la guardia.
	var hs: Dictionary = d["heroes"] as Dictionary
	if hs.has(id):
		return false
	var mx: int = 1
	for k: Variant in hs.keys():
		mx = maxi(mx, nivel(str(k)))
	hs[id] = {"lvl": maxi(1, mx - 1)}
	var g: Array = d["guardia"] as Array
	if g.size() < GUARDIA_MAX:
		g.append(id)
		return true
	return false


static func llegada_de_la_noche(noche: int) -> String:
	if noche >= 1 and noche <= LLEGADAS.size():
		var id: String = LLEGADAS[noche - 1]
		if not (d["heroes"] as Dictionary).has(id):
			return id
	return ""


## Faro
static func faro_max() -> int:
	return 24 + 8 * n("lente")


static func luz_max() -> int:
	return 4 + n("lente")


static func destello_dano() -> int:
	return 6 + 4 * n("lente")


static func coste_lente() -> Dictionary:
	var l: int = n("lente")
	return {"hierro": 3 + 2 * l, "madera": 2 + l}


static func coste_nivel(lvl: int) -> int:
	return 2 * lvl + 1


static func puede_pagar(c: Dictionary) -> bool:
	for k: Variant in c.keys():
		if n(str(k)) < int(c[k]):
			return false
	return true


static func pagar(c: Dictionary) -> bool:
	if not puede_pagar(c):
		return false
	for k: Variant in c.keys():
		d[str(k)] = n(str(k)) - int(c[k])
	return true


static func mejorar_lente() -> bool:
	if n("lente") >= LENTE_MAX or not pagar(coste_lente()):
		return false
	d["lente"] = n("lente") + 1
	d["faro_hp"] = mini(n("faro_hp") + 8, faro_max())
	guardar()
	return true


static func subir_heroe(id: String) -> bool:
	var lvl: int = nivel(id)
	if lvl >= NIVEL_MAX or not pagar({"hierro": coste_nivel(lvl)}):
		return false
	((d["heroes"] as Dictionary)[id] as Dictionary)["lvl"] = lvl + 1
	guardar()
	return true


static func reparar() -> bool:
	if n("faro_hp") >= faro_max() or n("madera") < 1:
		return false
	d["madera"] = n("madera") - 1
	d["faro_hp"] = mini(n("faro_hp") + 4, faro_max())
	guardar()
	return true


## Dia
static func explorar(i: int) -> Dictionary:
	if n("horas") <= 0:
		return {}
	var lug: Dictionary = LUGARES[i] as Dictionary
	var botin: Dictionary = {}
	var bt: Dictionary = lug["botin"] as Dictionary
	for k: Variant in bt.keys():
		var r: Array = bt[k] as Array
		var cant: int = rng.randi_range(int(r[0]), int(r[1]))
		if cant > 0:
			botin[str(k)] = cant
			d[str(k)] = n(str(k)) + cant
	d["horas"] = n("horas") - 1
	d["empezada"] = true
	var ev: Array = lug["eventos"] as Array
	var texto: String = str(ev[rng.randi() % ev.size()])
	d["diario"] = texto
	guardar()
	return {"texto": texto, "botin": botin}


## Noche
static func escala_hp(noche: int) -> float:
	return 1.0 + 0.15 * float(noche - 1)


static func escala_atk(noche: int) -> float:
	return 1.0 + 0.10 * float(noche - 1)


static func oleadas(noche: int) -> Array:
	match noche:
		1: return [["sombra", "sombra"]]
		2: return [["sombra", "rondador"]]
		3: return [["espectro"], ["sombra", "sombra"]]
		4: return [["rondador", "sombra"], ["espectro", "sombra"]]
		5: return [["rondador", "rondador"], ["espectro", "sombra", "sombra"]]
		6: return [["espectro", "espectro"], ["rondador", "rondador", "sombra"]]
		7: return [["sombra", "leviatan", "sombra"]]
	var pool: Array[String] = ["sombra", "rondador", "espectro"]
	var out: Array = []
	for w: int in 2:
		var ola: Array = []
		for j: int in rng.randi_range(2, 3):
			ola.append(pool[rng.randi() % pool.size()])
		out.append(ola)
	return out


static func botin_noche(noche: int) -> Dictionary:
	return {"aceite": 2 + floori(noche / 3.0), "madera": 2, "hierro": 1 + floori(noche / 2.0)}


static func amanecer(victoria: bool) -> Dictionary:
	var botin: Dictionary = botin_noche(n("noche")) if victoria else {"aceite": 1, "madera": 1, "hierro": 1}
	for k: Variant in botin.keys():
		d[str(k)] = n(str(k)) + int(botin[k])
	if victoria:
		d["ganadas"] = n("ganadas") + 1
		d["mejor"] = maxi(n("mejor"), n("noche"))
		Save.submit_best("noche", n("noche"))
		d["noche"] = n("noche") + 1
	d["dia"] = n("dia") + 1
	d["horas"] = HORAS_DIA
	var cura: int = int(ceil(float(faro_max()) * 0.3))
	d["faro_hp"] = clampi(n("faro_hp") + cura, ceili(faro_max() * 0.3), faro_max())
	d["diario"] = DIARIOS[rng.randi() % DIARIOS.size()]
	d["empezada"] = true
	guardar()
	return botin

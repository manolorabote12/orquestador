extends Control
## La noche: combate por turnos donde la luz del faro es un recurso.

const ISLA: String = "res://libre/isla.tscn"
const TITULO: String = "res://libre/main.tscn"

var noche: int = 1
var heroes: Array[Dictionary] = []
var enemigos: Array[Dictionary] = []
var oleadas: Array = []
var oleada_i: int = -1
var faro_hp: int = 30
var faro_max: int = 30
var luz: int = 3
var luz_max: int = 5
var turno: int = 0
var sel: int = -1
var modo: String = "atk"
var busy: bool = true
var over: bool = false
var gano: bool = false
var provoca: int = -1
var barrera: bool = false
var llegada_pendiente: bool = false
var _primer_turno: bool = true
var _llegada: String = ""

var _mundo: Control
var _haz: Polygon2D
var _destello: ColorRect
var _lbl_titulo: Label
var _lbl_faro: Label
var _barra_faro: ProgressBar
var _panel_faro: PanelContainer
var _pips: Pips
var _lbl_hint: Label
var _btn_atk: Button
var _btn_hab: Button
var _btn_luz: Button
var _btn_dest: Button
var _btn_fin: Button
var _btn_huir: Button
var _modal_fin: Dictionary = {}
var _pulso_fin: Tween = null


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Audio.play_track("nivel")
	noche = Estado.n("noche")
	faro_max = Estado.faro_max()
	faro_hp = clampi(Estado.n("faro_hp"), 1, faro_max)
	luz_max = Estado.luz_max()
	luz = clampi(int(Estado.d.get("luz_inicial", 3)), 1, luz_max)
	_llegada = Estado.llegada_de_la_noche(noche)
	if _llegada != "":
		Estado.fichar(_llegada)
		Estado.guardar()
	_construir_base()
	_construir_heroes()
	_construir_panel()
	oleadas = Estado.oleadas(noche)
	if _llegada != "":
		_mostrar_llegada()
	else:
		_comenzar()


func _comenzar() -> void:
	llegada_pendiente = false
	_siguiente_oleada()


func cerrar_llegada() -> void:
	if not llegada_pendiente:
		return
	Estilo.cerrar(_modal_fin)
	_modal_fin = {}
	_comenzar()


# ------------------------------------------------------------ construccion
func _construir_base() -> void:
	_mundo = Control.new()
	_mundo.size = Vector2(720, 1280)
	_mundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_mundo)
	Estilo.fondo_cubrir(_mundo, "bg_noche", 1.07)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.04, 0.09, 0.22)
	vel.size = Vector2(720, 1280)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mundo.add_child(vel)
	for i: int in 3:
		var t: TextureRect = TextureRect.new()
		t.texture = Juice.dot_texture()
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.size = Vector2(560, 220)
		t.position = Vector2(-200 + i * 220, 280 + i * 130)
		t.modulate = Color(0.75, 0.85, 0.92, 0.14)
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_mundo.add_child(t)
		var tw: Tween = t.create_tween().set_loops()
		tw.tween_property(t, "position:x", t.position.x + 120.0, 8.0 + i * 2.0).set_trans(Tween.TRANS_SINE)
		tw.tween_property(t, "position:x", t.position.x, 8.0 + i * 2.0).set_trans(Tween.TRANS_SINE)
	_haz = Polygon2D.new()
	_haz.color = Color(1.0, 0.86, 0.5, 0.55)
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_haz.material = mat
	_haz.modulate.a = 0.0
	_mundo.add_child(_haz)
	# cabecera
	_btn_huir = Estilo.boton("Huir", false, 80)
	_btn_huir.position = Vector2(16, 16)
	_btn_huir.size = Vector2(130, 80)
	_btn_huir.pressed.connect(_pedir_huir)
	_mundo.add_child(_btn_huir)
	_lbl_titulo = Estilo.etiqueta("Noche %d" % noche, 36, Estilo.ORO)
	_lbl_titulo.position = Vector2(160, 16)
	_lbl_titulo.size = Vector2(544, 80)
	_mundo.add_child(_lbl_titulo)
	_panel_faro = Estilo.panel(Color(0.05, 0.07, 0.12, 0.85))
	_panel_faro.position = Vector2(16, 104)
	_panel_faro.size = Vector2(688, 140)
	_mundo.add_child(_panel_faro)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	_panel_faro.add_child(vb)
	_lbl_faro = Estilo.etiqueta("", 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_faro)
	_barra_faro = Estilo.barra(Color("c9ced6"), 16.0)
	vb.add_child(_barra_faro)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	vb.add_child(hb)
	hb.add_child(Estilo.etiqueta("Luz", 26, Estilo.ORO))
	_pips = Pips.new(luz_max, Estilo.ORO, 14.0)
	hb.add_child(_pips)
	_destello = ColorRect.new()
	_destello.color = Color(1, 0.95, 0.8, 0.0)
	_destello.size = Vector2(720, 1280)
	_destello.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_destello.z_index = 50
	_mundo.add_child(_destello)


func _centros(n: int, ancho: float) -> Array[float]:
	var out: Array[float] = []
	match n:
		1: out = [360.0]
		2: out = [210.0, 510.0]
		_: out = [ancho * 0.55, 360.0, 720.0 - ancho * 0.55]
	return out


func _crear_unidad(es_enemigo: bool, id: String, cx: float, y: float, ancho: float, alto_spr: float, texid: String, nombre: String, col_barra: Color) -> Dictionary:
	var u: Control = Control.new()
	u.size = Vector2(ancho, alto_spr + 150.0)
	u.position = Vector2(cx - ancho / 2.0, y)
	u.pivot_offset = Vector2(ancho / 2.0, alto_spr)
	u.mouse_filter = Control.MOUSE_FILTER_STOP
	_mundo.add_child(u)
	var oy: float = 54.0 if es_enemigo else 0.0
	var ring: Panel = Panel.new()
	var sb: StyleBoxFlat = Estilo.caja(Color(1, 0.85, 0.4, 0.14), Estilo.ORO, 18, 3)
	sb.shadow_size = 0
	ring.add_theme_stylebox_override("panel", sb)
	ring.position = Vector2(8, oy - 6)
	ring.size = Vector2(ancho - 16, alto_spr + 100.0)
	ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ring.visible = false
	u.add_child(ring)
	var halo: TextureRect = TextureRect.new()
	halo.texture = Juice.dot_texture()
	halo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	halo.size = Vector2(ancho + 50.0, alto_spr + 40.0)
	halo.position = Vector2(-25.0, oy - 20.0)
	halo.modulate = Color(1.0, 0.86, 0.45, 0.6)
	halo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	halo.visible = false
	u.add_child(halo)
	var spr: TextureRect = Estilo.sprite(texid, Vector2(ancho, alto_spr), 0.14 if id == "leviatan" else 0.0)
	spr.position = Vector2(0, oy)
	u.add_child(spr)
	var ln: Label = Estilo.etiqueta(nombre, 21, Estilo.TEXTO)
	ln.position = Vector2(-10, oy + alto_spr + 2.0)
	ln.size = Vector2(ancho + 20.0, 28)
	u.add_child(ln)
	var bar: ProgressBar = Estilo.barra(col_barra, 16.0)
	bar.position = Vector2(14, oy + alto_spr + 32.0)
	bar.size = Vector2(ancho - 28.0, 16)
	u.add_child(bar)
	var est: Label = Estilo.etiqueta("", 20, Estilo.ORO)
	est.position = Vector2(-10, oy + alto_spr + 50.0)
	est.size = Vector2(ancho + 20.0, 28)
	u.add_child(est)
	var intent: Label = Estilo.etiqueta("", 20, Estilo.ROJO)
	intent.position = Vector2(-20, 0)
	intent.size = Vector2(ancho + 40.0, 54)
	u.add_child(intent)
	return {"nodo": u, "spr": spr, "bar": bar, "est": est, "intent": intent, "halo": halo, "ring": ring, "nombre": ln}


func _construir_heroes() -> void:
	var ids: Array[String] = Estado.guardia()
	if ids.is_empty():
		ids = ["ibsen"]
		if not (Estado.d["heroes"] as Dictionary).has("ibsen"):
			Estado.fichar("ibsen")
	var cs: Array[float] = _centros(ids.size(), 220.0)
	for i: int in ids.size():
		var id: String = ids[i]
		var def: Dictionary = Estado.HEROES[id] as Dictionary
		var lvl: int = Estado.nivel(id)
		var hpm: int = Estado.hp_heroe(id, lvl)
		var u: Dictionary = _crear_unidad(false, id, cs[i], 652.0, 220.0, 190.0, str(def["tex"]), str(def["nombre"]), Color("86bba8"))
		var h: Dictionary = u.duplicate()
		h["id"] = id
		h["lvl"] = lvl
		h["hp"] = hpm
		h["hpmax"] = hpm
		h["atk"] = Estado.atk_heroe(id, lvl)
		h["actuo"] = false
		h["vivo"] = true
		(h["bar"] as ProgressBar).max_value = hpm
		(h["bar"] as ProgressBar).value = hpm
		var idx: int = i
		(h["nodo"] as Control).gui_input.connect(func(ev: InputEvent) -> void:
			if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
				_tap_heroe(idx))
		heroes.append(h)
		UI.pop_in(h["nodo"] as Control, 0.1 * i)


func _construir_panel() -> void:
	_lbl_hint = Estilo.etiqueta("", 22, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	_lbl_hint.position = Vector2(20, 912)
	_lbl_hint.size = Vector2(680, 64)
	_mundo.add_child(_lbl_hint)
	_btn_atk = _boton_accion("Atacar\n(gratis)", Vector2(20, 982), Vector2(334, 84), _on_atk)
	_btn_hab = _boton_accion("Habilidad\n1 luz", Vector2(366, 982), Vector2(334, 84), _on_hab)
	_btn_luz = _boton_accion("Iluminar\n1 luz · debilita", Vector2(20, 1074), Vector2(334, 84), _on_luz)
	_btn_dest = _boton_accion("Destello del faro\n3 luz · a todos", Vector2(366, 1074), Vector2(334, 84), _on_dest)
	_btn_fin = Estilo.boton("Terminar turno", true, 88)
	_btn_fin.position = Vector2(20, 1168)
	_btn_fin.size = Vector2(680, 88)
	_btn_fin.pressed.connect(terminar_turno)
	_mundo.add_child(_btn_fin)


func _boton_accion(t: String, pos: Vector2, tam: Vector2, f: Callable) -> Button:
	var b: Button = Estilo.boton(t, false, tam.y)
	b.position = pos
	b.size = tam
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(f)
	_mundo.add_child(b)
	return b


func _mostrar_llegada() -> void:
	llegada_pendiente = true
	var def: Dictionary = Estado.HEROES[_llegada] as Dictionary
	var m: Dictionary = Estilo.modal(self, "La niebla trae a alguien", 620.0)
	_modal_fin = m
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var s: TextureRect = Estilo.sprite(str(def["tex"]), Vector2(260, 330))
	s.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(s)
	vb.add_child(Estilo.etiqueta(str(def["nombre"]), 40, Color(str(def["col"])).lightened(0.3)))
	vb.add_child(Estilo.etiqueta("%s de %s" % [def["rol"], def["mundo"]], 24, Estilo.NIEBLA))
	var fr: Label = Estilo.etiqueta(str(def["frase"]), 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	fr.custom_minimum_size = Vector2(560, 0)
	vb.add_child(fr)
	if not Estado.guardia().has(_llegada):
		var nota: Label = Estilo.etiqueta("La guardia está completa: se queda en reserva. Cámbialo de día en «Héroes».", 21, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, true)
		nota.custom_minimum_size = Vector2(560, 0)
		vb.add_child(nota)
	var b: Button = Estilo.boton("Bienvenido", true, 92)
	b.pressed.connect(cerrar_llegada)
	vb.add_child(b)
	Audio.play("powerup", 0.05, -4.0, 0.8)
	Estilo.fundir(s, 0.0, 1.0, 0.8)


# ------------------------------------------------------------ oleadas y turnos
func _esperar(t: float) -> void:
	await get_tree().create_timer(t).timeout


func _banner(texto: String, col: Color = Color(0.91, 0.72, 0.34)) -> void:
	var l: Label = Estilo.etiqueta(texto, 50, col)
	l.position = Vector2(0, 470)
	l.size = Vector2(720, 90)
	l.z_index = 40
	l.modulate.a = 0.0
	_mundo.add_child(l)
	var tw: Tween = l.create_tween()
	tw.tween_property(l, "modulate:a", 1.0, 0.3)
	tw.tween_interval(0.7)
	tw.tween_property(l, "modulate:a", 0.0, 0.4)
	tw.tween_callback(l.queue_free)


func _siguiente_oleada() -> void:
	oleada_i += 1
	for e: Dictionary in enemigos:
		(e["nodo"] as Control).queue_free()
	enemigos.clear()
	var lista: Array = oleadas[oleada_i] as Array
	var n: int = lista.size()
	var cs: Array[float] = _centros(n, 220.0)
	if lista.has("leviatan"):
		cs = [100.0, 360.0, 620.0]
	for i: int in n:
		var id: String = str(lista[i])
		var def: Dictionary = Estado.ENEMIGOS[id] as Dictionary
		var boss: bool = id == "leviatan"
		var ancho: float = 300.0 if boss else (200.0 if lista.has("leviatan") else 220.0)
		var alto: float = 250.0 if boss else 215.0
		var u: Dictionary = _crear_unidad(true, id, cs[i], 250.0 if boss else 262.0, ancho, alto, str(def["tex"]), str(def["nombre"]), Color("c4604b"))
		var hpm: int = int(round(float(def["hp"]) * Estado.escala_hp(noche)))
		if noche == 1:
			hpm = int(round(hpm * 0.9))
		var e: Dictionary = u.duplicate()
		e["id"] = id
		e["hp"] = hpm
		e["hpmax"] = hpm
		e["atk"] = float(def["atk"]) * Estado.escala_atk(noche)
		e["rasgo"] = str(def["rasgo"])
		e["lit"] = 0
		e["vivo"] = true
		e["ataques"] = []
		(e["bar"] as ProgressBar).max_value = hpm
		(e["bar"] as ProgressBar).value = hpm
		var idx: int = i
		(e["nodo"] as Control).gui_input.connect(func(ev: InputEvent) -> void:
			if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
				_tap_enemigo(idx))
		enemigos.append(e)
		Estilo.fundir(e["spr"] as TextureRect, 0.0, 1.0, 0.7)
		var nodo: Control = e["nodo"] as Control
		nodo.scale = Vector2(0.85, 0.85)
		nodo.create_tween().tween_property(nodo, "scale", Vector2.ONE, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_lbl_titulo.text = "Noche %d · Oleada %d de %d" % [noche, oleada_i + 1, oleadas.size()]
	if lista.has("leviatan"):
		_banner("¡El Leviatán emerge!", Estilo.ROJO)
		Audio.play("explode", 0.0, -4.0, 0.6)
		_temblar(0.5)
	else:
		_banner("Oleada %d" % (oleada_i + 1))
	await _esperar(0.9)
	_inicio_turno()


func _inicio_turno() -> void:
	if over:
		return
	turno += 1
	if not _primer_turno:
		luz = mini(luz_max, luz + 2)
	_primer_turno = false
	for h: Dictionary in heroes:
		h["actuo"] = false
	_planear_ataques()
	modo = "atk"
	busy = false
	_auto_seleccionar()
	_ui()


func _vivos_h() -> Array[int]:
	var out: Array[int] = []
	for i: int in heroes.size():
		if bool(heroes[i]["vivo"]):
			out.append(i)
	return out


func _vivos_e() -> Array[int]:
	var out: Array[int] = []
	for i: int in enemigos.size():
		if bool(enemigos[i]["vivo"]):
			out.append(i)
	return out


func _planear_ataques() -> void:
	var vh: Array[int] = _vivos_h()
	for e: Dictionary in enemigos:
		var lista: Array = []
		if not bool(e["vivo"]):
			e["ataques"] = lista
			continue
		var cuantos: int = 2 if str(e["id"]) == "leviatan" else 1
		for k: int in cuantos:
			var faro: bool = Estado.rng.randf() < 0.4 or vh.is_empty()
			if str(e["id"]) == "leviatan":
				faro = k == 1
			if faro:
				lista.append({"tipo": "faro", "idx": -1})
			else:
				lista.append({"tipo": "hero", "idx": vh[Estado.rng.randi() % vh.size()]})
		e["ataques"] = lista


func _objetivo(a: Dictionary) -> Dictionary:
	if provoca >= 0 and bool(heroes[provoca]["vivo"]):
		return {"tipo": "hero", "idx": provoca}
	if str(a["tipo"]) == "hero":
		var i: int = int(a["idx"])
		if bool(heroes[i]["vivo"]):
			return a
		var vh: Array[int] = _vivos_h()
		if vh.is_empty():
			return {"tipo": "faro", "idx": -1}
		return {"tipo": "hero", "idx": vh[0]}
	return a


func _dano_ataque(e: Dictionary, obj: Dictionary) -> int:
	var d: float = float(e["atk"])
	if int(e["lit"]) > 0:
		d *= 0.6
	if barrera:
		d *= 0.5
	if str(obj["tipo"]) == "hero" and int(obj["idx"]) == provoca:
		d *= 0.7
	return maxi(1, int(round(d)))


func _dano_a_enemigo(base: float, e: Dictionary) -> int:
	var lit: bool = int(e["lit"]) > 0
	var m: float = 1.0
	if lit:
		m = 1.5
	else:
		match str(e["rasgo"]):
			"coraza": m = 0.65
			"intangible": return 0
			"velo": m = 0.6
	return maxi(1, int(round(base * m)))


func _auto_seleccionar() -> void:
	if sel >= 0 and sel < heroes.size() and bool(heroes[sel]["vivo"]) and not bool(heroes[sel]["actuo"]):
		return
	sel = -1
	for i: int in heroes.size():
		if bool(heroes[i]["vivo"]) and not bool(heroes[i]["actuo"]):
			sel = i
			return


func _quedan_por_actuar() -> bool:
	for h: Dictionary in heroes:
		if bool(h["vivo"]) and not bool(h["actuo"]):
			return true
	return false


# ------------------------------------------------------------ interfaz
func _necesita_objetivo(id: String) -> bool:
	return id == "ibsen" or id == "koji" or id == "nerea"


func _ui() -> void:
	_pips.poner(luz_max, luz)
	_barra_faro.max_value = faro_max
	create_tween().tween_property(_barra_faro, "value", float(faro_hp), 0.25)
	_lbl_faro.text = "Integridad del faro  %d / %d" % [faro_hp, faro_max]
	var vh: bool = sel >= 0 and not busy and not over
	var ve: int = _vivos_e().size()
	_btn_atk.disabled = not vh
	_btn_hab.disabled = not vh or luz < 1
	_btn_luz.disabled = busy or over or luz < 1 or ve == 0
	_btn_dest.disabled = busy or over or luz < 3 or ve == 0
	_btn_fin.disabled = busy or over
	_btn_huir.disabled = busy or over
	if sel >= 0:
		var hid: String = str(heroes[sel]["id"])
		var def: Dictionary = Estado.HEROES[hid] as Dictionary
		_btn_hab.text = "%s\n1 luz" % def["hab"]
	else:
		_btn_hab.text = "Habilidad\n1 luz"
	for b: Button in [_btn_atk, _btn_hab, _btn_luz]:
		b.modulate = Color.WHITE
	if not busy and not over:
		if modo == "atk" and sel >= 0:
			_btn_atk.modulate = Color(1.3, 1.15, 0.8)
		elif modo == "hab":
			_btn_hab.modulate = Color(1.3, 1.15, 0.8)
		elif modo == "luz":
			_btn_luz.modulate = Color(1.3, 1.15, 0.8)
	for i: int in heroes.size():
		var h: Dictionary = heroes[i]
		(h["ring"] as Panel).visible = i == sel and not busy
		var st: String = ""
		if not bool(h["vivo"]):
			st = "Caído"
		elif i == provoca:
			st = "Provoca"
		elif bool(h["actuo"]):
			st = "Ya actuó"
		elif barrera:
			st = "Barrera"
		(h["est"] as Label).text = st
		if bool(h["vivo"]):
			Estilo.param(h["spr"] as CanvasItem, "gris", 0.6 if bool(h["actuo"]) else 0.0)
	for e: Dictionary in enemigos:
		if not bool(e["vivo"]):
			continue
		var lit: int = int(e["lit"])
		(e["halo"] as TextureRect).visible = lit > 0
		(e["est"] as Label).text = "Iluminado ×%d" % lit if lit > 0 else ("Intangible" if str(e["rasgo"]) == "intangible" else ("Coraza" if str(e["rasgo"]) == "coraza" else ("Velo" if str(e["rasgo"]) == "velo" else "")))
		(e["est"] as Label).add_theme_color_override("font_color", Estilo.ORO if lit > 0 else Estilo.NIEBLA)
		_texto_intentos(e)
	if _pulso_fin != null:
		_pulso_fin.kill()
		_pulso_fin = null
	_btn_fin.scale = Vector2.ONE
	if not busy and not over and not _quedan_por_actuar():
		_pulso_fin = Estilo.pulso(_btn_fin)
	_lbl_hint.text = _texto_hint()


func _texto_intentos(e: Dictionary) -> void:
	var t: Array[String] = []
	for a: Dictionary in (e["ataques"] as Array):
		var obj: Dictionary = _objetivo(a)
		var d: int = _dano_ataque(e, obj)
		if str(obj["tipo"]) == "faro":
			t.append("→ Faro  %d" % d)
		else:
			t.append("→ %s  %d" % [str(Estado.HEROES[str(heroes[int(obj["idx"])]["id"])]["nombre"]).split(" ")[-1], d])
	var l: Label = e["intent"] as Label
	l.text = "\n".join(t)
	var faro: bool = t.size() > 0 and t[0].begins_with("→ Faro")
	l.add_theme_color_override("font_color", Estilo.ROJO if faro else Color("e8a35e"))


func _texto_hint() -> String:
	if over:
		return ""
	if busy:
		return "..."
	if modo == "luz":
		return "Toca al enemigo que quieres iluminar."
	if not _quedan_por_actuar():
		return "Todos han actuado. Gasta luz si quieres o termina el turno."
	for e: Dictionary in enemigos:
		if bool(e["vivo"]) and str(e["rasgo"]) == "intangible" and int(e["lit"]) <= 0:
			return "Los espectros son intangibles: ¡ilumínalos para poder herirlos!"
	if noche == 1 and turno <= 2:
		return "Toca un héroe y luego a un enemigo. Iluminar (1 luz) lo debilita: recibe más daño y golpea con menos fuerza."
	if sel >= 0:
		return "%s: toca a un enemigo para atacarle." % str(Estado.HEROES[str(heroes[sel]["id"])]["nombre"])
	return "Toca un héroe para elegirlo."


func _temblar(f: float) -> void:
	var tw: Tween = _mundo.create_tween()
	for i: int in 5:
		var k: float = f * 16.0 * (1.0 - float(i) / 5.0)
		tw.tween_property(_mundo, "position", Vector2(Estado.rng.randf_range(-k, k), Estado.rng.randf_range(-k, k)), 0.04)
	tw.tween_property(_mundo, "position", Vector2.ZERO, 0.04)


func _popup(pos: Vector2, texto: String, col: Color, tam: int = 40) -> void:
	UI.float_text(_mundo, pos, texto, col, tam)


func _centro_enemigo(i: int) -> Vector2:
	var n: Control = enemigos[i]["nodo"] as Control
	return n.position + Vector2(n.size.x / 2.0, 54.0 + 110.0)


func _centro_heroe(i: int) -> Vector2:
	var n: Control = heroes[i]["nodo"] as Control
	return n.position + Vector2(n.size.x / 2.0, 95.0)


# ------------------------------------------------------------ toques
func _tap_heroe(i: int) -> void:
	if busy or over or i >= heroes.size():
		return
	if bool(heroes[i]["vivo"]) and not bool(heroes[i]["actuo"]):
		sel = i
		modo = "atk"
		Audio.play("click")
		_ui()


func _tap_enemigo(i: int) -> void:
	if busy or over or i >= enemigos.size() or not bool(enemigos[i]["vivo"]):
		return
	if modo == "luz":
		accion_iluminar(i)
	elif sel >= 0:
		if modo == "hab":
			accion_habilidad(sel, i)
		else:
			accion_atacar(sel, i)
	else:
		Audio.play("hurt", 0.05, -10.0)


func _unico_enemigo() -> int:
	var v: Array[int] = _vivos_e()
	return v[0] if v.size() == 1 else -1


func _on_atk() -> void:
	if busy or sel < 0:
		return
	modo = "atk"
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_atacar(sel, u)
	else:
		_ui()


func _on_hab() -> void:
	if busy or sel < 0:
		return
	modo = "hab"
	var id: String = str(heroes[sel]["id"])
	if not _necesita_objetivo(id):
		accion_habilidad(sel, -1)
		return
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_habilidad(sel, u)
	else:
		_ui()


func _on_luz() -> void:
	if busy:
		return
	modo = "luz"
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_iluminar(u)
	else:
		_ui()


func _on_dest() -> void:
	accion_destello()


func _pedir_huir() -> void:
	if busy or over:
		return
	Estilo.confirmar(self, "¿Huir de la noche?", "La niebla se cobrará su precio: volverás al día sin botín de la noche.", "Huir", "Quedarme", func() -> void:
		if not busy and not over:
			_derrota("huida"))


# ------------------------------------------------------------ acciones del jugador
func _puede_actuar(hi: int) -> bool:
	return not busy and not over and hi >= 0 and hi < heroes.size() and bool(heroes[hi]["vivo"]) and not bool(heroes[hi]["actuo"])


func _embestida(nodo: Control, destino: Vector2, frac: float, arriba: bool = false) -> void:
	var p0: Vector2 = nodo.position
	var centro: Vector2 = nodo.position + Vector2(nodo.size.x / 2.0, 100.0)
	var dir: Vector2 = (destino - centro) * frac
	if arriba:
		dir = Vector2(0, 40)
	var tw: Tween = nodo.create_tween()
	tw.tween_property(nodo, "position", p0 + dir, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(nodo, "position", p0, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	await _esperar(0.12)


func _golpear_enemigo(ei: int, dmg: int, col: Color = Color("f1e7cf")) -> void:
	var e: Dictionary = enemigos[ei]
	var c: Vector2 = _centro_enemigo(ei)
	if dmg <= 0:
		_popup(c + Vector2(-60, -60), "¡Atraviesa!", Estilo.NIEBLA, 34)
		Audio.play("hurt", 0.05, -12.0, 1.6)
		return
	e["hp"] = maxi(0, int(e["hp"]) - dmg)
	create_tween().tween_property(e["bar"] as ProgressBar, "value", float(e["hp"]), 0.25)
	_popup(c + Vector2(-30, -70), "-%d" % dmg, col, 44)
	Estilo.destello(e["spr"] as CanvasItem, Color(1, 1, 1), 0.2)
	Juice.burst(_mundo, c, Color(0.9, 0.85, 0.7), 8, 200.0)
	Audio.play("explode", 0.1, -10.0, 1.7)
	_temblar(0.12)
	if int(e["hp"]) <= 0:
		e["vivo"] = false
		(e["intent"] as Label).text = ""
		(e["est"] as Label).text = ""
		(e["halo"] as TextureRect).visible = false
		Audio.play("explode", 0.1, -4.0)
		Juice.burst(_mundo, c, Color(0.7, 0.8, 0.85), 18, 300.0)
		Juice.ring(_mundo, c, Color(0.8, 0.9, 1.0), 90.0)
		Estilo.fundir(e["spr"] as TextureRect, 1.0, 0.0, 0.5)
		(e["nodo"] as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		Juice.hitstop(0.05)


func _lanzar_haz(dest: Vector2) -> void:
	var o: Vector2 = Vector2(360, 1000)
	var dir: Vector2 = (dest - o).normalized()
	var perp: Vector2 = Vector2(-dir.y, dir.x)
	_haz.polygon = PackedVector2Array([o + perp * 12.0, o - perp * 12.0, dest - perp * 95.0, dest + perp * 95.0])
	_haz.modulate.a = 1.0
	var tw: Tween = _haz.create_tween()
	tw.tween_interval(0.2)
	tw.tween_property(_haz, "modulate:a", 0.0, 0.4)


func accion_atacar(hi: int, ei: int) -> void:
	if not _puede_actuar(hi) or ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"]):
		return
	busy = true
	var h: Dictionary = heroes[hi]
	h["actuo"] = true
	_ui()
	await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.45)
	await _golpear_enemigo(ei, _dano_a_enemigo(float(h["atk"]), enemigos[ei]))
	await _esperar(0.25)
	await _tras_accion()


func accion_habilidad(hi: int, ei: int) -> void:
	if not _puede_actuar(hi) or luz < 1:
		return
	var h: Dictionary = heroes[hi]
	var id: String = str(h["id"])
	if _necesita_objetivo(id) and (ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"])):
		return
	busy = true
	luz -= 1
	h["actuo"] = true
	_ui()
	var atk: float = float(h["atk"])
	var c: Vector2 = _centro_heroe(hi)
	Audio.play("powerup", 0.05, -4.0, 1.2)
	Juice.sparkle(_mundo, c, Color(str((Estado.HEROES[id] as Dictionary)["col"])), 8, 220.0)
	_popup(c + Vector2(-80, -110), str((Estado.HEROES[id] as Dictionary)["hab"]), Color(str((Estado.HEROES[id] as Dictionary)["col"])).lightened(0.3), 28)
	match id:
		"ibsen":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.5)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 1.2, enemigos[ei]))
			provoca = hi
		"koji":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.55)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 2.2, enemigos[ei]), Color("ffd98a"))
		"nerea":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.2)
			var mult: float = 1.3 * (2.0 if int(enemigos[ei]["lit"]) > 0 else 1.0)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * mult, enemigos[ei]), Color("ffd98a"))
		"alba":
			var peor: int = -1
			var ratio: float = 2.0
			for i: int in heroes.size():
				if bool(heroes[i]["vivo"]):
					var r: float = float(heroes[i]["hp"]) / float(heroes[i]["hpmax"])
					if r < ratio:
						ratio = r
						peor = i
			if peor >= 0:
				var cura: int = int(round(6.0 + atk * 1.6))
				var t: Dictionary = heroes[peor]
				t["hp"] = mini(int(t["hpmax"]), int(t["hp"]) + cura)
				create_tween().tween_property(t["bar"] as ProgressBar, "value", float(t["hp"]), 0.3)
				_popup(_centro_heroe(peor) + Vector2(-20, -60), "+%d" % cura, Estilo.VERDE, 44)
				Juice.sparkle(_mundo, _centro_heroe(peor), Estilo.VERDE, 8, 160.0)
			faro_hp = mini(faro_max, faro_hp + 5)
			_popup(Vector2(500, 150), "+5 faro", Estilo.VERDE, 30)
			await _esperar(0.35)
		"tumo":
			barrera = true
			for i: int in heroes.size():
				Juice.ring(_mundo, _centro_heroe(i), Color("d9c27a"), 80.0)
			await _esperar(0.35)
		"lyra":
			for ei2: int in _vivos_e():
				_lanzar_haz(_centro_enemigo(ei2))
				await _golpear_enemigo(ei2, _dano_a_enemigo(atk * 1.0, enemigos[ei2]), Color("9fe0d4"))
			await _esperar(0.1)
	modo = "atk"
	await _esperar(0.2)
	await _tras_accion()


func accion_iluminar(ei: int) -> void:
	if busy or over or luz < 1 or ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"]):
		return
	busy = true
	luz -= 1
	var e: Dictionary = enemigos[ei]
	e["lit"] = 2
	var c: Vector2 = _centro_enemigo(ei)
	_lanzar_haz(c)
	Audio.play("powerup", 0.03, -3.0, 1.5)
	Juice.sparkle(_mundo, c, Estilo.ORO, 10, 220.0)
	_popup(c + Vector2(-70, -90), "¡Iluminado!", Estilo.ORO, 34)
	Estilo.destello(e["spr"] as CanvasItem, Color(1.0, 0.9, 0.55), 0.35)
	modo = "atk"
	_ui()
	await _esperar(0.4)
	busy = false
	_auto_seleccionar()
	_ui()


func accion_destello() -> void:
	if busy or over or luz < 3 or _vivos_e().is_empty():
		return
	busy = true
	luz -= 3
	_ui()
	_destello.color.a = 0.0
	var tw: Tween = _destello.create_tween()
	tw.tween_property(_destello, "color:a", 0.7, 0.12)
	tw.tween_property(_destello, "color:a", 0.0, 0.5)
	Audio.play("explode", 0.0, -2.0, 1.2)
	Juice.vibrate(60)
	_temblar(0.3)
	await _esperar(0.2)
	for ei: int in _vivos_e():
		enemigos[ei]["lit"] = 2
		_lanzar_haz(_centro_enemigo(ei))
		await _golpear_enemigo(ei, _dano_a_enemigo(float(Estado.destello_dano()), enemigos[ei]), Color("fff1b0"))
	modo = "atk"
	await _esperar(0.2)
	await _tras_accion()


func _tras_accion() -> void:
	if over:
		return
	if _vivos_e().is_empty():
		await _fin_oleada()
		return
	busy = false
	_auto_seleccionar()
	_ui()


func _fin_oleada() -> void:
	busy = true
	_ui()
	if oleada_i + 1 < oleadas.size():
		await _esperar(0.6)
		await _siguiente_oleada()
	else:
		await _victoria()


# ------------------------------------------------------------ fase enemiga
func terminar_turno() -> void:
	if busy or over:
		return
	busy = true
	sel = -1
	_ui()
	await _fase_enemiga()


func _fase_enemiga() -> void:
	_banner("La niebla ataca", Estilo.ROJO)
	await _esperar(0.5)
	for ei: int in enemigos.size():
		var e: Dictionary = enemigos[ei]
		if not bool(e["vivo"]):
			continue
		for a: Dictionary in (e["ataques"] as Array):
			var obj: Dictionary = _objetivo(a)
			var dmg: int = _dano_ataque(e, obj)
			var dest: Vector2 = Vector2(360, 190) if str(obj["tipo"]) == "faro" else _centro_heroe(int(obj["idx"]))
			await _embestida(e["nodo"] as Control, dest, 0.35)
			if str(obj["tipo"]) == "faro":
				faro_hp = maxi(0, faro_hp - dmg)
				_popup(Vector2(480, 150), "-%d" % dmg, Estilo.ROJO, 46)
				Estilo.destello(_barra_faro, Color(1, 0.3, 0.2), 0.3)
				_panel_faro.modulate = Color(1.6, 0.6, 0.5)
				_panel_faro.create_tween().tween_property(_panel_faro, "modulate", Color.WHITE, 0.4)
				create_tween().tween_property(_barra_faro, "value", float(faro_hp), 0.2)
				_lbl_faro.text = "Integridad del faro  %d / %d" % [faro_hp, faro_max]
				Audio.play("hurt", 0.05, 0.0, 0.7)
				Juice.vibrate(40)
				_temblar(0.45)
			else:
				var hi: int = int(obj["idx"])
				var h: Dictionary = heroes[hi]
				h["hp"] = maxi(0, int(h["hp"]) - dmg)
				create_tween().tween_property(h["bar"] as ProgressBar, "value", float(h["hp"]), 0.2)
				_popup(_centro_heroe(hi) + Vector2(-20, -70), "-%d" % dmg, Estilo.ROJO, 44)
				Estilo.destello(h["spr"] as CanvasItem, Color(1, 0.25, 0.2), 0.3)
				Audio.play("hurt", 0.08)
				Juice.vibrate(30)
				_temblar(0.25)
				if int(h["hp"]) <= 0:
					h["vivo"] = false
					Estilo.param(h["spr"] as CanvasItem, "gris", 1.0)
					Estilo.param(h["spr"] as CanvasItem, "alfa", 0.45)
					(h["est"] as Label).text = "Caído"
			await _esperar(0.3)
			if faro_hp <= 0:
				await _derrota("faro")
				return
			if _vivos_h().is_empty():
				await _derrota("heroes")
				return
	for e: Dictionary in enemigos:
		e["lit"] = maxi(0, int(e["lit"]) - 1)
	provoca = -1
	barrera = false
	await _esperar(0.2)
	_inicio_turno()


# ------------------------------------------------------------ final
func _linea_botin(botin: Dictionary) -> String:
	var t: Array[String] = []
	var nombres: Dictionary = {"aceite": "aceite", "madera": "madera", "hierro": "hierro"}
	for k: Variant in botin.keys():
		t.append("+%d %s" % [int(botin[k]), nombres[str(k)]])
	return "   ".join(t)


func _victoria() -> void:
	over = true
	busy = true
	gano = true
	_ui()
	var era_final: bool = noche == Estado.NOCHE_FINAL and not bool(Estado.d.get("final_visto", false))
	Audio.play("win")
	Audio.play_voice("victoria")
	Juice.confetti(_mundo, Vector2(360, 450))
	await _esperar(0.9)
	Estado.d["faro_hp"] = faro_hp
	if era_final:
		Estado.d["final_visto"] = true
	var botin: Dictionary = Estado.amanecer(true)
	var m: Dictionary = Estilo.modal(self, "Amanece", 620.0)
	_modal_fin = m
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var t1: String = "La niebla se retira. La noche %d queda atrás." % noche
	if era_final:
		t1 = "El Leviatán se deshace en bruma y, por primera vez en años, el sol toca el mar. Los náufragos miran el horizonte: ya no tienen que irse. Pero la niebla volverá... y el faro seguirá encendido."
	var l1: Label = Estilo.etiqueta(t1, 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l1.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l1)
	vb.add_child(Estilo.etiqueta("Botín del amanecer", 26, Estilo.ORO))
	vb.add_child(Estilo.etiqueta(_linea_botin(botin), 30, Estilo.TEXTO))
	var cura: Label = Estilo.etiqueta("El faro recupera fuerzas con la luz del día.", 22, Estilo.NIEBLA)
	vb.add_child(cura)
	var b: Button = Estilo.boton("Volver al faro", true, 96)
	b.pressed.connect(continuar)
	vb.add_child(b)


func _derrota(motivo: String) -> void:
	over = true
	busy = true
	_ui()
	Audio.play("lose")
	Audio.play_voice("derrota")
	_temblar(0.6)
	await _esperar(0.7)
	Estado.d["faro_hp"] = maxi(0, faro_hp)
	var botin: Dictionary = Estado.amanecer(false)
	var m: Dictionary = Estilo.modal(self, "La niebla gana esta noche", 620.0)
	_modal_fin = m
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var txt: String = "El faro se apaga, pero no del todo."
	match motivo:
		"heroes": txt = "Todos los náufragos han caído. Amanece entre humo y silencio."
		"huida": txt = "Huyes escaleras abajo. La luz sigue encendida, aunque sin ti."
	var l1: Label = Estilo.etiqueta(txt + "\nVuelve a prepararte: la misma noche te espera.", 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l1.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l1)
	vb.add_child(Estilo.etiqueta("Entre los restos: " + _linea_botin(botin), 24, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var b: Button = Estilo.boton("Volver al día", true, 96)
	b.pressed.connect(continuar)
	vb.add_child(b)


func continuar() -> void:
	if not over:
		return
	if gano:
		Ads.show_interstitial("level_end")
	Kit.change_scene(ISLA)

extends Control
## La noche: combate por turnos donde la luz del faro es un recurso.

const ISLA: String = "res://libre/isla.tscn"
const TITULO: String = "res://libre/main.tscn"

var noche: int = 1
var heroes: Array[Dictionary] = []
var enemigos: Array[Dictionary] = []
var oleadas: Array = []
var oleada_i: int = -1
var faro_hp: int = 30
var faro_max: int = 30
var luz: int = 3
var luz_max: int = 5
var turno: int = 0
var sel: int = -1
var modo: String = "atk"
var busy: bool = true
var over: bool = false
var gano: bool = false
var provoca: int = -1
var barrera: bool = false
var llegada_pendiente: bool = false
var juego: String = "campana"
var reto: String = ""
var barrera_turnos: int = 0
var inspirado: int = 0
var olas_ganadas: int = 0
var dura: bool = false
var _segunda: bool = false
signal _eleccion(si: bool)
var escudo_inicial: bool = false
var _primer_turno: bool = true
var _llegada: String = ""

var _mundo: Control
var _haz: Polygon2D
var _destello: ColorRect
var _lbl_titulo: Label
var _lbl_faro: Label
var _barra_faro: ProgressBar
var _panel_faro: PanelContainer
var _pips: Pips
var _lbl_hint: Label
var _btn_atk: Button
var _btn_hab: Button
var _btn_luz: Button
var _btn_dest: Button
var _btn_fin: Button
var _btn_huir: Button
var _modal_fin: Dictionary = {}
var _pulso_fin: Tween = null


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Audio.play_track(_pista())
	juego = str(Estado.partida.get("modo", "campana"))
	reto = str(Estado.partida.get("reto", "")) if juego == "reto" else ""
	noche = mini(Estado.n("noche"), Estado.NOCHE_FINAL)
	faro_max = Estado.faro_max()
	luz_max = Estado.luz_max()
	if juego == "campana":
		faro_hp = clampi(Estado.n("faro_hp"), 1, faro_max)
		var mod: Dictionary = Estado.d.get("noche_mod", {}) as Dictionary
		luz = clampi(int(Estado.d.get("luz_inicial", 3)) + int(mod.get("luz", 0)), 1, luz_max)
		dura = bool(mod.get("dura", false))
		escudo_inicial = bool(mod.get("escudo", false))
		_llegada = Estado.llegada_de_la_noche(noche)
		if _llegada != "":
			Estado.fichar(_llegada)
			Estado.guardar()
	else:
		if reto == "fragil":
			faro_max = maxi(10, faro_max / 2)
		faro_hp = faro_max
		luz = maxi(3, luz_max - 1)
	_construir_base()
	_construir_heroes()
	_construir_panel()
	oleadas = Estado.oleadas(noche) if juego == "campana" else Estado.oleadas_modo()
	if juego == "campana" and noche == 1 and not Consejo.visto("noche"):
		(func() -> void: Consejo.mostrar(self, "noche")).call_deferred()
	if _llegada != "":
		_mostrar_llegada()
	else:
		_comenzar()


func _comenzar() -> void:
	llegada_pendiente = false
	_siguiente_oleada()


func cerrar_llegada() -> void:
	if not llegada_pendiente:
		return
	Estilo.cerrar(_modal_fin)
	_modal_fin = {}
	_comenzar()


# ------------------------------------------------------------ construccion
func _construir_base() -> void:
	_mundo = Control.new()
	_mundo.size = Vector2(720, 1280)
	_mundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_mundo)
	Estilo.fondo_cubrir(_mundo, _fondo(), 1.07)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.04, 0.09, 0.22)
	vel.size = Vector2(720, 1280)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mundo.add_child(vel)
	for i: int in 3:
		var t: TextureRect = TextureRect.new()
		t.texture = Juice.dot_texture()
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.size = Vector2(560, 220)
		t.position = Vector2(-200 + i * 220, 280 + i * 130)
		t.modulate = Color(0.75, 0.85, 0.92, 0.14)
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_mundo.add_child(t)
		var tw: Tween = t.create_tween().set_loops()
		tw.tween_property(t, "position:x", t.position.x + 120.0, 8.0 + i * 2.0).set_trans(Tween.TRANS_SINE)
		tw.tween_property(t, "position:x", t.position.x, 8.0 + i * 2.0).set_trans(Tween.TRANS_SINE)
	_haz = Polygon2D.new()
	_haz.color = Color(1.0, 0.86, 0.5, 0.55)
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_haz.material = mat
	_haz.modulate.a = 0.0
	_mundo.add_child(_haz)
	# cabecera
	_btn_huir = Estilo.boton(Idioma.t("Huir"), false, 80)
	_btn_huir.position = Vector2(16, 16)
	_btn_huir.size = Vector2(130, 80)
	_btn_huir.pressed.connect(_pedir_huir)
	_mundo.add_child(_btn_huir)
	_lbl_titulo = Estilo.etiqueta(Idioma.t("Noche %d") % noche, 28, Estilo.ORO)
	_lbl_titulo.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_lbl_titulo.position = Vector2(160, 16)
	_lbl_titulo.size = Vector2(544, 80)
	_mundo.add_child(_lbl_titulo)
	_panel_faro = Estilo.panel(Color(0.05, 0.07, 0.12, 0.85))
	_panel_faro.position = Vector2(16, 104)
	_panel_faro.size = Vector2(688, 140)
	_mundo.add_child(_panel_faro)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	_panel_faro.add_child(vb)
	_lbl_faro = Estilo.etiqueta("", 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_faro)
	_barra_faro = Estilo.barra(Color("c9ced6"), 16.0)
	vb.add_child(_barra_faro)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	vb.add_child(hb)
	hb.add_child(Estilo.etiqueta(Idioma.t("Luz"), 26, Estilo.ORO))
	_pips = Pips.new(luz_max, Estilo.ORO, 14.0)
	hb.add_child(_pips)
	_destello = ColorRect.new()
	_destello.color = Color(1, 0.95, 0.8, 0.0)
	_destello.size = Vector2(720, 1280)
	_destello.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_destello.z_index = 50
	_mundo.add_child(_destello)


## Cada marea tiene su música; los jefes, la suya.
func _pista() -> String:
	var m: int = Estado.marea_de(noche)
	if juego == "reto":
		m = (Estado.dia_de_hoy() % 5) + 1
	elif juego == "eterna":
		m = 1
	return "marea_%d" % m


func _fondo() -> String:
	var m: int = Estado.marea_de(noche)
	if juego == "caceria":
		for i: int in Datos.MAREAS.size():
			if str((Datos.MAREAS[i] as Dictionary)["jefe"]) == str(Estado.partida.get("jefe", "")):
				m = i + 1
	elif juego != "campana":
		m = (Estado.dia_de_hoy() % 5) + 1 if juego == "reto" else 1
	var id: String = str(Estado.datos_marea(m)["bg"])
	return id if Estilo.tex(id) != null else "bg_noche"


func _titulo() -> String:
	match juego:
		"eterna": return Idioma.t("Niebla eterna · Oleada %d") % (oleada_i + 1)
		"caceria": return Idioma.t("Cacería · %s · Rango %d") % [str((Estado.ENEMIGOS[str(Estado.partida["jefe"])] as Dictionary)["nombre"]), int(Estado.partida["rango"])]
		"reto": return Idioma.t("Reto del día · Oleada %d de %d") % [oleada_i + 1, oleadas.size()]
	var k: int = Estado.noche_en_marea(noche)
	var corto: String = str(Idioma.t(Estado.datos_marea(Estado.marea_de(noche))["nombre"])).trim_prefix(Idioma.t("Marea de ")).trim_prefix(Idioma.t("Marea del "))
	return Idioma.t("%s · %s · Oleada %d/%d") % [corto, Idioma.t("Noche final") if k == Datos.NOCHES_POR_MAREA else Idioma.t("Noche %d") % k, oleada_i + 1, oleadas.size()]


func _centros(n: int, ancho: float) -> Array[float]:
	var out: Array[float] = []
	match n:
		1: out = [360.0]
		2: out = [210.0, 510.0]
		3: out = [ancho * 0.55, 360.0, 720.0 - ancho * 0.55]
		_: out = [92.0, 272.0, 452.0, 632.0]
	return out


func _crear_unidad(es_enemigo: bool, id: String, cx: float, y: float, ancho: float, alto_spr: float, texid: String, nombre: String, col_barra: Color) -> Dictionary:
	var u: Control = Control.new()
	u.size = Vector2(ancho, alto_spr + 150.0)
	u.position = Vector2(cx - ancho / 2.0, y)
	u.pivot_offset = Vector2(ancho / 2.0, alto_spr)
	u.mouse_filter = Control.MOUSE_FILTER_STOP
	_mundo.add_child(u)
	var oy: float = 54.0 if es_enemigo else 0.0
	var ring: Panel = Panel.new()
	var sb: StyleBoxFlat = Estilo.caja(Color(1, 0.85, 0.4, 0.14), Estilo.ORO, 18, 3)
	sb.shadow_size = 0
	ring.add_theme_stylebox_override("panel", sb)
	ring.position = Vector2(8, oy - 6)
	ring.size = Vector2(ancho - 16, alto_spr + 100.0)
	ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ring.visible = false
	u.add_child(ring)
	var halo: TextureRect = TextureRect.new()
	halo.texture = Juice.dot_texture()
	halo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	halo.size = Vector2(ancho + 50.0, alto_spr + 40.0)
	halo.position = Vector2(-25.0, oy - 20.0)
	halo.modulate = Color(1.0, 0.86, 0.45, 0.6)
	halo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	halo.visible = false
	u.add_child(halo)
	var spr: TextureRect = Estilo.sprite(texid, Vector2(ancho, alto_spr), 0.14 if id == "leviatan" else 0.0)
	spr.position = Vector2(0, oy)
	spr.pivot_offset = Vector2(ancho / 2.0, alto_spr)
	spr.name = "Spr"
	u.add_child(spr)
	_reposo(spr, es_enemigo, id)
	var ln: Label = Estilo.etiqueta(nombre, 21, Estilo.TEXTO)
	ln.position = Vector2(-10, oy + alto_spr + 2.0)
	ln.size = Vector2(ancho + 20.0, 28)
	u.add_child(ln)
	var bar: ProgressBar = Estilo.barra(col_barra, 16.0)
	bar.position = Vector2(14, oy + alto_spr + 32.0)
	bar.size = Vector2(ancho - 28.0, 16)
	u.add_child(bar)
	var est: Label = Estilo.etiqueta("", 20, Estilo.ORO)
	est.position = Vector2(-10, oy + alto_spr + 50.0)
	est.size = Vector2(ancho + 20.0, 28)
	u.add_child(est)
	var intent: Label = Estilo.etiqueta("", 20, Estilo.ROJO)
	intent.position = Vector2(-20, 0)
	intent.size = Vector2(ancho + 40.0, 54)
	u.add_child(intent)
	return {"nodo": u, "spr": spr, "bar": bar, "est": est, "intent": intent, "halo": halo, "ring": ring, "nombre": ln}


func _construir_heroes() -> void:
	var ids: Array[String] = Estado.guardia()
	if ids.is_empty():
		ids = ["ibsen"]
		if not (Estado.d["heroes"] as Dictionary).has("ibsen"):
			Estado.fichar("ibsen")
	if reto == "solo_dos" and ids.size() > 2:
		ids = ids.slice(0, 2)
	var cuatro: bool = ids.size() >= 4
	var cs: Array[float] = _centros(ids.size(), 220.0)
	for i: int in ids.size():
		var id: String = ids[i]
		var def: Dictionary = Estado.HEROES[id] as Dictionary
		var lvl: int = Estado.nivel(id)
		var hpm: int = Estado.hp_heroe(id, lvl)
		var u: Dictionary = _crear_unidad(false, id, cs[i], 652.0, 172.0 if cuatro else 220.0, 170.0 if cuatro else 190.0, str(def["tex"]), str(Idioma.t(def["nombre"])).split(" ")[-1] if cuatro else str(Idioma.t(def["nombre"])), Color("86bba8"))
		var h: Dictionary = u.duplicate()
		h["id"] = id
		h["lvl"] = lvl
		h["hp"] = hpm
		h["hpmax"] = hpm
		h["atk"] = Estado.atk_heroe(id, lvl)
		h["m"] = Estado.mods(id)
		h["escudo"] = 0
		h["atrapado"] = 0
		h["revive"] = float((h["m"] as Dictionary).get("revive", 0.0)) > 0.0
		h["gratis"] = false
		h["actuo"] = false
		h["vivo"] = true
		(h["bar"] as ProgressBar).max_value = hpm
		(h["bar"] as ProgressBar).value = hpm
		var idx: int = i
		(h["nodo"] as Control).gui_input.connect(func(ev: InputEvent) -> void:
			if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
				_tap_heroe(idx))
		heroes.append(h)
		UI.pop_in(h["nodo"] as Control, 0.1 * i)


func _construir_panel() -> void:
	_lbl_hint = Estilo.etiqueta("", 22, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	_lbl_hint.position = Vector2(20, 912)
	_lbl_hint.size = Vector2(680, 64)
	_mundo.add_child(_lbl_hint)
	_btn_atk = _boton_accion(Idioma.t("Atacar\n(gratis)"), Vector2(20, 982), Vector2(334, 84), _on_atk)
	_btn_hab = _boton_accion(Idioma.t("Habilidad\n1 luz"), Vector2(366, 982), Vector2(334, 84), _on_hab)
	_btn_luz = _boton_accion(Idioma.t("Iluminar\n1 luz · debilita"), Vector2(20, 1074), Vector2(334, 84), _on_luz)
	_btn_dest = _boton_accion(Idioma.t("Destello del faro\n3 luz · a todos"), Vector2(366, 1074), Vector2(334, 84), _on_dest)
	_btn_fin = Estilo.boton(Idioma.t("Terminar turno"), true, 88)
	_btn_fin.position = Vector2(20, 1168)
	_btn_fin.size = Vector2(680, 88)
	_btn_fin.pressed.connect(terminar_turno)
	_mundo.add_child(_btn_fin)


func _boton_accion(t: String, pos: Vector2, tam: Vector2, f: Callable) -> Button:
	var b: Button = Estilo.boton(t, false, tam.y)
	b.position = pos
	b.size = tam
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(f)
	_mundo.add_child(b)
	return b


func _mostrar_llegada() -> void:
	llegada_pendiente = true
	var def: Dictionary = Estado.HEROES[_llegada] as Dictionary
	var m: Dictionary = Estilo.modal(self, Idioma.t("La niebla trae a alguien"), 620.0)
	_modal_fin = m
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var s: TextureRect = Estilo.sprite(str(def["tex"]), Vector2(260, 330))
	s.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(s)
	vb.add_child(Estilo.etiqueta(str(Idioma.t(def["nombre"])), 40, Color(str(def["col"])).lightened(0.3)))
	vb.add_child(Estilo.etiqueta((Idioma.t("%s de %s") % [Idioma.t(def["rol"]), Idioma.t(def["mundo"])]).replace(Idioma.t(" de el "), Idioma.t(" del ")), 24, Estilo.NIEBLA))
	var fr: Label = Estilo.etiqueta(str(Idioma.t(def["frase"])), 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	fr.custom_minimum_size = Vector2(560, 0)
	vb.add_child(fr)
	if not Estado.guardia().has(_llegada):
		var nota: Label = Estilo.etiqueta(Idioma.t("La guardia está completa: se queda en reserva. Cámbialo de día en «Héroes»."), 21, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, true)
		nota.custom_minimum_size = Vector2(560, 0)
		vb.add_child(nota)
	var b: Button = Estilo.boton(Idioma.t("¡A la guardia!"), true, 92)
	b.pressed.connect(cerrar_llegada)
	vb.add_child(b)
	Audio.play("powerup", 0.05, -4.0, 0.8)
	Estilo.fundir(s, 0.0, 1.0, 0.8)


# ------------------------------------------------------------ oleadas y turnos
func _esperar(t: float) -> void:
	await get_tree().create_timer(t).timeout


func _banner(texto: String, col: Color = Color(0.91, 0.72, 0.34)) -> void:
	var l: Label = Estilo.etiqueta(texto, 50, col)
	l.position = Vector2(0, 470)
	l.size = Vector2(720, 90)
	l.z_index = 40
	l.modulate.a = 0.0
	_mundo.add_child(l)
	var tw: Tween = l.create_tween()
	tw.tween_property(l, "modulate:a", 1.0, 0.3)
	tw.tween_interval(0.7)
	tw.tween_property(l, "modulate:a", 0.0, 0.4)
	tw.tween_callback(l.queue_free)


func _siguiente_oleada() -> void:
	oleada_i += 1
	for e: Dictionary in enemigos:
		(e["nodo"] as Control).queue_free()
	enemigos.clear()
	if juego == "eterna" and oleada_i >= oleadas.size():
		oleadas.append_array(Estado.oleadas_modo())
	var lista: Array = oleadas[oleada_i] as Array
	var n: int = lista.size()
	var hay_jefe: bool = false
	for x: Variant in lista:
		if bool((Estado.ENEMIGOS[str(x).trim_prefix("!")] as Dictionary).get("jefe", false)):
			hay_jefe = true
	var cs: Array[float] = _centros(n, 220.0)
	if hay_jefe:
		cs = [100.0, 360.0, 620.0]
	for i: int in n:
		enemigos.append(_crear_enemigo(str(lista[i]), cs[i], hay_jefe, i))
	_lbl_titulo.text = _titulo()
	## Entre oleadas: enfermeria, escudos y la barrera del campanario.
	if oleada_i > 0:
		var cura: float = Estado.cura_entre_oleadas()
		for hh: Dictionary in heroes:
			if bool(hh["vivo"]) and cura > 0.0:
				hh["hp"] = mini(int(hh["hpmax"]), int(hh["hp"]) + int(ceil(float(hh["hpmax"]) * cura)))
				(hh["bar"] as ProgressBar).value = int(hh["hp"])
	for hh: Dictionary in heroes:
		hh["gratis"] = float((hh["m"] as Dictionary).get("hab_gratis", 0.0)) > 0.0
		var esc: float = float((hh["m"] as Dictionary).get("escudo", 0.0)) + (0.2 if escudo_inicial and oleada_i == 0 else 0.0)
		if bool(hh["vivo"]) and esc > 0.0:
			hh["escudo"] = maxi(int(hh["escudo"]), int(round(float(hh["hpmax"]) * esc)))
	barrera_turnos = Estado.turnos_barrera()
	barrera = barrera_turnos > 0
	if hay_jefe:
		Audio.play_track("jefe")
		for e: Dictionary in enemigos:
			if bool(e["jefe"]):
				_banner(Idioma.t("¡%s!") % str(Idioma.t(e["nombre"])), Estilo.ROJO)
		Audio.play("explode", 0.0, -4.0, 0.6)
		_temblar(0.5)
	else:
		_banner(Idioma.t("Oleada %d") % (oleada_i + 1))
	await _esperar(0.9)
	_inicio_turno()


func _crear_enemigo(raw: String, cx: float, hay_jefe: bool, idx: int) -> Dictionary:
	var elite: bool = raw.begins_with("!")
	var id: String = raw.trim_prefix("!")
	var def: Dictionary = Estado.ENEMIGOS[id] as Dictionary
	var boss: bool = bool(def.get("jefe", false))
	var ancho: float = 300.0 if boss else (200.0 if hay_jefe else 220.0)
	var alto: float = 250.0 if boss else 215.0
	var nombre: String = str(Idioma.t(def["nombre"]))
	var u: Dictionary = _crear_unidad(true, id, cx, 250.0 if boss else 262.0, ancho, alto, str(def["tex"]), nombre, Color("c4604b"))
	var geq: float = Estado.noche_equivalente(oleada_i) if juego != "campana" else float(noche)
	var rp: float = Estado.rampa(noche) if juego == "campana" else 1.0
	var hpm: int = int(round(float(def["hp"]) * Estado.escala_hp(geq) * (1.6 if elite else 1.0) * (1.05 if boss else 1.0) * (1.25 if dura else 1.0) * rp))
	if juego == "campana" and noche == 1:
		hpm = int(round(hpm * 0.9))
	var e: Dictionary = u.duplicate()
	e["id"] = id
	e["nombre"] = nombre
	e["jefe"] = boss
	e["elite"] = elite
	e["hp"] = hpm
	e["hpmax"] = hpm
	e["atk"] = float(def["atk"]) * Estado.escala_atk(geq) * (1.25 if elite else 1.0) * (1.2 if dura else 1.0) * rp
	var rs: Array[String] = []
	for r: Variant in (def["rasgos"] as Array):
		rs.append(str(r))
	if reto == "enemigos_veloces" and not rs.has("veloz"):
		rs.append("veloz")
	e["rasgos"] = rs
	if rs.has("copia"):
		var mejor: float = 0.0
		for hh: Dictionary in heroes:
			mejor = maxf(mejor, float(hh["atk"]))
		e["atk"] = maxf(float(e["atk"]), mejor * 0.8)
	e["lit"] = 0
	e["vivo"] = true
	e["escudo"] = 0
	e["veneno"] = 0
	e["veneno_t"] = 0
	e["aturdido"] = false
	e["t"] = 0
	e["ataques"] = []
	if elite:
		(e["spr"] as TextureRect).modulate = Color(1.15, 1.0, 0.8)
	(e["bar"] as ProgressBar).max_value = hpm
	(e["bar"] as ProgressBar).value = hpm
	(e["nodo"] as Control).gui_input.connect(func(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
			_tap_enemigo(idx))
	Estilo.fundir(e["spr"] as TextureRect, 0.0, 1.0, 0.7)
	var nodo: Control = e["nodo"] as Control
	nodo.scale = Vector2(0.85, 0.85)
	nodo.create_tween().tween_property(nodo, "scale", Vector2.ONE, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return e


func _tiene(e: Dictionary, r: String) -> bool:
	return (e["rasgos"] as Array).has(r)


func _invocacion(e: Dictionary) -> String:
	for r: Variant in (e["rasgos"] as Array):
		if str(r).begins_with("invoca:"):
			return str(r).get_slice(":", 1)
	return ""


func _inicio_turno() -> void:
	if over:
		return
	turno += 1
	if not _primer_turno:
		luz = mini(luz_max, luz + Estado.luz_turno() * (2 if reto == "luz_doble" else 1))
	_primer_turno = false
	## Canto: cada monstruo que canta se bebe 1 de luz.
	for e: Dictionary in enemigos:
		if bool(e["vivo"]) and _tiene(e, "canto") and luz > 0:
			luz -= 1
			_popup(_centro_enemigo(enemigos.find(e)) + Vector2(-60, -100), Idioma.t("-1 luz"), Estilo.NIEBLA, 30)
	for i: int in heroes.size():
		var h: Dictionary = heroes[i]
		h["actuo"] = false
		if not bool(h["vivo"]):
			continue
		var rg: float = float((h["m"] as Dictionary).get("regen", 0.0))
		if rg > 0.0 and int(h["hp"]) < int(h["hpmax"]):
			h["hp"] = mini(int(h["hpmax"]), int(h["hp"]) + int(ceil(float(h["hpmax"]) * rg)))
			(h["bar"] as ProgressBar).value = int(h["hp"])
		if int(h["atrapado"]) > 0:
			h["atrapado"] = int(h["atrapado"]) - 1
			h["atrapado_v"] = turno
			h["actuo"] = true
	_planear_ataques()
	modo = "atk"
	busy = false
	_auto_seleccionar()
	_ui()


func _vivos_h() -> Array[int]:
	var out: Array[int] = []
	for i: int in heroes.size():
		if bool(heroes[i]["vivo"]):
			out.append(i)
	return out


func _vivos_e() -> Array[int]:
	var out: Array[int] = []
	for i: int in enemigos.size():
		if bool(enemigos[i]["vivo"]):
			out.append(i)
	return out


func _planear_ataques() -> void:
	var vh: Array[int] = _vivos_h()
	for e: Dictionary in enemigos:
		var lista: Array = []
		if not bool(e["vivo"]):
			e["ataques"] = lista
			continue
		if bool(e["aturdido"]):
			e["ataques"] = lista
			continue
		var cuantos: int = 2 if _tiene(e, "veloz") else 1
		for k: int in cuantos:
			var faro: bool = Estado.rng.randf() < 0.4 or vh.is_empty()
			if bool(e["jefe"]) and cuantos > 1:
				faro = k == 1
			if faro:
				lista.append({"tipo": "faro", "idx": -1})
			else:
				lista.append({"tipo": "hero", "idx": vh[Estado.rng.randi() % vh.size()]})
		e["ataques"] = lista


func _objetivo(a: Dictionary) -> Dictionary:
	if provoca >= 0 and bool(heroes[provoca]["vivo"]):
		return {"tipo": "hero", "idx": provoca}
	if str(a["tipo"]) == "hero":
		var i: int = int(a["idx"])
		if bool(heroes[i]["vivo"]):
			return a
		var vh: Array[int] = _vivos_h()
		if vh.is_empty():
			return {"tipo": "faro", "idx": -1}
		return {"tipo": "hero", "idx": vh[0]}
	return a


func _dano_ataque(e: Dictionary, obj: Dictionary) -> int:
	var d: float = float(e["atk"])
	if int(e["lit"]) > 0:
		d *= 0.6
	if barrera:
		d *= 0.5
	if str(obj["tipo"]) == "hero":
		if int(obj["idx"]) == provoca:
			d *= 0.7
		d *= 1.0 - minf(0.6, float((heroes[int(obj["idx"])]["m"] as Dictionary).get("defensa", 0.0)))
	return maxi(1, int(round(d)))


func _dano_a_enemigo(base: float, e: Dictionary, hi: int = -1) -> int:
	var lit: bool = int(e["lit"]) > 0
	var m: float = 1.0
	if lit:
		m = 1.5
	else:
		if _tiene(e, "intangible"):
			return 0
		if _tiene(e, "coraza"):
			m *= 0.65
		if _tiene(e, "velo"):
			m *= 0.6
	if hi >= 0 and hi < heroes.size():
		var md: Dictionary = heroes[hi]["m"] as Dictionary
		if lit:
			m *= 1.0 + float(md.get("contra_luz", 0.0))
		if bool(e["jefe"]):
			m *= 1.0 + float(md.get("contra_jefe", 0.0))
		if inspirado > 0:
			m *= 1.4
		if Estado.rng.randf() < float(md.get("critico", 0.0)):
			m *= 1.8
			_popup(_centro_heroe(hi) + Vector2(-50, -120), Idioma.t("¡Crítico!"), Color("ffd98a"), 30)
	return maxi(1, int(round(base * m)))


func _auto_seleccionar() -> void:
	if sel >= 0 and sel < heroes.size() and bool(heroes[sel]["vivo"]) and not bool(heroes[sel]["actuo"]):
		return
	sel = -1
	for i: int in heroes.size():
		if bool(heroes[i]["vivo"]) and not bool(heroes[i]["actuo"]):
			sel = i
			return


func _quedan_por_actuar() -> bool:
	for h: Dictionary in heroes:
		if bool(h["vivo"]) and not bool(h["actuo"]):
			return true
	return false


# ------------------------------------------------------------ interfaz
func _necesita_objetivo(id: String) -> bool:
	return bool((Estado.HEROES[id] as Dictionary).get("obj", false))


func _ui() -> void:
	_pips.poner(luz_max, luz)
	_barra_faro.max_value = faro_max
	create_tween().tween_property(_barra_faro, "value", float(faro_hp), 0.25)
	_lbl_faro.text = Idioma.t("Integridad del faro  %d / %d") % [faro_hp, faro_max]
	var vh: bool = sel >= 0 and not busy and not over
	var ve: int = _vivos_e().size()
	_btn_atk.disabled = not vh
	_btn_hab.disabled = not vh or (luz < 1 and not (sel >= 0 and bool(heroes[sel]["gratis"])))
	_btn_luz.disabled = busy or over or luz < 1 or ve == 0
	_btn_dest.disabled = busy or over or luz < 3 or ve == 0 or reto == "sin_destello"
	_btn_fin.disabled = busy or over
	_btn_huir.disabled = busy or over
	if sel >= 0:
		var hid: String = str(heroes[sel]["id"])
		var def: Dictionary = Estado.HEROES[hid] as Dictionary
		_btn_hab.text = "%s\n%s" % [Idioma.t(def["hab"]), "gratis" if bool(heroes[sel]["gratis"]) else Idioma.t("1 luz")]
	else:
		_btn_hab.text = Idioma.t("Habilidad\n1 luz")
	for b: Button in [_btn_atk, _btn_hab, _btn_luz]:
		b.modulate = Color.WHITE
	if not busy and not over:
		if modo == "atk" and sel >= 0:
			_btn_atk.modulate = Color(1.3, 1.15, 0.8)
		elif modo == "hab":
			_btn_hab.modulate = Color(1.3, 1.15, 0.8)
		elif modo == "luz":
			_btn_luz.modulate = Color(1.3, 1.15, 0.8)
	for i: int in heroes.size():
		var h: Dictionary = heroes[i]
		(h["ring"] as Panel).visible = i == sel and not busy
		var st: String = ""
		if not bool(h["vivo"]):
			st = Idioma.t("Caído")
		elif int(h["atrapado"]) > 0 or (bool(h["actuo"]) and int(h.get("atrapado_v", 0)) == turno):
			st = Idioma.t("Atrapado")
		elif int(h["escudo"]) > 0:
			st = Idioma.t("Escudo %d") % int(h["escudo"])
		elif i == provoca:
			st = Idioma.t("Provoca")
		elif bool(h["actuo"]):
			st = Idioma.t("Ya actuó")
		elif barrera:
			st = Idioma.t("Barrera")
		(h["est"] as Label).text = st
		if bool(h["vivo"]):
			Estilo.param(h["spr"] as CanvasItem, "gris", 0.6 if bool(h["actuo"]) else 0.0)
	for e: Dictionary in enemigos:
		if not bool(e["vivo"]):
			continue
		var lit: int = int(e["lit"])
		(e["halo"] as TextureRect).visible = lit > 0
		(e["est"] as Label).text = _estado_enemigo(e)
		(e["est"] as Label).add_theme_color_override("font_color", Estilo.ORO if lit > 0 else Estilo.NIEBLA)
		_texto_intentos(e)
	if _pulso_fin != null:
		_pulso_fin.kill()
		_pulso_fin = null
	_btn_fin.scale = Vector2.ONE
	if not busy and not over and not _quedan_por_actuar():
		_pulso_fin = Estilo.pulso(_btn_fin)
	_lbl_hint.text = _texto_hint()


const NOMBRE_RASGO: Dictionary = {"coraza": "Coraza", "intangible": "Intangible", "velo": "Velo", "regenera": "Regenera",
	"veloz": "Veloz", "descarga": "Descarga", "atrapa": "Atrapa", "espinas": "Espinas", "canto": "Canto", "caparazon": "Caparazón",
	"furia": "Furia", "escudo_aliados": "Protege", "come_luz": "Come luz", "copia": "Copia"}


func _estado_enemigo(e: Dictionary) -> String:
	var t: Array[String] = []
	if bool(e.get("elite", false)):
		t.append(Idioma.t("Antiguo"))
	if int(e["lit"]) > 0:
		t.append(Idioma.t("Iluminado ×%d") % int(e["lit"]))
	if bool(e["aturdido"]):
		t.append(Idioma.t("Aturdido"))
	if int(e["escudo"]) > 0:
		t.append(Idioma.t("Escudo %d") % int(e["escudo"]))
	if int(e["veneno_t"]) > 0:
		t.append(Idioma.t("Veneno"))
	for r: Variant in (e["rasgos"] as Array):
		if t.size() >= 2:
			break
		if NOMBRE_RASGO.has(str(r)) and not (int(e["lit"]) > 0 and str(r) in ["intangible", "coraza", "velo"]):
			t.append(Idioma.t(NOMBRE_RASGO[str(r)]))
	return " · ".join(t)


func _texto_intentos(e: Dictionary) -> void:
	var t: Array[String] = []
	for a: Dictionary in (e["ataques"] as Array):
		var obj: Dictionary = _objetivo(a)
		var d: int = _dano_ataque(e, obj)
		if str(obj["tipo"]) == "faro":
			t.append(Idioma.t("→ Faro  %d") % d)
		else:
			t.append(Idioma.t("→ %s  %d") % [str(Estado.HEROES[str(heroes[int(obj["idx"])]["id"])]["nombre"]).split(" ")[-1], d])
	var l: Label = e["intent"] as Label
	l.text = "\n".join(t)
	var faro: bool = t.size() > 0 and t[0].begins_with(Idioma.t("→ Faro"))
	l.add_theme_color_override("font_color", Estilo.ROJO if faro else Color("e8a35e"))


func _texto_hint() -> String:
	if over:
		return ""
	if busy:
		return "..."
	if modo == "luz":
		return Idioma.t("Toca al enemigo que quieres iluminar.")
	if not _quedan_por_actuar():
		return Idioma.t("Todos han actuado. Gasta luz si quieres o termina el turno.")
	for e: Dictionary in enemigos:
		if bool(e["vivo"]) and _tiene(e, "intangible") and int(e["lit"]) <= 0:
			return Idioma.t("%s es intangible: ¡ilumínalo para poder herirlo!") % str(Idioma.t(e["nombre"]))
	if juego == "campana" and noche == 1 and turno <= 2:
		return Idioma.t("Toca un héroe y luego a un enemigo. Iluminar (1 luz) lo debilita: recibe más daño y golpea con menos fuerza.")
	if sel >= 0:
		return Idioma.t("%s: toca a un enemigo para atacarle.") % str(Idioma.t(Estado.HEROES[str(heroes[sel]["id"])]["nombre"]))
	return Idioma.t("Toca un héroe para elegirlo.")


func _temblar(f: float) -> void:
	var tw: Tween = _mundo.create_tween()
	for i: int in 5:
		var k: float = f * 16.0 * (1.0 - float(i) / 5.0)
		tw.tween_property(_mundo, "position", Vector2(Estado.rng.randf_range(-k, k), Estado.rng.randf_range(-k, k)), 0.04)
	tw.tween_property(_mundo, "position", Vector2.ZERO, 0.04)


func _popup(pos: Vector2, texto: String, col: Color, tam: int = 40) -> void:
	UI.float_text(_mundo, pos, texto, col, tam)


func _centro_enemigo(i: int) -> Vector2:
	var n: Control = enemigos[i]["nodo"] as Control
	return n.position + Vector2(n.size.x / 2.0, 54.0 + 110.0)


func _centro_heroe(i: int) -> Vector2:
	var n: Control = heroes[i]["nodo"] as Control
	return n.position + Vector2(n.size.x / 2.0, 95.0)


# ------------------------------------------------------------ toques
func _tap_heroe(i: int) -> void:
	if busy or over or i >= heroes.size():
		return
	if bool(heroes[i]["vivo"]) and not bool(heroes[i]["actuo"]):
		sel = i
		modo = "atk"
		Audio.play("click")
		_ui()


func _tap_enemigo(i: int) -> void:
	if busy or over or i >= enemigos.size() or not bool(enemigos[i]["vivo"]):
		return
	if modo == "luz":
		accion_iluminar(i)
	elif sel >= 0:
		if modo == "hab":
			accion_habilidad(sel, i)
		else:
			accion_atacar(sel, i)
	else:
		Audio.play("hurt", 0.05, -10.0)


func _unico_enemigo() -> int:
	var v: Array[int] = _vivos_e()
	return v[0] if v.size() == 1 else -1


func _on_atk() -> void:
	if busy or sel < 0:
		return
	modo = "atk"
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_atacar(sel, u)
	else:
		_ui()


func _on_hab() -> void:
	if busy or sel < 0:
		return
	modo = "hab"
	var id: String = str(heroes[sel]["id"])
	if not _necesita_objetivo(id):
		accion_habilidad(sel, -1)
		return
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_habilidad(sel, u)
	else:
		_ui()


func _on_luz() -> void:
	if busy:
		return
	modo = "luz"
	var u: int = _unico_enemigo()
	if u >= 0:
		accion_iluminar(u)
	else:
		_ui()


func _on_dest() -> void:
	accion_destello()


func _pedir_huir() -> void:
	if busy or over:
		return
	Estilo.confirmar(self, Idioma.t("¿Huir de la noche?"), Idioma.t("La niebla se cobrará su precio: volverás al día sin botín de la noche."), Idioma.t("Huir"), Idioma.t("Quedarme"), func() -> void:
		if not busy and not over:
			_derrota("huida"))


# ------------------------------------------------------------ acciones del jugador
func _puede_actuar(hi: int) -> bool:
	return not busy and not over and hi >= 0 and hi < heroes.size() and bool(heroes[hi]["vivo"]) and not bool(heroes[hi]["actuo"])


# ------------------------------------------------------------ animacion
## Los personajes son dibujos: se animan con el cuerpo entero (respirar, flotar, coger impulso,
## estirarse al atacar, encogerse al recibir y caer al morir).
const VOLADORES: Array[String] = ["sombra", "espectro", "arpia", "medusa", "llorona", "ojo", "polilla", "pescador", "leviatan", "reina_tormenta", "apagafaros"]


func _reposo(spr: TextureRect, es_enemigo: bool, id: String) -> void:
	var fase: float = Estado.rng.randf_range(0.0, 1.2)
	var tw: Tween = spr.create_tween().set_loops()
	spr.set_meta("y0", spr.position.y)
	if es_enemigo and VOLADORES.has(id):
		var y0: float = spr.position.y
		tw.tween_interval(fase)
		tw.tween_property(spr, "position:y", y0 - 12.0, 1.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tw.parallel().tween_property(spr, "rotation", deg_to_rad(2.0), 1.3).set_trans(Tween.TRANS_SINE)
		tw.tween_property(spr, "position:y", y0 + 4.0, 1.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tw.parallel().tween_property(spr, "rotation", deg_to_rad(-2.0), 1.3).set_trans(Tween.TRANS_SINE)
		tw.tween_interval(0.01)
	else:
		var d: float = 0.95 if es_enemigo else 1.15
		tw.tween_interval(fase)
		tw.tween_property(spr, "scale", Vector2(0.99, 1.025), d).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tw.tween_property(spr, "scale", Vector2(1.01, 0.99), d).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	spr.set_meta("idle", tw)


func _spr(nodo: Control) -> TextureRect:
	return nodo.get_node_or_null("Spr") as TextureRect


func _parar_reposo(spr: TextureRect) -> void:
	if spr != null and spr.has_meta("idle"):
		(spr.get_meta("idle") as Tween).kill()
		spr.remove_meta("idle")


## Encogerse y salir despedido un poco al recibir un golpe.
func _recibir(spr: TextureRect, desde_arriba: bool) -> void:
	if spr == null:
		return
	var y0: float = float(spr.get_meta("y0", spr.position.y))
	var tw: Tween = spr.create_tween()
	tw.tween_property(spr, "position:y", y0 + (-14.0 if desde_arriba else 14.0) * -1.0, 0.06)
	tw.parallel().tween_property(spr, "scale", Vector2(1.12, 0.86), 0.06)
	tw.tween_property(spr, "position:y", y0, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(spr, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Caer: se inclina, se hunde y se apaga.
func _caida(spr: TextureRect, enemigo: bool) -> void:
	if spr == null:
		return
	_parar_reposo(spr)
	var tw: Tween = spr.create_tween()
	tw.tween_property(spr, "scale", Vector2(1.15, 0.8), 0.08)
	tw.tween_property(spr, "rotation", deg_to_rad(14.0 if enemigo else -10.0), 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(spr, "position:y", spr.position.y + (50.0 if enemigo else 18.0), 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(spr, "scale", Vector2(0.95, 0.85), 0.4)


## Lanzar una habilidad: salto corto con brillo.
func _conjurar(nodo: Control, col: Color) -> void:
	var spr: TextureRect = _spr(nodo)
	if spr == null:
		return
	var y0: float = float(spr.get_meta("y0", spr.position.y))
	var tw: Tween = spr.create_tween()
	tw.tween_property(spr, "scale", Vector2(1.1, 0.88), 0.08)
	tw.tween_property(spr, "position:y", y0 - 26.0, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(spr, "scale", Vector2(0.94, 1.1), 0.14)
	tw.parallel().tween_property(spr, "modulate", col.lightened(0.5), 0.14)
	tw.tween_property(spr, "position:y", y0, 0.2).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(spr, "scale", Vector2.ONE, 0.2)
	tw.parallel().tween_property(spr, "modulate", Color.WHITE, 0.3)
	Juice.ring(_mundo, nodo.position + Vector2(nodo.size.x / 2.0, 120.0), col, 110.0)


## Atacar: coger impulso hacia atrás, estirarse hacia el objetivo, golpe y volver.
func _embestida(nodo: Control, destino: Vector2, frac: float, arriba: bool = false) -> void:
	var p0: Vector2 = nodo.position
	var centro: Vector2 = nodo.position + Vector2(nodo.size.x / 2.0, 100.0)
	var dir: Vector2 = (destino - centro) * frac
	if arriba:
		dir = Vector2(0, 40)
	var spr: TextureRect = _spr(nodo)
	var inclina: float = clampf(dir.x / 300.0, -1.0, 1.0) * deg_to_rad(9.0)
	var tw: Tween = nodo.create_tween()
	tw.tween_property(nodo, "position", p0 - dir.normalized() * 14.0, 0.09).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(nodo, "position", p0 + dir, 0.11).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_property(nodo, "position", p0, 0.24).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	if spr != null:
		var ts: Tween = spr.create_tween()
		ts.tween_property(spr, "scale", Vector2(1.1, 0.9), 0.09)
		ts.parallel().tween_property(spr, "rotation", -inclina * 0.6, 0.09)
		ts.tween_property(spr, "scale", Vector2(0.9, 1.12), 0.11)
		ts.parallel().tween_property(spr, "rotation", inclina, 0.11)
		ts.tween_property(spr, "scale", Vector2.ONE, 0.24).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		ts.parallel().tween_property(spr, "rotation", 0.0, 0.24)
	await _esperar(0.2)


func _golpear_enemigo(ei: int, dmg: int, col: Color = Color("f1e7cf"), hi: int = -1, rebote: bool = true) -> void:
	var e: Dictionary = enemigos[ei]
	var c: Vector2 = _centro_enemigo(ei)
	if not bool(e["vivo"]):
		return
	if dmg <= 0:
		_popup(c + Vector2(-60, -60), Idioma.t("¡Atraviesa!"), Estilo.NIEBLA, 34)
		Audio.play("hurt", 0.05, -12.0, 1.6)
		return
	var real: int = dmg
	if int(e["escudo"]) > 0:
		var abs_: int = mini(int(e["escudo"]), dmg)
		e["escudo"] = int(e["escudo"]) - abs_
		real = dmg - abs_
		_popup(c + Vector2(-90, -40), Idioma.t("Escudo -%d") % abs_, Color("9fd4e0"), 28)
	e["hp"] = maxi(0, int(e["hp"]) - real)
	create_tween().tween_property(e["bar"] as ProgressBar, "value", float(e["hp"]), 0.25)
	if real > 0:
		_popup(c + Vector2(-30, -70), "-%d" % real, col, 44)
	Estilo.destello(e["spr"] as CanvasItem, Color(1, 1, 1), 0.2)
	_recibir(e["spr"] as TextureRect, false)
	Juice.burst(_mundo, c, Color(0.9, 0.85, 0.7), 8, 200.0)
	Audio.play("explode", 0.1, -10.0, 1.7)
	_temblar(0.12)
	if hi >= 0 and hi < heroes.size() and bool(heroes[hi]["vivo"]):
		var h: Dictionary = heroes[hi]
		var md: Dictionary = h["m"] as Dictionary
		var robo: float = float(md.get("robo", 0.0))
		if robo > 0.0 and real > 0:
			_curar(hi, int(ceil(float(real) * robo)))
		if _tiene(e, "espinas") and real > 0:
			var esp: int = maxi(1, int(round(float(real) * 0.25)))
			h["hp"] = maxi(1, int(h["hp"]) - esp)
			create_tween().tween_property(h["bar"] as ProgressBar, "value", float(h["hp"]), 0.2)
			_popup(_centro_heroe(hi) + Vector2(-20, -60), "-%d" % esp, Estilo.ROJO, 30)
		if float(md.get("veneno", 0.0)) > 0.0:
			e["veneno"] = maxi(int(e["veneno"]), int(round(float(h["atk"]) * float(md["veneno"]))))
			e["veneno_t"] = maxi(int(e["veneno_t"]), 2)
		if Estado.rng.randf() < float(md.get("aturdir", 0.0)) and int(e["hp"]) > 0:
			e["aturdido"] = true
			e["ataques"] = []
			_popup(c + Vector2(-60, -110), Idioma.t("¡Aturdido!"), Color("9fd4e0"), 30)
		if rebote and Estado.rng.randf() < float(md.get("rebote", 0.0)):
			for ej: int in _vivos_e():
				if ej != ei:
					_lanzar_haz(_centro_enemigo(ej))
					await _golpear_enemigo(ej, _dano_a_enemigo(float(h["atk"]) * 0.6, enemigos[ej], hi), Color("9fe0d4"), hi, false)
					break
	if int(e["hp"]) <= 0:
		e["vivo"] = false
		(e["intent"] as Label).text = ""
		(e["est"] as Label).text = ""
		(e["halo"] as TextureRect).visible = false
		Audio.play("explode", 0.1, -4.0)
		Juice.burst(_mundo, c, Color(0.7, 0.8, 0.85), 18, 300.0)
		Juice.ring(_mundo, c, Color(0.8, 0.9, 1.0), 90.0)
		_caida(e["spr"] as TextureRect, true)
		Estilo.fundir(e["spr"] as TextureRect, 1.0, 0.0, 0.6)
		(e["nodo"] as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		Juice.hitstop(0.05)
		if hi >= 0 and hi < heroes.size():
			var lm: int = int((heroes[hi]["m"] as Dictionary).get("luz_matar", 0.0))
			if lm > 0:
				luz = mini(luz_max, luz + lm)
				_popup(_centro_heroe(hi) + Vector2(-40, -110), Idioma.t("+%d luz") % lm, Estilo.ORO, 30)
		if _tiene(e, "descarga"):
			await _descarga(e)


func _curar(hi: int, cant: int) -> void:
	var t: Dictionary = heroes[hi]
	if not bool(t["vivo"]) or cant <= 0:
		return
	t["hp"] = mini(int(t["hpmax"]), int(t["hp"]) + cant)
	create_tween().tween_property(t["bar"] as ProgressBar, "value", float(t["hp"]), 0.3)
	_popup(_centro_heroe(hi) + Vector2(-20, -60), "+%d" % cant, Estilo.VERDE, 36)


func _descarga(e: Dictionary) -> void:
	_banner(Idioma.t("¡Descarga!"), Color("9fc4ff"))
	_destello.color = Color(0.6, 0.75, 1.0, 0.5)
	_destello.create_tween().tween_property(_destello, "color:a", 0.0, 0.4)
	var d: int = maxi(1, int(round(float(e["atk"]) * 0.8)))
	for i: int in _vivos_h():
		_herir_heroe(i, d)
	await _esperar(0.3)


## Daño a un héroe: escudo primero, luego vida; si cae, terquedad.
func _herir_heroe(hi: int, dmg: int) -> void:
	var h: Dictionary = heroes[hi]
	if int(h["escudo"]) > 0:
		var a: int = mini(int(h["escudo"]), dmg)
		h["escudo"] = int(h["escudo"]) - a
		dmg -= a
		_popup(_centro_heroe(hi) + Vector2(-70, -40), Idioma.t("Escudo -%d") % a, Color("9fd4e0"), 26)
	if dmg <= 0:
		return
	h["hp"] = maxi(0, int(h["hp"]) - dmg)
	create_tween().tween_property(h["bar"] as ProgressBar, "value", float(h["hp"]), 0.2)
	_popup(_centro_heroe(hi) + Vector2(-20, -70), "-%d" % dmg, Estilo.ROJO, 44)
	Estilo.destello(h["spr"] as CanvasItem, Color(1, 0.25, 0.2), 0.3)
	_recibir(h["spr"] as TextureRect, true)
	if int(h["hp"]) <= 0:
		if bool(h["revive"]):
			h["revive"] = false
			h["hp"] = int(ceil(float(h["hpmax"]) * 0.3))
			(h["bar"] as ProgressBar).value = int(h["hp"])
			_popup(_centro_heroe(hi) + Vector2(-70, -120), Idioma.t("¡Se levanta!"), Estilo.ORO, 32)
			return
		_caer(hi)


func _caer(hi: int) -> void:
	var h: Dictionary = heroes[hi]
	h["vivo"] = false
	h["escudo"] = 0
	_caida(h["spr"] as TextureRect, false)
	Estilo.param(h["spr"] as CanvasItem, "gris", 1.0)
	Estilo.param(h["spr"] as CanvasItem, "alfa", 0.45)
	(h["est"] as Label).text = Idioma.t("Caído")


func _levantar(hi: int, frac: float) -> void:
	var h: Dictionary = heroes[hi]
	h["vivo"] = true
	h["hp"] = maxi(1, int(ceil(float(h["hpmax"]) * frac)))
	(h["bar"] as ProgressBar).value = int(h["hp"])
	var sp: TextureRect = h["spr"] as TextureRect
	sp.create_tween().tween_property(sp, "rotation", 0.0, 0.3)
	sp.position.y = float(sp.get_meta("y0", sp.position.y))
	sp.scale = Vector2.ONE
	_reposo(sp, false, str(h["id"]))
	Estilo.param(h["spr"] as CanvasItem, "gris", 0.0)
	Estilo.param(h["spr"] as CanvasItem, "alfa", 1.0)
	_popup(_centro_heroe(hi) + Vector2(-60, -110), Idioma.t("¡Vuelve!"), Estilo.ORO, 32)


func _lanzar_haz(dest: Vector2) -> void:
	var o: Vector2 = Vector2(360, 1000)
	var dir: Vector2 = (dest - o).normalized()
	var perp: Vector2 = Vector2(-dir.y, dir.x)
	_haz.polygon = PackedVector2Array([o + perp * 12.0, o - perp * 12.0, dest - perp * 95.0, dest + perp * 95.0])
	_haz.modulate.a = 1.0
	var tw: Tween = _haz.create_tween()
	tw.tween_interval(0.2)
	tw.tween_property(_haz, "modulate:a", 0.0, 0.4)


func accion_atacar(hi: int, ei: int) -> void:
	if not _puede_actuar(hi) or ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"]):
		return
	busy = true
	var h: Dictionary = heroes[hi]
	h["actuo"] = true
	_ui()
	await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.45)
	await _golpear_enemigo(ei, _dano_a_enemigo(float(h["atk"]), enemigos[ei], hi), Color("f1e7cf"), hi)
	await _esperar(0.25)
	await _tras_accion()


func accion_habilidad(hi: int, ei: int) -> void:
	if not _puede_actuar(hi):
		return
	var h: Dictionary = heroes[hi]
	var gratis: bool = bool(h["gratis"])
	if luz < 1 and not gratis:
		return
	var id: String = str(h["id"])
	if _necesita_objetivo(id) and (ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"])):
		return
	busy = true
	if gratis:
		h["gratis"] = false
	else:
		luz -= 1
	h["actuo"] = true
	_ui()
	var atk: float = float(h["atk"])
	var c: Vector2 = _centro_heroe(hi)
	var col: Color = Color(str((Estado.HEROES[id] as Dictionary)["col"]))
	Audio.play("powerup", 0.05, -4.0, 1.2)
	Juice.sparkle(_mundo, c, col, 8, 220.0)
	_conjurar(h["nodo"] as Control, col)
	_popup(c + Vector2(-80, -110), str(Idioma.t((Estado.HEROES[id] as Dictionary)["hab"])), col.lightened(0.3), 28)
	match id:
		"ibsen":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.5)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 1.2, enemigos[ei], hi), Color("f1e7cf"), hi)
			provoca = hi
		"koji":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.55)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 2.2, enemigos[ei], hi), Color("ffd98a"), hi)
		"nerea":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.2)
			var mult: float = 1.3 * (2.0 if int(enemigos[ei]["lit"]) > 0 else 1.0)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * mult, enemigos[ei], hi), Color("ffd98a"), hi)
		"alba":
			var peor: int = -1
			var ratio: float = 2.0
			for i: int in heroes.size():
				if bool(heroes[i]["vivo"]):
					var r: float = float(heroes[i]["hp"]) / float(heroes[i]["hpmax"])
					if r < ratio:
						ratio = r
						peor = i
			if peor >= 0:
				_curar(peor, int(round(6.0 + atk * 1.6)))
				Juice.sparkle(_mundo, _centro_heroe(peor), Estilo.VERDE, 8, 160.0)
			var rep_: int = 5 + int(atk / 2.0)
			faro_hp = mini(faro_max, faro_hp + rep_)
			_popup(Vector2(500, 150), Idioma.t("+%d faro") % rep_, Estilo.VERDE, 30)
			await _esperar(0.35)
		"tumo":
			barrera = true
			barrera_turnos = maxi(barrera_turnos, 1)
			for i: int in heroes.size():
				Juice.ring(_mundo, _centro_heroe(i), Color("d9c27a"), 80.0)
			await _esperar(0.35)
		"lyra":
			for ei2: int in _vivos_e():
				_lanzar_haz(_centro_enemigo(ei2))
				await _golpear_enemigo(ei2, _dano_a_enemigo(atk * 1.0, enemigos[ei2], hi), Color("9fe0d4"), hi, false)
			await _esperar(0.1)
		"bram":
			for i: int in _vivos_h():
				heroes[i]["escudo"] = int(heroes[i]["escudo"]) + int(round(atk * 1.6))
				Juice.ring(_mundo, _centro_heroe(i), Color("c07a44"), 80.0)
			Audio.play("explode", 0.05, -8.0, 1.4)
			await _esperar(0.35)
		"mireia":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.5)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 1.7, enemigos[ei], hi), Color("9fe0f4"), hi)
			if not bool(enemigos[ei]["vivo"]):
				luz = mini(luz_max, luz + 2)
				_popup(c + Vector2(-40, -150), Idioma.t("+2 luz"), Estilo.ORO, 32)
		"ossian":
			inspirado = 2
			for i: int in _vivos_h():
				Juice.sparkle(_mundo, _centro_heroe(i), Color("d6b46a"), 6, 160.0)
			await _esperar(0.35)
		"zahir":
			for ei2: int in _vivos_e():
				var e2: Dictionary = enemigos[ei2]
				e2["veneno"] = maxi(int(e2["veneno"]), int(round(atk * 0.9)))
				e2["veneno_t"] = 3
				Juice.burst(_mundo, _centro_enemigo(ei2), Color("8fbf5a"), 10, 160.0)
			await _esperar(0.35)
		"hilda":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.55)
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 1.4, enemigos[ei], hi), Color("cfe8ff"), hi)
			if bool(enemigos[ei]["vivo"]):
				enemigos[ei]["aturdido"] = true
				enemigos[ei]["ataques"] = []
				_popup(_centro_enemigo(ei) + Vector2(-60, -110), Idioma.t("¡Aturdido!"), Color("9fd4e0"), 30)
		"selene":
			luz = mini(luz_max, luz + 3)
			var vv: Array[int] = _vivos_e()
			if not vv.is_empty():
				var objetivo: int = vv[Estado.rng.randi() % vv.size()]
				enemigos[objetivo]["lit"] = maxi(int(enemigos[objetivo]["lit"]), 2)
				_lanzar_haz(_centro_enemigo(objetivo))
			_popup(c + Vector2(-40, -150), Idioma.t("+3 luz"), Estilo.ORO, 32)
			await _esperar(0.35)
		"pip":
			var caido: int = -1
			for i: int in heroes.size():
				if not bool(heroes[i]["vivo"]):
					caido = i
					break
			if caido >= 0:
				_levantar(caido, 0.4)
			else:
				for i: int in _vivos_h():
					_curar(i, int(ceil(float(heroes[i]["hpmax"]) * 0.2)))
			Audio.play("coin", 0.0, -2.0, 0.6)
			await _esperar(0.35)
		"morgana":
			await _embestida(h["nodo"] as Control, _centro_enemigo(ei), 0.4)
			var hp0: int = int(enemigos[ei]["hp"])
			await _golpear_enemigo(ei, _dano_a_enemigo(atk * 1.5, enemigos[ei], hi), Color("7fe0c4"), hi)
			var hecho: int = hp0 - int(enemigos[ei]["hp"])
			var vh: Array[int] = _vivos_h()
			if hecho > 0 and not vh.is_empty():
				for i: int in vh:
					_curar(i, maxi(1, hecho / vh.size()))
	modo = "atk"
	await _esperar(0.2)
	await _tras_accion()


func accion_iluminar(ei: int) -> void:
	if busy or over or luz < 1 or ei < 0 or ei >= enemigos.size() or not bool(enemigos[ei]["vivo"]):
		return
	busy = true
	luz -= 1
	var e: Dictionary = enemigos[ei]
	e["lit"] = 2
	var c: Vector2 = _centro_enemigo(ei)
	if _tiene(e, "come_luz"):
		var cura: int = int(ceil(float(e["hpmax"]) * 0.12))
		e["hp"] = mini(int(e["hpmax"]), int(e["hp"]) + cura)
		(e["bar"] as ProgressBar).value = int(e["hp"])
		_popup(c + Vector2(-20, -40), "+%d" % cura, Estilo.VERDE, 30)
	_lanzar_haz(c)
	Audio.play("powerup", 0.03, -3.0, 1.5)
	Juice.sparkle(_mundo, c, Estilo.ORO, 10, 220.0)
	_popup(c + Vector2(-70, -90), Idioma.t("¡Iluminado!"), Estilo.ORO, 34)
	Estilo.destello(e["spr"] as CanvasItem, Color(1.0, 0.9, 0.55), 0.35)
	modo = "atk"
	_ui()
	await _esperar(0.4)
	busy = false
	_auto_seleccionar()
	_ui()


func accion_destello() -> void:
	if busy or over or luz < 3 or _vivos_e().is_empty() or reto == "sin_destello":
		return
	busy = true
	luz -= 3
	_ui()
	_destello.color.a = 0.0
	var tw: Tween = _destello.create_tween()
	tw.tween_property(_destello, "color:a", 0.7, 0.12)
	tw.tween_property(_destello, "color:a", 0.0, 0.5)
	Audio.play("explode", 0.0, -2.0, 1.2)
	Juice.vibrate(60)
	_temblar(0.3)
	await _esperar(0.2)
	for ei: int in _vivos_e():
		enemigos[ei]["lit"] = 2
		_lanzar_haz(_centro_enemigo(ei))
		await _golpear_enemigo(ei, _dano_a_enemigo(float(Estado.destello_dano()), enemigos[ei]), Color("fff1b0"))
	modo = "atk"
	await _esperar(0.2)
	await _tras_accion()


func _tras_accion() -> void:
	if over:
		return
	if _vivos_e().is_empty():
		await _fin_oleada()
		return
	busy = false
	_auto_seleccionar()
	_ui()


func _fin_oleada() -> void:
	busy = true
	_ui()
	olas_ganadas += 1
	if oleada_i + 1 < oleadas.size() or juego == "eterna":
		await _esperar(0.6)
		await _siguiente_oleada()
	else:
		await _victoria()


# ------------------------------------------------------------ fase enemiga
func terminar_turno() -> void:
	if busy or over:
		return
	busy = true
	sel = -1
	_ui()
	await _fase_enemiga()


func _fase_enemiga() -> void:
	_banner(Idioma.t("La niebla ataca"), Estilo.ROJO)
	await _esperar(0.5)
	for ei: int in enemigos.size():
		var e: Dictionary = enemigos[ei]
		if not bool(e["vivo"]):
			continue
		for a: Dictionary in (e["ataques"] as Array):
			if not bool(e["vivo"]):
				break
			var obj: Dictionary = _objetivo(a)
			var dmg: int = _dano_ataque(e, obj)
			var dest: Vector2 = Vector2(360, 190) if str(obj["tipo"]) == "faro" else _centro_heroe(int(obj["idx"]))
			await _embestida(e["nodo"] as Control, dest, 0.35)
			if str(obj["tipo"]) == "faro":
				faro_hp = maxi(0, faro_hp - dmg)
				_popup(Vector2(480, 150), "-%d" % dmg, Estilo.ROJO, 46)
				Estilo.destello(_barra_faro, Color(1, 0.3, 0.2), 0.3)
				_panel_faro.modulate = Color(1.6, 0.6, 0.5)
				_panel_faro.create_tween().tween_property(_panel_faro, "modulate", Color.WHITE, 0.4)
				create_tween().tween_property(_barra_faro, "value", float(faro_hp), 0.2)
				_lbl_faro.text = Idioma.t("Integridad del faro  %d / %d") % [faro_hp, faro_max]
				Audio.play("hurt", 0.05, 0.0, 0.7)
				Juice.vibrate(40)
				_temblar(0.45)
			else:
				var hi: int = int(obj["idx"])
				_herir_heroe(hi, dmg)
				if _tiene(e, "atrapa") and bool(heroes[hi]["vivo"]):
					heroes[hi]["atrapado"] = 1
					_popup(_centro_heroe(hi) + Vector2(-60, -120), Idioma.t("¡Atrapado!"), Color("9fd4e0"), 30)
				Audio.play("hurt", 0.08)
				Juice.vibrate(30)
				_temblar(0.25)
			await _esperar(0.3)
			if faro_hp <= 0:
				await _derrota("faro")
				return
			if _vivos_h().is_empty():
				await _derrota("heroes")
				return
	await _efectos_enemigos()
	if over:
		return
	if _vivos_e().is_empty():
		await _fin_oleada()
		return
	for e: Dictionary in enemigos:
		e["lit"] = maxi(0, int(e["lit"]) - 1)
		e["aturdido"] = false
	provoca = -1
	barrera_turnos = maxi(0, barrera_turnos - 1)
	barrera = barrera_turnos > 0
	inspirado = maxi(0, inspirado - 1)
	await _esperar(0.2)
	_inicio_turno()


## Al final del turno enemigo: veneno, regeneracion, furia, caparazones, escudos e invocaciones.
func _efectos_enemigos() -> void:
	for ei: int in enemigos.size():
		var e: Dictionary = enemigos[ei]
		if not bool(e["vivo"]):
			continue
		e["t"] = int(Idioma.t(e["t"])) + 1
		var c: Vector2 = _centro_enemigo(ei)
		if int(e["veneno_t"]) > 0:
			e["veneno_t"] = int(e["veneno_t"]) - 1
			await _golpear_enemigo(ei, int(e["veneno"]), Color("8fbf5a"))
			if not bool(e["vivo"]):
				continue
		if _tiene(e, "regenera") and int(e["hp"]) < int(e["hpmax"]):
			## Un jefe que se cura un 12% por turno era un muro (bot, 21 nov: 25 derrotas seguidas contra el Coral).
			var cura: int = int(ceil(float(e["hpmax"]) * (0.04 if bool(e["jefe"]) else 0.12)))
			e["hp"] = mini(int(e["hpmax"]), int(e["hp"]) + cura)
			create_tween().tween_property(e["bar"] as ProgressBar, "value", float(e["hp"]), 0.25)
			_popup(c + Vector2(-20, -40), "+%d" % cura, Estilo.VERDE, 30)
		if _tiene(e, "furia"):
			e["atk"] = float(e["atk"]) * 1.15
		if _tiene(e, "caparazon") and int(Idioma.t(e["t"])) % 2 == 1:
			e["escudo"] = int(e["escudo"]) + int(round(float(e["hpmax"]) * (0.1 if bool(e["jefe"]) else 0.25)))
			Juice.ring(_mundo, c, Color("c4604b"), 90.0)
		if _tiene(e, "escudo_aliados"):
			for ej: int in _vivos_e():
				enemigos[ej]["escudo"] = int(enemigos[ej]["escudo"]) + int(round(float(e["atk"]) * 1.2))
		var inv: String = _invocacion(e)
		if inv != "" and int(Idioma.t(e["t"])) % 4 == 0:
			_invocar(inv)
	await _esperar(0.15)


func _invocar(id: String) -> void:
	for i: int in enemigos.size():
		var e: Dictionary = enemigos[i]
		if bool(e["vivo"]) or bool(e["jefe"]):
			continue
		var x: float = (e["nodo"] as Control).position.x + (e["nodo"] as Control).size.x / 2.0
		(e["nodo"] as Control).queue_free()
		enemigos[i] = _crear_enemigo(id, x, true, i)
		_banner(Idioma.t("¡Llegan refuerzos!"), Estilo.ROJO)
		return


# ------------------------------------------------------------ final
func _linea_botin(botin: Dictionary) -> String:
	var t: Array[String] = []
	for k: Variant in botin.keys():
		if Datos.NOMBRE_RECURSO.has(str(k)) and int(botin[k]) > 0:
			t.append(Idioma.t("+%d %s") % [int(botin[k]), str(Idioma.t(Datos.NOMBRE_RECURSO[str(k)])).to_lower()])
	return "   ".join(t) if not t.is_empty() else "nada"


func _anadir_reliquia(vb: VBoxContainer, botin: Dictionary) -> void:
	var rel: String = str(botin.get("reliquia", ""))
	if rel == "" or not Datos.RELIQUIAS.has(rel):
		return
	var r: Dictionary = Datos.RELIQUIAS[rel] as Dictionary
	var hb: HBoxContainer = HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 12)
	vb.add_child(hb)
	hb.add_child(Estilo.sprite(rel, Vector2(96, 96)))
	var l: Label = Estilo.etiqueta(Idioma.t("Reliquia: %s\n%s") % [Idioma.t(r["nombre"]), Idioma.t(r["desc"])], 22, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT, true)
	l.custom_minimum_size = Vector2(420, 0)
	hb.add_child(l)


func _victoria() -> void:
	over = true
	busy = true
	gano = true
	_ui()
	Audio.play("win")
	Audio.play_track("victoria", false)
	Audio.play_voice("victoria")
	Juice.confetti(_mundo, Vector2(360, 450))
	await _esperar(0.9)
	var titulo: String = Idioma.t("Amanece")
	var t1: String = ""
	var botin: Dictionary = {}
	if juego == "campana":
		var k: int = Estado.noche_en_marea(noche)
		var m: int = Estado.marea_de(noche)
		Estado.d["faro_hp"] = faro_hp
		botin = Estado.amanecer(true)
		t1 = Idioma.t("La niebla se retira. %s queda atrás.") % Estado.titulo_noche(noche)
		if k == Datos.NOCHES_POR_MAREA:
			titulo = Idioma.t("%s superada") % str(Idioma.t(Estado.datos_marea(m)["nombre"]))
			t1 = str(Idioma.t(Estado.datos_marea(m)["final"]))
			if noche >= Estado.NOCHE_FINAL:
				Estado.d["final_visto"] = true
				t1 += Idioma.t("\n\nHas salvado el último faro. La Niebla eterna y las Cacerías siguen esperándote.")
		elif k == 6:
			t1 = Idioma.t("Los monstruos antiguos se hunden en el mar. Entre los restos, algo brilla.")
	else:
		botin = Estado.premio_modo(true, olas_ganadas)
		titulo = Idioma.t("¡Cacería completada!") if juego == "caceria" else Idioma.t("¡Reto superado!")
		t1 = Idioma.t("Vuelves al faro con el botín.")
	var m2: Dictionary = Estilo.modal(self, titulo, 620.0)
	_modal_fin = m2
	var vb: VBoxContainer = m2["vb"] as VBoxContainer
	var l1: Label = Estilo.etiqueta(t1, 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l1.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l1)
	vb.add_child(Estilo.etiqueta(Idioma.t("Botín"), 26, Estilo.ORO))
	vb.add_child(Estilo.etiqueta(_linea_botin(botin), 28, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true))
	_anadir_reliquia(vb, botin)
	_boton_doble(vb, botin)
	var b: Button = Estilo.boton(Idioma.t("Volver al faro"), true, 96)
	b.pressed.connect(continuar)
	vb.add_child(b)


## Anuncio voluntario: el botín de la noche otra vez.
func _boton_doble(vb: VBoxContainer, botin: Dictionary) -> void:
	var extra: Dictionary = {}
	for k: Variant in botin.keys():
		if Datos.NOMBRE_RECURSO.has(str(k)) and int(botin[k]) > 0:
			extra[str(k)] = int(botin[k])
	if extra.is_empty() or not Ads.rewarded_available():
		return
	var bd: Button = Estilo.boton(Idioma.t("Ver un anuncio: botín ×2"), false, 84)
	bd.pressed.connect(func() -> void:
		bd.disabled = true
		var ok: Array[bool] = [false]
		var f: Callable = func(pl: String) -> void:
			if pl == "botin_doble":
				ok[0] = true
		Ads.reward_earned.connect(f)
		await Ads.show_rewarded("botin_doble")
		Ads.reward_earned.disconnect(f)
		if ok[0]:
			Estado.sumar(extra)
			Estado.guardar()
			Audio.play("coin")
			bd.text = Idioma.t("¡Botín doble! ") + _linea_botin(extra)
		else:
			bd.disabled = false)
	vb.add_child(bd)


## Segunda oportunidad a cambio de un anuncio (una por noche): la guardia se levanta y el faro aguanta.
func _ofrecer_segunda() -> bool:
	if _segunda or not Ads.rewarded_available():
		return false
	_segunda = true
	await _esperar(0.5)
	var m: Dictionary = Estilo.modal(self, Idioma.t("La luz se resiste"), 600.0)
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Todavía queda una chispa en la lámpara."), 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true))
	var b1: Button = Estilo.boton(Idioma.t("Ver un anuncio: seguir luchando\n(la guardia se levanta y el faro aguanta)"), true, 112)
	b1.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b1.add_theme_font_size_override("font_size", 22)
	b1.pressed.connect(func() -> void: _eleccion.emit(true))
	vb.add_child(b1)
	var b2: Button = Estilo.boton(Idioma.t("Rendirse"), false, 80)
	b2.pressed.connect(func() -> void: _eleccion.emit(false))
	vb.add_child(b2)
	var quiere: bool = await _eleccion
	Estilo.cerrar(m)
	if not quiere:
		return false
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "segunda":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("segunda")
	Ads.reward_earned.disconnect(f)
	if not ok[0]:
		return false
	for i: int in heroes.size():
		if not bool(heroes[i]["vivo"]):
			_levantar(i, 0.5)
		else:
			_curar(i, int(ceil(float(heroes[i]["hpmax"]) * 0.3)))
	faro_hp = maxi(faro_hp, int(ceil(float(faro_max) * 0.4)))
	_barra_faro.value = faro_hp
	_lbl_faro.text = Idioma.t("Integridad del faro  %d / %d") % [faro_hp, faro_max]
	luz = mini(luz_max, luz + 3)
	_banner(Idioma.t("¡La luz vuelve!"), Estilo.ORO)
	Audio.play("powerup")
	await _esperar(0.6)
	return true


func _derrota(motivo: String) -> void:
	if motivo != "huida" and juego != "eterna":
		busy = true
		if await _ofrecer_segunda():
			for e: Dictionary in enemigos:
				e["lit"] = maxi(0, int(e["lit"]) - 1)
				e["aturdido"] = false
			busy = false
			_inicio_turno()
			return
	over = true
	busy = true
	_ui()
	Audio.play("lose")
	Audio.play_voice("derrota")
	_temblar(0.6)
	await _esperar(0.7)
	var botin: Dictionary = {}
	var txt: String = Idioma.t("El faro se apaga, pero no del todo.")
	match motivo:
		"heroes": txt = Idioma.t("Todos los náufragos han caído. Amanece entre humo y silencio.")
		"huida": txt = Idioma.t("Huyes escaleras abajo. La luz sigue encendida, aunque sin ti.")
	var titulo: String = Idioma.t("La niebla gana esta noche")
	if juego == "campana":
		Estado.d["faro_hp"] = maxi(0, faro_hp)
		botin = Estado.amanecer(false)
		txt += Idioma.t("\nVuelve a prepararte: la misma noche te espera.")
	elif juego == "eterna":
		botin = Estado.premio_modo(false, olas_ganadas)
		titulo = Idioma.t("Fin de la Niebla eterna")
		txt = Idioma.t("Aguantaste %d oleadas (tu récord: %d).") % [olas_ganadas, Estado.n("eterna_mejor")]
	else:
		botin = Estado.premio_modo(false, olas_ganadas)
		txt += Idioma.t("\nInténtalo otra vez cuando estés más fuerte.")
	var m: Dictionary = Estilo.modal(self, titulo, 620.0)
	_modal_fin = m
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var l1: Label = Estilo.etiqueta(txt, 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l1.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l1)
	if not botin.is_empty():
		vb.add_child(Estilo.etiqueta(Idioma.t("Botín: ") + _linea_botin(botin), 24, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
		_anadir_reliquia(vb, botin)
		if juego == "eterna":
			_boton_doble(vb, botin)
	var b: Button = Estilo.boton(Idioma.t("Volver al faro"), true, 96)
	b.pressed.connect(continuar)
	vb.add_child(b)


func continuar() -> void:
	if not over:
		return
	if gano:
		Ads.show_interstitial("level_end")
	Estado.partida = {"modo": "campana"}
	Kit.change_scene(ISLA)

extends Control
## La Arena de los Fareros: asaltas el faro de otros jugadores (su guardia guardada, manejada por la IA)
## o, sin conexión, el de los fareros rivales de la historia. 5 asaltos al día.

const ISLA: String = "res://libre/isla.tscn"
const NOCHE: String = "res://libre/noche.tscn"

var _info: Label
var _estado: Label
var _lista: VBoxContainer
var _modal: Dictionary = {}
var _online: bool = false


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estado.arena_dia()
	Audio.play_track("jefe")
	Estilo.fondo_cubrir(self, "bg_titulo" if Estilo.tex("bg_titulo") != null else "bg_noche", 1.05)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.03, 0.06, 0.66)
	vel.size = get_viewport_rect().size
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	var t: Label = Estilo.etiqueta(Idioma.t("La Arena de los Fareros"), 40, Estilo.ORO)
	t.position = Vector2(0, 22)
	t.size = Vector2(720, 56)
	add_child(t)
	_info = Estilo.etiqueta("", 22, Estilo.TEXTO)
	_info.position = Vector2(0, 80)
	_info.size = Vector2(720, 32)
	add_child(_info)
	_estado = Estilo.etiqueta("", 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	_estado.position = Vector2(30, 112)
	_estado.size = Vector2(660, 56)
	add_child(_estado)
	_defensa()
	var sc: ScrollContainer = ScrollContainer.new()
	sc.position = Vector2(16, 372)
	sc.size = Vector2(688, 700)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	sc.add_child(_lista)
	var abajo: Array = [[Idioma.t("Clasificación"), abrir_clasificacion], [Idioma.t("Amigos"), abrir_amigos], [Idioma.t("Quién me atacó"), abrir_registro]]
	for k: int in abajo.size():
		var bb: Button = Estilo.boton(str(abajo[k][0]), false, 80)
		bb.position = Vector2(20 + k * 228, 1084)
		bb.size = Vector2(216, 80)
		bb.add_theme_font_size_override("font_size", 20)
		bb.pressed.connect(abajo[k][1] as Callable)
		add_child(bb)
	var bv: Button = Estilo.boton(Idioma.t("Volver a la isla"), true, 88)
	bv.position = Vector2(20, 1176)
	bv.size = Vector2(680, 88)
	bv.pressed.connect(func() -> void: Kit.change_scene(ISLA))
	add_child(bv)
	_refrescar_info()
	_cargar_rivales()


func _refrescar_info() -> void:
	_info.text = Idioma.t("Puntos %d · Victorias %d · Asaltos hoy %d/%d") % [Estado.n("arena_puntos"), Estado.n("arena_victorias"), Estado.n("arena_tickets"), Estado.ARENA_TICKETS]


func _defensa() -> void:
	var p: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.85), Estilo.ORO.darkened(0.4))
	p.position = Vector2(16, 176)
	p.size = Vector2(688, 184)
	add_child(p)
	var vb: VBoxContainer = VBoxContainer.new()
	p.add_child(vb)
	var eq: Array = Estado.equipo_defensa()
	vb.add_child(Estilo.etiqueta(Idioma.t("Tu defensa (tu guardia) · Poder %d") % Estado.poder(eq), 22, Estilo.ORO))
	var hb: HBoxContainer = HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 14)
	vb.add_child(hb)
	for e: Variant in eq:
		var c: VBoxContainer = VBoxContainer.new()
		hb.add_child(c)
		c.add_child(Estilo.sprite(str((Estado.HEROES[str((e as Dictionary)["id"])] as Dictionary)["tex"]), Vector2(100, 110)))
		c.add_child(Estilo.etiqueta(Idioma.t("nv %d") % int((e as Dictionary)["lvl"]), 18, Estilo.TEXTO))


func _cargar_rivales() -> void:
	for c: Node in _lista.get_children():
		c.queue_free()
	var rivales: Array = []
	_online = Online.available()
	if _online and Online.alias() == "":
		_estado.text = Idioma.t("Elige un apodo para luchar contra otros fareros de verdad.")
		var ba: Button = Estilo.boton(Idioma.t("Elegir apodo"), true, 80)
		ba.pressed.connect(abrir_apodo)
		_lista.add_child(ba)
	elif _online:
		_estado.text = Idioma.t("Buscando faros...")
		var eq: Array = Estado.equipo_defensa()
		await Online.duelo_publicar({"heroes": eq}, Estado.poder(eq))
		var r: Dictionary = await Online.duelo_rivales()
		if not r.is_empty():
			var yo: Dictionary = r.get("yo", {}) as Dictionary
			Estado.d["arena_puntos"] = int(yo.get("puntos", Estado.n("arena_puntos")))
			for x: Variant in (r["rivales"] as Array):
				var rv: Dictionary = x as Dictionary
				var hs: Array = Estado.equipo_remoto(rv.get("equipo", {}))
				if not hs.is_empty():
					rivales.append({"alias": str(rv.get("alias", "?")), "equipo": hs, "puntos": str(rv.get("puntos", 1000)).to_int(), "id": str(rv.get("id", 0)).to_int(), "npc": false})
		_estado.text = Idioma.t("Asalta el faro de otros jugadores. Su guardia la maneja la niebla.") if not rivales.is_empty() else Idioma.t("Aún hay pocos fareros conectados: te esperan los rivales de la niebla.")
	else:
		_estado.text = Idioma.t("Sin conexión: te esperan los fareros rivales de la niebla.")
	var i: int = 0
	while rivales.size() < 3:
		rivales.append(Estado.rival_npc(i))
		i += 1
	_refrescar_info()
	for rv: Variant in rivales:
		_tarjeta(rv as Dictionary)
	if Estado.n("arena_tickets") <= 0 and Estado.n("arena_extra") != Estado.dia_de_hoy() and Ads.rewarded_available():
		var bx: Button = Estilo.boton(Idioma.t("Ver un anuncio: +1 asalto"), false, 80)
		bx.pressed.connect(func() -> void: _asalto_extra(bx))
		_lista.add_child(bx)


func _tarjeta(rv: Dictionary) -> void:
	var card: PanelContainer = Estilo.panel(Color(0.1, 0.12, 0.18, 0.95), Estilo.ROJO.darkened(0.3))
	_lista.add_child(card)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	card.add_child(hb)
	var eq: Array = rv["equipo"] as Array
	var retrato: String = str(rv.get("retrato", ""))
	if retrato == "" or Estilo.tex(retrato) == null:
		retrato = str((Estado.HEROES[str((eq[0] as Dictionary)["id"])] as Dictionary)["tex"])
	hb.add_child(Estilo.sprite(retrato, Vector2(96, 126)))
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(vb)
	var marca: String = Idioma.t("Farero de la niebla") if bool(rv.get("npc", false)) else Idioma.t("Jugador")
	vb.add_child(Estilo.etiqueta(str(rv["alias"]), 24, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT))
	var linea: Label = Estilo.etiqueta("%s · %s %d · %s %d" % [marca, Idioma.t("Puntos"), int(rv["puntos"]), Idioma.t("Poder"), Estado.poder(eq)], 17, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
	linea.custom_minimum_size = Vector2(380, 0)
	vb.add_child(linea)
	var caras: HBoxContainer = HBoxContainer.new()
	caras.add_theme_constant_override("separation", 4)
	vb.add_child(caras)
	for e: Variant in eq:
		caras.add_child(Estilo.sprite(str((Estado.HEROES[str((e as Dictionary)["id"])] as Dictionary)["tex"]), Vector2(48, 56)))
	if rv.has("lema"):
		var lema: Label = Estilo.etiqueta(str(rv["lema"]), 16, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		lema.custom_minimum_size = Vector2(380, 0)
		vb.add_child(lema)
	var b: Button = Estilo.boton(Idioma.t("Asaltar"), true, 72)
	b.custom_minimum_size = Vector2(124, 72)
	b.add_theme_font_size_override("font_size", 22)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.disabled = Estado.n("arena_tickets") <= 0
	b.pressed.connect(func() -> void: asaltar(rv))
	hb.add_child(b)


func asaltar(rv: Dictionary) -> void:
	if Estado.n("arena_tickets") <= 0:
		return
	var p: Dictionary = {"modo": "arena", "rival": str(rv["alias"]), "equipo": rv["equipo"], "npc": bool(rv.get("npc", false)),
		"puntos_rival": int(rv["puntos"]), "combate": 0}
	if not bool(rv.get("npc", false)):
		var r: Dictionary = await Online.duelo_empezar(int(rv["id"]))
		if r.is_empty():
			_estado.text = Idioma.t("No se pudo empezar el asalto. Prueba otra vez.")
			return
		p["combate"] = int(r["combate"])
		var hs: Array = Estado.equipo_remoto(r.get("equipo", {}))
		if not hs.is_empty():
			p["equipo"] = hs
	Estado.d["arena_tickets"] = Estado.n("arena_tickets") - 1
	Estado.guardar()
	Estado.partida = p
	Audio.play("powerup")
	Kit.change_scene(NOCHE)


func _asalto_extra(b: Button) -> void:
	b.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "arena_extra":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("arena_extra")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		Estado.d["arena_extra"] = Estado.dia_de_hoy()
		Estado.d["arena_tickets"] = Estado.n("arena_tickets") + 1
		Estado.guardar()
	_cargar_rivales()


func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func abrir_apodo() -> void:
	_modal = Estilo.modal(self, Idioma.t("Tu apodo de farero"), 600.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Es lo único que verán los demás. Nada de nombres reales."), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var le: LineEdit = LineEdit.new()
	le.max_length = Online.ALIAS_MAX
	le.custom_minimum_size = Vector2(520, 64)
	le.add_theme_font_size_override("font_size", 28)
	vb.add_child(le)
	var err: Label = Estilo.etiqueta("", 20, Estilo.ROJO)
	vb.add_child(err)
	var b: Button = Estilo.boton(Idioma.t("Guardar"), true, 80)
	b.pressed.connect(func() -> void:
		var e: String = Online.set_alias(le.text)
		if e != "":
			err.text = e
			return
		_cerrar()
		_cargar_rivales())
	vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cancelar"))
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_clasificacion() -> void:
	_modal = Estilo.modal(self, Idioma.t("Clasificación"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var filas: Array = []
	if _online:
		filas = await Online.duelo_top(20)
	if filas.is_empty():
		## Sin conexión: tú y los fareros de la niebla.
		var tabla: Array = [{"alias": Idioma.t("Tú"), "puntos": Estado.n("arena_puntos"), "tuyo": true}]
		for i: int in Datos.RIVALES.size():
			var f: Dictionary = Datos.RIVALES[i] as Dictionary
			tabla.append({"alias": Idioma.t(f["nombre"]), "puntos": 900 + ((i * 97 + Estado.dia_de_hoy()) % 700), "tuyo": false})
		tabla.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["puntos"]) > int(b["puntos"]))
		for i: int in tabla.size():
			filas.append({"posicion": i + 1, "alias": tabla[i]["alias"], "puntos": tabla[i]["puntos"], "tuyo": tabla[i]["tuyo"]})
	for x: Variant in filas:
		var r: Dictionary = x as Dictionary
		vb.add_child(Estilo.etiqueta("%d. %s · %d" % [int(r["posicion"]), str(r["alias"]), int(r["puntos"])], 22,
			Estilo.ORO if bool(r.get("tuyo", false)) else Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


## Amigos: tu código para compartir, añadir el de un amigo y asaltar su faro (sus héroes de verdad).
func abrir_amigos() -> void:
	_modal = Estilo.modal(self, Idioma.t("Amigos"), 660.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	if not _online or Online.alias() == "":
		vb.add_child(Estilo.etiqueta(Idioma.t("Conéctate y elige un apodo para añadir amigos y asaltar sus faros.") if not _online
			else Idioma.t("Elige primero un apodo de farero."), 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	else:
		var mio: String = await Online.friend_code()
		if not is_instance_valid(vb):
			return
		vb.add_child(Estilo.etiqueta(Idioma.t("Tu código: %s") % (mio if mio != "" else "—"), 26, Estilo.ORO))
		if mio != "":
			var bcp: Button = Estilo.boton(Idioma.t("Copiar mi código"), false, 64)
			bcp.pressed.connect(func() -> void:
				DisplayServer.clipboard_set(mio)
				bcp.text = Idioma.t("¡Copiado!"))
			vb.add_child(bcp)
		var fila: HBoxContainer = HBoxContainer.new()
		fila.add_theme_constant_override("separation", 8)
		vb.add_child(fila)
		var le: LineEdit = LineEdit.new()
		le.placeholder_text = Idioma.t("Código de tu amigo")
		le.custom_minimum_size = Vector2(330, 64)
		le.add_theme_font_size_override("font_size", 26)
		fila.add_child(le)
		var msg: Label = Estilo.etiqueta("", 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
		var ba: Button = Estilo.boton(Idioma.t("Añadir"), true, 64)
		ba.custom_minimum_size = Vector2(170, 64)
		ba.pressed.connect(func() -> void:
			if le.text.strip_edges() == "":
				return
			ba.disabled = true
			var r: Dictionary = await Online.friend_add(le.text)
			if not is_instance_valid(vb):
				return
			if r.is_empty():
				msg.text = Idioma.t("Ese código no existe (o es el tuyo).")
				ba.disabled = false
				return
			_cerrar()
			abrir_amigos())
		fila.add_child(ba)
		vb.add_child(msg)
		var lista: Array = await Online.duelo_amigos()
		if not is_instance_valid(vb):
			return
		if lista.is_empty():
			vb.add_child(Estilo.etiqueta(Idioma.t("Aún no tienes amigos con faro. Pásales tu código."), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
		for x: Variant in lista:
			var rv: Dictionary = x as Dictionary
			var hs: Array = Estado.equipo_remoto(rv.get("equipo", {}))
			if hs.is_empty():
				continue
			var amigo: Dictionary = {"alias": str(rv.get("alias", "?")), "equipo": hs, "puntos": str(rv.get("puntos", 1000)).to_int(), "id": str(rv.get("id", 0)).to_int(), "npc": false}
			var b: Button = Estilo.boton("%s %s · %s %d" % [Idioma.t("Asaltar"), amigo["alias"], Idioma.t("Poder"), Estado.poder(amigo["equipo"] as Array)], false, 72)
			b.add_theme_font_size_override("font_size", 21)
			b.disabled = Estado.n("arena_tickets") <= 0
			b.pressed.connect(func() -> void:
				_cerrar()
				asaltar(amigo))
			vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_registro() -> void:
	_modal = Estilo.modal(self, Idioma.t("Quién me atacó"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var filas: Array = await Online.duelo_registro() if _online else []
	if filas.is_empty():
		vb.add_child(Estilo.etiqueta(Idioma.t("Nadie ha asaltado tu faro todavía.") if _online else Idioma.t("Conéctate para que otros fareros puedan asaltar tu faro."), 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for x: Variant in filas:
		var r: Dictionary = x as Dictionary
		var defendido: bool = not bool(r["gano"])
		vb.add_child(Estilo.etiqueta((Idioma.t("%s asaltó tu faro y lo defendiste") if defendido else Idioma.t("%s asaltó tu faro y ganó")) % str(r["alias"]), 21,
			Estilo.VERDE if defendido else Estilo.ROJO, HORIZONTAL_ALIGNMENT_LEFT, true))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)

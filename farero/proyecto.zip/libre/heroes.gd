extends Control
## Los náufragos: subir de nivel, elegir talentos, equipar reliquias y decidir quién hace guardia.

const ISLA: String = "res://libre/isla.tscn"

var _lista: VBoxContainer
var _cab: Label
var _chips: Label
var _modal: Dictionary = {}


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estilo.fondo_cubrir(self, "bg_isla", 1.07)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.03, 0.06, 0.62)
	vel.size = Vector2(720, 1280)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	var t: Label = Estilo.etiqueta(Idioma.t("Los náufragos"), 42, Estilo.ORO)
	t.position = Vector2(0, 18)
	t.size = Vector2(720, 60)
	add_child(t)
	_chips = Estilo.etiqueta("", 22, Estilo.TEXTO)
	_chips.position = Vector2(0, 78)
	_chips.size = Vector2(720, 32)
	add_child(_chips)
	_cab = Estilo.etiqueta("", 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	_cab.position = Vector2(30, 112)
	_cab.size = Vector2(660, 60)
	add_child(_cab)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.position = Vector2(16, 176)
	sc.size = Vector2(688, 976)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 10)
	sc.add_child(_lista)
	var bv: Button = Estilo.boton(Idioma.t("Volver a la isla"), true, 92)
	bv.position = Vector2(20, 1164)
	bv.size = Vector2(680, 92)
	bv.pressed.connect(func() -> void: Kit.change_scene(ISLA))
	add_child(bv)
	_llenar()
	_consejo.call_deferred()


func _consejo() -> void:
	if Consejo.mostrar(self, "heroes"):
		return
	if Estado.talentos_abiertos() and Consejo.mostrar(self, "talentos"):
		return
	if not (Estado.d["reliquias"] as Array).is_empty():
		Consejo.mostrar(self, "reliquia")


func _llenar() -> void:
	for c: Node in _lista.get_children():
		c.queue_free()
	var t: Array[String] = []
	for r: String in ["hierro", "madera", "aceite", "ambar"]:
		t.append(Idioma.t("%s %d") % [Idioma.t(Datos.NOMBRE_RECURSO[r]), Estado.n(r)])
	_chips.text = "   ".join(t)
	_cab.text = Idioma.t("Guardia: %d de %d.%s") % [Estado.guardia().size(), Estado.guardia_max(),
		"" if Estado.talentos_abiertos() else Idioma.t("  Construye la Biblioteca del faro para abrir los talentos.")]
	var guardia: Array[String] = Estado.guardia()
	for id: String in Estado.orden_heroes():
		_tarjeta(id, guardia.has(id))


func _tarjeta(id: String, en_guardia: bool) -> void:
	var h: Dictionary = Estado.HEROES[id] as Dictionary
	var tiene: bool = (Estado.d["heroes"] as Dictionary).has(id)
	var card: PanelContainer = Estilo.panel(Color(0.1, 0.13, 0.2, 0.95), Color(str(h["col"])).darkened(0.1 if en_guardia else 0.5))
	_lista.add_child(card)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	card.add_child(hb)
	var spr: TextureRect = Estilo.sprite(str(h["tex"]), Vector2(110, 140))
	hb.add_child(spr)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 2)
	hb.add_child(vb)
	if not tiene:
		Estilo.param(spr, "gris", 1.0)
		Estilo.param(spr, "alfa", 0.3)
		vb.add_child(Estilo.etiqueta("???", 28, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT))
		var g: int = int(h["llega"])
		vb.add_child(Estilo.etiqueta(Idioma.t("La niebla lo traerá en %s.") % Estado.titulo_noche(g).to_lower(), 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
		return
	var lvl: int = Estado.nivel(id)
	var estrella: String = "  ★" if not Estado.talento_pendiente(id).is_empty() else ""
	vb.add_child(Estilo.etiqueta(Idioma.t("%s · nv %d%s") % [Idioma.t(h["nombre"]), lvl, estrella], 25, Color(str(h["col"])).lightened(0.3), HORIZONTAL_ALIGNMENT_LEFT))
	vb.add_child(Estilo.etiqueta(Idioma.t("%s · Vida %d · Fuerza %d") % [Idioma.t(h["rol"]), Estado.hp_heroe(id), int(Estado.atk_heroe(id))], 19, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
	var rel: String = str(Estado.h(id).get("rel", ""))
	var d: Label = Estilo.etiqueta("%s%s" % [Idioma.t(h["hab"]), ("  ·  " + str(Idioma.t((Datos.RELIQUIAS[rel] as Dictionary)["nombre"]))) if rel != "" else ""], 18, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
	d.custom_minimum_size = Vector2(240, 0)
	vb.add_child(d)
	var bv: VBoxContainer = VBoxContainer.new()
	bv.add_theme_constant_override("separation", 6)
	hb.add_child(bv)
	var c: Dictionary = Estado.coste_nivel(id)
	var bs: Button = Estilo.boton(Idioma.t("Subir nivel\n") + Estado.texto_coste(c) if lvl < Estado.NIVEL_MAX else Idioma.t("Nivel\nmáximo"), false, 70)
	bs.custom_minimum_size = Vector2(190, 70)
	bs.add_theme_font_size_override("font_size", 17)
	bs.disabled = lvl >= Estado.NIVEL_MAX or not Estado.puede_pagar(c)
	bs.pressed.connect(func() -> void:
		if Estado.subir_heroe(id):
			Audio.play("powerup")
		_llenar())
	bv.add_child(bs)
	var fila: HBoxContainer = HBoxContainer.new()
	fila.add_theme_constant_override("separation", 6)
	bv.add_child(fila)
	var bg: Button = Estilo.boton(Idioma.t("Guardia") if en_guardia else Idioma.t("Reserva"), en_guardia, 60)
	bg.custom_minimum_size = Vector2(92, 60)
	bg.add_theme_font_size_override("font_size", 17)
	bg.pressed.connect(func() -> void:
		if not Estado.alternar_guardia(id):
			Audio.play("hurt")
		Estado.guardar()
		_llenar())
	fila.add_child(bg)
	var bd: Button = Estilo.boton(Idioma.t("Ficha"), false, 60)
	bd.custom_minimum_size = Vector2(92, 60)
	bd.add_theme_font_size_override("font_size", 17)
	bd.pressed.connect(func() -> void: abrir_ficha(id))
	fila.add_child(bd)


# ---------------- ficha: habilidad, talentos y reliquia ----------------
func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func abrir_ficha(id: String) -> void:
	if not _modal.is_empty():
		_cerrar()
	var h: Dictionary = Estado.HEROES[id] as Dictionary
	_modal = Estilo.modal(self, str(Idioma.t(h["nombre"])), 660.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(620, 820)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var l: VBoxContainer = VBoxContainer.new()
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.add_theme_constant_override("separation", 8)
	sc.add_child(l)
	var top: HBoxContainer = HBoxContainer.new()
	top.add_theme_constant_override("separation", 12)
	l.add_child(top)
	top.add_child(Estilo.sprite(str(h["tex"]), Vector2(170, 220)))
	var info: VBoxContainer = VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(info)
	info.add_child(Estilo.etiqueta((Idioma.t("%s de %s") % [Idioma.t(h["rol"]), str(Idioma.t(h["mundo"]))]).replace(Idioma.t(" de el "), Idioma.t(" del ")), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
	info.add_child(Estilo.etiqueta(Idioma.t("Nivel %d · Vida %d · Fuerza %d") % [Estado.nivel(id), Estado.hp_heroe(id), int(Estado.atk_heroe(id))], 21, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true))
	var hab: Label = Estilo.etiqueta(Idioma.t("%s: %s") % [Idioma.t(h["hab"]), Idioma.t(h["desc"])], 20, Color(str(h["col"])).lightened(0.3), HORIZONTAL_ALIGNMENT_LEFT, true)
	hab.custom_minimum_size = Vector2(400, 0)
	info.add_child(hab)
	var fr: Label = Estilo.etiqueta(str(Idioma.t(h["frase"])), 19, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
	fr.custom_minimum_size = Vector2(400, 0)
	info.add_child(fr)
	# talentos
	l.add_child(Estilo.etiqueta(Idioma.t("Talentos"), 28, Estilo.ORO))
	if not Estado.talentos_abiertos():
		l.add_child(Estilo.etiqueta(Idioma.t("Construye la Biblioteca del faro para abrirlos."), 20, Estilo.NIEBLA))
	var tal: Dictionary = Estado.h(id).get("tal", {}) as Dictionary
	for t: Dictionary in Datos.TALENTOS:
		var nv: int = int(t["nivel"])
		var elegido: String = str(tal.get(str(nv), ""))
		var fila: HBoxContainer = HBoxContainer.new()
		fila.add_theme_constant_override("separation", 8)
		l.add_child(fila)
		fila.add_child(Estilo.etiqueta(Idioma.t("nv %d") % nv, 20, Estilo.NIEBLA))
		for cual: String in ["a", "b"]:
			var op: Dictionary = t[cual] as Dictionary
			var b: Button = Estilo.boton("%s\n%s" % [Idioma.t(op["nombre"]), Idioma.t(op["desc"])], elegido == cual, 96)
			b.custom_minimum_size = Vector2(250, 104)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			b.clip_text = true
			b.add_theme_font_size_override("font_size", 16)
			var puede: bool = Estado.talentos_abiertos() and elegido == "" and Estado.nivel(id) >= nv
			b.disabled = not puede and elegido != cual
			if elegido != "" and elegido != cual:
				b.modulate = Color(1, 1, 1, 0.45)
			b.pressed.connect(func() -> void:
				if puede:
					Estado.elegir_talento(id, nv, cual)
					Audio.play("powerup")
					abrir_ficha(id)
					_llenar())
			fila.add_child(b)
	# reliquia
	l.add_child(Estilo.etiqueta(Idioma.t("Reliquia"), 28, Estilo.ORO))
	var propias: Array = Estado.d["reliquias"] as Array
	if propias.is_empty():
		l.add_child(Estilo.etiqueta(Idioma.t("Aún no tienes reliquias. Salen de los jefes, de las noches antiguas y de las cacerías."), 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var actual: String = str(Estado.h(id).get("rel", ""))
	for r: Variant in propias:
		var rid: String = str(r)
		var def: Dictionary = Datos.RELIQUIAS[rid] as Dictionary
		var quien: String = ""
		for k: Variant in (Estado.d["heroes"] as Dictionary).keys():
			if str(Estado.h(str(k)).get("rel", "")) == rid and str(k) != id:
				quien = str(Idioma.t((Estado.HEROES[str(k)] as Dictionary)["nombre"])).split(" ")[-1]
		var fila2: HBoxContainer = HBoxContainer.new()
		fila2.add_theme_constant_override("separation", 8)
		l.add_child(fila2)
		fila2.add_child(Estilo.sprite(rid, Vector2(72, 72)))
		var br: Button = Estilo.boton("%s%s\n%s" % [Idioma.t(def["nombre"]), (Idioma.t("  (lleva %s)") % quien) if quien != "" else "", Idioma.t(def["desc"])], actual == rid, 84)
		br.custom_minimum_size = Vector2(0, 90)
		br.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		br.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		br.clip_text = true
		br.add_theme_font_size_override("font_size", 17)
		br.pressed.connect(func() -> void:
			Estado.equipar(id, "" if actual == rid else rid)
			Audio.play("click")
			abrir_ficha(id)
			_llenar())
		fila2.add_child(br)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"))
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)

extends RefCounted
## Bot: juega El Farero de la Niebla como un jugador cuidadoso (explora, mejora, ilumina y ataca).


static func _esperar_escena(tree: SceneTree, metodo: String, max_s: float = 8.0) -> Node:
	var t: float = 0.0
	while t < max_s:
		var cs: Node = tree.current_scene
		if cs != null and cs.has_method(metodo) and cs.is_node_ready():
			return cs
		await tree.create_timer(0.1).timeout
		t += 0.1
	return null


static func _elegir_objetivo(n: Node) -> int:
	var mejor: int = -1
	var hp_mejor: int = 999999
	for i: int in n.enemigos.size():
		var e: Dictionary = n.enemigos[i]
		if not bool(e["vivo"]):
			continue
		if str(e["rasgo"]) == "intangible" and int(e["lit"]) <= 0:
			continue
		if int(e["hp"]) < hp_mejor:
			hp_mejor = int(e["hp"])
			mejor = i
	return mejor


static func _esperar_libre(tree: SceneTree, n: Node) -> void:
	var w: float = 0.0
	while n.busy and not n.over and w < 25.0:
		await tree.create_timer(0.1).timeout
		w += 0.1


static func _turno(tree: SceneTree, n: Node) -> void:
	# 1) iluminar: primero los intangibles y los que mas pegan
	var orden: Array[int] = []
	for i: int in n.enemigos.size():
		orden.append(i)
	orden.sort_custom(func(a: int, b: int) -> bool:
		var ea: Dictionary = n.enemigos[a]
		var eb: Dictionary = n.enemigos[b]
		var pa: float = float(ea["atk"]) + (100.0 if str(ea["rasgo"]) == "intangible" else 0.0)
		var pb: float = float(eb["atk"]) + (100.0 if str(eb["rasgo"]) == "intangible" else 0.0)
		return pa > pb)
	for ei: int in orden:
		if n.over:
			return
		await _esperar_libre(tree, n)
		var e: Dictionary = n.enemigos[ei]
		if bool(e["vivo"]) and int(e["lit"]) <= 0 and n.luz >= 1:
			await n.accion_iluminar(ei)
	# 2) heroes
	for hi: int in n.heroes.size():
		if n.over:
			return
		await _esperar_libre(tree, n)
		var h: Dictionary = n.heroes[hi]
		if not bool(h["vivo"]) or bool(h["actuo"]):
			continue
		var id: String = str(h["id"])
		if id == "alba" and n.luz >= 1:
			var herido: bool = false
			for o: Dictionary in n.heroes:
				if bool(o["vivo"]) and float(o["hp"]) < float(o["hpmax"]) * 0.6:
					herido = true
			if herido or n.faro_hp < n.faro_max / 2:
				await n.accion_habilidad(hi, -1)
				continue
		var t: int = _elegir_objetivo(n)
		if t < 0:
			continue
		if id == "tumo" and n.luz >= 1 and n.turno % 2 == 1:
			await n.accion_habilidad(hi, -1)
		elif (id == "koji" or id == "nerea" or id == "lyra") and n.luz >= 1 and n.luz > 1:
			await n.accion_habilidad(hi, t)
		else:
			await n.accion_atacar(hi, t)
	if n.over:
		return
	await _esperar_libre(tree, n)
	await n.terminar_turno()


static func jugar(tree: SceneTree) -> Dictionary:
	Estado.nuevo()
	var ganadas: int = 0
	var intentos: int = 0
	var log: Array[String] = []
	tree.change_scene_to_file("res://libre/isla.tscn")
	while ganadas < 3 and intentos < 6:
		intentos += 1
		var isla: Node = await _esperar_escena(tree, "abrir_explorar")
		if isla == null:
			return {"ok": false, "niveles": ganadas, "detalle": "no cargo la isla"}
		await tree.create_timer(0.3).timeout
		var lugares: Array[int] = [0, 2, 1]
		for i: int in 3:
			isla.explorar(lugares[i])
		for k: int in 4:
			isla.reparar()
		isla.mejorar_lente()
		for id: String in Estado.guardia():
			isla.subir(id)
		isla.encender()
		var n: Node = await _esperar_escena(tree, "accion_destello")
		if n == null:
			return {"ok": false, "niveles": ganadas, "detalle": "no cargo la noche"}
		await tree.create_timer(0.3).timeout
		if n.llegada_pendiente:
			n.cerrar_llegada()
		var vueltas: int = 0
		while not n.over and vueltas < 80:
			vueltas += 1
			await _esperar_libre(tree, n)
			if n.over:
				break
			await _turno(tree, n)
		var w: float = 0.0
		while not n.over and w < 5.0:
			await tree.create_timer(0.1).timeout
			w += 0.1
		await tree.create_timer(0.5).timeout
		if n.gano:
			ganadas += 1
			log.append("noche %d ganada en %d turnos" % [n.noche, n.turno])
		else:
			log.append("noche %d perdida" % n.noche)
		n.continuar()
	return {"ok": ganadas >= 3, "niveles": ganadas, "detalle": "; ".join(log)}

extends RefCounted
## Bot: juega El Farero como un jugador cuidadoso. De día explora, repara y gasta (héroes, plantas,
## talentos, reliquias); de noche ilumina, usa habilidades y ataca. Sirve para medir la dificultad:
## cuántas noches pasa y cuántas veces pierde en cada una.
##   ORQ_BOT_NOCHES = hasta qué noche juega (por defecto 3)   ORQ_BOT_VELOCIDAD = time_scale (1)

const CURAN: Array[String] = ["alba", "pip", "morgana"]


static func _esperar_escena(tree: SceneTree, metodo: String, max_s: float = 8.0) -> Node:
	var t: float = 0.0
	while t < max_s:
		var cs: Node = tree.current_scene
		if cs != null and cs.has_method(metodo) and cs.is_node_ready():
			return cs
		await tree.create_timer(0.1).timeout
		t += 0.1
	return null


static func _rasgo(e: Dictionary, r: String) -> bool:
	return (e["rasgos"] as Array).has(r)


static func _elegir_objetivo(n: Node) -> int:
	var mejor: int = -1
	var puntos: float = -1.0
	for i: int in n.enemigos.size():
		var e: Dictionary = n.enemigos[i]
		if not bool(e["vivo"]):
			continue
		if _rasgo(e, "intangible") and int(e["lit"]) <= 0:
			continue
		## Primero lo que se puede rematar y lo que más pega.
		var p: float = float(e["atk"]) * 10.0 / maxf(1.0, float(e["hp"]))
		if p > puntos:
			puntos = p
			mejor = i
	return mejor


static func _esperar_libre(tree: SceneTree, n: Node) -> void:
	var w: float = 0.0
	while n.busy and not n.over and w < 25.0:
		await tree.create_timer(0.1).timeout
		w += 0.1


static func _vivos(n: Node) -> int:
	var c: int = 0
	for e: Dictionary in n.enemigos:
		if bool(e["vivo"]):
			c += 1
	return c


static func _turno(tree: SceneTree, n: Node) -> void:
	# 1) destello si hay muchos y sobra luz
	await _esperar_libre(tree, n)
	if _vivos(n) >= 3 and n.luz >= 5 and n.reto != "sin_destello":
		await n.accion_destello()
	# 2) iluminar intangibles y a los que más pegan, guardando luz para habilidades
	var orden: Array[int] = []
	for i: int in n.enemigos.size():
		orden.append(i)
	orden.sort_custom(func(a: int, b: int) -> bool:
		var ea: Dictionary = n.enemigos[a]
		var eb: Dictionary = n.enemigos[b]
		var pa: float = float(ea["atk"]) + (100.0 if _rasgo(ea, "intangible") else 0.0) + (50.0 if bool(ea["jefe"]) else 0.0)
		var pb: float = float(eb["atk"]) + (100.0 if _rasgo(eb, "intangible") else 0.0) + (50.0 if bool(eb["jefe"]) else 0.0)
		return pa > pb)
	for ei: int in orden:
		if n.over:
			return
		await _esperar_libre(tree, n)
		var e: Dictionary = n.enemigos[ei]
		var hace_falta: bool = _rasgo(e, "intangible") or n.luz >= 3
		if bool(e["vivo"]) and int(e["lit"]) <= 0 and n.luz >= 1 and hace_falta and not _rasgo(e, "come_luz"):
			await n.accion_iluminar(ei)
	# 3) héroes
	for hi: int in n.heroes.size():
		if n.over:
			return
		await _esperar_libre(tree, n)
		var h: Dictionary = n.heroes[hi]
		if not bool(h["vivo"]) or bool(h["actuo"]):
			continue
		var id: String = str(h["id"])
		var puede_hab: bool = n.luz >= 1 or bool(h["gratis"])
		if CURAN.has(id) and puede_hab:
			var herido: bool = false
			for o: Dictionary in n.heroes:
				if not bool(o["vivo"]) or float(o["hp"]) < float(o["hpmax"]) * 0.55:
					herido = true
			if herido or (id == "alba" and n.faro_hp < n.faro_max / 2):
				var t0: int = _elegir_objetivo(n)
				if id != "morgana" or t0 >= 0:
					await n.accion_habilidad(hi, t0)
					continue
		var t: int = _elegir_objetivo(n)
		if t < 0:
			continue
		var apoyo: bool = id in ["tumo", "bram", "ossian", "zahir", "selene", "lyra", "grog", "sable", "tobias"]
		if id == "selene" and n.luz <= 1 and puede_hab:
			await n.accion_habilidad(hi, -1)
		elif apoyo and puede_hab and (n.luz >= 2 or bool(h["gratis"])) and (id != "tumo" or n.turno % 2 == 1):
			await n.accion_habilidad(hi, -1)
		elif not apoyo and not CURAN.has(id) and puede_hab and (n.luz >= 2 or bool(h["gratis"])):
			await n.accion_habilidad(hi, t)
		else:
			await n.accion_atacar(hi, t)
	if n.over:
		return
	await _esperar_libre(tree, n)
	await n.terminar_turno()


## Una noche entera (o un modo). Devuelve true si gana.
static func _jugar_noche(tree: SceneTree, max_vueltas: int = 80) -> Dictionary:
	var n: Node = await _esperar_escena(tree, "accion_destello")
	if n == null:
		return {"error": "no cargo la noche"}
	await tree.create_timer(0.3).timeout
	if n.llegada_pendiente:
		n.cerrar_llegada()
	var vueltas: int = 0
	while not n.over and vueltas < max_vueltas:
		vueltas += 1
		await _esperar_libre(tree, n)
		if n.over:
			break
		await _turno(tree, n)
	if not n.over:
		n._pedir_huir()
		await tree.create_timer(0.3).timeout
		if not n.over:
			await n._derrota("huida")
	var w: float = 0.0
	while not (n._modal_fin as Dictionary).size() > 0 and w < 8.0:
		await tree.create_timer(0.1).timeout
		w += 0.1
	var r: Dictionary = {"gano": n.gano, "noche": n.noche, "turnos": n.turno, "olas": n.olas_ganadas}
	n.continuar()
	return r


# ---------------------------------------------------------------- economía del día
static func _peso(c: Dictionary) -> int:
	var t: int = 0
	for k: Variant in c.keys():
		t += int(c[k]) * (12 if str(k) == "ambar" else 1)
	return t


static func _dia() -> void:
	# guardia: los mejores
	var ids: Array[String] = []
	for k: Variant in (Estado.d["heroes"] as Dictionary).keys():
		ids.append(str(k))
	ids.sort_custom(func(a: String, b: String) -> bool: return Estado.hp_heroe(a) * Estado.atk_heroe(a) > Estado.hp_heroe(b) * Estado.atk_heroe(b))
	Estado.d["guardia"] = ids.slice(0, Estado.guardia_max())
	# explorar: lo que más falta
	var ls: Array = Estado.lugares()
	while Estado.n("horas") > 0:
		Estado.explorar((Estado.n("dia") + Estado.n("horas")) % ls.size())
		var si: int = Estado.suceso_al_explorar()
		if si >= 0:
			var ops: Array = (Datos.SUCESOS[si] as Dictionary)["opciones"] as Array
			var oi: int = Estado.rng.randi() % ops.size()
			if not Estado.puede_pagar(Estado.coste_opcion(ops[oi] as Dictionary)):
				oi = ops.size() - 1
			Estado.resolver_suceso(si, oi)
	while Estado.n("faro_hp") < Estado.faro_max() * 0.8 and Estado.reparar():
		pass
	# talentos y reliquias
	for id: String in ids:
		var t: Dictionary = Estado.talento_pendiente(id)
		while not t.is_empty():
			Estado.elegir_talento(id, int(t["nivel"]), "a" if int(t["nivel"]) != 10 else "b")
			t = Estado.talento_pendiente(id)
	var rels: Array = (Estado.d["reliquias"] as Array).duplicate()
	for i: int in mini(rels.size(), Estado.guardia().size()):
		Estado.equipar(Estado.guardia()[i], str(rels[i]))
	# gastar: lo más barato primero (héroes de guardia y plantas)
	for vuelta: int in 60:
		var mejor: String = ""
		var coste_m: int = 999999
		for id: String in Estado.guardia():
			if Estado.nivel(id) < Estado.NIVEL_MAX and Estado.puede_pagar(Estado.coste_nivel(id)):
				var c: int = _peso(Estado.coste_nivel(id))
				if c < coste_m:
					coste_m = c
					mejor = "h:" + id
		for p: Dictionary in Datos.PLANTAS:
			var pid: String = str(p["id"])
			if Estado.planta(pid) < int(p["max"]) and Estado.puede_pagar(Estado.coste_planta(pid)):
				var c2: int = int(float(_peso(Estado.coste_planta(pid))) * 1.3)
				if c2 < coste_m:
					coste_m = c2
					mejor = "p:" + pid
		if mejor == "":
			break
		if mejor.begins_with("h:"):
			Estado.subir_heroe(mejor.substr(2))
		else:
			Estado.mejorar_planta(mejor.substr(2))
	Estado.guardar()


static func jugar(tree: SceneTree) -> Dictionary:
	var hasta: int = int(OS.get_environment("ORQ_BOT_NOCHES")) if OS.get_environment("ORQ_BOT_NOCHES") != "" else 3
	var vel: float = float(OS.get_environment("ORQ_BOT_VELOCIDAD")) if OS.get_environment("ORQ_BOT_VELOCIDAD") != "" else 1.0
	Engine.time_scale = vel
	Estado.nuevo()
	var perdidas: Dictionary = {}
	var log: Array[String] = []
	var intentos: int = 0
	tree.change_scene_to_file("res://libre/isla.tscn")
	while Estado.n("noche") <= hasta and intentos < hasta * 2:
		intentos += 1
		var isla: Node = await _esperar_escena(tree, "abrir_explorar")
		if isla == null:
			return {"ok": false, "detalle": "no cargo la isla"}
		await tree.create_timer(0.2).timeout
		_dia()
		isla.encender()
		var r: Dictionary = await _jugar_noche(tree)
		if r.has("error"):
			return {"ok": false, "detalle": str(r["error"])}
		if not bool(r["gano"]):
			perdidas[str(r["noche"])] = int(perdidas.get(str(r["noche"]), 0)) + 1
		elif int(r["noche"]) % 6 == 0 or int(r["noche"]) <= 3:
			log.append("noche %d ganada en %d turnos" % [int(r["noche"]), int(r["turnos"])])
	# Los modos, una vez cada uno (si están abiertos)
	var modos: Array[String] = []
	if Estado.n("mejor") >= 4:
		for p: Dictionary in [{"modo": "reto", "reto": str(Estado.reto_de_hoy()["id"])}, {"modo": "eterna"}]:
			var isla2: Node = await _esperar_escena(tree, "abrir_explorar")
			isla2._jugar(p)
			var r2: Dictionary = await _jugar_noche(tree, 40 if str(p["modo"]) == "eterna" else 80)
			modos.append("%s: %s (%d oleadas)" % [p["modo"], "gana" if bool(r2.get("gano", false)) else "acaba", int(r2.get("olas", 0))])
	var niveles: Array[String] = []
	for id: String in Estado.guardia():
		niveles.append("%s %d" % [id, Estado.nivel(id)])
	var plantas: Array[String] = []
	for k: Variant in (Estado.d["plantas"] as Dictionary).keys():
		plantas.append("%s %d" % [k, int((Estado.d["plantas"] as Dictionary)[k])])
	Engine.time_scale = 1.0
	var llego: int = Estado.n("noche") - 1
	return {"ok": llego >= mini(hasta, 3), "niveles": llego, "intentos": intentos,
		"detalle": "; ".join(log), "perdidas": perdidas, "guardia": ", ".join(niveles), "plantas": ", ".join(plantas),
		"reliquias": (Estado.d["reliquias"] as Array).size(), "modos": modos}

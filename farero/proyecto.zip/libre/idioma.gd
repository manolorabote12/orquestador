class_name Idioma
extends RefCounted
## Español (el texto original) e inglés (res://libre/en.json: original -> traducción). Los textos que
## se ven tal cual se traducen solos (auto-traducción de Godot); los que se montan con % pasan por t().

static var _listo: bool = false
static var _en: Dictionary = {}


static func iniciar() -> void:
	if _listo:
		return
	_listo = true
	var f: FileAccess = FileAccess.open("res://libre/en.json", FileAccess.READ)
	if f != null:
		var d: Variant = JSON.parse_string(f.get_as_text())
		if d is Dictionary:
			_en = d as Dictionary
	var tr_en: Translation = Translation.new()
	tr_en.locale = "en"
	for k: Variant in _en.keys():
		tr_en.add_message(str(k), str(_en[k]))
	TranslationServer.add_translation(tr_en)
	var lang: String = str(Save.get_setting("lang", ""))
	if lang == "":
		lang = "es" if OS.get_locale_language() == "es" else "en"
	TranslationServer.set_locale(lang)


static func actual() -> String:
	return "en" if TranslationServer.get_locale().begins_with("en") else "es"


static func nombre() -> String:
	return "English" if actual() == "en" else "Español"


static func cambiar() -> void:
	var nuevo: String = "es" if actual() == "en" else "en"
	Save.set_setting("lang", nuevo)
	TranslationServer.set_locale(nuevo)


static func t(s: Variant) -> String:
	var txt: String = str(s)
	if actual() == "en" and _en.has(txt):
		return str(_en[txt])
	return txt

extends Control
## Titulo: la isla, el faro y el comienzo de la partida.

const ISLA: String = "res://libre/isla.tscn"

var _vb: VBoxContainer
var _aviso: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Audio.play_track("menu")
	var bg: TextureRect = Estilo.fondo_cubrir(self, "bg_titulo" if Estilo.tex("bg_titulo") != null else "bg_isla", 1.0)
	## Respira despacio: la cámara se acerca a la isla.
	bg.create_tween().set_loops().tween_property(bg, "scale", Vector2(1.04, 1.04), 9.0).set_trans(Tween.TRANS_SINE)
	_haz()
	_niebla()
	_lluvia()
	_titulo()
	_botones()
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 72)
	ba.position = Vector2(544, 22)
	ba.size = Vector2(160, 72)
	ba.add_theme_font_size_override("font_size", 20)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	add_child(ba)


## El haz del faro: gira (de perfil se ve ir y volver) y destella cuando apunta a la cámara.
const LAMPARA: Vector2 = Vector2(404, 607)


func _haz() -> void:
	var pivote: Node2D = Node2D.new()
	pivote.position = LAMPARA
	add_child(pivote)
	var cono: Polygon2D = Polygon2D.new()
	cono.polygon = PackedVector2Array([Vector2(0, -6), Vector2(760, -150), Vector2(760, 150), Vector2(0, 6)])
	cono.vertex_colors = PackedColorArray([Color(1, 0.86, 0.5, 0.55), Color(1, 0.86, 0.5, 0.0), Color(1, 0.86, 0.5, 0.0), Color(1, 0.86, 0.5, 0.55)])
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	cono.material = mat
	pivote.add_child(cono)
	var brillo: TextureRect = TextureRect.new()
	brillo.texture = Juice.dot_texture()
	brillo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	brillo.size = Vector2(150, 150)
	brillo.position = LAMPARA - Vector2(75, 75)
	brillo.modulate = Color(1, 0.85, 0.5, 0.7)
	brillo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	brillo.material = mat
	add_child(brillo)
	var tw: Tween = pivote.create_tween().set_loops()
	tw.tween_property(pivote, "scale:x", -1.0, 3.2).from(1.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(pivote, "scale:x", 1.0, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var tb: Tween = brillo.create_tween().set_loops()
	tb.tween_interval(1.25)
	tb.tween_property(brillo, "scale", Vector2(1.9, 1.9), 0.35).set_trans(Tween.TRANS_SINE)
	tb.parallel().tween_property(brillo, "modulate:a", 1.0, 0.35)
	tb.tween_property(brillo, "scale", Vector2.ONE, 0.6).set_trans(Tween.TRANS_SINE)
	tb.parallel().tween_property(brillo, "modulate:a", 0.6, 0.6)
	tb.tween_interval(1.85)
	brillo.pivot_offset = Vector2(75, 75)


func _niebla() -> void:
	var cap: Control = Control.new()
	cap.size = Vector2(720, 1280)
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cap.clip_contents = true
	add_child(cap)
	for i: int in 6:
		var t: TextureRect = TextureRect.new()
		t.texture = Juice.dot_texture()
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.size = Vector2(700, 240)
		t.position = Vector2(-320 + i * 150, 560 + i * 110)
		t.modulate = Color(0.8, 0.88, 0.92, 0.13)
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cap.add_child(t)
		var dx: float = 160.0 if i % 2 == 0 else -160.0
		var tw: Tween = t.create_tween().set_loops()
		tw.tween_property(t, "position:x", t.position.x + dx, 8.0 + i).set_trans(Tween.TRANS_SINE)
		tw.tween_property(t, "position:x", t.position.x, 8.0 + i).set_trans(Tween.TRANS_SINE)


func _lluvia() -> void:
	var p: CPUParticles2D = CPUParticles2D.new()
	p.position = Vector2(360, -20)
	p.amount = 90
	p.lifetime = 1.4
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(420, 10)
	p.direction = Vector2(-0.25, 1)
	p.spread = 3.0
	p.gravity = Vector2(0, 0)
	p.initial_velocity_min = 900.0
	p.initial_velocity_max = 1200.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	p.color = Color(0.75, 0.82, 0.9, 0.22)
	add_child(p)


func _titulo() -> void:
	var a: Label = Estilo.etiqueta(Idioma.t("El Farero"), 112, Estilo.ORO)
	a.add_theme_constant_override("outline_size", 18)
	a.add_theme_color_override("font_outline_color", Color(0.05, 0.04, 0.02, 0.9))
	a.add_theme_color_override("font_shadow_color", Color(1, 0.75, 0.3, 0.45))
	a.add_theme_constant_override("shadow_offset_x", 0)
	a.add_theme_constant_override("shadow_offset_y", 0)
	a.add_theme_constant_override("shadow_outline_size", 34)
	a.position = Vector2(0, 90)
	a.size = Vector2(720, 140)
	a.pivot_offset = Vector2(360, 70)
	add_child(a)
	var b: Label = Estilo.etiqueta(Idioma.t("de la Niebla"), 62, Estilo.TEXTO)
	b.add_theme_constant_override("outline_size", 12)
	b.position = Vector2(0, 216)
	b.size = Vector2(720, 90)
	add_child(b)
	var s: Label = Estilo.etiqueta(Idioma.t("Un faro. Una isla perdida.\nTodo lo que la niebla trae."), 27, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	s.position = Vector2(60, 312)
	s.size = Vector2(600, 90)
	add_child(s)
	a.scale = Vector2(1.25, 1.25)
	for c: Control in [a, b, s]:
		c.modulate.a = 0.0
		var tw: Tween = c.create_tween()
		tw.tween_interval(0.3 + 0.35 * float([a, b, s].find(c)))
		tw.tween_property(c, "modulate:a", 1.0, 1.0)
		if c == a:
			tw.parallel().tween_property(a, "scale", Vector2.ONE, 1.4).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	## Un brillo que recorre el título cada pocos segundos.
	var tb: Tween = a.create_tween().set_loops()
	tb.tween_interval(4.0)
	tb.tween_property(a, "modulate", Color(1.35, 1.25, 1.05), 0.25)
	tb.tween_property(a, "modulate", Color.WHITE, 0.6)


func _botones() -> void:
	_vb = VBoxContainer.new()
	_vb.add_theme_constant_override("separation", 10)
	_vb.position = Vector2(110, 920)
	_vb.size = Vector2(500, 320)
	add_child(_vb)
	var tiene: bool = Estado.tiene_partida() or Estado.n("noche") > 1
	var bp: Button = Estilo.boton(Idioma.t("Continuar") if tiene else Idioma.t("Empezar"), true, 96)
	bp.pressed.connect(_continuar)
	_vb.add_child(bp)
	Estilo.pulso(bp)
	if tiene:
		var bn: Button = Estilo.boton(Idioma.t("Nueva partida"))
		bn.pressed.connect(func() -> void:
			Estilo.confirmar(self, Idioma.t("¿Borrar la isla?"), Idioma.t("Se perderán tus héroes, mejoras y noches superadas."), Idioma.t("Borrar"), Idioma.t("Cancelar"), _nueva))
		_vb.add_child(bn)
		var mejor: int = Estado.n("mejor")
		if mejor > 0:
			_vb.add_child(Estilo.etiqueta(Idioma.t("Noche más lejana superada: %d") % mejor, 24, Estilo.NIEBLA))
	var hoy: int = Save.today()
	if Save.daily_pending(hoy) > 0:
		var bd: Button = Estilo.boton(Idioma.t("Barril a la deriva (regalo diario)"))
		bd.add_theme_font_size_override("font_size", 25)
		bd.pressed.connect(func() -> void: _barril(bd, hoy))
		_vb.add_child(bd)
	_aviso = Estilo.etiqueta("", 26, Estilo.ORO)
	_vb.add_child(_aviso)
	for i: int in _vb.get_child_count():
		var c: Control = _vb.get_child(i) as Control
		UI.pop_in(c, 0.5 + 0.12 * i)


func _barril(b: Button, hoy: int) -> void:
	Save.claim_daily(hoy)
	Estado.d["aceite"] = Estado.n("aceite") + 4
	Estado.guardar()
	Audio.play("coin")
	_aviso.text = Idioma.t("El mar te deja 4 de aceite.")
	b.queue_free()


func _continuar() -> void:
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)


func _nueva() -> void:
	Estado.nuevo()
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)

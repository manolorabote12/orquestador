extends Control
## Titulo: la isla, el faro y el comienzo de la partida.

const ISLA: String = "res://libre/isla.tscn"

var _vb: VBoxContainer
var _aviso: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Audio.play_track("menu")
	Estilo.fondo_cubrir(self, "bg_isla", 1.07)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.03, 0.05, 0.1, 0.38)
	vel.size = Vector2(720, 1280)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	_niebla()
	_titulo()
	_botones()


func _niebla() -> void:
	var cap: Control = Control.new()
	cap.size = Vector2(720, 1280)
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cap.clip_contents = true
	add_child(cap)
	for i: int in 5:
		var t: TextureRect = TextureRect.new()
		t.texture = Juice.dot_texture()
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.size = Vector2(620, 260)
		t.position = Vector2(-300 + i * 160, 380 + i * 150)
		t.modulate = Color(0.85, 0.92, 0.95, 0.16)
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cap.add_child(t)
		var dx: float = 140.0 if i % 2 == 0 else -140.0
		var tw: Tween = t.create_tween().set_loops()
		tw.tween_property(t, "position:x", t.position.x + dx, 9.0 + i).set_trans(Tween.TRANS_SINE)
		tw.tween_property(t, "position:x", t.position.x, 9.0 + i).set_trans(Tween.TRANS_SINE)


func _titulo() -> void:
	var a: Label = Estilo.etiqueta("El Farero", 108, Estilo.ORO)
	a.add_theme_constant_override("outline_size", 14)
	a.position = Vector2(0, 70)
	a.size = Vector2(720, 130)
	add_child(a)
	var b: Label = Estilo.etiqueta("de la Niebla", 66, Estilo.TEXTO)
	b.position = Vector2(0, 190)
	b.size = Vector2(720, 90)
	add_child(b)
	var s: Label = Estilo.etiqueta("Un faro. Una isla perdida.\nTodo lo que la niebla trae.", 28, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	s.position = Vector2(60, 290)
	s.size = Vector2(600, 90)
	add_child(s)
	for c: Control in [a, b, s]:
		c.modulate.a = 0.0
		var tw: Tween = c.create_tween()
		tw.tween_interval(0.15 * float([a, b, s].find(c)))
		tw.tween_property(c, "modulate:a", 1.0, 0.8)


func _botones() -> void:
	_vb = VBoxContainer.new()
	_vb.add_theme_constant_override("separation", 16)
	_vb.position = Vector2(100, 840)
	_vb.size = Vector2(520, 380)
	add_child(_vb)
	var tiene: bool = Estado.tiene_partida() or Estado.n("noche") > 1
	var bp: Button = Estilo.boton("Continuar" if tiene else "Empezar", true, 104)
	bp.pressed.connect(_continuar)
	_vb.add_child(bp)
	Estilo.pulso(bp)
	if tiene:
		var bn: Button = Estilo.boton("Nueva partida")
		bn.pressed.connect(func() -> void:
			Estilo.confirmar(self, "¿Borrar la isla?", "Se perderán tus héroes, mejoras y noches superadas.", "Borrar", "Cancelar", _nueva))
		_vb.add_child(bn)
		var mejor: int = Estado.n("mejor")
		if mejor > 0:
			_vb.add_child(Estilo.etiqueta("Noche más lejana superada: %d" % mejor, 24, Estilo.NIEBLA))
	var hoy: int = Save.today()
	if Save.daily_pending(hoy) > 0:
		var bd: Button = Estilo.boton("Barril a la deriva (regalo diario)")
		bd.add_theme_font_size_override("font_size", 25)
		bd.pressed.connect(func() -> void: _barril(bd, hoy))
		_vb.add_child(bd)
	_aviso = Estilo.etiqueta("", 26, Estilo.ORO)
	_vb.add_child(_aviso)
	for i: int in _vb.get_child_count():
		var c: Control = _vb.get_child(i) as Control
		UI.pop_in(c, 0.5 + 0.12 * i)


func _barril(b: Button, hoy: int) -> void:
	Save.claim_daily(hoy)
	Estado.d["aceite"] = Estado.n("aceite") + 4
	Estado.guardar()
	Audio.play("coin")
	_aviso.text = "El mar te deja 4 de aceite."
	b.queue_free()


func _continuar() -> void:
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)


func _nueva() -> void:
	Estado.nuevo()
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)

extends Control
## Titulo: la isla, el faro y el comienzo de la partida.

const ISLA: String = "res://libre/isla.tscn"

var _vb: VBoxContainer
var _aviso: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Audio.play_track("menu")
	Historia.sonidos()
	var bg: TextureRect = Estilo.fondo_cubrir(self, "bg_titulo" if Estilo.tex("bg_titulo") != null else "bg_isla", 1.0)
	## Respira despacio: la cámara se acerca a la isla.
	bg.create_tween().set_loops().tween_property(bg, "scale", Vector2(1.04, 1.04), 9.0).set_trans(Tween.TRANS_SINE)
	_haz()
	_niebla()
	_lluvia()
	_titulo()
	_botones()
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 72)
	ba.position = Vector2(544, 22)
	ba.size = Vector2(160, 72)
	ba.add_theme_font_size_override("font_size", 20)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	add_child(ba)


## El haz del faro: gira (de perfil se ve ir y volver) y destella cuando apunta a la cámara.
const LAMPARA: Vector2 = Vector2(404, 607)


var _conos: Array[Polygon2D] = []
var _brillo: TextureRect
var _giro: float = 0.0
var _t_ola: float = 1.5


## Dos haces opuestos que dan la vuelta entera a la lámpara: de perfil se alargan y se acortan, y cuando
## uno apunta a la cámara se ensancha y la lámpara destella.
func _haz() -> void:
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	for k: int in 2:
		var cono: Polygon2D = Polygon2D.new()
		cono.position = LAMPARA
		cono.material = mat
		add_child(cono)
		_conos.append(cono)
	_brillo = TextureRect.new()
	_brillo.texture = Juice.dot_texture()
	_brillo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_brillo.size = Vector2(150, 150)
	_brillo.position = LAMPARA - Vector2(75, 75)
	_brillo.pivot_offset = Vector2(75, 75)
	_brillo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_brillo.material = mat
	add_child(_brillo)
	_mar()
	var amb: AudioStreamOggVorbis = load("res://assets/libre/olas_bucle.ogg") as AudioStreamOggVorbis
	if amb != null:
		amb.loop = true
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		p.stream = amb
		p.volume_db = -13.0 + linear_to_db(maxf(0.01, float(Save.get_setting("sfx", 1.0))))
		add_child(p)
		p.play()


func _process(delta: float) -> void:
	if _conos.is_empty():
		return
	_giro = fmod(_giro + delta * TAU / 7.0, TAU)
	var frente: float = 0.0
	for k: int in 2:
		var phi: float = _giro + PI * k
		var lx: float = 780.0 * cos(phi)
		var hacia: float = sin(phi)
		frente = maxf(frente, hacia)
		var w: float = 70.0 + 170.0 * maxf(0.0, hacia)
		var a0: float = 0.5 * (0.35 + 0.65 * absf(cos(phi))) + 0.25 * maxf(0.0, hacia)
		if hacia < 0.0:
			a0 *= 0.55
		var c: Color = Color(1, 0.86, 0.5, a0)
		var c0: Color = Color(1, 0.86, 0.5, 0.0)
		_conos[k].polygon = PackedVector2Array([Vector2(0, -6), Vector2(lx, -w), Vector2(lx, w), Vector2(0, 6)])
		_conos[k].vertex_colors = PackedColorArray([c, c0, c0, c])
	var f: float = pow(frente, 6.0)
	_brillo.scale = Vector2.ONE * (1.0 + 1.3 * f)
	_brillo.modulate = Color(1, 0.85, 0.5, 0.55 + 0.45 * f)
	## Rompientes contra las rocas de la isla, con su golpe de mar.
	_t_ola -= delta
	if _t_ola <= 0.0:
		_t_ola = randf_range(2.2, 4.2)
		_rompiente(Vector2([150.0, 600.0, 300.0, 520.0][randi() % 4], randf_range(990.0, 1010.0)))


## El mar pintado se mueve: el fondo se ondula bajo una capa con espuma que corre.
func _mar() -> void:
	var r: ColorRect = ColorRect.new()
	var alto: float = get_viewport_rect().size.y
	r.position = Vector2(0, alto * 0.75)
	r.size = Vector2(720, alto * 0.25 + 4.0)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh: Shader = Shader.new()
	sh.code = """shader_type canvas_item;
uniform sampler2D pantalla : hint_screen_texture, filter_linear;
void fragment() {
	vec2 uv = SCREEN_UV;
	float y = UV.y;
	float o = sin(UV.x * 18.0 + TIME * 1.3 + y * 9.0) * 0.004 + sin(UV.x * 7.0 - TIME * 0.9) * 0.003;
	uv.x += o * (0.3 + y);
	uv.y += sin(UV.x * 11.0 + TIME * 1.7) * 0.0025 * (0.4 + y);
	vec3 c = texture(pantalla, uv).rgb;
	float espuma = smoothstep(0.82, 1.0, sin(UV.x * 23.0 - TIME * 2.1 + sin(y * 14.0 + TIME) * 2.0) * 0.5 + 0.5) * smoothstep(0.0, 0.3, y);
	c += vec3(0.55, 0.62, 0.66) * espuma * 0.12;
	COLOR = vec4(c, smoothstep(0.0, 0.08, y));
}"""
	var m: ShaderMaterial = ShaderMaterial.new()
	m.shader = sh
	r.material = m
	add_child(r)


func _rompiente(pos: Vector2) -> void:
	var p: CPUParticles2D = CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.amount = 46
	p.lifetime = 1.3
	p.explosiveness = 0.85
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(50, 6)
	p.direction = Vector2(0, -1)
	p.spread = 28.0
	p.gravity = Vector2(0, 520)
	p.initial_velocity_min = 200.0
	p.initial_velocity_max = 420.0
	p.scale_amount_min = 3.0
	p.scale_amount_max = 7.0
	var g: Gradient = Gradient.new()
	g.set_color(0, Color(0.92, 0.96, 1.0, 0.75))
	g.set_color(1, Color(0.85, 0.92, 1.0, 0.0))
	p.color_ramp = g
	add_child(p)
	p.emitting = true
	Audio.play("olas", 0.1, -12.0)
	get_tree().create_timer(1.6).timeout.connect(p.queue_free)


func _niebla() -> void:
	var cap: Control = Control.new()
	cap.size = get_viewport_rect().size
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cap.clip_contents = true
	add_child(cap)
	for i: int in 6:
		var t: TextureRect = TextureRect.new()
		t.texture = Juice.dot_texture()
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.size = Vector2(700, 240)
		t.position = Vector2(-320 + i * 150, 560 + i * 110)
		t.modulate = Color(0.8, 0.88, 0.92, 0.13)
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cap.add_child(t)
		var dx: float = 160.0 if i % 2 == 0 else -160.0
		var tw: Tween = t.create_tween().set_loops()
		tw.tween_property(t, "position:x", t.position.x + dx, 8.0 + i).set_trans(Tween.TRANS_SINE)
		tw.tween_property(t, "position:x", t.position.x, 8.0 + i).set_trans(Tween.TRANS_SINE)


func _lluvia() -> void:
	var p: CPUParticles2D = CPUParticles2D.new()
	p.position = Vector2(360, -20)
	p.amount = 90
	p.lifetime = 1.4
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(420, 10)
	p.direction = Vector2(-0.25, 1)
	p.spread = 3.0
	p.gravity = Vector2(0, 0)
	p.initial_velocity_min = 900.0
	p.initial_velocity_max = 1200.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	p.color = Color(0.75, 0.82, 0.9, 0.22)
	add_child(p)


func _titulo() -> void:
	var a: Label = Estilo.etiqueta(Idioma.t("El Farero"), 112, Estilo.ORO)
	a.add_theme_constant_override("outline_size", 18)
	a.add_theme_color_override("font_outline_color", Color(0.05, 0.04, 0.02, 0.9))
	a.add_theme_color_override("font_shadow_color", Color(1, 0.75, 0.3, 0.45))
	a.add_theme_constant_override("shadow_offset_x", 0)
	a.add_theme_constant_override("shadow_offset_y", 0)
	a.add_theme_constant_override("shadow_outline_size", 34)
	a.position = Vector2(0, 90)
	a.size = Vector2(720, 140)
	a.pivot_offset = Vector2(360, 70)
	add_child(a)
	var b: Label = Estilo.etiqueta(Idioma.t("de la Niebla"), 62, Estilo.TEXTO)
	b.add_theme_constant_override("outline_size", 12)
	b.position = Vector2(0, 216)
	b.size = Vector2(720, 90)
	add_child(b)
	var s: Label = Estilo.etiqueta(Idioma.t("Un faro. Una isla perdida.\nTodo lo que la niebla trae."), 27, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	s.position = Vector2(60, 312)
	s.size = Vector2(600, 90)
	add_child(s)
	a.scale = Vector2(1.25, 1.25)
	for c: Control in [a, b, s]:
		c.modulate.a = 0.0
		var tw: Tween = c.create_tween()
		tw.tween_interval(0.3 + 0.35 * float([a, b, s].find(c)))
		tw.tween_property(c, "modulate:a", 1.0, 1.0)
		if c == a:
			tw.parallel().tween_property(a, "scale", Vector2.ONE, 1.4).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	## Un brillo que recorre el título cada pocos segundos.
	var tb: Tween = a.create_tween().set_loops()
	tb.tween_interval(4.0)
	tb.tween_property(a, "modulate", Color(1.35, 1.25, 1.05), 0.25)
	tb.tween_property(a, "modulate", Color.WHITE, 0.6)


func _botones() -> void:
	_vb = VBoxContainer.new()
	_vb.add_theme_constant_override("separation", 10)
	_vb.position = Vector2(110, 920)
	_vb.size = Vector2(500, 320)
	add_child(_vb)
	var tiene: bool = Estado.tiene_partida() or Estado.n("noche") > 1
	var bp: Button = Estilo.boton(Idioma.t("Continuar") if tiene else Idioma.t("Empezar"), true, 96)
	bp.pressed.connect(_continuar)
	_vb.add_child(bp)
	Estilo.pulso(bp)
	if tiene:
		var bn: Button = Estilo.boton(Idioma.t("Nueva partida"))
		bn.pressed.connect(func() -> void:
			Estilo.confirmar(self, Idioma.t("¿Borrar la isla?"), Idioma.t("Se perderán tus héroes, mejoras y noches superadas."), Idioma.t("Borrar"), Idioma.t("Cancelar"), _nueva))
		_vb.add_child(bn)
		var mejor: int = Estado.n("mejor")
		if mejor > 0:
			_vb.add_child(Estilo.etiqueta(Idioma.t("Noche más lejana superada: %d") % mejor, 24, Estilo.NIEBLA))
	var hoy: int = Save.today()
	if Save.daily_pending(hoy) > 0:
		var bd: Button = Estilo.boton(Idioma.t("Barril a la deriva (regalo diario)"))
		bd.add_theme_font_size_override("font_size", 25)
		bd.pressed.connect(func() -> void: _barril(bd, hoy))
		_vb.add_child(bd)
	_aviso = Estilo.etiqueta("", 26, Estilo.ORO)
	_vb.add_child(_aviso)
	for i: int in _vb.get_child_count():
		var c: Control = _vb.get_child(i) as Control
		UI.pop_in(c, 0.5 + 0.12 * i)


func _barril(b: Button, hoy: int) -> void:
	Save.claim_daily(hoy)
	Estado.d["aceite"] = Estado.n("aceite") + 4
	Estado.guardar()
	Audio.play("coin")
	_aviso.text = Idioma.t("El mar te deja 4 de aceite.")
	b.queue_free()


func _continuar() -> void:
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)


func _nueva() -> void:
	Estado.nuevo()
	Estado.d["empezada"] = true
	Estado.guardar()
	Kit.change_scene(ISLA)

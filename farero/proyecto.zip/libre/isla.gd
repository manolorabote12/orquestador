extends Control
## El día: explorar la isla, preparar a los héroes, levantar el faro planta a planta y encender la luz.
## Desde aquí también se abren las mareas (campaña) y los modos: Niebla eterna, Cacerías y Reto del día.

const NOCHE: String = "res://libre/noche.tscn"
const TITULO: String = "res://libre/main.tscn"
const HEROES_ESC: String = "res://libre/heroes.tscn"
const FARO_ESC: String = "res://libre/faro.tscn"

var _chips: Dictionary = {}
var _lbl_dia: Label
var _lbl_marea: Label
var _horas: Pips
var _barra_faro: ProgressBar
var _lbl_faro: Label
var _lbl_luz: Label
var _lbl_diario: Label
var _btn_explorar: Button
var _btn_encender: Button
var _btn_heroes: Button
var _modal: Dictionary = {}
var _pulso: Tween = null


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estado.partida = {"modo": "campana"}
	Estado.d["empezada"] = true
	Audio.play_track("dia")
	Estilo.fondo_cubrir(self, "bg_isla", 1.07)
	_gaviotas()
	_hud()
	_diario()
	_botones()
	if str(Estado.d.get("diario", "")) == "":
		Estado.d["diario"] = Idioma.t("Anoche el mar te devolvió a un capitán medio ahogado. El faro necesita aceite, madera y hierro. Explora mientras quede luz del día.")
	_lbl_diario.text = str(Estado.d["diario"])
	Estado.cobrar_monedero()
	if not Store.purchased.is_connected(_comprado):
		Store.purchased.connect(_comprado)
	_refrescar()
	if not Estado.campana_terminada() and Estado.n("visto_marea") < Estado.marea():
		_intro_marea.call_deferred()
	_consejos.call_deferred()


func _consejos() -> void:
	await get_tree().create_timer(0.4).timeout
	if not _modal.is_empty():
		return
	if not Consejo.mostrar(self, "isla") and Estado.n("mejor") >= Datos.NOCHES_POR_MAREA:
		Consejo.mostrar(self, "modos")


func _gaviotas() -> void:
	var cap: Control = Control.new()
	cap.size = get_viewport_rect().size
	cap.clip_contents = true
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(cap)
	for i: int in 3:
		var g: Label = Estilo.etiqueta("~v~", 30, Color(0.2, 0.22, 0.28, 0.8))
		g.position = Vector2(-80, 420 + i * 70)
		cap.add_child(g)
		var tw: Tween = g.create_tween().set_loops()
		tw.tween_interval(2.0 + i * 3.0)
		tw.tween_property(g, "position:x", 800.0, 16.0 + i * 3.0)
		tw.tween_callback(func() -> void: g.position.x = -80.0)


func _hud() -> void:
	var p: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82))
	p.position = Vector2(16, 20)
	p.size = Vector2(688, 104)
	add_child(p)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 16)
	p.add_child(hb)
	var izq: VBoxContainer = VBoxContainer.new()
	izq.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	izq.add_theme_constant_override("separation", 0)
	hb.add_child(izq)
	_lbl_dia = Estilo.etiqueta(Idioma.t("Día 1"), 34, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT)
	izq.add_child(_lbl_dia)
	_lbl_marea = Estilo.etiqueta("", 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT)
	izq.add_child(_lbl_marea)
	var col: VBoxContainer = VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(col)
	col.add_child(Estilo.etiqueta(Idioma.t("Horas de luz"), 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_RIGHT))
	_horas = Pips.new(Estado.horas_dia(), Estilo.ORO, 14.0)
	col.add_child(_horas)
	var fila: HBoxContainer = HBoxContainer.new()
	fila.position = Vector2(16, 134)
	fila.size = Vector2(688, 64)
	fila.add_theme_constant_override("separation", 6)
	add_child(fila)
	for r: String in Datos.RECURSOS:
		var ch: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82), Color(Datos.COL_RECURSO[r]).darkened(0.3))
		ch.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fila.add_child(ch)
		var h: HBoxContainer = HBoxContainer.new()
		h.add_theme_constant_override("separation", 6)
		h.alignment = BoxContainer.ALIGNMENT_CENTER
		ch.add_child(h)
		var l: Label = Estilo.etiqueta("0", 21, Color(Datos.COL_RECURSO[r]).lightened(0.35))
		h.add_child(l)
		_chips[r] = l
	var pf: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82))
	pf.position = Vector2(16, 208)
	pf.size = Vector2(688, 96)
	add_child(pf)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	pf.add_child(vb)
	_lbl_faro = Estilo.etiqueta("", 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_faro)
	_barra_faro = Estilo.barra(Color("c9ced6"), 16.0)
	vb.add_child(_barra_faro)
	_lbl_luz = Estilo.etiqueta("", 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_luz)


func _diario() -> void:
	var p: PanelContainer = Estilo.panel(Color(0.93, 0.87, 0.72, 0.9), Color(0.45, 0.32, 0.14))
	p.position = Vector2(20, 722)
	p.size = Vector2(680, 150)
	add_child(p)
	_lbl_diario = Estilo.etiqueta("", 25, Color("3a2a16"), HORIZONTAL_ALIGNMENT_LEFT, true)
	_lbl_diario.remove_theme_constant_override("outline_size")
	_lbl_diario.add_theme_constant_override("outline_size", 0)
	_lbl_diario.custom_minimum_size = Vector2(640, 0)
	p.add_child(_lbl_diario)


func _botones() -> void:
	_btn_explorar = _boton(Idioma.t("Explorar la isla"), Vector2(20, 892), Vector2(334, 92), abrir_explorar)
	_btn_heroes = _boton(Idioma.t("Héroes"), Vector2(366, 892), Vector2(334, 92), func() -> void: Kit.change_scene(HEROES_ESC))
	var bf: Button = _boton(Idioma.t("El faro"), Vector2(20, 994), Vector2(218, 92), func() -> void: Kit.change_scene(FARO_ESC))
	var bt: Button = _boton(Idioma.t("Taberna"), Vector2(251, 994), Vector2(218, 92), func() -> void: Kit.change_scene("res://libre/taberna.tscn"))
	bt.disabled = Estado.n("mejor") < 3
	var bm: Button = _boton(Idioma.t("Modos"), Vector2(482, 994), Vector2(218, 92), abrir_mareas)
	_btn_encender = Estilo.boton(Idioma.t("Encender el faro"), true, 108)
	_btn_encender.position = Vector2(20, 1100)
	_btn_encender.size = Vector2(680, 108)
	_btn_encender.pressed.connect(_pedir_encender)
	add_child(_btn_encender)
	for i: int in 6:
		UI.pop_in([_btn_explorar, _btn_heroes, bf, bt, bm, _btn_encender][i] as Control, 0.05 * i)


func _boton(t: String, pos: Vector2, tam: Vector2, f: Callable) -> Button:
	var b: Button = Estilo.boton(t, false, tam.y)
	b.position = pos
	b.size = tam
	b.pressed.connect(f)
	add_child(b)
	return b


func _refrescar() -> void:
	_lbl_dia.text = Idioma.t("Día %d") % Estado.n("dia")
	if Estado.campana_terminada():
		_lbl_marea.text = Idioma.t("Todas las mareas superadas")
	else:
		_lbl_marea.text = Estado.titulo_noche(Estado.n("noche"))
	_horas.poner(Estado.horas_dia(), Estado.n("horas"))
	for r: String in Datos.RECURSOS:
		(_chips[r] as Label).text = Idioma.t("%s %d") % [str(Idioma.t(Datos.NOMBRE_RECURSO[r])), Estado.n(r)]
	var fm: int = Estado.faro_max()
	_barra_faro.max_value = fm
	_barra_faro.value = Estado.n("faro_hp")
	_lbl_faro.text = Idioma.t("Integridad del faro  %d / %d") % [Estado.n("faro_hp"), fm]
	var lz: int = mini(Estado.luz_max(), 2 + Estado.n("aceite"))
	var mod: Dictionary = Estado.d.get("noche_mod", {}) as Dictionary
	var extra: Array[String] = []
	if int(mod.get("luz", 0)) != 0:
		extra.append(Idioma.t("%+d luz") % int(mod["luz"]))
	if bool(mod.get("escudo", false)):
		extra.append("escudo")
	if bool(mod.get("dura", false)):
		extra.append(Idioma.t("noche dura"))
	_lbl_luz.text = Idioma.t("Luz inicial esta noche: %d de %d%s") % [lz, Estado.luz_max(), ("  ·  " + ", ".join(extra)) if not extra.is_empty() else (Idioma.t("  (más aceite = más luz)") if lz < Estado.luz_max() else "")]
	var extra_ok: bool = Estado.n("horas") <= 0 and Estado.n("hora_extra") != Estado.n("dia") and Ads.rewarded_available()
	_btn_explorar.text = Idioma.t("Explorar la isla") if Estado.n("horas") > 0 else (Idioma.t("Anuncio: +1 hora") if extra_ok else Idioma.t("Anochece..."))
	_btn_explorar.disabled = Estado.n("horas") <= 0 and not extra_ok
	var pend: int = 0
	for id: Variant in (Estado.d["heroes"] as Dictionary).keys():
		if not Estado.talento_pendiente(str(id)).is_empty():
			pend += 1
	_btn_heroes.text = Idioma.t("Héroes  ★") if pend > 0 else Idioma.t("Héroes")
	if Estado.campana_terminada():
		_btn_encender.text = Idioma.t("Niebla eterna")
	else:
		var k: int = Estado.noche_en_marea(Estado.n("noche"))
		_btn_encender.text = Idioma.t("Encender · Noche final") if k == Datos.NOCHES_POR_MAREA else Idioma.t("Encender el faro · Noche %d") % k
	if _pulso != null:
		_pulso.kill()
		_pulso = null
	if Estado.n("horas") <= 0:
		_pulso = Estilo.pulso(_btn_encender)
	else:
		_btn_encender.scale = Vector2.ONE


func _cerrar_modal() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func _intro_marea() -> void:
	var m: int = Estado.marea()
	Estado.d["visto_marea"] = m
	Estado.guardar()
	if not _modal.is_empty():
		return
	var dm: Dictionary = Estado.datos_marea(m)
	_modal = Estilo.modal(self, str(Idioma.t(dm["nombre"])), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	if Estilo.tex(str(dm["bg"])) != null:
		var t: TextureRect = Estilo.sprite(str(dm["bg"]), Vector2(560, 300))
		t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		t.clip_contents = true
		vb.add_child(t)
	var l: Label = Estilo.etiqueta(str(Idioma.t(dm["texto"])), 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l)
	vb.add_child(Estilo.etiqueta(Idioma.t("12 noches. Al final, %s.") % str((Estado.ENEMIGOS[str(dm["jefe"])] as Dictionary)["nombre"]).to_lower(), 22, Color(str(dm["color"])), HORIZONTAL_ALIGNMENT_CENTER, true))
	var b: Button = Estilo.boton(Idioma.t("Que venga"), true, 92)
	b.pressed.connect(_cerrar_modal)
	vb.add_child(b)


# ---------------- Explorar ----------------
func abrir_explorar() -> void:
	if not _modal.is_empty():
		return
	if Estado.n("horas") <= 0:
		_hora_extra()
		return
	_modal = Estilo.modal(self, Idioma.t("¿Adónde vas?"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Cada salida gasta una hora de luz."), 24, Estilo.NIEBLA))
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(600, 640)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lista.add_theme_constant_override("separation", 8)
	sc.add_child(lista)
	var ls: Array = Estado.lugares()
	for i: int in ls.size():
		var lug: Dictionary = ls[i] as Dictionary
		var b: Button = Estilo.boton("%s\n%s" % [Idioma.t(lug["nombre"]), Idioma.t(lug["desc"])], false, 104)
		b.add_theme_font_size_override("font_size", 22)
		var idx: int = i
		b.pressed.connect(func() -> void: explorar(idx))
		lista.add_child(b)
	if Estado.marea() < Datos.MAREAS.size():
		lista.add_child(Estilo.etiqueta(Idioma.t("Cada marea nueva abre otros lugares de la isla."), 20, Estilo.NIEBLA))
	var bc: Button = Estilo.boton(Idioma.t("Volver"))
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)


func explorar(i: int) -> void:
	var r: Dictionary = Estado.explorar(i)
	_cerrar_modal()
	if r.is_empty():
		return
	var partes: Array[String] = []
	var botin: Dictionary = r["botin"] as Dictionary
	var y: float = 500.0
	for k: Variant in botin.keys():
		var rec: String = str(k)
		partes.append(Idioma.t("+%d %s") % [int(botin[k]), str(Idioma.t(Datos.NOMBRE_RECURSO[rec])).to_lower()])
		UI.float_text(self, Vector2(250, y), Idioma.t("+%d %s") % [int(botin[k]), Idioma.t(Datos.NOMBRE_RECURSO[rec])], Color(Datos.COL_RECURSO[rec]), 40)
		y += 54.0
	_lbl_diario.text = "%s\n%s" % [str(Idioma.t(r["texto"])), Idioma.t("Recoges: ") + (", ".join(partes) if not partes.is_empty() else "nada")]
	var rel: String = str(r.get("reliquia", ""))
	if rel != "":
		_lbl_diario.text += Idioma.t("\n¡Encuentras una reliquia: %s!") % str(Idioma.t((Datos.RELIQUIAS[rel] as Dictionary)["nombre"]))
		Audio.play("powerup")
	Audio.play("coin")
	Juice.vibrate(20)
	if Estado.n("horas") <= 0:
		_lbl_diario.text += Idioma.t("\nLa luz se apaga. Es hora de encender el faro.")
	_refrescar()
	var si: int = Estado.suceso_al_explorar()
	if si >= 0:
		abrir_suceso(si)


## Un suceso con decisiones: cada opción puede salir bien o mal.
func abrir_suceso(si: int) -> void:
	if not _modal.is_empty():
		_cerrar_modal()
	var s: Dictionary = Datos.SUCESOS[si] as Dictionary
	if not Consejo.visto("suceso"):
		Consejo.mostrar(self, "suceso")
		await get_tree().create_timer(0.1).timeout
		var w: int = 0
		while not Consejo._abierto.is_empty() and is_instance_valid(Consejo._abierto.get("capa")) and w < 300:
			w += 1
			await get_tree().create_timer(0.2).timeout
	_modal = Estilo.modal(self, str(Idioma.t(s["titulo"])), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var l: Label = Estilo.etiqueta(str(Idioma.t(s["texto"])), 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(580, 0)
	vb.add_child(l)
	var ops: Array = s["opciones"] as Array
	for oi: int in ops.size():
		var op: Dictionary = ops[oi] as Dictionary
		var c: Dictionary = Estado.coste_opcion(op)
		var arriesgada: bool = (op["r"] as Array).size() > 1
		var txt: String = str(Idioma.t(op["t"]))
		if not c.is_empty():
			txt += Idioma.t("\n(cuesta %s)") % Estado.texto_coste(c)
		elif arriesgada:
			txt += Idioma.t("\n(puede salir mal)")
		var b: Button = Estilo.boton(txt, oi == 0, 96)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.add_theme_font_size_override("font_size", 22)
		b.disabled = not Estado.puede_pagar(c)
		var idx: int = oi
		b.pressed.connect(func() -> void: _decidir(si, idx))
		vb.add_child(b)


func _decidir(si: int, oi: int) -> void:
	var r: Dictionary = Estado.resolver_suceso(si, oi)
	_cerrar_modal()
	_modal = Estilo.modal(self, str(Idioma.t((Datos.SUCESOS[si] as Dictionary)["titulo"])), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var l: Label = Estilo.etiqueta(str(Idioma.t(r["texto"])), 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l)
	var hecho: Array = r["hecho"] as Array
	if not hecho.is_empty():
		var h: Label = Estilo.etiqueta(" · ".join(hecho), 22, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, true)
		h.custom_minimum_size = Vector2(560, 0)
		vb.add_child(h)
	Audio.play("powerup" if not str(hecho).contains("-") else "hurt")
	var b: Button = Estilo.boton(Idioma.t("Seguir"), true, 88)
	b.pressed.connect(func() -> void:
		_cerrar_modal()
		_refrescar())
	vb.add_child(b)
	_lbl_diario.text = str(Idioma.t(r["texto"]))
	_refrescar()


## Anuncio voluntario: una hora más de luz (una vez al día).
func _hora_extra() -> void:
	_btn_explorar.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "hora_extra":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("hora_extra")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		Estado.d["hora_extra"] = Estado.n("dia")
		Estado.d["horas"] = 1
		Estado.guardar()
		Audio.play("powerup")
		_lbl_diario.text = Idioma.t("El sol se queda un poco más sobre la isla.")
	_refrescar()


# ---------------- Mareas y modos ----------------
func abrir_mareas() -> void:
	if not _modal.is_empty():
		return
	_modal = Estilo.modal(self, Idioma.t("Mareas y modos"), 660.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(620, 780)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lista.add_theme_constant_override("separation", 10)
	sc.add_child(lista)
	var g: int = Estado.n("noche")
	for i: int in Datos.MAREAS.size():
		var dm: Dictionary = Datos.MAREAS[i] as Dictionary
		var desde: int = i * Datos.NOCHES_POR_MAREA + 1
		var hechas: int = clampi(g - desde, 0, Datos.NOCHES_POR_MAREA)
		var txt: String = Idioma.t("%s · %d/12") % [Idioma.t(dm["nombre"]), hechas]
		if g < desde:
			txt = Idioma.t("%s · por descubrir") % Idioma.t(dm["nombre"])
		var l: Label = Estilo.etiqueta(txt, 25, Color(str(dm["color"])) if g >= desde else Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT)
		lista.add_child(l)
		var bar: ProgressBar = Estilo.barra(Color(str(dm["color"])), 12.0)
		bar.max_value = 12
		bar.value = hechas
		lista.add_child(bar)
	lista.add_child(Estilo.etiqueta(Idioma.t("Modos"), 30, Estilo.ORO))
	var abierta: bool = Estado.n("mejor") >= Datos.NOCHES_POR_MAREA
	var be: Button = Estilo.boton(Idioma.t("Niebla eterna\nOleadas sin fin · récord %d") % Estado.n("eterna_mejor") if abierta else Idioma.t("Niebla eterna\nSe abre al superar la Marea de Niebla"), false, 104)
	be.add_theme_font_size_override("font_size", 22)
	be.disabled = not abierta
	be.pressed.connect(func() -> void: _jugar({"modo": "eterna"}))
	lista.add_child(be)
	var ar: bool = Estado.arena_abierta()
	var bar: Button = Estilo.boton(Idioma.t("Arena de los Fareros\nAsalta faros rivales") if ar else Idioma.t("Arena de los Fareros\nSe abre al superar la noche 6"), true, 104)
	bar.add_theme_font_size_override("font_size", 22)
	bar.disabled = not ar
	bar.pressed.connect(func() -> void: Kit.change_scene("res://libre/arena.tscn"))
	lista.add_child(bar)
	var rt: Dictionary = Estado.reto_de_hoy()
	var hecho: bool = Estado.n("reto_dia") == Estado.dia_de_hoy()
	var br: Button = Estilo.boton(Idioma.t("Reto del día: %s\n%s%s") % [Idioma.t(rt["nombre"]), Idioma.t(rt["desc"]), Idioma.t("  (hecho)") if hecho else ""], false, 112)
	br.add_theme_font_size_override("font_size", 21)
	br.disabled = Estado.n("mejor") < 4
	br.pressed.connect(func() -> void: _jugar({"modo": "reto", "reto": str(rt["id"])}))
	lista.add_child(br)
	var jefes: Array = Estado.d["jefes"] as Array
	if jefes.is_empty():
		lista.add_child(Estilo.etiqueta(Idioma.t("Cacerías: derrota al jefe de una marea para poder volver a cazarlo."), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for j: Variant in jefes:
		var jid: String = str(j)
		var rango: int = int((Estado.d["caceria"] as Dictionary).get(jid, 0)) + 1
		var bj: Button = Estilo.boton(Idioma.t("Cacería: %s\nRango %d de 10") % [Idioma.t((Estado.ENEMIGOS[jid] as Dictionary)["nombre"]), mini(rango, 10)], false, 104)
		bj.add_theme_font_size_override("font_size", 22)
		bj.pressed.connect(func() -> void: _jugar({"modo": "caceria", "jefe": jid, "rango": mini(rango, 10)}))
		lista.add_child(bj)
	if Store.available() or Store.showcase():
		var bs: Button = Estilo.boton(Idioma.t("Tienda"), true, 80)
		bs.pressed.connect(func() -> void:
			_cerrar_modal()
			abrir_tienda())
		lista.add_child(bs)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 80)
	ba.pressed.connect(func() -> void:
		_cerrar_modal()
		Consejo.ajustes(self))
	lista.add_child(ba)
	var bt: Button = Estilo.boton(Idioma.t("Volver al inicio"), false, 80)
	bt.pressed.connect(func() -> void: Kit.change_scene(TITULO))
	lista.add_child(bt)
	var bc: Button = Estilo.boton(Idioma.t("Volver"))
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)


func _jugar(p: Dictionary) -> void:
	Estado.partida = p
	Audio.play("powerup")
	Kit.change_scene(NOCHE)


# ---------------- Tienda ----------------
func _comprado(_id: String) -> void:
	var w: int = Estado.cobrar_monedero()
	Audio.play("coin")
	_lbl_diario.text = Idioma.t("¡Gracias! +%d ámbar.") % w if w > 0 else Idioma.t("¡Gracias por tu compra!")
	_refrescar()


func abrir_tienda() -> void:
	if not _modal.is_empty():
		return
	_modal = Estilo.modal(self, Idioma.t("Tienda"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("El ámbar sirve para la taberna, las estrellas y las mejoras grandes del faro."), 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var ps: Dictionary = Store.products()
	for id: Variant in ps.keys():
		var pid: String = str(id)
		if str((ps[pid] as Dictionary).get("kind", "")) in ["pass", "vip"]:
			continue
		if Store.owns(pid) or (str((ps[pid] as Dictionary)["kind"]) in ["no_ads", "bundle"] and Store.no_ads()):
			continue
		var b: Button = Estilo.boton("%s\n%s" % [Idioma.t(Store.label(pid)), Store.price(pid)], false, 92)
		b.add_theme_font_size_override("font_size", 21)
		b.pressed.connect(func() -> void: Store.buy(pid))
		vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)


# ---------------- Noche ----------------
func _pedir_encender() -> void:
	if not _modal.is_empty():
		return
	if Estado.campana_terminada():
		_jugar({"modo": "eterna"})
		return
	if Estado.n("horas") > 0:
		Estilo.confirmar(self, Idioma.t("¿Encender ya?"), Idioma.t("Todavía te quedan %d horas de luz para explorar.") % Estado.n("horas"), Idioma.t("Encender"), Idioma.t("Esperar"), encender)
	else:
		encender()


func encender() -> void:
	var lz: int = mini(Estado.luz_max(), 2 + Estado.n("aceite"))
	Estado.d["aceite"] = Estado.n("aceite") - (lz - 2)
	Estado.d["luz_inicial"] = lz
	Estado.partida = {"modo": "campana"}
	Estado.guardar()
	Audio.play("powerup")
	Kit.change_scene(NOCHE)

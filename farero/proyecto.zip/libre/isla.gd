extends Control
## El dia: explorar la isla, reparar el faro, preparar a los heroes y encender la luz.

const NOCHE: String = "res://libre/noche.tscn"
const TITULO: String = "res://libre/main.tscn"
const COL_RECURSO: Dictionary = {"aceite": "#e8b857", "madera": "#a8764a", "hierro": "#8fa6bd"}
const NOMBRE_RECURSO: Dictionary = {"aceite": "Aceite", "madera": "Madera", "hierro": "Hierro"}

var _chips: Dictionary = {}
var _lbl_dia: Label
var _horas: Pips
var _barra_faro: ProgressBar
var _lbl_faro: Label
var _lbl_luz: Label
var _lbl_diario: Label
var _btn_explorar: Button
var _btn_encender: Button
var _modal: Dictionary = {}
var _lista: VBoxContainer = null
var _pulso: Tween = null


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estado.d["empezada"] = true
	Audio.play_track("menu")
	Estilo.fondo_cubrir(self, "bg_isla", 1.07)
	_gaviotas()
	_hud()
	_diario()
	_botones()
	if str(Estado.d.get("diario", "")) == "":
		Estado.d["diario"] = "Anoche el mar te devolvió a un capitán medio ahogado. El faro necesita aceite, madera y hierro. Explora mientras quede luz del día."
	_lbl_diario.text = str(Estado.d["diario"])
	_refrescar()


func _gaviotas() -> void:
	var cap: Control = Control.new()
	cap.size = Vector2(720, 1280)
	cap.clip_contents = true
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(cap)
	for i: int in 3:
		var g: Label = Estilo.etiqueta("~v~", 30, Color(0.2, 0.22, 0.28, 0.8))
		g.position = Vector2(-80, 420 + i * 70)
		cap.add_child(g)
		var tw: Tween = g.create_tween().set_loops()
		tw.tween_interval(2.0 + i * 3.0)
		tw.tween_property(g, "position:x", 800.0, 16.0 + i * 3.0)
		tw.tween_callback(func() -> void: g.position.x = -80.0)


func _hud() -> void:
	var p: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82))
	p.position = Vector2(16, 20)
	p.size = Vector2(688, 100)
	add_child(p)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	p.add_child(hb)
	_lbl_dia = Estilo.etiqueta("Día 1", 40, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT)
	_lbl_dia.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(_lbl_dia)
	var col: VBoxContainer = VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(col)
	col.add_child(Estilo.etiqueta("Horas de luz", 20, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_RIGHT))
	_horas = Pips.new(Estado.HORAS_DIA, Estilo.ORO, 15.0)
	col.add_child(_horas)
	# recursos
	var fila: HBoxContainer = HBoxContainer.new()
	fila.position = Vector2(16, 130)
	fila.size = Vector2(688, 70)
	fila.add_theme_constant_override("separation", 10)
	add_child(fila)
	for r: String in Estado.RECURSOS:
		var ch: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82), Color(COL_RECURSO[r]).darkened(0.3))
		ch.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fila.add_child(ch)
		var h: HBoxContainer = HBoxContainer.new()
		h.add_theme_constant_override("separation", 10)
		h.alignment = BoxContainer.ALIGNMENT_CENTER
		ch.add_child(h)
		var dot: Pips = Pips.new(1, Color(COL_RECURSO[r]), 11.0)
		h.add_child(dot)
		var l: Label = Estilo.etiqueta("%s 0" % NOMBRE_RECURSO[r], 25, Estilo.TEXTO)
		h.add_child(l)
		_chips[r] = l
	# faro
	var pf: PanelContainer = Estilo.panel(Color(0.06, 0.08, 0.13, 0.82))
	pf.position = Vector2(16, 210)
	pf.size = Vector2(688, 96)
	add_child(pf)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	pf.add_child(vb)
	_lbl_faro = Estilo.etiqueta("Faro 32/32", 24, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_faro)
	_barra_faro = Estilo.barra(Color("c9ced6"), 16.0)
	vb.add_child(_barra_faro)
	_lbl_luz = Estilo.etiqueta("", 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(_lbl_luz)


func _diario() -> void:
	var p: PanelContainer = Estilo.panel(Color(0.93, 0.87, 0.72, 0.9), Color(0.45, 0.32, 0.14))
	p.position = Vector2(20, 722)
	p.size = Vector2(680, 150)
	add_child(p)
	_lbl_diario = Estilo.etiqueta("", 25, Color("3a2a16"), HORIZONTAL_ALIGNMENT_LEFT, true)
	_lbl_diario.remove_theme_constant_override("outline_size")
	_lbl_diario.add_theme_constant_override("outline_size", 0)
	_lbl_diario.custom_minimum_size = Vector2(640, 0)
	p.add_child(_lbl_diario)


func _botones() -> void:
	_btn_explorar = Estilo.boton("Explorar la isla", false, 96)
	_btn_explorar.position = Vector2(20, 892)
	_btn_explorar.size = Vector2(334, 96)
	_btn_explorar.pressed.connect(abrir_explorar)
	add_child(_btn_explorar)
	var bh: Button = Estilo.boton("Héroes", false, 96)
	bh.position = Vector2(366, 892)
	bh.size = Vector2(334, 96)
	bh.pressed.connect(abrir_heroes)
	add_child(bh)
	var bf: Button = Estilo.boton("El faro", false, 88)
	bf.position = Vector2(20, 998)
	bf.size = Vector2(334, 88)
	bf.pressed.connect(abrir_faro)
	add_child(bf)
	var bt: Button = Estilo.boton("Volver al inicio", false, 88)
	bt.position = Vector2(366, 998)
	bt.size = Vector2(334, 88)
	bt.pressed.connect(func() -> void: Kit.change_scene(TITULO))
	add_child(bt)
	_btn_encender = Estilo.boton("Encender el faro · Noche %d" % Estado.n("noche"), true, 108)
	_btn_encender.position = Vector2(20, 1100)
	_btn_encender.size = Vector2(680, 108)
	_btn_encender.pressed.connect(_pedir_encender)
	add_child(_btn_encender)
	for i: int in 5:
		var c: Control = [_btn_explorar, bh, bf, bt, _btn_encender][i] as Control
		UI.pop_in(c, 0.05 * i)


func _refrescar() -> void:
	_lbl_dia.text = "Día %d" % Estado.n("dia")
	_horas.poner(Estado.HORAS_DIA, Estado.n("horas"))
	for r: String in Estado.RECURSOS:
		(_chips[r] as Label).text = "%s %d" % [NOMBRE_RECURSO[r], Estado.n(r)]
	var fm: int = Estado.faro_max()
	_barra_faro.max_value = fm
	_barra_faro.value = Estado.n("faro_hp")
	_lbl_faro.text = "Integridad del faro  %d / %d" % [Estado.n("faro_hp"), fm]
	var lz: int = mini(Estado.luz_max(), 2 + Estado.n("aceite"))
	_lbl_luz.text = "Lente nv %d · Luz inicial esta noche: %d de %d%s" % [Estado.n("lente"), lz, Estado.luz_max(), "  (más aceite = más luz)" if lz < Estado.luz_max() else ""]
	_btn_explorar.text = "Explorar la isla" if Estado.n("horas") > 0 else "Anochece..."
	_btn_explorar.disabled = Estado.n("horas") <= 0
	_btn_encender.text = "Encender el faro · Noche %d" % Estado.n("noche")
	if _pulso != null:
		_pulso.kill()
		_pulso = null
	if Estado.n("horas") <= 0:
		_pulso = Estilo.pulso(_btn_encender)
	else:
		_btn_encender.scale = Vector2.ONE


func _cerrar_modal() -> void:
	Estilo.cerrar(_modal)
	_modal = {}
	_lista = null


# ---------------- Explorar ----------------
func abrir_explorar() -> void:
	if not _modal.is_empty():
		return
	_modal = Estilo.modal(self, "¿Adónde vas?", 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta("Cada salida gasta una hora de luz.", 24, Estilo.NIEBLA))
	for i: int in Estado.LUGARES.size():
		var lug: Dictionary = Estado.LUGARES[i] as Dictionary
		var b: Button = Estilo.boton("%s\n%s" % [lug["nombre"], lug["desc"]], false, 112)
		b.add_theme_font_size_override("font_size", 24)
		var idx: int = i
		b.pressed.connect(func() -> void: explorar(idx))
		vb.add_child(b)
	var bc: Button = Estilo.boton("Volver")
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)


func explorar(i: int) -> void:
	var r: Dictionary = Estado.explorar(i)
	_cerrar_modal()
	if r.is_empty():
		return
	var partes: Array[String] = []
	var botin: Dictionary = r["botin"] as Dictionary
	var y: float = 500.0
	for k: Variant in botin.keys():
		var rec: String = str(k)
		partes.append("+%d %s" % [int(botin[k]), str(NOMBRE_RECURSO[rec]).to_lower()])
		UI.float_text(self, Vector2(250, y), "+%d %s" % [int(botin[k]), NOMBRE_RECURSO[rec]], Color(COL_RECURSO[rec]), 40)
		y += 54.0
	_lbl_diario.text = "%s\n%s" % [str(r["texto"]), "Recoges: " + (", ".join(partes) if not partes.is_empty() else "nada")]
	Audio.play("coin")
	Juice.vibrate(20)
	if Estado.n("horas") <= 0:
		_lbl_diario.text += "\nLa luz se apaga. Es hora de encender el faro."
	_refrescar()


# ---------------- Heroes ----------------
func abrir_heroes() -> void:
	if not _modal.is_empty():
		return
	_modal = Estilo.modal(self, "Los náufragos", 664.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta("Elige hasta %d en guardia. La niebla trae uno nuevo cada noche." % Estado.GUARDIA_MAX, 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(620, 700)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	_lista = VBoxContainer.new()
	_lista.add_theme_constant_override("separation", 10)
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_lista)
	_llenar_heroes()
	var bc: Button = Estilo.boton("Volver")
	bc.pressed.connect(func() -> void:
		_cerrar_modal()
		_refrescar())
	vb.add_child(bc)


func _llenar_heroes() -> void:
	if _lista == null:
		return
	for c: Node in _lista.get_children():
		c.queue_free()
	var orden: Array[String] = ["ibsen"]
	orden.append_array(Estado.LLEGADAS)
	var guardia: Array[String] = Estado.guardia()
	for id: String in orden:
		var h: Dictionary = Estado.HEROES[id] as Dictionary
		var card: PanelContainer = Estilo.panel(Color(0.12, 0.15, 0.22, 0.95), Color(h["col"]).darkened(0.2))
		_lista.add_child(card)
		var hb: HBoxContainer = HBoxContainer.new()
		hb.add_theme_constant_override("separation", 12)
		card.add_child(hb)
		var tiene: bool = (Estado.d["heroes"] as Dictionary).has(id)
		var spr: TextureRect = Estilo.sprite(str(h["tex"]), Vector2(96, 130))
		if not tiene:
			Estilo.param(spr, "gris", 1.0)
			Estilo.param(spr, "alfa", 0.35)
		hb.add_child(spr)
		var vb: VBoxContainer = VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vb.add_theme_constant_override("separation", 2)
		hb.add_child(vb)
		if not tiene:
			var noche: int = Estado.LLEGADAS.find(id) + 1
			vb.add_child(Estilo.etiqueta("???", 28, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT))
			vb.add_child(Estilo.etiqueta("Llegará con la niebla de la noche %d." % noche, 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
			continue
		var lvl: int = Estado.nivel(id)
		vb.add_child(Estilo.etiqueta("%s · nv %d" % [h["nombre"], lvl], 26, Color(h["col"]).lightened(0.3), HORIZONTAL_ALIGNMENT_LEFT))
		vb.add_child(Estilo.etiqueta("%s · Vida %d · Fuerza %d" % [h["rol"], Estado.hp_heroe(id, lvl), int(Estado.atk_heroe(id, lvl))], 20, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
		var d: Label = Estilo.etiqueta("%s: %s" % [h["hab"], h["desc"]], 18, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		d.custom_minimum_size = Vector2(250, 0)
		vb.add_child(d)
		var bv: VBoxContainer = VBoxContainer.new()
		bv.add_theme_constant_override("separation", 8)
		hb.add_child(bv)
		var coste: int = Estado.coste_nivel(lvl)
		var bs: Button = Estilo.boton("Subir\n%d hierro" % coste if lvl < Estado.NIVEL_MAX else "Nivel\nmáximo", false, 80)
		bs.custom_minimum_size = Vector2(130, 80)
		bs.add_theme_font_size_override("font_size", 21)
		bs.disabled = lvl >= Estado.NIVEL_MAX or Estado.n("hierro") < coste
		bs.pressed.connect(func() -> void: subir(id))
		bv.add_child(bs)
		var en: bool = guardia.has(id)
		var bg: Button = Estilo.boton("En guardia" if en else "Reserva", en, 80)
		bg.custom_minimum_size = Vector2(130, 80)
		bg.add_theme_font_size_override("font_size", 21)
		bg.pressed.connect(func() -> void:
			if not Estado.alternar_guardia(id):
				Audio.play("hurt")
			Estado.guardar()
			_llenar_heroes())
		bv.add_child(bg)


func subir(id: String) -> void:
	if Estado.subir_heroe(id):
		Audio.play("powerup")
		_refrescar()
		_llenar_heroes()


# ---------------- Faro ----------------
func abrir_faro() -> void:
	if not _modal.is_empty():
		return
	_modal = Estilo.modal(self, "El faro", 640.0)
	_lista = _modal["vb"] as VBoxContainer
	_llenar_faro()


func _llenar_faro() -> void:
	if _lista == null:
		return
	var vb: VBoxContainer = _lista
	var hijos: Array[Node] = vb.get_children()
	for i: int in range(1, hijos.size()):
		hijos[i].queue_free()
	var fm: int = Estado.faro_max()
	var info: Label = Estilo.etiqueta("Integridad %d / %d\nLente nivel %d de %d\nLuz máxima %d · Destello: %d de daño" % [Estado.n("faro_hp"), fm, Estado.n("lente"), Estado.LENTE_MAX, Estado.luz_max(), Estado.destello_dano()], 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	info.custom_minimum_size = Vector2(580, 0)
	vb.add_child(info)
	var br: Button = Estilo.boton("Reparar +4  (1 madera)", false, 92)
	br.disabled = Estado.n("faro_hp") >= fm or Estado.n("madera") < 1
	br.pressed.connect(func() -> void:
		reparar()
		_llenar_faro())
	vb.add_child(br)
	var c: Dictionary = Estado.coste_lente()
	var txt: String = "Mejorar la lente  (%d hierro, %d madera)" % [int(c["hierro"]), int(c["madera"])]
	if Estado.n("lente") >= Estado.LENTE_MAX:
		txt = "La lente brilla al máximo"
	var bl: Button = Estilo.boton(txt, true, 100)
	bl.add_theme_font_size_override("font_size", 25)
	bl.disabled = Estado.n("lente") >= Estado.LENTE_MAX or not Estado.puede_pagar(c)
	bl.pressed.connect(func() -> void:
		mejorar_lente()
		_llenar_faro())
	vb.add_child(bl)
	var nota: Label = Estilo.etiqueta("Cada nivel: +1 de luz máxima, +8 de integridad y más daño de destello.", 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	nota.custom_minimum_size = Vector2(580, 0)
	vb.add_child(nota)
	var bc: Button = Estilo.boton("Volver")
	bc.pressed.connect(func() -> void:
		_cerrar_modal()
		_refrescar())
	vb.add_child(bc)


func reparar() -> void:
	if Estado.reparar():
		Audio.play("powerup", 0.05, -4.0)
		_refrescar()


func mejorar_lente() -> void:
	if Estado.mejorar_lente():
		Audio.play("powerup")
		Juice.vibrate(40)
		_refrescar()


# ---------------- Noche ----------------
func _pedir_encender() -> void:
	if not _modal.is_empty():
		return
	if Estado.n("horas") > 0:
		Estilo.confirmar(self, "¿Encender ya?", "Todavía te quedan %d horas de luz para explorar." % Estado.n("horas"), "Encender", "Esperar", encender)
	else:
		encender()


func encender() -> void:
	var lz: int = mini(Estado.luz_max(), 2 + Estado.n("aceite"))
	Estado.d["aceite"] = Estado.n("aceite") - (lz - 2)
	Estado.d["luz_inicial"] = lz
	Estado.guardar()
	Audio.play("powerup")
	Kit.change_scene(NOCHE)

class_name Estilo
extends RefCounted
## Estetica: grabado antiguo coloreado. Colores, letra, botones, paneles y modales.

static var TINTA: Color = Color("141a28")
static var TINTA2: Color = Color("232b3f")
static var PAPEL: Color = Color("efe3c6")
static var TEXTO: Color = Color("f1e7cf")
static var ORO: Color = Color("e8b857")
static var ORO_OSC: Color = Color("9a6f2a")
static var NIEBLA: Color = Color("a9bbc4")
static var ROJO: Color = Color("d0664f")
static var VERDE: Color = Color("86bba8")

static var _fuente: Font = null
static var _shader: Shader = null
static var _cache: Dictionary = {}

const SHADER_CODIGO: String = """
shader_type canvas_item;
uniform float alfa = 1.0;
uniform float gris = 0.0;
uniform float fade_bottom = 0.0;
uniform vec4 flash_col : source_color = vec4(1.0);
uniform float flash = 0.0;
void fragment() {
	vec4 c = texture(TEXTURE, UV);
	float m = min(c.r, c.b) - c.g;
	c.a *= 1.0 - smoothstep(0.13, 0.22, m);
	if (fade_bottom > 0.0) {
		c.a *= clamp((1.0 - UV.y) / fade_bottom, 0.0, 1.0);
	}
	float l = dot(c.rgb, vec3(0.3, 0.59, 0.11));
	c.rgb = mix(c.rgb, vec3(l * 0.55), gris);
	c.rgb = mix(c.rgb, flash_col.rgb, flash);
	c.a *= alfa;
	COLOR = c;
}
"""


static func fuente() -> Font:
	if _fuente == null:
		var sf: SystemFont = SystemFont.new()
		sf.font_names = PackedStringArray(["Georgia", "Noto Serif", "Palatino Linotype", "Times New Roman", "DejaVu Serif", "serif"])
		sf.allow_system_fallback = true
		if UI.font != null:
			var fb: Array[Font] = [UI.font]
			sf.fallbacks = fb
		_fuente = sf
	return _fuente


static func tex(id: String) -> Texture2D:
	if _cache.has(id):
		return _cache[id] as Texture2D
	var path: String = "res://assets/libre/%s.png" % id
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path) as Texture2D
	if t == null:
		t = Kit.load_texture(path)
	_cache[id] = t
	return t


static func mat_recorte() -> ShaderMaterial:
	if _shader == null:
		_shader = Shader.new()
		_shader.code = SHADER_CODIGO
	var m: ShaderMaterial = ShaderMaterial.new()
	m.shader = _shader
	return m


static func sprite(id: String, caja: Vector2, fade_bottom: float = 0.0) -> TextureRect:
	var r: TextureRect = TextureRect.new()
	r.texture = tex(id)
	r.custom_minimum_size = caja
	r.size = caja
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m: ShaderMaterial = mat_recorte()
	m.set_shader_parameter("fade_bottom", fade_bottom)
	r.material = m
	return r


static func param(r: CanvasItem, nombre: String, v: Variant) -> void:
	var m: ShaderMaterial = r.material as ShaderMaterial
	if m != null:
		m.set_shader_parameter(nombre, v)


static func destello(r: CanvasItem, col: Color, seg: float = 0.25) -> void:
	if r == null or not r.is_inside_tree():
		return
	param(r, "flash_col", col)
	var tw: Tween = r.create_tween()
	tw.tween_method(func(v: float) -> void: param(r, "flash", v), 0.8, 0.0, seg)


static func fundir(r: CanvasItem, desde: float, hasta: float, seg: float = 0.4) -> void:
	if r == null or not r.is_inside_tree():
		return
	param(r, "alfa", desde)
	var tw: Tween = r.create_tween()
	tw.tween_method(func(v: float) -> void: param(r, "alfa", v), desde, hasta, seg)


static func etiqueta(texto: String, tam: int = 28, col: Color = Color(0.945, 0.906, 0.812), alin: int = HORIZONTAL_ALIGNMENT_CENTER, wrap: bool = false) -> Label:
	var l: Label = Label.new()
	l.text = texto
	l.horizontal_alignment = alin as HorizontalAlignment
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_override("font", fuente())
	l.add_theme_font_size_override("font_size", tam)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.07, 0.12, 0.9))
	l.add_theme_constant_override("outline_size", maxi(2, int(tam / 9.0)))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func caja(fondo: Color, borde: Color, radio: int = 12, grosor: int = 2) -> StyleBoxFlat:
	var s: StyleBoxFlat = StyleBoxFlat.new()
	s.bg_color = fondo
	s.border_color = borde
	s.set_border_width_all(grosor)
	s.set_corner_radius_all(radio)
	s.content_margin_left = 18
	s.content_margin_right = 18
	s.content_margin_top = 12
	s.content_margin_bottom = 12
	s.shadow_color = Color(0, 0, 0, 0.35)
	s.shadow_size = 6
	return s


static func panel(fondo: Color = Color(0.078, 0.102, 0.157, 0.86), borde: Color = Color(0.6, 0.44, 0.17)) -> PanelContainer:
	var p: PanelContainer = PanelContainer.new()
	p.add_theme_stylebox_override("panel", caja(fondo, borde))
	return p


static func boton(texto: String, primario: bool = false, alto: float = 88.0) -> Button:
	var b: Button = Button.new()
	b.text = texto
	b.custom_minimum_size = Vector2(0, alto)
	b.focus_mode = Control.FOCUS_NONE
	b.clip_text = false
	b.add_theme_font_override("font", fuente())
	b.add_theme_font_size_override("font_size", 30 if primario else 28)
	var fondo: Color = ORO if primario else TINTA2
	var borde: Color = Color("fff0b8") if primario else ORO_OSC
	var txt: Color = Color("2a1d0c") if primario else TEXTO
	b.add_theme_stylebox_override("normal", caja(fondo, borde, 14, 3))
	b.add_theme_stylebox_override("hover", caja(fondo.lightened(0.08), borde, 14, 3))
	b.add_theme_stylebox_override("pressed", caja(fondo.darkened(0.2), borde, 14, 3))
	b.add_theme_stylebox_override("disabled", caja(Color(0.12, 0.14, 0.2, 0.8), Color(0.3, 0.3, 0.35), 14, 2))
	b.add_theme_stylebox_override("focus", caja(fondo, borde, 14, 3))
	for c: String in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(c, txt)
	b.add_theme_color_override("font_disabled_color", Color(0.5, 0.52, 0.58))
	b.resized.connect(func() -> void: b.pivot_offset = b.size / 2.0)
	b.button_down.connect(func() -> void:
		var tw: Tween = b.create_tween()
		tw.tween_property(b, "scale", Vector2(0.95, 0.95), 0.06))
	b.button_up.connect(func() -> void:
		var tw: Tween = b.create_tween()
		tw.tween_property(b, "scale", Vector2.ONE, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT))
	b.pressed.connect(func() -> void:
		Audio.play("click")
		Juice.vibrate(15))
	return b


static func barra(col: Color, alto: float = 18.0) -> ProgressBar:
	var pb: ProgressBar = ProgressBar.new()
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, alto)
	pb.size = Vector2(100, alto)
	var fondo: StyleBoxFlat = StyleBoxFlat.new()
	fondo.bg_color = Color(0.05, 0.06, 0.1, 0.9)
	fondo.border_color = Color(0.5, 0.4, 0.2)
	fondo.set_border_width_all(2)
	fondo.set_corner_radius_all(int(alto / 2.0))
	var lleno: StyleBoxFlat = StyleBoxFlat.new()
	lleno.bg_color = col
	lleno.set_corner_radius_all(int(alto / 2.0))
	pb.add_theme_stylebox_override("background", fondo)
	pb.add_theme_stylebox_override("fill", lleno)
	pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return pb


static func fondo_cubrir(padre: Control, id: String, zoom: float = 1.07) -> TextureRect:
	var bg: TextureRect = TextureRect.new()
	bg.texture = tex(id)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.position = Vector2.ZERO
	bg.size = Vector2(720, 1280)
	bg.pivot_offset = Vector2(360, 640)
	bg.scale = Vector2(zoom, zoom)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	padre.add_child(bg)
	return bg


## Modal: velo + panel central. Devuelve {"capa", "vb", "panel"}.
static func modal(padre: Control, titulo: String, ancho: float = 640.0) -> Dictionary:
	var capa: Control = Control.new()
	capa.set_anchors_preset(Control.PRESET_FULL_RECT)
	capa.mouse_filter = Control.MOUSE_FILTER_STOP
	padre.add_child(capa)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.04, 0.08, 0.78)
	vel.set_anchors_preset(Control.PRESET_FULL_RECT)
	vel.mouse_filter = Control.MOUSE_FILTER_STOP
	capa.add_child(vel)
	var centro: CenterContainer = CenterContainer.new()
	centro.set_anchors_preset(Control.PRESET_FULL_RECT)
	centro.mouse_filter = Control.MOUSE_FILTER_IGNORE
	capa.add_child(centro)
	var pn: PanelContainer = panel(Color(0.09, 0.115, 0.17, 0.97), Color(0.78, 0.58, 0.24))
	pn.custom_minimum_size = Vector2(ancho, 0)
	pn.resized.connect(func() -> void: pn.pivot_offset = pn.size / 2.0)
	centro.add_child(pn)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pn.add_child(vb)
	if titulo != "":
		vb.add_child(etiqueta(titulo, 40, ORO))
	capa.modulate.a = 0.0
	pn.scale = Vector2(0.92, 0.92)
	var tw: Tween = capa.create_tween().set_parallel(true)
	tw.tween_property(capa, "modulate:a", 1.0, 0.18)
	tw.tween_property(pn, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return {"capa": capa, "vb": vb, "panel": pn}


static func cerrar(m: Dictionary) -> void:
	var capa: Control = m.get("capa") as Control
	if capa != null and is_instance_valid(capa):
		capa.queue_free()


static func confirmar(padre: Control, titulo: String, texto: String, si: String, no: String, al_aceptar: Callable) -> void:
	var m: Dictionary = modal(padre, titulo, 600.0)
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var t: Label = etiqueta(texto, 28, TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	t.custom_minimum_size = Vector2(540, 0)
	vb.add_child(t)
	var fila: HBoxContainer = HBoxContainer.new()
	fila.add_theme_constant_override("separation", 14)
	vb.add_child(fila)
	var bn: Button = boton(no)
	bn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bn.pressed.connect(func() -> void: cerrar(m))
	fila.add_child(bn)
	var bs: Button = boton(si, true)
	bs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bs.pressed.connect(func() -> void:
		cerrar(m)
		al_aceptar.call())
	fila.add_child(bs)


static func pulso(c: Control) -> Tween:
	var tw: Tween = c.create_tween().set_loops()
	tw.tween_property(c, "scale", Vector2(1.04, 1.04), 0.7).set_trans(Tween.TRANS_SINE)
	tw.tween_property(c, "scale", Vector2.ONE, 0.7).set_trans(Tween.TRANS_SINE)
	return tw

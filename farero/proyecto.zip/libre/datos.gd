class_name Datos
extends RefCounted
## Todo el contenido de El Farero: mareas (capitulos), heroes, monstruos, plantas del faro, reliquias,
## talentos y lugares. Las reglas viven en estado.gd y noche.gd; aqui solo hay datos.

const NOCHES_POR_MAREA: int = 12
const RECURSOS: Array[String] = ["aceite", "madera", "hierro", "ambar"]
const NOMBRE_RECURSO: Dictionary = {"aceite": "Aceite", "madera": "Madera", "hierro": "Hierro", "ambar": "Ámbar"}
const COL_RECURSO: Dictionary = {"aceite": "#e8b857", "madera": "#a8764a", "hierro": "#8fa6bd", "ambar": "#e07a3a"}

# ------------------------------------------------------------------ heroes
## llega: noche global en la que la niebla lo trae (0 = desde el principio).
const HEROES: Dictionary = {
	"ibsen": {"nombre": "Capitán Ibsen", "mundo": "los Mares de Hierro", "rol": "Guardián", "llega": 0,
		"hp": 42, "atk": 7, "tex": "h_ibsen", "col": "#c9a24a", "obj": true,
		"hab": "Ancla de hierro", "desc": "Golpea y atrae todos los ataques hacia él (recibe un 30% menos).",
		"frase": "«He cruzado mil mares y ninguno olía tanto a despedida como este.»"},
	"alba": {"nombre": "Sor Alba", "mundo": "el Convento de las Estrellas", "rol": "Sanadora", "llega": 2,
		"hp": 32, "atk": 5, "tex": "h_alba", "col": "#8fb4d8", "obj": false,
		"hab": "Plegaria de estrellas", "desc": "Cura al héroe más herido y repara un poco el faro.",
		"frase": "«Vi apagarse mi cielo. Déjame ayudarte a cuidar el tuyo.»"},
	"koji": {"nombre": "Koji", "mundo": "el Valle de los Arces", "rol": "Duelista", "llega": 4,
		"hp": 28, "atk": 10, "tex": "h_koji", "col": "#c2573a", "obj": true,
		"hab": "Corte de papel", "desc": "Un tajo certero: 2,2 veces su fuerza sobre un enemigo.",
		"frase": "«Mi espada recuerda a quienes ya no están.»"},
	"tumo": {"nombre": "Tumo", "mundo": "la Ciudad de los Relojes", "rol": "Autómata", "llega": 6,
		"hp": 46, "atk": 5, "tex": "h_tumo", "col": "#b8a05a", "obj": false,
		"hab": "Cúpula de horas", "desc": "Una barrera reduce a la mitad el daño de la próxima embestida, a héroes y faro.",
		"frase": "«Mi cuerda se agota... pero aún me quedan horas para ti.»"},
	"nerea": {"nombre": "Nerea", "mundo": "la Tierra del Ocaso", "rol": "Cazadora", "llega": 9,
		"hp": 31, "atk": 9, "tex": "h_nerea", "col": "#9a8fb8", "obj": true,
		"hab": "Saeta eclipsada", "desc": "Dispara: daño doble contra enemigos iluminados.",
		"frase": "«Cazo lo que vive en lo oscuro. Enséñamelo con tu luz.»"},
	"lyra": {"nombre": "Lyra", "mundo": "el Archipiélago Volador", "rol": "Aeronauta", "llega": 14,
		"hp": 30, "atk": 8, "tex": "h_lyra", "col": "#6fa6a0", "obj": false,
		"hab": "Tormenta de brújula", "desc": "Un estallido que alcanza a todos los enemigos.",
		"frase": "«Perdí mi globo entre las nubes. Tu luz es el único norte que me queda.»"},
	"bram": {"nombre": "Bram", "mundo": "las Forjas del Norte", "rol": "Herrero", "llega": 17,
		"hp": 50, "atk": 6, "tex": "h_bram", "col": "#c07a44", "obj": false,
		"hab": "Yunque protector", "desc": "Forja un escudo para cada héroe que absorbe daño.",
		"frase": "«Todo lo roto se puede volver a forjar. Hasta un faro. Hasta un hombre.»"},
	"mireia": {"nombre": "Mireia", "mundo": "los Arrecifes de Nácar", "rol": "Buceadora", "llega": 21,
		"hp": 33, "atk": 9, "tex": "h_mireia", "col": "#5fa9c4", "obj": true,
		"hab": "Arpón de perlas", "desc": "Golpe de 1,7 veces su fuerza. Si remata, recupera 2 de luz.",
		"frase": "«Bajé a buscar perlas y encontré tu luz al subir.»"},
	"ossian": {"nombre": "Ossian", "mundo": "las Colinas del Eco", "rol": "Bardo", "llega": 26,
		"hp": 34, "atk": 5, "tex": "h_ossian", "col": "#d6b46a", "obj": false,
		"hab": "Balada del faro", "desc": "Inspira a la guardia: +40% de fuerza durante este turno y el siguiente.",
		"frase": "«No veo el faro, pero lo oigo. Canta como mi madre.»"},
	"zahir": {"nombre": "Zahir", "mundo": "el Desierto de Cristal", "rol": "Alquimista", "llega": 30,
		"hp": 30, "atk": 7, "tex": "h_zahir", "col": "#8fbf5a", "obj": false,
		"hab": "Frasco corrosivo", "desc": "Envenena a todos los enemigos: pierden vida durante 3 turnos.",
		"frase": "«En mi tierra la niebla no existía. Aquí la convertiré en sal.»"},
	"hilda": {"nombre": "Hilda", "mundo": "los Mares Blancos", "rol": "Rompehielos", "llega": 38,
		"hp": 44, "atk": 8, "tex": "h_hilda", "col": "#9fc4d8", "obj": true,
		"hab": "Golpe rompehielos", "desc": "1,4 veces su fuerza y aturde: el enemigo pierde sus ataques este turno.",
		"frase": "«He roto hielo de cien palmos. Tu niebla no me asusta.»"},
	"selene": {"nombre": "Selene", "mundo": "el Observatorio Hundido", "rol": "Astrónoma", "llega": 43,
		"hp": 29, "atk": 6, "tex": "h_selene", "col": "#8a9ae0", "obj": false,
		"hab": "Estrella fugaz", "desc": "Atrapa una estrella: +3 de luz e ilumina a un enemigo al azar.",
		"frase": "«Las estrellas me dijeron dónde estabas. Vine a darles la razón.»"},
	"pip": {"nombre": "Pip", "mundo": "el Pueblo de las Campanas", "rol": "Campanero", "llega": 50,
		"hp": 26, "atk": 4, "tex": "h_pip", "col": "#e0b85a", "obj": false,
		"hab": "Campanada", "desc": "Levanta a un héroe caído con 40% de vida; si no hay caídos, cura un 20% a todos.",
		"frase": "«¡Toco la campana y la gente vuelve! Siempre vuelve.»"},
	"morgana": {"nombre": "Morgana", "mundo": "la Gruta de las Mareas", "rol": "Bruja del mar", "llega": 55,
		"hp": 36, "atk": 9, "tex": "h_morgana", "col": "#4fa38a", "obj": true,
		"hab": "Marea que devuelve", "desc": "Golpea con 1,5 veces su fuerza y reparte ese daño como curación.",
		"frase": "«Yo ayudé a traer esta niebla. Déjame ayudar a llevármela.»"},
}

# ------------------------------------------------------------------ monstruos
## rasgos: coraza, intangible, velo, regenera, veloz, descarga, atrapa, espinas, canto, caparazon,
## furia, escudo_aliados, come_luz, copia, invoca:<id>
const ENEMIGOS: Dictionary = {
	"sombra": {"nombre": "Sombra de bruma", "hp": 16, "atk": 4, "tex": "m_sombra", "rasgos": [], "desc": "Frágil, pero llega en grupo."},
	"rondador": {"nombre": "Rondador de niebla", "hp": 30, "atk": 6, "tex": "m_rondador", "rasgos": ["coraza"], "desc": "Coraza: sin luz recibe un 35% menos de daño."},
	"espectro": {"nombre": "Espectro del naufragio", "hp": 22, "atk": 7, "tex": "m_espectro", "rasgos": ["intangible"], "desc": "Intangible: sin luz no se le puede herir."},
	"ahogado": {"nombre": "Marinero ahogado", "hp": 26, "atk": 5, "tex": "m_ahogado", "rasgos": ["regenera"], "desc": "Regenera un 12% de su vida cada turno."},
	"arpia": {"nombre": "Arpía del vendaval", "hp": 20, "atk": 5, "tex": "m_arpia", "rasgos": ["veloz"], "desc": "Veloz: ataca dos veces."},
	"medusa": {"nombre": "Medusa de rayo", "hp": 24, "atk": 5, "tex": "m_medusa", "rasgos": ["descarga"], "desc": "Al morir descarga un rayo sobre toda la guardia."},
	"tentaculo": {"nombre": "Tentáculo del abismo", "hp": 34, "atk": 6, "tex": "m_tentaculo", "rasgos": ["atrapa"], "desc": "Atrapa al héroe que golpea: no podrá actuar el turno siguiente."},
	"golem_coral": {"nombre": "Gólem de coral", "hp": 40, "atk": 6, "tex": "m_golem_coral", "rasgos": ["espinas", "coraza"], "desc": "Espinas: devuelve parte del daño a quien le golpea."},
	"sirena": {"nombre": "Sirena roja", "hp": 24, "atk": 6, "tex": "m_sirena", "rasgos": ["canto"], "desc": "Su canto roba 1 de luz al empezar tu turno."},
	"cangrejo_rojo": {"nombre": "Cangrejo de cráneos", "hp": 36, "atk": 6, "tex": "m_cangrejo_rojo", "rasgos": ["caparazon"], "desc": "Cada dos turnos se cubre con un caparazón que absorbe daño."},
	"anguila": {"nombre": "Anguila carmesí", "hp": 28, "atk": 6, "tex": "m_anguila", "rasgos": ["furia"], "desc": "Furia: cada turno pega un 15% más fuerte."},
	"pescador": {"nombre": "Pescador sin rostro", "hp": 30, "atk": 7, "tex": "m_pescador", "rasgos": ["regenera", "intangible"], "desc": "Intangible y regenera. Ilumínalo y no le des tregua."},
	"lobo_hielo": {"nombre": "Lobo de escarcha", "hp": 26, "atk": 7, "tex": "m_lobo_hielo", "rasgos": ["atrapa", "veloz"], "desc": "Veloz y congela al héroe que muerde."},
	"morsa": {"nombre": "Morsa espectral", "hp": 46, "atk": 6, "tex": "m_morsa", "rasgos": ["coraza", "caparazon"], "desc": "Una mole: coraza y caparazón de hielo."},
	"llorona": {"nombre": "Llorona de hielo", "hp": 24, "atk": 5, "tex": "m_llorona", "rasgos": ["escudo_aliados", "intangible"], "desc": "Protege a los suyos con escarcha cada turno."},
	"tripulante": {"nombre": "Tripulante helado", "hp": 18, "atk": 6, "tex": "m_tripulante", "rasgos": ["furia"], "desc": "Llegan en cuadrilla y se enfurecen."},
	"ojo": {"nombre": "Ojo del eclipse", "hp": 26, "atk": 6, "tex": "m_ojo", "rasgos": ["canto", "velo"], "desc": "Se bebe tu luz y la oscuridad lo protege."},
	"polilla": {"nombre": "Polilla de ceniza", "hp": 30, "atk": 6, "tex": "m_polilla", "rasgos": ["come_luz", "veloz"], "desc": "Iluminarla la cura... pero así recibe más daño."},
	"caballero": {"nombre": "Caballero sin faro", "hp": 48, "atk": 8, "tex": "m_caballero", "rasgos": ["coraza", "furia", "espinas"], "desc": "Armadura, rabia y púas."},
	"eco": {"nombre": "Eco de ti mismo", "hp": 34, "atk": 6, "tex": "m_eco", "rasgos": ["copia"], "desc": "Golpea con la fuerza de tu mejor héroe."},
	# jefes
	"leviatan": {"nombre": "Leviatán de la Niebla", "hp": 120, "atk": 8, "tex": "m_leviatan2", "rasgos": ["velo", "veloz"], "jefe": true, "desc": "Ataca dos veces. Sin luz recibe un 40% menos de daño."},
	"reina_tormenta": {"nombre": "La Reina de la Tormenta", "hp": 150, "atk": 8, "tex": "m_jefe_tormenta", "rasgos": ["veloz", "invoca:arpia", "descarga"], "jefe": true, "desc": "Rápida como el rayo. Llama a sus arpías."},
	"coral_late": {"nombre": "El Coral que Late", "hp": 165, "atk": 8, "tex": "m_jefe_coral", "rasgos": ["regenera", "espinas", "invoca:cangrejo_rojo"], "jefe": true, "desc": "Late, sangra y se cura. Sus cangrejos lo protegen."},
	"capitan_helado": {"nombre": "El Capitán Helado", "hp": 215, "atk": 9, "tex": "m_jefe_helado", "rasgos": ["atrapa", "caparazon", "invoca:tripulante"], "jefe": true, "desc": "Congela a quien toca y llama a su tripulación."},
	"apagafaros": {"nombre": "El que Apaga los Faros", "hp": 245, "atk": 10, "tex": "m_jefe_eclipse", "rasgos": ["velo", "canto", "furia", "invoca:ojo"], "jefe": true, "desc": "El final de toda luz. No lo dejes respirar."},
}

# ------------------------------------------------------------------ mareas (capitulos)
const MAREAS: Array = [
	{"nombre": "Marea de Niebla", "bg": "bg_noche", "color": "#8fa6bd",
		"pool": ["sombra", "rondador", "espectro", "ahogado"], "jefe": "leviatan", "intro": 1,
		"texto": "La niebla rodea la isla. Algo grande respira debajo.",
		"final": "El Leviatán se deshace en bruma. Pero en el horizonte se encienden relámpagos: llega la tormenta."},
	{"nombre": "Marea de Tormenta", "bg": "bg_noche_2", "color": "#7fa8d8",
		"pool": ["arpia", "medusa", "tentaculo", "golem_coral", "sombra"], "jefe": "reina_tormenta", "intro": 2,
		"texto": "El cielo se rompe. Las arpías chillan sobre las olas.",
		"final": "La Reina cae entre truenos. Cuando escampa, el mar se ha vuelto rojo."},
	{"nombre": "Marea Roja", "bg": "bg_noche_3", "color": "#d0604b",
		"pool": ["sirena", "cangrejo_rojo", "anguila", "pescador", "golem_coral"], "jefe": "coral_late", "intro": 3,
		"texto": "El agua sabe a hierro. Algo late bajo el arrecife.",
		"final": "El Coral deja de latir. Esa noche el mar se hiela de golpe."},
	{"nombre": "Marea de Hielo", "bg": "bg_noche_4", "color": "#9fd4e0",
		"pool": ["lobo_hielo", "morsa", "llorona", "tripulante", "tentaculo"], "jefe": "capitan_helado", "intro": 4,
		"texto": "Témpanos, auroras y un barco atrapado en el hielo que no debería estar ahí.",
		"final": "El Capitán se rompe como un carámbano. Y entonces el sol se vuelve negro."},
	{"nombre": "Marea del Eclipse", "bg": "bg_noche_5", "color": "#b48ad8",
		"pool": ["ojo", "polilla", "caballero", "eco", "espectro"], "jefe": "apagafaros", "intro": 5,
		"texto": "Un sol negro cuelga sobre el mar. Todos los faros del mundo se han apagado. Todos menos el tuyo.",
		"final": "El que Apaga los Faros se deshace en ceniza. El sol vuelve. Y desde el horizonte, uno a uno, responden otros faros."},
]

# ------------------------------------------------------------------ plantas del faro
## coste por nivel: base * (nivel+1); el ambar aparece desde "ambar_desde".
const PLANTAS: Array = [
	{"id": "linterna", "nombre": "Sala de la linterna", "max": 10, "coste": {"hierro": 4, "madera": 2}, "ambar_desde": 5,
		"desc": "+1 de luz máxima y más daño de destello por nivel."},
	{"id": "muros", "nombre": "Muros de piedra", "max": 10, "coste": {"madera": 3, "hierro": 2}, "ambar_desde": 6,
		"desc": "+12 de integridad del faro por nivel."},
	{"id": "maquinas", "nombre": "Sala de máquinas", "max": 6, "coste": {"hierro": 6, "aceite": 3}, "ambar_desde": 3,
		"desc": "Más luz cada turno: +1 en los niveles 2, 4 y 6."},
	{"id": "enfermeria", "nombre": "Enfermería", "max": 6, "coste": {"madera": 4, "aceite": 2}, "ambar_desde": 4,
		"desc": "Entre oleadas la guardia recupera un 8% de vida por nivel."},
	{"id": "campanario", "nombre": "Campanario", "max": 5, "coste": {"hierro": 5, "madera": 3}, "ambar_desde": 3,
		"desc": "Cada oleada empieza con barrera. Más niveles: la barrera dura más turnos."},
	{"id": "senales", "nombre": "Torre de señales", "max": 4, "coste": {"madera": 5, "hierro": 5}, "ambar_desde": 2,
		"desc": "Nivel 2: guardia de 4 héroes. Cada nivel, más botín de las noches."},
	{"id": "muelle", "nombre": "Muelle", "max": 5, "coste": {"madera": 6}, "ambar_desde": 3,
		"desc": "+1 hora de exploración en los niveles 1, 3 y 5. Más botín al explorar."},
	{"id": "taller", "nombre": "Taller", "max": 6, "coste": {"madera": 4, "hierro": 3}, "ambar_desde": 4,
		"desc": "Subir de nivel a los héroes cuesta un 6% menos por nivel."},
	{"id": "biblioteca", "nombre": "Biblioteca", "max": 4, "coste": {"madera": 5, "aceite": 4}, "ambar_desde": 1,
		"desc": "Abre los talentos de los héroes (nivel 1) y da un 10% más de fuerza por nivel extra."},
]

# ------------------------------------------------------------------ talentos (cada 5 niveles, 1 de 2)
const TALENTOS: Array = [
	{"nivel": 5, "a": {"id": "vida", "nombre": "Piel curtida", "desc": "+20% de vida."},
		"b": {"id": "fuerza", "nombre": "Brazo firme", "desc": "+20% de fuerza."}},
	{"nivel": 10, "a": {"id": "luz_matar", "nombre": "Cazaluces", "desc": "+1 de luz cada vez que remata a un enemigo."},
		"b": {"id": "hab_gratis", "nombre": "Inspirado", "desc": "Su primera habilidad de cada oleada no gasta luz."}},
	{"nivel": 15, "a": {"id": "critico", "nombre": "Ojo de halcón", "desc": "25% de golpe crítico (daño ×1,8)."},
		"b": {"id": "robo", "nombre": "Sed de marea", "desc": "Se cura un 25% del daño que hace."}},
	{"nivel": 20, "a": {"id": "revive", "nombre": "Terquedad", "desc": "La primera vez que cae en una noche, se levanta con 30% de vida."},
		"b": {"id": "escudo", "nombre": "Coraza de faro", "desc": "Empieza cada oleada con un escudo igual al 25% de su vida."}},
	{"nivel": 25, "a": {"id": "regen", "nombre": "Aliento", "desc": "Recupera un 6% de vida al empezar cada turno."},
		"b": {"id": "fuerza2", "nombre": "Leyenda", "desc": "+30% de fuerza."}},
]

# ------------------------------------------------------------------ reliquias
const RELIQUIAS: Dictionary = {
	"r_brujula": {"nombre": "Brújula del náufrago", "desc": "+15% de fuerza.", "m": {"fuerza": 0.15}},
	"r_campana": {"nombre": "Campana de proa", "desc": "Empieza cada oleada con un escudo del 20% de su vida.", "m": {"escudo": 0.2}},
	"r_perla": {"nombre": "Perla negra", "desc": "+25% de vida.", "m": {"vida": 0.25}},
	"r_ancla": {"nombre": "Ancla de oro", "desc": "Recibe un 15% menos de daño.", "m": {"defensa": 0.15}},
	"r_reloj": {"nombre": "Reloj roto", "desc": "Su primera habilidad de cada oleada no gasta luz.", "m": {"hab_gratis": 1}},
	"r_llave": {"nombre": "Llave de la serpiente", "desc": "20% de golpe crítico.", "m": {"critico": 0.2}},
	"r_vela": {"nombre": "Vela que no se apaga", "desc": "+1 de luz al rematar a un enemigo.", "m": {"luz_matar": 1}},
	"r_diente": {"nombre": "Colmillo de bestia", "desc": "+25% de fuerza contra jefes.", "m": {"contra_jefe": 0.25}},
	"r_coral": {"nombre": "Rama de coral", "desc": "Se cura un 15% del daño que hace.", "m": {"robo": 0.15}},
	"r_escarcha": {"nombre": "Esquirla de escarcha", "desc": "Sus golpes tienen un 20% de aturdir.", "m": {"aturdir": 0.2}},
	"r_pluma": {"nombre": "Pluma de tormenta", "desc": "Sus golpes alcanzan también a otro enemigo (40%).", "m": {"rebote": 0.4}},
	"r_mapa": {"nombre": "Mapa del tesoro", "desc": "+1 de cada recurso al ganar una noche.", "m": {"botin": 1}},
	"r_lente": {"nombre": "Prisma de lente", "desc": "Hace un 30% más contra enemigos iluminados.", "m": {"contra_luz": 0.3}},
	"r_rosario": {"nombre": "Rosario de conchas", "desc": "Recupera un 5% de vida cada turno.", "m": {"regen": 0.05}},
	"r_frasco": {"nombre": "Frasco verde", "desc": "Sus golpes envenenan (pierden vida 2 turnos).", "m": {"veneno": 0.35}},
	"r_corona": {"nombre": "Corona del rey ahogado", "desc": "+15% de vida y de fuerza.", "m": {"vida": 0.15, "fuerza": 0.15}},
}

# ------------------------------------------------------------------ lugares (se abren por marea)
const LUGARES: Array = [
	{"nombre": "Playa de los Restos", "desc": "Barriles y maderos que arrastra la marea.", "marea": 1,
		"botin": {"aceite": [2, 4], "madera": [0, 2], "hierro": [0, 1]},
		"eventos": ["Entre las algas hallas un violín sin cuerdas. Alguien lo echó de menos.",
			"La marea ha dejado un barril intacto y una bota de niño. Solo te llevas el barril.",
			"Un mascarón de proa te mira desde la arena. Parece querer decirte algo."]},
	{"nombre": "Bosque Gris", "desc": "Pinos doblados por un viento que ya no sopla.", "marea": 1,
		"botin": {"madera": [2, 4], "aceite": [0, 2]},
		"eventos": ["Los árboles susurran en un idioma de ramas. Cortas lo justo y pides perdón.",
			"Hay un columpio colgado de un pino. Se mece, aunque no hay brisa.",
			"Encuentras un hacha oxidada clavada en un tronco, como una promesa sin cumplir."]},
	{"nombre": "Acantilado Roto", "desc": "Vetas de hierro y nidos que nadie habita.", "marea": 1,
		"botin": {"hierro": [2, 3], "madera": [0, 1], "aceite": [0, 1]},
		"eventos": ["Desde lo alto, la niebla parece un mar de leche. Algo se mueve dentro.",
			"Rascas el hierro de una veta antigua. Suena a campana lejana.",
			"Un nido vacío, perfectamente cuidado. Esperan a alguien que no volverá."]},
	{"nombre": "Ruinas Sumergidas", "desc": "Algo habitó aquí. Algo todavía susurra.", "marea": 1,
		"botin": {"hierro": [1, 3], "aceite": [1, 3], "madera": [1, 2]},
		"eventos": ["Un reloj de pared marca una hora que no existe. Te llevas sus engranajes.",
			"En las paredes, mapas de mundos que nunca has visto. Todos acaban en un faro.",
			"Una mesa puesta para siete. Nadie ha tocado la sopa en cien años."]},
	{"nombre": "Pecio del Albatros", "desc": "Un clíper partido por un rayo. Su bodega sigue cerrada.", "marea": 2,
		"botin": {"hierro": [2, 4], "aceite": [1, 3]},
		"eventos": ["En el cuaderno de bitácora la última línea dice: «Vemos una luz. Estamos salvados».",
			"Los cañones del pecio apuntan al cielo, como si dispararan a las nubes.",
			"Un loro disecado repite, a su manera, el nombre de un barco."]},
	{"nombre": "Isla de los Pararrayos", "desc": "Cien varas de hierro clavadas en la roca.", "marea": 2,
		"botin": {"hierro": [3, 5]},
		"eventos": ["Arrancas una vara todavía caliente. Huele a ozono y a promesa.",
			"El suelo está lleno de cristal: arena que un rayo convirtió en vidrio."]},
	{"nombre": "Arrecife Escarlata", "desc": "Corales rojos que crecen sobre huesos.", "marea": 3,
		"botin": {"aceite": [3, 5], "madera": [1, 2]},
		"eventos": ["Un pez rojo te sigue hasta la orilla. Cuando te vas, se queda mirando.",
			"Entre el coral hay un anillo de compromiso. Lo dejas donde está."]},
	{"nombre": "Ermita del Pescador", "desc": "Una choza con redes que se remiendan solas.", "marea": 3,
		"botin": {"madera": [3, 5], "aceite": [1, 2]},
		"eventos": ["Sobre la mesa, una taza caliente. No hay nadie. Nunca hay nadie.",
			"Las redes tienen nudos que ningún marinero conoce."]},
	{"nombre": "Barco Varado en el Hielo", "desc": "La tripulación sigue a bordo. Congelada.", "marea": 4,
		"botin": {"hierro": [3, 5], "madera": [2, 3]},
		"eventos": ["El cocinero helado sostiene un cucharón. Le quitas el cucharón con respeto.",
			"En el camarote del capitán hay un retrato de una mujer que se parece a Hilda."]},
	{"nombre": "Cueva de la Aurora", "desc": "Hielo azul que brilla por dentro.", "marea": 4,
		"botin": {"aceite": [3, 6], "ambar": [0, 1]},
		"eventos": ["La aurora se refleja en el hielo y por un momento ves el faro desde arriba.",
			"Dentro del hielo hay una mariposa de hace mil años. Todavía tiene color."]},
	{"nombre": "Campo de Ceniza", "desc": "Lo que queda de los faros que se apagaron.", "marea": 5,
		"botin": {"hierro": [3, 6], "aceite": [2, 4], "ambar": [0, 1]},
		"eventos": ["Recoges una lente rota de otro faro. Todavía calienta.",
			"Huellas en la ceniza que van hacia el mar y no vuelven."]},
	{"nombre": "Observatorio Hundido", "desc": "Telescopios que apuntan hacia abajo.", "marea": 5,
		"botin": {"madera": [3, 5], "ambar": [0, 2]},
		"eventos": ["Un mapa de estrellas con una nueva, dibujada a mano: tu faro.",
			"El telescopio no muestra el cielo: muestra el fondo del mar, lleno de luces."]},
]

const DIARIOS: Array[String] = [
	"La niebla se ha retirado un poco. No te fíes: solo toma impulso.",
	"El faro cruje cuando el viento cambia. Es su forma de conversar contigo.",
	"Alguien ha dibujado una estrella en la ventana, por dentro. Nadie más vive aquí.",
	"Las gaviotas ya no vuelan hacia el mar abierto. Se quedan, como tú.",
	"Un día más. La lámpara brilla; eso es lo único que importa.",
	"Los náufragos han encendido una hoguera en la playa y cantan en idiomas distintos la misma canción.",
	"Ossian dice que el faro tiene voz. Nadie le lleva la contraria.",
	"Bram ha forjado una barandilla nueva. Dice que es para que nadie más se caiga al mar.",
	"Has soñado con otros faros. En el sueño, todos estaban encendidos.",
]

## Modificadores del reto del dia.
const RETOS: Array = [
	{"id": "luz_doble", "nombre": "Noche estrellada", "desc": "Recuperas el doble de luz cada turno."},
	{"id": "sin_destello", "nombre": "Lente agrietada", "desc": "No puedes usar el destello del faro."},
	{"id": "enemigos_veloces", "nombre": "Viento de cola", "desc": "Todos los monstruos atacan dos veces."},
	{"id": "fragil", "nombre": "Muros de papel", "desc": "El faro tiene la mitad de integridad."},
	{"id": "elite", "nombre": "Noche antigua", "desc": "Todos los monstruos son antiguos (más fuertes)."},
	{"id": "solo_dos", "nombre": "Guardia mínima", "desc": "Solo luchan tus dos primeros héroes."},
]

# ------------------------------------------------------------------ sucesos del día (con decisiones)
## Cada opción tiene uno o varios resultados con su probabilidad. Efectos: aceite, madera, hierro, ambar
## (se multiplican por la marea), faro (+/- integridad), reliquia, nivel (un héroe al azar sube), horas,
## luz_noche (+luz al empezar la próxima noche), escudo_noche (la guardia empieza con escudo),
## noche_dura (próxima noche: monstruos +25% y botín x1,6).
const SUCESOS: Array = [
	{"titulo": "Un bote a la deriva", "marea": 1, "texto": "Un bote golpea las rocas. Dentro, un marinero respira apenas y abraza un cofre.",
		"opciones": [
			{"t": "Salvar al marinero", "r": [{"p": 1.0, "e": {"nivel": 1, "aceite": 2}, "x": "Antes de morir de agradecimiento, te enseña un par de trucos de esgrima a la guardia. Y te deja su aceite."}]},
			{"t": "Abrir el cofre", "r": [{"p": 0.6, "e": {"hierro": 6, "ambar": 1}, "x": "Hierro y un trozo de ámbar. El marinero te mira sin decir nada."},
				{"p": 0.4, "e": {"faro": -6}, "x": "Una anguila sale del cofre y muerde los pilares del faro antes de huir."}]}]},
	{"titulo": "La campana del naufragio", "marea": 1, "texto": "Bajo el agua suena una campana. Alguien, o algo, la toca a intervalos.",
		"opciones": [
			{"t": "Bucear hasta ella", "r": [{"p": 0.5, "e": {"reliquia": 1}, "x": "En el fondo, atada a la campana, hay una reliquia que brilla."},
				{"p": 0.5, "e": {"horas": -1, "madera": 2}, "x": "No llegas. Vuelves helado y con un tablón. Pierdes una hora."}]},
			{"t": "Responder con la campana del faro", "r": [{"p": 1.0, "e": {"escudo_noche": 1}, "x": "El fondo deja de sonar. Esta noche la guardia luchará más tranquila."}]}]},
	{"titulo": "Huellas que no son tuyas", "marea": 1, "texto": "En la arena hay huellas descalzas que salen del mar y suben hacia el faro.",
		"opciones": [
			{"t": "Seguirlas", "r": [{"p": 0.55, "e": {"aceite": 4, "madera": 3}, "x": "Llevan a una cueva con un alijo de contrabandistas."},
				{"p": 0.45, "e": {"noche_dura": 1}, "x": "Llevan al faro... y por dentro. Algo te ha marcado. Esta noche vendrán más fuertes (y con más botín)."}]},
			{"t": "Borrarlas y echar sal", "r": [{"p": 1.0, "e": {"luz_noche": 1}, "x": "Una vieja costumbre. La lámpara parece arder con más ganas."}]}]},
	{"titulo": "El mercader de niebla", "marea": 1, "texto": "Un hombre sin sombra ofrece cambiar cosas. Habla bajito, como si alguien escuchara.",
		"opciones": [
			{"t": "Cambiar madera por hierro", "r": [{"p": 1.0, "e": {"madera": -4, "hierro": 6}, "x": "Trato hecho. El hierro está frío como un pez."}]},
			{"t": "Cambiar hierro por ámbar", "r": [{"p": 1.0, "e": {"hierro": -10, "ambar": 1}, "x": "Te da una gota de ámbar con un mosquito dentro. Parece de otro mundo."}]},
			{"t": "No tratar con él", "r": [{"p": 1.0, "e": {}, "x": "Se encoge de hombros y la niebla se lo traga."}]}]},
	{"titulo": "Gaviotas furiosas", "marea": 1, "texto": "Una bandada de gaviotas defiende algo brillante en el acantilado.",
		"opciones": [
			{"t": "Espantarlas", "r": [{"p": 0.7, "e": {"hierro": 4, "aceite": 2}, "x": "Un farol de barco intacto. Mucho hierro y algo de aceite."},
				{"p": 0.3, "e": {"horas": -1}, "x": "Te persiguen hasta la playa. Pierdes una hora y algo de dignidad."}]},
			{"t": "Dejarles pescado", "r": [{"p": 1.0, "e": {"aceite": -1, "luz_noche": 1}, "x": "Esta noche vigilarán el mar por ti y chillarán cuando algo se acerque."}]}]},
	{"titulo": "La tormenta trae un globo", "marea": 2, "texto": "Un globo aerostático roto cae en el bosque. La cesta todavía cuelga de un pino.",
		"opciones": [
			{"t": "Desmontar el globo", "r": [{"p": 1.0, "e": {"madera": 5, "aceite": 3}, "x": "Lona, cuerdas y un depósito de queroseno. Lyra lo mira con nostalgia."}]},
			{"t": "Buscar a su piloto", "r": [{"p": 0.6, "e": {"nivel": 1, "reliquia": 1}, "x": "No hay piloto, pero sí su diario y una reliquia. Tus héroes aprenden de sus notas."},
				{"p": 0.4, "e": {"faro": -8, "noche_dura": 1}, "x": "El piloto se convirtió en arpía. Huyes, pero esta noche volverá con amigas."}]}]},
	{"titulo": "Rayo en el pararrayos", "marea": 2, "texto": "Un rayo cae en la vara del faro y la deja zumbando, al rojo.",
		"opciones": [
			{"t": "Canalizarlo hacia la lámpara", "r": [{"p": 0.65, "e": {"luz_noche": 3}, "x": "La lámpara se carga de energía. Esta noche empezarás con mucha luz."},
				{"p": 0.35, "e": {"faro": -10}, "x": "La descarga revienta un muro. El faro tiembla."}]},
			{"t": "Dejar que se enfríe", "r": [{"p": 1.0, "e": {"hierro": 5}, "x": "La vara se ha fundido en un lingote perfecto."}]}]},
	{"titulo": "Botellas con mensaje", "marea": 2, "texto": "La marea trae siete botellas. Cada una con un mensaje distinto, la misma letra.",
		"opciones": [
			{"t": "Leerlas todas (1 hora)", "r": [{"p": 1.0, "e": {"horas": -1, "nivel": 1, "ambar": 1}, "x": "Son consejos de un farero de otro tiempo. Tus héroes los estudian."}]},
			{"t": "Venderlas al mercader", "r": [{"p": 1.0, "e": {"aceite": 5}, "x": "Paga en aceite, que es lo que tiene."}]}]},
	{"titulo": "El arrecife sangra", "marea": 3, "texto": "Un coral rojo palpita junto a la orilla. Late al ritmo de algo mucho más grande.",
		"opciones": [
			{"t": "Arrancarlo", "r": [{"p": 0.6, "e": {"ambar": 2}, "x": "Su corazón es ámbar puro."},
				{"p": 0.4, "e": {"noche_dura": 1, "ambar": 1}, "x": "Al arrancarlo, el mar entero se estremece. Esta noche vendrán a por ti."}]},
			{"t": "Quemarlo con aceite", "r": [{"p": 1.0, "e": {"aceite": -3, "escudo_noche": 1}, "x": "El latido se apaga. La guardia respira mejor."}]}]},
	{"titulo": "La sirena atrapada", "marea": 3, "texto": "Una sirena roja está enredada en una red. No canta: llora.",
		"opciones": [
			{"t": "Liberarla", "r": [{"p": 0.5, "e": {"reliquia": 1}, "x": "Antes de irse te deja una reliquia del fondo del mar."},
				{"p": 0.5, "e": {"luz_noche": -1, "aceite": 3}, "x": "Se lleva un poco de tu luz al irse, pero deja aceite de ballena en la orilla."}]},
			{"t": "Taparte los oídos y seguir", "r": [{"p": 1.0, "e": {"madera": 4}, "x": "La red tiene buena madera de boya. Te la llevas."}]}]},
	{"titulo": "El pescador te ofrece su caña", "marea": 3, "texto": "Un pescador sin cara te tiende una caña. «Pesca lo que quieras», dice sin boca.",
		"opciones": [
			{"t": "Pescar", "r": [{"p": 0.5, "e": {"hierro": 8, "aceite": 4}, "x": "Sacas un ancla entera y un barril."},
				{"p": 0.5, "e": {"faro": -8}, "x": "Algo enorme tira de la caña. Por poco no te arrastra; el faro recibe el golpe del agua."}]},
			{"t": "Rechazarla con educación", "r": [{"p": 1.0, "e": {"luz_noche": 1}, "x": "Asiente y se disuelve. Hay respeto entre la gente del mar."}]}]},
	{"titulo": "El barco helado", "marea": 4, "texto": "Un barco atrapado en el hielo. La tripulación sigue en cubierta, inmóvil.",
		"opciones": [
			{"t": "Saquear la bodega", "r": [{"p": 0.6, "e": {"hierro": 10, "madera": 6}, "x": "Provisiones para un año. Nadie protesta."},
				{"p": 0.4, "e": {"noche_dura": 1, "hierro": 6}, "x": "Al salir, oyes crujir el hielo: la tripulación ha girado la cabeza hacia ti."}]},
			{"t": "Rezar por ellos", "r": [{"p": 1.0, "e": {"escudo_noche": 1, "nivel": 1}, "x": "Sor Alba reza contigo. Algo se calienta dentro de la guardia."}]}]},
	{"titulo": "La aurora habla", "marea": 4, "texto": "La aurora baja hasta el agua y forma palabras en un idioma antiguo.",
		"opciones": [
			{"t": "Escuchar (1 hora)", "r": [{"p": 1.0, "e": {"horas": -1, "ambar": 2}, "x": "Te habla de faros antiguos. Al terminar, tienes ámbar en las manos."}]},
			{"t": "Recoger su luz en frascos", "r": [{"p": 1.0, "e": {"luz_noche": 2}, "x": "La luz de la aurora alumbrará esta noche."}]}]},
	{"titulo": "Lobos en la orilla", "marea": 4, "texto": "Tres lobos de escarcha rodean a un ciervo. Te miran a ti.",
		"opciones": [
			{"t": "Defender al ciervo", "r": [{"p": 0.6, "e": {"nivel": 1}, "x": "La guardia los espanta. El combate les sienta bien."},
				{"p": 0.4, "e": {"faro": -6, "nivel": 1}, "x": "Los espantas, pero dañan la puerta del faro."}]},
			{"t": "Volver despacio", "r": [{"p": 1.0, "e": {}, "x": "Te dejan ir. El ciervo no tiene tanta suerte."}]}]},
	{"titulo": "Ceniza que cae", "marea": 5, "texto": "Del sol negro cae ceniza tibia. En ella hay restos de lentes de otros faros.",
		"opciones": [
			{"t": "Recoger las lentes", "r": [{"p": 1.0, "e": {"luz_noche": 2, "hierro": 4}, "x": "Engarzas los cristales en tu linterna."}]},
			{"t": "Enterrar las lentes", "r": [{"p": 1.0, "e": {"escudo_noche": 1, "ambar": 1}, "x": "Un pequeño funeral por los faros apagados. Se te queda una gota de ámbar en la mano."}]}]},
	{"titulo": "Tu eco", "marea": 5, "texto": "Un farero idéntico a ti te espera en la playa. Dice que él es el de verdad.",
		"opciones": [
			{"t": "Luchar contra él", "r": [{"p": 0.5, "e": {"reliquia": 1, "nivel": 1}, "x": "Ganas. Se deshace y deja algo que era tuyo sin saberlo."},
				{"p": 0.5, "e": {"faro": -12}, "x": "Pierdes. Se lleva un trozo del faro antes de desaparecer."}]},
			{"t": "Invitarle a cenar", "r": [{"p": 1.0, "e": {"aceite": -2, "luz_noche": 2}, "x": "Cenáis en silencio. Al amanecer se ha ido, pero la lámpara arde más fuerte."}]}]},
	{"titulo": "Los faros responden", "marea": 5, "texto": "En el horizonte se enciende un faro lejano. Hace señales: tres largas, una corta.",
		"opciones": [
			{"t": "Responder toda la noche", "r": [{"p": 1.0, "e": {"aceite": -4, "ambar": 2, "nivel": 1}, "x": "Os pasáis la noche hablando con luz. Aprendes mucho."}]},
			{"t": "Guardar el aceite", "r": [{"p": 1.0, "e": {"aceite": 3}, "x": "Mejor no gastar. Pero el otro faro se apaga, decepcionado."}]}]},
]

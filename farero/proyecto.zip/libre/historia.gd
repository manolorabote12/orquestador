class_name Historia
extends RefCounted
## La historia de El Farero (v10): escenas ilustradas con decisiones que cambian lo que pasa después.
## Cada escena llega en una noche concreta de la campaña; lo que eliges mueve tres hilos (Esperanza, Niebla
## y Deuda), da o quita recursos y abre o cierra opciones de escenas futuras. Al final hay tres desenlaces
## y el Libro de la Marea guarda los que ya has visto.

## Condiciones de una opción: "esperanza>=2", "deuda>=1", "eleccion:corsaria=0" (escogiste esa opción).
const ESCENAS: Array = [
	{"id": "naufragos", "noche": 3, "img": "esc_naufragos", "titulo": "Luz para los náufragos",
		"texto": "La tormenta empuja un barco contra los arrecifes. Desde la cubierta, alguien agita un farol pidiendo luz. Si enciendes el faro a tope, gastarás el aceite de esta noche.",
		"opciones": [
			{"t": "Encender el faro a tope", "e": {"aceite": -3, "nivel": 1}, "h": {"esperanza": 1},
				"x": "La luz barre el mar y el barco esquiva las rocas. Los marineros suben al faro empapados y juran defenderlo."},
			{"t": "Guardar la luz para la noche", "e": {"aceite": 2}, "h": {"niebla": 1},
				"x": "El farol se apaga entre las olas. Esa noche oyes una campana bajo el agua que antes no estaba."}]},
	{"id": "campana", "noche": 9, "img": "esc_campana", "titulo": "La campana sumergida",
		"texto": "Bajo el faro hay una cripta inundada. En el centro cuelga una campana verde que tañe sola, y los ahogados la escuchan con los ojos abiertos.",
		"opciones": [
			{"t": "Tocarla para despedirlos", "e": {"escudo_noche": 1}, "h": {"esperanza": 1, "niebla": -1},
				"x": "Los ahogados cierran los ojos y se hunden en paz. Esta noche el mar está más tranquilo."},
			{"t": "Arrancarle el badajo de bronce", "e": {"hierro": 8, "reliquia": 1}, "h": {"niebla": 1},
				"x": "El bronce vale una fortuna. Los ahogados te siguen con la mirada mientras subes la escalera."},
			{"t": "Preguntarles por el barco perdido", "si": "eleccion:naufragos=1", "e": {"luz_noche": 2}, "h": {"esperanza": 1},
				"x": "«No fue culpa tuya», susurran. Te dan la luz que les quedaba."}]},
	{"id": "corsaria", "noche": 15, "img": "esc_corsaria", "titulo": "El pacto de la Corsaria",
		"texto": "La capitana Sable atraca en tu muelle con un saco de oro. Quiere que esta noche apagues el faro una hora para que pase su contrabando.",
		"opciones": [
			{"t": "Aceptar el oro", "e": {"hierro": 10, "ambar": 2}, "h": {"deuda": 2},
				"x": "La Corsaria sonríe. «Volveré a cobrarte el favor, farero». La Guardia del Puerto ya no se fía de ti."},
			{"t": "Rechazarla", "e": {"noche_dura": 1}, "h": {"esperanza": 1},
				"x": "Escupe al agua y zarpa. Esta noche sus aliados de la niebla atacarán con más ganas (y con más botín)."}]},
	{"id": "guardia", "noche": 21, "img": "esc_guardia", "titulo": "La Guardia del Puerto",
		"texto": "Los guardias del puerto suben al faro con faroles y mosquetes. El sargento te mira de arriba abajo.",
		"opciones": [
			{"t": "Pedirles que defiendan el faro", "si": "deuda<=1", "e": {"escudo_noche": 1, "luz_noche": 1}, "h": {"esperanza": 1},
				"x": "«Tu luz nos trajo a casa muchas veces», dice el sargento. Esta noche dos guardias vigilan la escalera."},
			{"t": "Pagar la multa por el contrabando", "si": "deuda>=2", "e": {"hierro": -8}, "h": {"deuda": -1},
				"x": "El sargento cuenta el hierro y se marcha sin decir nada. La deuda pesa un poco menos."},
			{"t": "Echarlos del faro", "e": {"faro": -6}, "h": {"niebla": 1},
				"x": "Se van rompiendo una ventana. Ahora estás solo con la niebla."}]},
	{"id": "nino", "noche": 27, "img": "esc_nino", "titulo": "El niño del barco de papel",
		"texto": "En la orilla, un niño echa barcos de papel al mar. Dice que su padre era el capitán del barco que pidió luz.",
		"opciones": [
			{"t": "Acogerlo en el faro", "e": {"aceite": -2}, "h": {"esperanza": 2},
				"x": "Duerme junto a la lámpara. Por la mañana ha dibujado el faro en la pared, con todos vosotros dentro."},
			{"t": "Llevarlo al pueblo", "e": {"madera": 4}, "h": {},
				"x": "Una familia lo acoge. Te regalan madera seca para el invierno."},
			{"t": "Contarle la verdad del naufragio", "si": "eleccion:naufragos=1", "e": {"nivel": 1}, "h": {"esperanza": 1, "niebla": -1},
				"x": "Llora, y luego te da la mano. «Entonces enciéndelo siempre», te pide."}]},
	{"id": "niebla_habla", "noche": 33, "img": "esc_niebla_habla", "titulo": "La niebla habla",
		"texto": "La niebla toma la forma de un rostro viejo. Te ofrece devolverte a alguien que perdiste... a cambio de un recuerdo.",
		"opciones": [
			{"t": "Aceptar el trato", "e": {"reliquia": 1, "nivel": 1}, "h": {"niebla": 2},
				"x": "Algo vuelve de la niebla. No recuerdas qué has dado a cambio, y eso es lo que más asusta."},
			{"t": "Negarte", "e": {"faro": -8}, "h": {"esperanza": 1},
				"x": "El rostro se deshace en un grito que agrieta los muros. Pero tus recuerdos siguen siendo tuyos."}]},
	{"id": "tormenta", "noche": 39, "img": "esc_tormenta", "titulo": "La serpiente de la tormenta",
		"texto": "Una serpiente de mar del tamaño de un barco se enrosca alrededor del faro vecino. Su luz parpadea.",
		"opciones": [
			{"t": "Desviar tu haz para cegarla", "e": {"aceite": -4, "luz_noche": 2}, "h": {"esperanza": 1},
				"x": "La serpiente se sumerge cegada. El farero vecino te hace señales de agradecimiento toda la noche."},
			{"t": "Dejar que se lleve el otro faro", "e": {"hierro": 6, "madera": 6}, "h": {"niebla": 1},
				"x": "Al amanecer, sus restos llegan a tu playa. Madera y hierro... y una lámpara apagada."}]},
	{"id": "ballena", "noche": 45, "img": "esc_ballena", "titulo": "El cementerio de ballenas",
		"texto": "La marea baja deja al descubierto el esqueleto de una ballena gigante. Entre sus costillas brillan velas que nadie encendió.",
		"opciones": [
			{"t": "Honrarla con una vigilia", "e": {"nivel": 1, "luz_noche": 1}, "h": {"esperanza": 1},
				"x": "Al amanecer las velas se apagan solas. La guardia despierta más fuerte."},
			{"t": "Saquear sus huesos", "e": {"hierro": 8, "madera": 8, "noche_dura": 1}, "h": {"niebla": 1},
				"x": "El hueso de ballena es mejor que el roble. Pero algo grande gime en el fondo del mar."}]},
	{"id": "traicion", "noche": 51, "img": "esc_traicion", "titulo": "Traición en el faro",
		"texto": "Al subir encuentras a una figura encapuchada robando aceite de la lámpara. Es uno de los tuyos.",
		"opciones": [
			{"t": "Perdonarlo", "e": {"aceite": -2}, "h": {"esperanza": 1},
				"x": "Te confiesa que la niebla le prometió volver a casa. Le das la mano. Esta vez se queda."},
			{"t": "Echarlo del faro", "e": {"faro": -6, "luz_noche": 1}, "h": {"niebla": 1},
				"x": "Se lo lleva la niebla antes de llegar al muelle. Recuperas el aceite, pero no la calma."},
			{"t": "Entregarlo a la Corsaria y saldar tu deuda", "si": "deuda>=1", "e": {"ambar": 2}, "h": {"deuda": -3, "niebla": 1},
				"x": "Sable se lo lleva encadenado. «Estamos en paz, farero». No te sientes en paz."}]},
	{"id": "ultima", "noche": 57, "img": "esc_faro_eterno", "titulo": "La última marea",
		"texto": "La niebla negra se acerca por última vez. Antes de encender, tienes que decidir qué harás cuando pase... si pasa.",
		"opciones": [
			{"t": "Mantener el faro encendido para siempre", "e": {"luz_noche": 2}, "h": {}, "final": "eterno",
				"x": "Juras no dejar que la lámpara se apague nunca. Tus héroes juran contigo."},
			{"t": "Ofrecer el faro a la niebla", "e": {"reliquia": 1}, "h": {"niebla": 3}, "final": "niebla",
				"x": "La niebla se enrosca a tus pies como un perro viejo. Ya no tienes miedo. Eso es lo peor."},
			{"t": "Preparar el último barco para los tuyos", "si": "esperanza>=3", "e": {"madera": -6}, "h": {}, "final": "barco",
				"x": "Clavas tablas toda la tarde. Si sobrevivís a esta noche, zarparéis todos juntos."}]},
]

const FINALES: Dictionary = {
	"eterno": {"titulo": "El Faro Eterno", "img": "esc_faro_eterno",
		"texto": "Cuando sale el sol, la niebla se retira hasta el horizonte y no vuelve. Los barcos regresan al puerto guiados por tu luz. Dicen que, desde entonces, el faro nunca se ha apagado."},
	"niebla": {"titulo": "La Niebla Gana", "img": "esc_niebla_gana",
		"texto": "La lámpara sigue encendida, pero ya no es la tuya. Ahora eres tú quien camina dentro de la niebla, y los fareros de otras islas cuentan historias del guardián gris que tañe campanas bajo el agua."},
	"barco": {"titulo": "El Último Barco", "img": "esc_ultimo_barco",
		"texto": "Al amanecer zarpáis todos juntos. El faro queda atrás, encendido una última vez para despediros. Nadie sabe adónde llevará la marea, pero por primera vez no tienes miedo de averiguarlo."},
}

const HILOS: Array[String] = ["esperanza", "niebla", "deuda"]


static func h() -> Dictionary:
	if not Estado.d.has("historia") or not (Estado.d["historia"] is Dictionary):
		Estado.d["historia"] = {"esperanza": 0, "niebla": 0, "deuda": 0, "elecciones": {}, "final": "", "finales": []}
	return Estado.d["historia"] as Dictionary


static func hilo(k: String) -> int:
	return int(h().get(k, 0))


## La escena que toca ahora (la primera de esta noche o anteriores que aún no se ha visto), o -1.
static func pendiente() -> int:
	if Estado.campana_terminada():
		return -1
	var el: Dictionary = h()["elecciones"] as Dictionary
	for i: int in ESCENAS.size():
		var e: Dictionary = ESCENAS[i] as Dictionary
		if Estado.n("noche") >= int(e["noche"]) and not el.has(str(e["id"])):
			return i
	return -1


static func cumple(cond: String) -> bool:
	if cond == "":
		return true
	if cond.begins_with("eleccion:"):
		var p: PackedStringArray = cond.substr(9).split("=")
		var el: Dictionary = h()["elecciones"] as Dictionary
		return el.has(p[0]) and int(el[p[0]]) == int(p[1])
	for op: String in [">=", "<="]:
		if cond.contains(op):
			var p2: PackedStringArray = cond.split(op)
			var v: int = hilo(p2[0])
			return v >= int(p2[1]) if op == ">=" else v <= int(p2[1])
	return true


## Aplica la opción: efectos de juego, hilos de la historia y desenlace. Devuelve {texto, hecho}.
static func elegir(ei: int, oi: int) -> Dictionary:
	var esc: Dictionary = ESCENAS[ei] as Dictionary
	var op: Dictionary = (esc["opciones"] as Array)[oi] as Dictionary
	var hecho: Array[String] = Estado.aplicar_efectos(op.get("e", {}) as Dictionary)
	var hh: Dictionary = h()
	var hilos: Dictionary = op.get("h", {}) as Dictionary
	for k: Variant in hilos.keys():
		var v: int = int(hilos[k])
		hh[str(k)] = maxi(0, int(hh.get(str(k), 0)) + v)
		hecho.append(Idioma.t("%s %+d") % [nombre_hilo(str(k)), v])
	(hh["elecciones"] as Dictionary)[str(esc["id"])] = oi
	if op.has("final"):
		hh["final"] = str(op["final"])
	Estado.guardar()
	return {"texto": str(Idioma.t(op["x"])), "hecho": hecho}


static func nombre_hilo(k: String) -> String:
	return str(Idioma.t({"esperanza": "Esperanza", "niebla": "Niebla", "deuda": "Deuda"}.get(k, k)))


## El desenlace según lo elegido en la última marea y cómo has llevado la historia.
static func final_actual() -> String:
	var f: String = str(h().get("final", ""))
	if f == "eterno" and hilo("niebla") > hilo("esperanza") + 1:
		return "niebla"
	if f == "":
		return "eterno" if hilo("esperanza") >= hilo("niebla") else "niebla"
	return f


## Al ganar la última noche: guarda el desenlace en el Libro de la Marea.
static func cerrar() -> String:
	var f: String = final_actual()
	var vistos: Array = finales_vistos()
	if not vistos.has(f):
		vistos.append(f)
	## Fuera de la partida: el Libro de la Marea sobrevive a empezar de nuevo.
	Save.set_setting("farero_finales", vistos)
	Estado.guardar()
	return f


static func finales_vistos() -> Array:
	var v: Variant = Save.get_setting("farero_finales", [])
	return (v as Array).duplicate() if v is Array else []


## Golpe de mar (sonido sintetizado del juego): se registra una vez.
static func sonidos() -> void:
	if not Audio._streams.has("olas") and ResourceLoader.exists("res://assets/libre/olas.ogg"):
		Audio.register("olas", load("res://assets/libre/olas.ogg") as AudioStream)


# ------------------------------------------------------------------ pantalla de escena
## Panel de pergamino con la ilustración arriba y el texto que se escribe solo. Devuelve el modal.
static func lamina(padre: Control, img: String, titulo: String, texto: String) -> Dictionary:
	var m: Dictionary = Estilo.modal(padre, "", 680.0)
	var pn: PanelContainer = m["panel"] as PanelContainer
	var sp: StyleBoxTexture = Estilo.caja_pintada("f_ui_panel", 0.12, 0.09, Color.WHITE, Vector2(84, 58))
	if sp != null:
		pn.add_theme_stylebox_override("panel", sp)
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	var marco: Control = Control.new()
	marco.custom_minimum_size = Vector2(510, 287)
	marco.clip_contents = true
	vb.add_child(marco)
	var tr: TextureRect = TextureRect.new()
	tr.texture = Estilo.tex(img)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	tr.size = Vector2(510, 287)
	tr.pivot_offset = Vector2(255, 143)
	marco.add_child(tr)
	## La ilustración respira: un acercamiento lento, como en un libro animado.
	var tw: Tween = tr.create_tween().set_loops()
	tw.tween_property(tr, "scale", Vector2(1.08, 1.08), 9.0).set_trans(Tween.TRANS_SINE)
	tw.tween_property(tr, "scale", Vector2.ONE, 9.0).set_trans(Tween.TRANS_SINE)
	var t: Label = Estilo.etiqueta(titulo, 36, Color("5a2e0e"))
	t.add_theme_constant_override("outline_size", 0)
	vb.add_child(t)
	var l: Label = Estilo.etiqueta(texto, 24, Color("2e1d0c"), HORIZONTAL_ALIGNMENT_CENTER, true)
	l.add_theme_constant_override("outline_size", 0)
	l.custom_minimum_size = Vector2(500, 0)
	l.visible_ratio = 0.0
	vb.add_child(l)
	l.create_tween().tween_property(l, "visible_ratio", 1.0, clampf(texto.length() / 70.0, 0.8, 3.5))
	m["texto"] = l
	sonidos()
	Audio.play("olas", 0.0, -6.0)
	return m


static func boton_opcion(texto: String, primario: bool) -> Button:
	var b: Button = Estilo.boton(texto, primario, 88)
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.add_theme_font_size_override("font_size", 22)
	return b

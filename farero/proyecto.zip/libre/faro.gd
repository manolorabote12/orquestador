extends Control
## El faro por dentro: cada planta se mejora por separado (luz, muros, máquinas, enfermería...).

const ISLA: String = "res://libre/isla.tscn"

var _lista: VBoxContainer
var _lbl: Label
var _chips: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	Estilo.fondo_cubrir(self, "bg_faro" if Estilo.tex("bg_faro") != null else "bg_isla", 1.04)
	var vel: ColorRect = ColorRect.new()
	vel.color = Color(0.02, 0.03, 0.06, 0.55)
	vel.size = get_viewport_rect().size
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	var t: Label = Estilo.etiqueta(Idioma.t("El faro"), 44, Estilo.ORO)
	t.position = Vector2(0, 18)
	t.size = Vector2(720, 60)
	add_child(t)
	_chips = Estilo.etiqueta("", 22, Estilo.TEXTO)
	_chips.position = Vector2(0, 80)
	_chips.size = Vector2(720, 34)
	add_child(_chips)
	_lbl = Estilo.etiqueta("", 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
	_lbl.position = Vector2(30, 116)
	_lbl.size = Vector2(660, 64)
	add_child(_lbl)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.position = Vector2(20, 186)
	sc.size = Vector2(680, 960)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	_lista = VBoxContainer.new()
	_lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lista.add_theme_constant_override("separation", 8)
	sc.add_child(_lista)
	var bv: Button = Estilo.boton(Idioma.t("Volver a la isla"), true, 92)
	bv.position = Vector2(20, 1164)
	bv.size = Vector2(680, 92)
	bv.pressed.connect(func() -> void: Kit.change_scene(ISLA))
	add_child(bv)
	_llenar()
	(func() -> void: Consejo.mostrar(self, "faro")).call_deferred()


func _llenar() -> void:
	for c: Node in _lista.get_children():
		c.queue_free()
	var t: Array[String] = []
	for r: String in Datos.RECURSOS:
		t.append(Idioma.t("%s %d") % [Idioma.t(Datos.NOMBRE_RECURSO[r]), Estado.n(r)])
	_chips.text = "   ".join(t)
	_lbl.text = Idioma.t("Integridad %d/%d · Luz máx. %d · +%d de luz por turno · Destello %d") % [Estado.n("faro_hp"), Estado.faro_max(), Estado.luz_max(), Estado.luz_turno(), Estado.destello_dano()]
	var br: Button = Estilo.boton(Idioma.t("Reparar el faro  (1 madera)"), false, 80)
	br.disabled = Estado.n("faro_hp") >= Estado.faro_max() or Estado.n("madera") < 1
	br.pressed.connect(func() -> void:
		if Estado.reparar():
			Audio.play("powerup", 0.05, -4.0)
		_llenar())
	_lista.add_child(br)
	for p: Dictionary in Datos.PLANTAS:
		_planta(p)


func _planta(p: Dictionary) -> void:
	var id: String = str(p["id"])
	var lv: int = Estado.planta(id)
	var mx: int = int(p["max"])
	var card: PanelContainer = Estilo.panel(Color(0.08, 0.1, 0.16, 0.92), Estilo.ORO.darkened(0.35) if lv > 0 else Color(0.3, 0.32, 0.38))
	_lista.add_child(card)
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	card.add_child(hb)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 2)
	hb.add_child(vb)
	vb.add_child(Estilo.etiqueta(Idioma.t("%s  ·  %d/%d") % [Idioma.t(p["nombre"]), lv, mx], 25, Estilo.ORO if lv > 0 else Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT))
	var d: Label = Estilo.etiqueta(str(Idioma.t(p["desc"])), 19, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
	d.custom_minimum_size = Vector2(380, 0)
	vb.add_child(d)
	var pips: Pips = Pips.new(mx, Estilo.ORO, 8.0)
	pips.poner(mx, lv)
	vb.add_child(pips)
	var c: Dictionary = Estado.coste_planta(id)
	var b: Button = Estilo.boton(Idioma.t("Máximo") if lv >= mx else Idioma.t("Mejorar\n") + Estado.texto_coste(c).replace(", ", "\n"), false, 104)
	b.custom_minimum_size = Vector2(176, 104)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.add_theme_font_size_override("font_size", 17)
	b.disabled = lv >= mx or not Estado.puede_pagar(c)
	b.pressed.connect(func() -> void:
		if Estado.mejorar_planta(id):
			Audio.play("powerup")
			Juice.vibrate(40)
		_llenar())
	hb.add_child(b)

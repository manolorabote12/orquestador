class_name Idioma
extends RefCounted
## El texto original está en español; cada idioma es un res://libre/<código>.json (original -> traducción).
## Los textos que se ven tal cual se traducen solos (auto-traducción de Godot); los que se montan con %
## pasan por t(). Añadir un idioma = añadir su .json y su nombre en NOMBRES.

const NOMBRES: Dictionary = {"es": "Español", "en": "English", "pt": "Português", "fr": "Français", "de": "Deutsch", "it": "Italiano"}

static var _listo: bool = false
static var _dic: Dictionary = {}
static var _hay: Array[String] = ["es"]


static func iniciar() -> void:
	if _listo:
		return
	_listo = true
	for code: String in NOMBRES.keys():
		if code == "es":
			continue
		var f: FileAccess = FileAccess.open("res://libre/%s.json" % code, FileAccess.READ)
		if f == null:
			continue
		var d: Variant = JSON.parse_string(f.get_as_text())
		if not d is Dictionary:
			continue
		_dic[code] = d
		_hay.append(code)
		var trad: Translation = Translation.new()
		trad.locale = code
		for k: Variant in (d as Dictionary).keys():
			trad.add_message(str(k), str((d as Dictionary)[k]))
		TranslationServer.add_translation(trad)
	var lang: String = str(Save.get_setting("lang", ""))
	if lang == "" or not _hay.has(lang):
		var sis: String = OS.get_locale_language()
		lang = sis if _hay.has(sis) else ("es" if sis == "es" else "en")
	TranslationServer.set_locale(lang)


static func actual() -> String:
	var l: String = TranslationServer.get_locale().substr(0, 2)
	return l if _hay.has(l) else "es"


static func nombre() -> String:
	return str(NOMBRES.get(actual(), "Español"))


static func cambiar() -> void:
	var i: int = _hay.find(actual())
	var nuevo: String = _hay[(i + 1) % _hay.size()]
	Save.set_setting("lang", nuevo)
	TranslationServer.set_locale(nuevo)


static func t(s: Variant) -> String:
	var txt: String = str(s)
	var l: String = actual()
	if l != "es" and _dic.has(l) and (_dic[l] as Dictionary).has(txt):
		return str((_dic[l] as Dictionary)[txt])
	return txt

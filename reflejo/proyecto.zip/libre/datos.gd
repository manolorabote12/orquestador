class_name Datos
extends RefCounted
## El Reflejo: mundos, obstáculos, patrones, misiones, mejoras, bufandas y recuerdos.

## Metros que dura cada mundo antes de pasar al siguiente (y vuelta a empezar, más rápido).
const METROS_MUNDO: int = 700

const MUNDOS: Array = [
	{"id": "lago", "corte": 0.74, "nombre": "El Lago del Ocaso", "cielo": "cielo_lago", "musica": "carrera_1",
		"arriba": Color("ff9d6c"), "horizonte": Color("ffcf9a"), "abajo": Color("2b1d4a"),
		"suelo": Color("24122b"), "lejos": Color("6b3a63"), "agua": Color("3d2f6e"), "acento": Color("ffd38a")},
	{"id": "bosque", "corte": 0.84, "nombre": "El Bosque Anegado", "cielo": "cielo_bosque", "musica": "carrera_1",
		"arriba": Color("9fd8c3"), "horizonte": Color("e2f3d9"), "abajo": Color("143a3a"),
		"suelo": Color("0f2622"), "lejos": Color("3f6d60"), "agua": Color("1b4a4e"), "acento": Color("c9ff9e")},
	{"id": "ciudad", "corte": 0.93, "nombre": "La Ciudad Hundida", "cielo": "cielo_ciudad", "musica": "carrera_2",
		"arriba": Color("3f6fb0"), "horizonte": Color("8fd3e8"), "abajo": Color("0c1a3a"),
		"suelo": Color("0b1430"), "lejos": Color("26407a"), "agua": Color("123064"), "acento": Color("ffe27a")},
	{"id": "glaciar", "corte": 0.64, "nombre": "El Glaciar de Cristal", "cielo": "cielo_glaciar", "musica": "carrera_2",
		"arriba": Color("a9d6f5"), "horizonte": Color("eefaff"), "abajo": Color("1a3550"),
		"suelo": Color("1b2c44"), "lejos": Color("6f9cc0"), "agua": Color("244a70"), "acento": Color("b9fff2")},
	{"id": "cielo", "corte": 0.95, "nombre": "El Cielo del Revés", "cielo": "cielo_cielo", "musica": "carrera_3",
		"arriba": Color("2a1752"), "horizonte": Color("7a4bb0"), "abajo": Color("08051a"),
		"suelo": Color("120a2a"), "lejos": Color("3c2478"), "agua": Color("1d0f45"), "acento": Color("ffb3f2")},
	{"id": "coral", "corte": 0.9, "nombre": "La Laguna de Coral", "cielo": "cielo_coral", "musica": "carrera_1",
		"arriba": Color("ff9fb2"), "horizonte": Color("ffe0c2"), "abajo": Color("0f4a5a"),
		"suelo": Color("2a1530"), "lejos": Color("b0587a"), "agua": Color("14606e"), "acento": Color("8ff7ff")},
	{"id": "otono", "corte": 0.88, "nombre": "El Lago de Otoño", "cielo": "cielo_otono", "musica": "carrera_1",
		"arriba": Color("e8935a"), "horizonte": Color("ffd8a0"), "abajo": Color("3a1e14"),
		"suelo": Color("2a160c"), "lejos": Color("8a4a2a"), "agua": Color("4a2a1a"), "acento": Color("ffb347")},
	{"id": "desierto", "corte": 0.9, "nombre": "El Oasis Dorado", "cielo": "cielo_desierto", "musica": "carrera_2",
		"arriba": Color("e8b060"), "horizonte": Color("fff0c0"), "abajo": Color("3a2a10"),
		"suelo": Color("3a2410"), "lejos": Color("b07a3a"), "agua": Color("2a5a5a"), "acento": Color("ffe08a")},
	{"id": "tormenta", "corte": 0.9, "nombre": "El Mar de la Tormenta", "cielo": "cielo_tormenta", "musica": "carrera_2",
		"arriba": Color("3a4458"), "horizonte": Color("8a98b0"), "abajo": Color("0a1018"),
		"suelo": Color("0e131c"), "lejos": Color("2a3446"), "agua": Color("142030"), "acento": Color("9fd8ff")},
	{"id": "aurora", "corte": 0.9, "nombre": "El Fiordo de la Aurora", "cielo": "cielo_aurora", "musica": "carrera_3",
		"arriba": Color("123a3a"), "horizonte": Color("7affc8"), "abajo": Color("061418"),
		"suelo": Color("0a1a20"), "lejos": Color("1e4a50"), "agua": Color("0e2a34"), "acento": Color("b0ffd8")},
]

## Corredores: cada uno con su ventaja. Lía es la de siempre.
const CORREDORES: Array = [
	{"id": "lia", "nombre": "Lía", "precio": 0, "texto": "La de siempre. Su bufanda es la tuya.", "tex": ""},
	{"id": "zorro", "nombre": "Kit, la del zorro", "precio": 2500, "texto": "+25% de luces en cada carrera.", "tex": "r_corredor_zorro"},
	{"id": "buho", "nombre": "Nilo, el del búho", "precio": 5000, "texto": "Los potenciadores duran un 40% más.", "tex": "r_corredor_buho"},
	{"id": "ciervo", "nombre": "Brisa, la del ciervo", "precio": 8000, "texto": "Empieza cada carrera con burbuja y salta un poco más.", "tex": "r_corredor_ciervo"},
]

## Logros: dan luces la primera vez.
const LOGROS: Array = [
	{"id": "m1000", "nombre": "Mil metros", "texto": "Corre 1000 m en una carrera.", "premio": 200},
	{"id": "m3000", "nombre": "Maratón", "texto": "Corre 3000 m en una carrera.", "premio": 600},
	{"id": "m7000", "nombre": "Al otro lado del mundo", "texto": "Corre 7000 m en una carrera.", "premio": 1500},
	{"id": "mundos", "nombre": "Diez mundos", "texto": "Llega al Fiordo de la Aurora.", "premio": 1000},
	{"id": "combo8", "nombre": "Por los pelos", "texto": "Llega a combo x8.", "premio": 400},
	{"id": "cambios60", "nombre": "Ida y vuelta", "texto": "Cambia de mundo 60 veces en una carrera.", "premio": 300},
	{"id": "recuerdos", "nombre": "La historia de Lía", "texto": "Encuentra los 15 fragmentos.", "premio": 2000},
	{"id": "reflejo10", "nombre": "Reflejo x10", "texto": "Llega al nivel de reflejo 10.", "premio": 800},
	{"id": "corredor", "nombre": "Nueva cara", "texto": "Consigue otro corredor.", "premio": 300},
	{"id": "espejos5", "nombre": "Reparadora", "texto": "Repara 5 espejos rotos en una carrera.", "premio": 500},
	{"id": "fantasma", "nombre": "Mejor que ayer", "texto": "Adelanta a tu fantasma.", "premio": 150},
	{"id": "luces500", "nombre": "Faro", "texto": "Recoge 500 luces en una carrera.", "premio": 500},
]

## Tipos de obstáculo: alto del suelo en el que choca (h0..h1) y ancho. «rama» cuelga: solo choca si saltas.
const TIPOS: Dictionary = {
	"roca": {"w": 58, "h0": 0, "h1": 56},
	"tronco": {"w": 124, "h0": 0, "h1": 46},
	"rama": {"w": 96, "h0": 92, "h1": 2000},
	"muro": {"w": 64, "h0": 0, "h1": 2000},
	"alta": {"w": 48, "h0": 0, "h1": 98},
	"pez": {"w": 40, "h0": 0, "h1": 0},
	"remolino": {"w": 96, "h0": -1, "h1": -1},
}

## Patrones: [dx, mundo, tipo]. Mundo «A» o «B»: al colocarlos se sortea cuál es arriba y cuál abajo.
## «n» es la dificultad mínima (0 al empezar, sube con los metros). «largo» es lo que ocupan.
const PATRONES: Array = [
	{"id": "salto", "n": 0, "largo": 60, "obs": [[0, "A", "roca"]]},
	{"id": "salto_b", "n": 0, "largo": 60, "obs": [[0, "B", "roca"]]},
	{"id": "tronco", "n": 0, "largo": 124, "obs": [[0, "A", "tronco"]]},
	{"id": "cambio", "n": 0, "largo": 64, "obs": [[0, "A", "muro"]]},
	{"id": "rama", "n": 1, "largo": 96, "obs": [[0, "A", "rama"]]},
	{"id": "rama_roca", "n": 1, "largo": 330, "obs": [[0, "A", "rama"], [260, "A", "roca"]]},
	{"id": "doble_salto", "n": 1, "largo": 300, "obs": [[0, "A", "roca"], [240, "A", "roca"]]},
	{"id": "cruce", "n": 1, "largo": 64, "obs": [[0, "A", "muro"], [0, "B", "roca"]]},
	{"id": "zigzag", "n": 2, "largo": 470, "obs": [[0, "A", "muro"], [400, "B", "muro"]]},
	{"id": "alta", "n": 2, "largo": 52, "obs": [[0, "A", "alta"], [0, "B", "rama"]]},
	{"id": "techo", "n": 2, "largo": 64, "obs": [[0, "A", "muro"], [0, "B", "rama"]]},
	{"id": "escalera", "n": 3, "largo": 560, "obs": [[0, "A", "roca"], [220, "A", "muro"], [220, "B", "roca"], [480, "B", "muro"]]},
	{"id": "pasillo", "n": 3, "largo": 420, "obs": [[0, "A", "muro"], [160, "B", "rama"], [340, "B", "roca"]]},
	{"id": "tijera", "n": 4, "largo": 380, "obs": [[0, "A", "muro"], [0, "B", "alta"], [320, "B", "muro"]]},
	{"id": "eco_salto", "n": 4, "largo": 124, "obs": [[0, "A", "tronco"], [0, "B", "tronco"]]},
	## Peces que saltan de un mundo a otro en arco: hay que cruzar o saltar a tiempo.
	{"id": "pez", "n": 2, "largo": 40, "obs": [[0, "A", "pez"]]},
	{"id": "pez_doble", "n": 3, "largo": 300, "obs": [[0, "A", "pez"], [260, "A", "pez"]]},
	## Remolinos: si los pisas, te arrastran al otro lado. Lo que espera allí decide si conviene saltarlos.
	{"id": "remolino", "n": 2, "largo": 360, "obs": [[0, "A", "remolino"], [300, "B", "roca"]]},
	{"id": "remolino_muro", "n": 3, "largo": 330, "obs": [[0, "A", "remolino"], [270, "B", "muro"]]},
]

## Potenciadores: duración base en segundos y lo que añade cada nivel de mejora.
const PODERES: Dictionary = {
	"burbuja": {"nombre": "Burbuja", "texto": "Aguanta un choque.", "base": 0.0, "por_nivel": 0.0, "color": Color("9fe8ff")},
	"iman": {"nombre": "Imán de luces", "texto": "Atrae las luces de los dos mundos.", "base": 7.0, "por_nivel": 2.0, "color": Color("ffd56b")},
	"eco": {"nombre": "Eco", "texto": "Corres en los dos mundos a la vez.", "base": 6.0, "por_nivel": 1.5, "color": Color("d6a8ff")},
	"calma": {"nombre": "Agua en calma", "texto": "Todo va más despacio y las luces valen doble.", "base": 5.0, "por_nivel": 1.2, "color": Color("8fffd2")},
}
const COSTE_MEJORA: Array = [120, 300, 700, 1400, 2600]
const NIVEL_MAX_MEJORA: int = 5

## Bufandas: solo estética. «arcoiris» y «estrellas» se animan.
const BUFANDAS: Array = [
	{"id": "roja", "nombre": "Roja", "precio": 0, "color": Color("ff4d5e")},
	{"id": "azul", "nombre": "Azul marea", "precio": 400, "color": Color("4da3ff")},
	{"id": "verde", "nombre": "Musgo", "precio": 600, "color": Color("6ee08a")},
	{"id": "dorada", "nombre": "Dorada", "precio": 1200, "color": Color("ffcc4d")},
	{"id": "blanca", "nombre": "Espuma", "precio": 1600, "color": Color("f4f7ff")},
	{"id": "arcoiris", "nombre": "Arcoíris", "precio": 3500, "color": Color("ff8ad8")},
	{"id": "estrellas", "nombre": "Noche estrellada", "precio": 6000, "color": Color("6b4dff")},
]

## Misiones: tipo, objetivo por nivel y texto. Se cumplen dentro de una carrera.
const MISIONES: Array = [
	{"tipo": "metros", "base": 400, "paso": 250, "texto": "Corre %d m en una carrera"},
	{"tipo": "cambios", "base": 20, "paso": 12, "texto": "Cambia de mundo %d veces en una carrera"},
	{"tipo": "luces", "base": 60, "paso": 40, "texto": "Recoge %d luces en una carrera"},
	{"tipo": "rozar", "base": 3, "paso": 2, "texto": "Haz %d «¡por un pelo!» en una carrera"},
	{"tipo": "saltos", "base": 25, "paso": 15, "texto": "Salta %d veces en una carrera"},
	{"tipo": "abajo", "base": 150, "paso": 100, "texto": "Corre %d m seguidos en el reflejo"},
	{"tipo": "arriba", "base": 200, "paso": 120, "texto": "Corre %d m seguidos sin tocar el agua"},
	{"tipo": "poderes", "base": 2, "paso": 1, "texto": "Usa %d potenciadores en una carrera"},
	{"tipo": "combo", "base": 3, "paso": 1, "texto": "Llega a combo x%d"},
]
const NIVEL_MAX_REFLEJO: int = 30

## La historia de Lía y su reflejo, en fragmentos de espejo.
const RECUERDOS: Array = [
	"Dicen que el Lago del Ocaso guarda los reflejos de todos los que se han asomado a él.",
	"Una tarde, Lía se asomó y su reflejo no la imitó. Le sonrió, se dio la vuelta y echó a correr.",
	"Lía corrió detrás. Su reflejo corría debajo, por el otro lado del agua, siempre un paso por delante.",
	"«¿Por qué huyes?», preguntó Lía. El agua contestó con un círculo que tardó mucho en deshacerse.",
	"En el bosque anegado, los árboles crecían hacia arriba y hacia abajo. Nadie sabía cuál era el de verdad.",
	"Lía cruzó al reflejo por primera vez. El agua no mojaba. Sabía a tormenta lejana.",
	"Allí abajo, las cosas que Lía había olvidado seguían brillando: una canción, un columpio, una voz.",
	"La voz era de su abuela. Le contaba que el reflejo no huye: va delante para enseñarte el camino.",
	"En la ciudad hundida, las farolas seguían encendidas por si alguien volvía a casa.",
	"El reflejo de Lía se paraba en cada farola. Como si esperara. Como si quisiera que Lía la alcanzara.",
	"Al llegar al glaciar, el reflejo era más nítido que Lía. Lía era la que se estaba borrando.",
	"«Si no te alcanzo, ¿me quedaré en el agua para siempre?» El hielo crujió: no era un sí.",
	"En el cielo del revés, las estrellas estaban debajo y la noche arriba. Lía ya no sabía dónde caer.",
	"Su reflejo le tendió la mano por primera vez. No para que la siguiera: para que corrieran juntas.",
	"Donde el cielo toca el agua no hay arriba ni abajo. Solo dos niñas que son la misma, corriendo.",
]
## Un fragmento cada tantos metros (si aún quedan por encontrar).
const METROS_RECUERDO: int = 450


static func mundo(i: int) -> Dictionary:
	return MUNDOS[posmod(i, MUNDOS.size())] as Dictionary


static func bufanda(id: String) -> Dictionary:
	for b: Variant in BUFANDAS:
		if str((b as Dictionary)["id"]) == id:
			return b as Dictionary
	return BUFANDAS[0] as Dictionary

extends Control
## Portada de El Reflejo: correr, reto del día, misiones, mejoras, bufandas, recuerdos y ajustes.

const JUEGO: String = "res://libre/juego.tscn"

var _modal: Dictionary = {}
var _l_luces: Label
var _t: float = 0.0
var _titulo: Label
var _sombra: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	var cobrado: int = Estado.cobrar_monedero()
	Audio.play_track("menu")
	var bg: TextureRect = Estilo.fondo_cubrir(self, "titulo", 1.02)
	bg.modulate = Color(0.9, 0.9, 0.95)
	var vel: ColorRect = ColorRect.new()
	vel.size = Vector2(720, 1280)
	vel.color = Color(0.03, 0.02, 0.08, 0.18)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	## El título y su reflejo en el agua.
	_titulo = Estilo.etiqueta(Idioma.t("El Reflejo"), 96, Color("fff3ea"))
	_titulo.position = Vector2(0, 108)
	_titulo.size = Vector2(720, 120)
	_titulo.add_theme_constant_override("outline_size", 14)
	_titulo.add_theme_color_override("font_outline_color", Color(0.35, 0.12, 0.25, 0.85))
	add_child(_titulo)
	_sombra = Estilo.etiqueta(Idioma.t("El Reflejo"), 96, Color(0.75, 0.85, 1.0, 0.28))
	_sombra.position = Vector2(0, 334)
	_sombra.size = Vector2(720, 120)
	_sombra.pivot_offset = Vector2(360, 0)
	_sombra.scale = Vector2(1, -1)
	add_child(_sombra)
	var sub: Label = Estilo.etiqueta(Idioma.t("Corre en dos mundos a la vez"), 28, Color("ffe2d2"))
	sub.position = Vector2(0, 346)
	sub.size = Vector2(720, 40)
	add_child(sub)
	var franja: PanelContainer = Estilo.panel(Color(0.06, 0.05, 0.14, 0.78), Color(1.0, 0.62, 0.43, 0.6))
	franja.position = Vector2(60, 586)
	franja.size = Vector2(600, 60)
	franja.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(franja)
	_l_luces = Estilo.etiqueta("", 24, Estilo.ORO)
	franja.add_child(_l_luces)
	_refrescar()
	var vb: VBoxContainer = VBoxContainer.new()
	vb.position = Vector2(110, 660)
	vb.size = Vector2(500, 560)
	vb.add_theme_constant_override("separation", 14)
	add_child(vb)
	var bc: Button = Estilo.boton(Idioma.t("Correr"), true, 104)
	bc.add_theme_font_size_override("font_size", 40)
	bc.pressed.connect(func() -> void: correr(false))
	vb.add_child(bc)
	Estilo.pulso(bc)
	var hecho_hoy: bool = Estado.n("reto_dia") == Estado.dia_de_hoy()
	var br: Button = Estilo.boton(Idioma.t("Reto del día") + ((" · %d" % Estado.n("reto_record")) if hecho_hoy else ""), false, 82)
	br.pressed.connect(func() -> void: correr(true))
	vb.add_child(br)
	var fila: HBoxContainer = HBoxContainer.new()
	fila.add_theme_constant_override("separation", 12)
	vb.add_child(fila)
	for par: Array in [[Idioma.t("Misiones"), abrir_misiones], [Idioma.t("Mejoras"), abrir_mejoras]]:
		var b: Button = Estilo.boton(str(par[0]), false, 80)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(par[1] as Callable)
		fila.add_child(b)
	var fila2: HBoxContainer = HBoxContainer.new()
	fila2.add_theme_constant_override("separation", 12)
	vb.add_child(fila2)
	for par: Array in [[Idioma.t("Bufandas"), abrir_bufandas], [Idioma.t("Recuerdos"), abrir_recuerdos]]:
		var b2: Button = Estilo.boton(str(par[0]), false, 80)
		b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b2.pressed.connect(par[1] as Callable)
		fila2.add_child(b2)
	var fila3: HBoxContainer = HBoxContainer.new()
	fila3.add_theme_constant_override("separation", 12)
	vb.add_child(fila3)
	for par: Array in [[Idioma.t("Corredores"), abrir_corredores], [Idioma.t("Logros"), abrir_logros]]:
		var b3: Button = Estilo.boton(str(par[0]), false, 80)
		b3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b3.pressed.connect(par[1] as Callable)
		fila3.add_child(b3)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 72)
	ba.position = Vector2(536, 20)
	ba.size = Vector2(164, 72)
	ba.add_theme_font_size_override("font_size", 22)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	add_child(ba)
	if Estado.n("regalo") != Estado.dia_de_hoy():
		var bg2: Button = Estilo.boton(Idioma.t("Regalo del lago"), false, 72)
		bg2.position = Vector2(20, 20)
		bg2.size = Vector2(230, 72)
		bg2.add_theme_font_size_override("font_size", 22)
		bg2.pressed.connect(func() -> void:
			Estado.d["regalo"] = Estado.dia_de_hoy()
			Estado.d["luces"] = Estado.n("luces") + 60
			Estado.guardar()
			Audio.play("ui_reward")
			bg2.queue_free()
			_refrescar())
		add_child(bg2)
		Estilo.pulso(bg2)
	if cobrado > 0:
		Estilo.confirmar(self, Idioma.t("¡Gracias!"), Idioma.t("Han llegado %d luces.") % cobrado, Idioma.t("Vale"), Idioma.t("Cerrar"), func() -> void: pass)


func _process(dt: float) -> void:
	_t += dt
	_sombra.position.x = sin(_t * 1.3) * 4.0
	_sombra.modulate.a = 0.8 + 0.2 * sin(_t * 2.1)


func _refrescar() -> void:
	_l_luces.text = Idioma.t("✦ %d luces   ·   Récord %d   ·   Reflejo x%d") % [Estado.n("luces"), Estado.n("record"), Estado.n("reflejo")]


func correr(reto: bool) -> void:
	Estado.partida = {"reto": reto}
	Kit.change_scene(JUEGO)


func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}
	_refrescar()


func _boton_cerrar(vb: VBoxContainer) -> void:
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 80)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_corredores() -> void:
	_modal = Estilo.modal(self, Idioma.t("Corredores"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("✦ %d luces") % Estado.n("luces"), 26, Estilo.ORO))
	for x: Variant in Datos.CORREDORES:
		var c: Dictionary = x as Dictionary
		var id: String = str(c["id"])
		var tiene: bool = (Estado.d["corredores"] as Array).has(id)
		var puesto: bool = str(Estado.d.get("corredor", "lia")) == id
		var t: String = Idioma.t(str(c["nombre"])) + "\n" + Idioma.t(str(c["texto"]))
		var b: Button = Estilo.boton(t + "\n" + (Idioma.t("Corriendo") if puesto else (Idioma.t("Elegir") if tiene else "✦ %d" % int(c["precio"]))), puesto, 110)
		b.add_theme_font_size_override("font_size", 19)
		b.disabled = not tiene and Estado.n("luces") < int(c["precio"])
		b.pressed.connect(func() -> void:
			if Estado.comprar_corredor(id):
				if id != "lia":
					Estado.logro("corredor")
				Audio.play("ui_reward")
				_cerrar()
				abrir_corredores())
		vb.add_child(b)
	_boton_cerrar(vb)


func abrir_logros() -> void:
	_modal = Estilo.modal(self, Idioma.t("Logros"), 660.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var tengo: Array = Estado.d["logros"] as Array
	vb.add_child(Estilo.etiqueta("%d / %d" % [tengo.size(), Datos.LOGROS.size()], 24, Estilo.ORO))
	for x: Variant in Datos.LOGROS:
		var l: Dictionary = x as Dictionary
		var hecho: bool = tengo.has(str(l["id"]))
		var e: Label = Estilo.etiqueta(("✓ " if hecho else "· ") + Idioma.t(str(l["nombre"])) + ": " + Idioma.t(str(l["texto"])) + "  ✦%d" % int(l["premio"]), 19,
			Estilo.VERDE if hecho else Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		e.custom_minimum_size = Vector2(580, 0)
		vb.add_child(e)
	_boton_cerrar(vb)


func abrir_misiones() -> void:
	_modal = Estilo.modal(self, Idioma.t("Misiones"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Nivel de reflejo x%d: multiplica tus puntos.") % Estado.n("reflejo"), 23, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	for x: Variant in (Estado.d["misiones"] as Array):
		var m: Dictionary = x as Dictionary
		var p: PanelContainer = Estilo.panel(Color(0.1, 0.1, 0.22, 0.95), Estilo.VERDE if bool(m["hecha"]) else Estilo.ORO_OSC)
		var l: Label = Estilo.etiqueta(("✓  " if bool(m["hecha"]) else "") + Estado.texto_mision(m), 24, Estilo.VERDE if bool(m["hecha"]) else Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
		l.custom_minimum_size = Vector2(540, 0)
		p.add_child(l)
		vb.add_child(p)
	vb.add_child(Estilo.etiqueta(Idioma.t("Cumple las tres para subir de nivel."), 20, Estilo.NIEBLA))
	_boton_cerrar(vb)


func abrir_mejoras() -> void:
	_modal = Estilo.modal(self, Idioma.t("Mejoras"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("✦ %d luces") % Estado.n("luces"), 26, Estilo.ORO))
	for id: String in ["burbuja", "iman", "eco", "calma"]:
		var p: Dictionary = Datos.PODERES[id] as Dictionary
		var fila: HBoxContainer = HBoxContainer.new()
		fila.add_theme_constant_override("separation", 10)
		vb.add_child(fila)
		var col: VBoxContainer = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fila.add_child(col)
		var nv: int = Estado.nivel_mejora(id)
		col.add_child(Estilo.etiqueta("%s  %s" % [Idioma.t(str(p["nombre"])), "●".repeat(nv) + "○".repeat(Datos.NIVEL_MAX_MEJORA - nv)], 23, p["color"] as Color, HORIZONTAL_ALIGNMENT_LEFT))
		var txt: String = Idioma.t(str(p["texto"]))
		if id == "burbuja":
			txt += " " + (Idioma.t("Empiezas cada carrera con una.") if nv > 0 else Idioma.t("Mejórala para empezar con una."))
		else:
			txt += " " + Idioma.t("%.1f s") % Estado.duracion(id)
		var lt: Label = Estilo.etiqueta(txt, 18, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
		lt.custom_minimum_size = Vector2(400, 0)
		col.add_child(lt)
		var coste: int = Estado.coste_mejora(id)
		var b: Button = Estilo.boton(Idioma.t("Máximo") if coste < 0 else "✦ %d" % coste, false, 72)
		b.custom_minimum_size = Vector2(140, 72)
		b.add_theme_font_size_override("font_size", 22)
		b.disabled = coste < 0 or Estado.n("luces") < coste
		b.pressed.connect(func() -> void:
			if Estado.mejorar(id):
				Audio.play("ui_reward")
				_cerrar()
				abrir_mejoras())
		fila.add_child(b)
	if Store.available() or Store.showcase():
		var bt: Button = Estilo.boton(Idioma.t("Tienda"), false, 76)
		bt.pressed.connect(func() -> void:
			_cerrar()
			abrir_tienda())
		vb.add_child(bt)
	_boton_cerrar(vb)


func abrir_tienda() -> void:
	_modal = Estilo.modal(self, Idioma.t("Tienda"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var ps: Dictionary = Store.products()
	for id: Variant in ps.keys():
		var pid: String = str(id)
		var kind: String = str((ps[pid] as Dictionary).get("kind", ""))
		if kind in ["pass", "vip"] or Store.owns(pid) or (kind in ["no_ads", "bundle"] and Store.no_ads()):
			continue
		var b: Button = Estilo.boton("%s\n%s" % [Idioma.t(Store.label(pid)), Store.price(pid)], false, 92)
		b.add_theme_font_size_override("font_size", 21)
		b.pressed.connect(func() -> void: Store.buy(pid))
		vb.add_child(b)
	_boton_cerrar(vb)


func abrir_bufandas() -> void:
	_modal = Estilo.modal(self, Idioma.t("Bufandas"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("✦ %d luces") % Estado.n("luces"), 26, Estilo.ORO))
	var grid: GridContainer = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	vb.add_child(grid)
	for x: Variant in Datos.BUFANDAS:
		var bu: Dictionary = x as Dictionary
		var id: String = str(bu["id"])
		var tiene: bool = Estado.tiene_bufanda(id)
		var puesta: bool = str(Estado.d["bufanda"]) == id
		var t: String = Idioma.t(str(bu["nombre"])) + "\n" + (Idioma.t("Puesta") if puesta else (Idioma.t("Ponérmela") if tiene else "✦ %d" % int(bu["precio"])))
		var b: Button = Estilo.boton(t, puesta, 92)
		b.custom_minimum_size = Vector2(285, 92)
		b.add_theme_font_size_override("font_size", 21)
		b.add_theme_color_override("font_color", (bu["color"] as Color).lightened(0.2) if not puesta else Color("2b1230"))
		b.disabled = not tiene and Estado.n("luces") < int(bu["precio"])
		b.pressed.connect(func() -> void:
			if Estado.comprar_bufanda(id):
				Audio.play("ui_reward")
				_cerrar()
				abrir_bufandas())
		grid.add_child(b)
	_boton_cerrar(vb)


func abrir_recuerdos() -> void:
	_modal = Estilo.modal(self, Idioma.t("Recuerdos"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var tengo: Array = Estado.d["recuerdos"] as Array
	vb.add_child(Estilo.etiqueta(Idioma.t("%d de %d fragmentos") % [tengo.size(), Datos.RECUERDOS.size()], 24, Estilo.NIEBLA))
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(580, 640)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.add_theme_constant_override("separation", 12)
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(lista)
	for i: int in Datos.RECUERDOS.size():
		var l: Label = Estilo.etiqueta(("%d. " % (i + 1)) + (Idioma.t(str(Datos.RECUERDOS[i])) if tengo.has(i) else Idioma.t("Aún no has encontrado este fragmento.")), 21,
			Estilo.TEXTO if tengo.has(i) else Color(0.5, 0.52, 0.65), HORIZONTAL_ALIGNMENT_LEFT, true)
		l.custom_minimum_size = Vector2(550, 0)
		lista.add_child(l)
	_boton_cerrar(vb)

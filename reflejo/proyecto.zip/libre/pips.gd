class_name Pips
extends Control
## Fila de circulos (llamas de luz, horas de sol).

var total: int = 3
var llenos: int = 3
var col: Color = Color("e8b857")
var radio: float = 15.0
var separacion: float = 8.0


func _init(t: int = 3, c: Color = Color("e8b857"), r: float = 15.0) -> void:
	total = t
	llenos = t
	col = c
	radio = r
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ajustar()


func poner(t: int, l: int) -> void:
	total = t
	llenos = clampi(l, 0, t)
	_ajustar()
	queue_redraw()


func _ajustar() -> void:
	custom_minimum_size = Vector2(float(total) * (radio * 2.0 + separacion), radio * 2.0 + 6.0)


func _draw() -> void:
	for i: int in total:
		var c: Vector2 = Vector2(radio + float(i) * (radio * 2.0 + separacion), radio + 3.0)
		if i < llenos:
			draw_circle(c, radio + 4.0, Color(col.r, col.g, col.b, 0.22))
			draw_circle(c, radio, col)
			draw_circle(c - Vector2(radio * 0.25, radio * 0.25), radio * 0.45, Color(1, 1, 1, 0.55))
		else:
			draw_arc(c, radio - 1.0, 0.0, TAU, 24, Color(col.r, col.g, col.b, 0.35), 3.0)

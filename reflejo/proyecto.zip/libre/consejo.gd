class_name Consejo
extends RefCounted
## Explicaciones cortas la primera vez que aparece cada cosa y el panel de ajustes.

const TEXTOS: Dictionary = {
	"carrera": ["Dos mundos", "Toca tu mundo para saltar. Toca el otro lado del agua para pasar a tu reflejo. Lo que bloquea un mundo no siempre está en el otro."],
	"rozar": ["¡Por un pelo!", "Si cambias de mundo justo antes de chocar, ganas combo. Cuanto más cerca, más puntos."],
	"eco": ["Eco", "Durante unos segundos corres en los dos mundos a la vez: recoges luces arriba y abajo. Si una de las dos choca, el eco se rompe, pero sigues."],
	"misiones": ["Misiones", "Cumple las tres misiones para subir tu nivel de reflejo: multiplica todos tus puntos."],
	"recuerdos": ["Fragmentos", "A veces el agua deja un fragmento de espejo. Cada uno guarda un recuerdo de la historia de Lía y su reflejo."],
}

static var _abierto: Dictionary = {}


static func visto(clave: String) -> bool:
	return ((Estado.d.get("consejos", {}) as Dictionary).has(clave))


## Lo muestra solo la primera vez. Devuelve true si lo ha mostrado.
static func mostrar(host: Control, clave: String) -> bool:
	if not _abierto.is_empty() and not is_instance_valid(_abierto.get("capa")):
		_abierto = {}
	if visto(clave) or not TEXTOS.has(clave) or not _abierto.is_empty():
		return false
	var c: Dictionary = Estado.d.get("consejos", {}) as Dictionary
	c[clave] = true
	Estado.d["consejos"] = c
	Estado.guardar()
	var t: Array = TEXTOS[clave] as Array
	_abierto = Estilo.modal(host, Idioma.t(t[0]), 600.0)
	var vb: VBoxContainer = _abierto["vb"] as VBoxContainer
	var l: Label = Estilo.etiqueta(Idioma.t(t[1]), 25, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.custom_minimum_size = Vector2(540, 0)
	vb.add_child(l)
	var b: Button = Estilo.boton(Idioma.t("Entendido"), true, 84)
	b.pressed.connect(func() -> void:
		Estilo.cerrar(_abierto)
		_abierto = {})
	vb.add_child(b)
	return true


static func ajustes(host: Control) -> void:
	var m: Dictionary = Estilo.modal(host, Idioma.t("Ajustes"), 620.0)
	var vb: VBoxContainer = m["vb"] as VBoxContainer
	for par: Array in [["music", Idioma.t("Música"), 0.8], ["sfx", Idioma.t("Efectos"), 1.0]]:
		var k: String = str(par[0])
		vb.add_child(Estilo.etiqueta(str(par[1]), 24, Estilo.NIEBLA))
		var s: HSlider = HSlider.new()
		s.min_value = 0.0
		s.max_value = 1.0
		s.step = 0.05
		s.value = float(Save.get_setting(k, par[2]))
		s.custom_minimum_size = Vector2(540, 48)
		s.value_changed.connect(func(v: float) -> void:
			Save.set_setting(k, v)
			if k == "music":
				Audio.apply_music_volume()
			else:
				Audio.play("click"))
		vb.add_child(s)
	var vib: bool = bool(Save.get_setting("haptics", true))
	var bv: Button = Estilo.boton(Idioma.t("Vibración: ") + (Idioma.t("sí") if vib else "no"), false, 76)
	bv.pressed.connect(func() -> void:
		var nv: bool = not bool(Save.get_setting("haptics", true))
		Save.set_setting("haptics", nv)
		bv.text = Idioma.t("Vibración: ") + (Idioma.t("sí") if nv else "no"))
	vb.add_child(bv)
	var bi: Button = Estilo.boton(Idioma.t("Idioma: ") + Idioma.nombre(), false, 76)
	bi.pressed.connect(func() -> void:
		Idioma.cambiar()
		Estilo.cerrar(m)
		host.get_tree().reload_current_scene())
	vb.add_child(bi)
	if Ads.privacy_options_required():
		var bp: Button = Estilo.boton(Idioma.t("Privacidad de los anuncios"), false, 76)
		bp.pressed.connect(Ads.show_privacy_options)
		vb.add_child(bp)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 84)
	bc.pressed.connect(func() -> void: Estilo.cerrar(m))
	vb.add_child(bc)

extends Node2D
## La carrera de El Reflejo. La pantalla está partida por el agua: arriba el mundo, abajo su reflejo.
## Lía corre en uno de los dos; tocar tu mundo = saltar, tocar el otro lado del agua = cruzar al reflejo.
## Los obstáculos de un mundo no siempre están en el otro. Toda la lógica va en paso(dt) para que el
## bot pueda jugar sin pantalla.

const MAIN: String = "res://libre/main.tscn"
const WL: float = 640.0
const SUELO: float = 46.0
const PX: float = 200.0
const ALTO_J: float = 88.0
const MEDIO_J: float = 16.0
const G: float = 2900.0
const V0: float = 930.0
const PX_POR_M: float = 40.0
const T_CAMBIO: float = 0.16
const HORIZONTE_GEN: float = 1900.0

const SHADER_AGUA: String = """
shader_type canvas_item;
uniform sampler2D pantalla : hint_screen_texture, filter_linear_mipmap;
uniform float t = 0.0;
uniform vec4 tinte : source_color = vec4(0.25, 0.2, 0.45, 1.0);
uniform float calma = 0.0;
void fragment() {
	vec2 uv = SCREEN_UV;
	float prof = UV.y;
	float a = mix(0.0035, 0.0012, calma) * (0.4 + prof);
	uv.x += sin(uv.y * 160.0 - t * 2.6) * a + sin(uv.y * 47.0 + t * 1.3) * a * 0.8;
	uv.y += sin(uv.x * 30.0 + t * 1.7) * a * 0.5;
	vec4 c = texture(pantalla, uv);
	float onda = sin(uv.y * 700.0 + sin(uv.x * 18.0 + t * 1.2) * 4.0 - t * 2.0);
	float brillo = smoothstep(0.92, 1.0, onda) * smoothstep(0.5, 0.0, prof) * 0.07 * (0.6 + 0.4 * sin(uv.x * 9.0 + t));
	c.rgb = mix(c.rgb, tinte.rgb, 0.28 + prof * 0.35) + brillo;
	COLOR = vec4(c.rgb, 1.0);
}
"""

## Estado de la carrera
var dist: float = 0.0
var vel: float = 380.0
var mundo: int = 0
var h: float = 0.0
var vh: float = 0.0
var en_suelo: bool = true
var buffer_salto: float = 0.0
var cambio_t: float = 0.0
var cambio_desde: int = 0
var vivo: bool = true
var pausa: bool = false
var revivido: bool = false
var reto: bool = false
var bot: bool = false
var tiempo: float = 0.0
var mundo_i: int = 0
var mezcla: float = 1.0
var mundo_prev: int = 0

var obs: Array = []
var luces: Array = []
var objetos: Array = []
var gen_x: float = 900.0
var dificultad: int = 0
var prox_poder: float = 320.0
var prox_recuerdo: float = 0.0
## Tramo «Espejo roto» al entrar en cada mundo (desde el segundo): zigzags seguidos con estela de luces.
var tramo: int = 0
var _tramo_mundo: int = 0
var _eventos: Array = []
var _tramo_ok: bool = true

var poder_t: Dictionary = {"iman": 0.0, "eco": 0.0, "calma": 0.0, "turbo": 0.0, "estrella": 0.0}
var burbuja: bool = false
var inmune: float = 0.0
var combo: int = 1
var combo_t: float = 0.0
var puntos: float = 0.0
var luces_carrera: int = 0
var recuerdos_carrera: Array = []
var stats: Dictionary = {"metros": 0, "cambios": 0, "luces": 0, "rozar": 0, "saltos": 0, "abajo": 0, "arriba": 0, "poderes": 0, "combo": 1}
var racha_px: float = 0.0
var causa: String = ""
## Fantasma: tu mejor carrera, grabada cada 0,1 s ([distancia, mundo, alto]); corre contigo.
var t_carrera: float = 0.0
var _grabacion: Array = []
var _fantasma: Array = []
var _fantasma_superado: bool = false

var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var _particulas: Array = []
var _textos: Array = []
var _sacudir: float = 0.0
var _capa: Node2D
var _agua: ColorRect
var _mat_agua: ShaderMaterial
var _hud: CanvasLayer
var _l_metros: Label
var _l_luces: Label
var _l_combo: Label
var _l_aviso: Label
var _barras: VBoxContainer
var _modal: Dictionary = {}
var _cielos: Dictionary = {}
var _bufanda: Dictionary = {}
var _pista: String = ""
var _motas: Array = []
var _tex_pez: Texture2D = null
var _tex_obs: Dictionary = {}
var _corredor: Dictionary = {}
var _tex_corredor: Texture2D = null
var v0: float = V0
var _destello: float = 0.0
static var _sonido_agua: AudioStreamWAV = null


func _ready() -> void:
	Estado.cargar()
	reto = bool(Estado.partida.get("reto", false))
	bot = bool(Estado.partida.get("bot", false))
	if bot:
		rng.seed = int(Estado.partida.get("semilla", 1))
	elif reto:
		rng.seed = Estado.dia_de_hoy() * 7919
	else:
		rng.randomize()
	_bufanda = Datos.bufanda(str(Estado.d["bufanda"]))
	_corredor = Estado.corredor()
	burbuja = Estado.nivel_mejora("burbuja") > 0 or str(_corredor["id"]) == "ciervo"
	if str(_corredor["id"]) == "ciervo":
		v0 = V0 * 1.07
	if str(_corredor["id"]) == "sol":
		poder_t["turbo"] = 3.0
	if not bot and str(_corredor["tex"]) != "":
		_tex_corredor = Estilo.tex(str(_corredor["tex"]))
	prox_recuerdo = Datos.METROS_RECUERDO * (1 + rng.randf() * 0.4)
	if not reto and not bot:
		var f: Variant = Save.get_setting("reflejo_fantasma", [])
		_fantasma = f if f is Array else []
	for m: Variant in Datos.MUNDOS:
		var id: String = str((m as Dictionary)["cielo"])
		_cielos[id] = Estilo.tex(id)
	_tex_pez = Estilo.tex("r_pez") if not bot else null
	if not bot:
		for m2: Variant in Datos.MUNDOS:
			for t2: String in ["roca", "tronco", "muro"]:
				var k: String = "o_%s_%s" % [str((m2 as Dictionary)["id"]), t2]
				_tex_obs[k] = Estilo.tex(k)
	var bb: BackBufferCopy = BackBufferCopy.new()
	bb.copy_mode = BackBufferCopy.COPY_MODE_RECT
	bb.rect = Rect2(0, WL, 720, get_viewport_rect().size.y - WL + 40.0)
	add_child(bb)
	_agua = ColorRect.new()
	_agua.position = Vector2(0, WL)
	_agua.size = Vector2(720, get_viewport_rect().size.y - WL + 40.0)
	_agua.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh: Shader = Shader.new()
	sh.code = SHADER_AGUA
	_mat_agua = ShaderMaterial.new()
	_mat_agua.shader = sh
	_agua.material = _mat_agua
	add_child(_agua)
	_capa = Node2D.new()
	_capa.draw.connect(_dibujar_capa)
	add_child(_capa)
	_hacer_hud()
	for i: int in 34:
		_motas.append({"x": rng.randf_range(0, 720), "y": rng.randf_range(40, WL - SUELO - 10), "z": rng.randf_range(0.3, 1.0), "f": rng.randf() * TAU})
	if not bot:
		_preparar_sonidos()
	_generar()
	_pista_mundo()
	if not bot and Consejo.mostrar(_hud.get_child(0) as Control, "carrera"):
		pausa = true
	elif not bot and _fantasma.size() > 20 and Consejo.mostrar(_hud.get_child(0) as Control, "fantasma"):
		pausa = true


func _hacer_hud() -> void:
	_hud = CanvasLayer.new()
	add_child(_hud)
	var raiz: Control = Control.new()
	raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(raiz)
	_l_metros = Estilo.etiqueta("0 m", 40, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT)
	_l_metros.position = Vector2(24, 18)
	_l_metros.size = Vector2(300, 50)
	raiz.add_child(_l_metros)
	_l_luces = Estilo.etiqueta("✦ 0", 28, Estilo.ORO, HORIZONTAL_ALIGNMENT_LEFT)
	_l_luces.position = Vector2(26, 66)
	_l_luces.size = Vector2(300, 36)
	raiz.add_child(_l_luces)
	_l_combo = Estilo.etiqueta("", 30, Estilo.VERDE)
	_l_combo.position = Vector2(160, 20)
	_l_combo.size = Vector2(400, 44)
	raiz.add_child(_l_combo)
	_l_aviso = Estilo.etiqueta("", 30, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_aviso.position = Vector2(60, 150)
	_l_aviso.size = Vector2(600, 90)
	_l_aviso.modulate.a = 0.0
	raiz.add_child(_l_aviso)
	_barras = VBoxContainer.new()
	_barras.position = Vector2(470, 110)
	_barras.size = Vector2(230, 10)
	_barras.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(_barras)
	if Estado.n("carreras") < 2 and not bot:
		## Primeras carreras: qué hace tocar cada mitad.
		for lado: int in 2:
			var pista: Label = Estilo.etiqueta("", 26, Color(1, 1, 1, 0.85), HORIZONTAL_ALIGNMENT_CENTER, true)
			pista.name = "Pista%d" % lado
			pista.position = Vector2(80, 300 if lado == 0 else 900)
			pista.size = Vector2(560, 80)
			raiz.add_child(pista)
	var bp: Button = Estilo.boton("II", false, 80)
	bp.position = Vector2(616, 18)
	bp.size = Vector2(84, 80)
	bp.pressed.connect(abrir_pausa)
	raiz.add_child(bp)


# ------------------------------------------------------------------ entrada

func _unhandled_input(e: InputEvent) -> void:
	if not vivo or pausa or bot:
		return
	if e is InputEventScreenTouch and (e as InputEventScreenTouch).pressed:
		tocar(0 if (e as InputEventScreenTouch).position.y < WL else 1)
	elif e is InputEventKey and (e as InputEventKey).pressed and not (e as InputEventKey).echo:
		var k: Key = (e as InputEventKey).keycode
		if k == KEY_SPACE:
			tocar(mundo)
		elif k == KEY_UP or k == KEY_W:
			tocar(0)
		elif k == KEY_DOWN or k == KEY_S:
			tocar(1)


## Tocar un lado: el tuyo = saltar; el otro = cruzar.
func tocar(lado: int) -> void:
	if lado == mundo:
		saltar()
	else:
		cambiar()


func saltar() -> void:
	if en_suelo:
		vh = v0
		en_suelo = false
		stats["saltos"] = int(stats["saltos"]) + 1
		if not bot:
			Audio.play("salto", 0.1, -6.0)
	else:
		buffer_salto = 0.12


func cambiar() -> void:
	if cambio_t > 0.0:
		return
	_comprobar_rozar()
	cambio_desde = mundo
	mundo = 1 - mundo
	cambio_t = T_CAMBIO
	inmune = maxf(inmune, 0.1)
	racha_px = 0.0
	stats["cambios"] = int(stats["cambios"]) + 1
	if not bot:
		_salpicar(PX, WL, 14)
		Audio.play("agua", 0.12, -3.0, 0.85 if mundo == 1 else 1.15)
		Juice.vibrate(8)


## Cambiar justo antes de un choque: «¡por un pelo!» y sube el combo.
func _comprobar_rozar() -> void:
	var lejos: float = vel * 0.22
	for x: Variant in obs:
		var o: Dictionary = x as Dictionary
		if int(o["m"]) != mundo or bool(o.get("rozado", false)) or str(o["tipo"]) in ["pez", "remolino"]:
			continue
		var ax: float = float(o["x"])
		if ax + float(o["w"]) < dist - MEDIO_J or ax > dist + MEDIO_J + lejos:
			continue
		if _choca_alto(o, h) or _choca_alto(o, 0.0):
			o["rozado"] = true
			stats["rozar"] = int(stats["rozar"]) + 1
			combo = mini(combo + 1, 12)
			combo_t = 4.0
			stats["combo"] = maxi(int(stats["combo"]), combo)
			puntos += 25.0 * combo
			if not bot:
				_texto_flotante(Idioma.t("¡Por un pelo!"), Vector2(PX, WL + (-120.0 if mundo == 1 else 120.0)), Estilo.VERDE)
				Audio.play("rozar", 0.03, -5.0, 1.0 + combo * 0.06)
				if combo == 2:
					Consejo.mostrar(_hud.get_child(0) as Control, "rozar")
			return


# ------------------------------------------------------------------ bucle

func _physics_process(dt: float) -> void:
	if bot:
		return
	if pausa:
		if Consejo._abierto.is_empty() and _modal.is_empty():
			pausa = false
		return
	paso(dt)


func _process(dt: float) -> void:
	tiempo += dt
	_mat_agua.set_shader_parameter("t", tiempo)
	_mat_agua.set_shader_parameter("calma", 1.0 if float(poder_t["calma"]) > 0.0 else 0.0)
	var m: Dictionary = Datos.mundo(mundo_i)
	_mat_agua.set_shader_parameter("tinte", (m["agua"] as Color).lerp(Datos.mundo(mundo_prev)["agua"] as Color, 1.0 - mezcla))
	_actualizar_particulas(dt)
	_destello = maxf(0.0, _destello - dt * 1.4)
	var avance: float = vel * dt * (0.6 if float(poder_t["calma"]) > 0.0 else 1.0) if vivo and not pausa else 0.0
	for mt: Variant in _motas:
		var d: Dictionary = mt as Dictionary
		d["x"] = fposmod(float(d["x"]) - avance * float(d["z"]) * 0.5 - dt * 12.0, 740.0)
		d["f"] = float(d["f"]) + dt
	if _sacudir > 0.0:
		_sacudir = maxf(0.0, _sacudir - dt * 3.0)
		position = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1)) * 14.0 * _sacudir
	else:
		position = Vector2.ZERO
	_hud_refrescar()
	queue_redraw()
	_capa.queue_redraw()


func paso(dt: float) -> void:
	if not vivo:
		return
	var esc: float = 0.6 if float(poder_t["calma"]) > 0.0 else 1.0
	var dtm: float = dt * esc
	var metros_antes: int = int(dist / PX_POR_M)
	vel = minf(370.0 + dist / PX_POR_M * 0.22, 840.0) * (1.8 if float(poder_t["turbo"]) > 0.0 else 1.0)
	dist += vel * dtm
	racha_px += vel * dtm
	var metros: int = int(dist / PX_POR_M)
	stats["metros"] = metros
	if mundo == 1:
		stats["abajo"] = maxi(int(stats["abajo"]), int(racha_px / PX_POR_M))
	else:
		stats["arriba"] = maxi(int(stats["arriba"]), int(racha_px / PX_POR_M))
	puntos += float(metros - metros_antes) * Estado.n("reflejo") * (1.0 + 0.25 * (combo - 1))
	## Física del salto (igual en los dos mundos: abajo es el espejo).
	if not en_suelo:
		vh -= G * dtm
		h += vh * dtm
		if h <= 0.0:
			h = 0.0
			vh = 0.0
			en_suelo = true
			if buffer_salto > 0.0:
				buffer_salto = 0.0
				saltar()
	buffer_salto = maxf(0.0, buffer_salto - dtm)
	t_carrera += dt
	if _grabacion.size() < int(t_carrera * 10.0) and _grabacion.size() < 6000:
		_grabacion.append([snappedf(dist, 0.1), mundo, snappedf(h, 0.1)])
	cambio_t = maxf(0.0, cambio_t - dt)
	inmune = maxf(0.0, inmune - dt)
	for k: String in poder_t.keys():
		poder_t[k] = maxf(0.0, float(poder_t[k]) - dt)
	if combo_t > 0.0:
		combo_t -= dt
		if combo_t <= 0.0:
			combo = 1
	## Mundo (bioma) según los metros.
	var mi: int = int(metros / float(Datos.METROS_MUNDO))
	if mi != mundo_i:
		mundo_prev = mundo_i
		mundo_i = mi
		mezcla = 0.0
		if not bot:
			_avisar(Idioma.t(str(Datos.mundo(mundo_i)["nombre"])))
			_pista_mundo()
			_destello = 1.0
			Juice.vibrate(30)
	mezcla = minf(1.0, mezcla + dt * 0.5)
	dificultad = mini(4, int(metros / 220.0))
	_generar()
	while not _eventos.is_empty() and float((_eventos[0] as Array)[0]) <= dist:
		var ev: String = str((_eventos.pop_front() as Array)[1])
		if ev == "tramo_ini":
			_tramo_ok = true
			if not bot:
				_avisar(Idioma.t("¡Espejo roto! Sigue la estela"))
				_destello = 0.6
		elif ev == "tramo_fin" and _tramo_ok:
			var premio: int = 30 + 10 * mundo_i
			luces_carrera += premio
			puntos += 200.0 * Estado.n("reflejo")
			stats["tramos"] = int(stats.get("tramos", 0)) + 1
			if not bot:
				_avisar(Idioma.t("¡Espejo reparado! +%d luces") % premio)
				Audio.play("ui_reward", 0.0, 0.0, 1.1)
	_recoger()
	_remolinos()
	_chocar()
	_limpiar()
	if not bot and Engine.get_physics_frames() % 30 == 0:
		_misiones_en_vivo()


# ------------------------------------------------------------------ choques

func _choca_alto(o: Dictionary, alto: float) -> bool:
	return alto < float(o["h1"]) - 6.0 and alto + ALTO_J > float(o["h0"]) + 6.0


## Altura del pez en un instante: positiva = arriba, negativa = en el reflejo.
func _alto_pez(o: Dictionary, t: float) -> float:
	return 150.0 * sin(TAU * t / float(o["periodo"]) + float(o["fase"]))


func _choca_en(o: Dictionary, en_mundo: int, alto: float, en_x: float, t_abs: float = -1.0) -> bool:
	var tipo: String = str(o["tipo"])
	if tipo == "remolino":
		return false
	var ax: float = float(o["x"])
	if ax > en_x + MEDIO_J or ax + float(o["w"]) < en_x - MEDIO_J:
		return false
	if tipo == "pez":
		var hp: float = _alto_pez(o, t_carrera if t_abs < 0.0 else t_abs)
		if (0 if hp >= 0.0 else 1) != en_mundo:
			return false
		var hf: float = absf(hp)
		return alto < hf + 16.0 and alto + ALTO_J > hf - 16.0
	if int(o["m"]) != en_mundo:
		return false
	return _choca_alto(o, alto)


## Turbo y estrella: lo que tocas sale volando (y da puntos) en vez de pararte.
func invencible() -> bool:
	return float(poder_t["turbo"]) > 0.0 or float(poder_t["estrella"]) > 0.0


func _chocar() -> void:
	if inmune > 0.0:
		return
	for x: Variant in obs:
		var o: Dictionary = x as Dictionary
		if bool(o.get("roto", false)):
			continue
		if invencible() and _choca_en(o, mundo, h, dist):
			o["roto"] = true
			o["roto_en"] = tiempo
			puntos += 25.0 * Estado.n("reflejo")
			if not bot:
				_sacudir = maxf(_sacudir, 0.35)
				Juice.vibrate(25)
				Audio.play("choque", 0.1, -6.0, 1.4)
				_salpicar(PX + 30.0, _y(mundo, h + 40.0), 26, Datos.PODERES["estrella" if float(poder_t["estrella"]) > 0.0 else "turbo"]["color"] as Color)
			continue
		if _choca_en(o, mundo, h, dist):
			_golpe(o)
			return
		if float(poder_t["eco"]) > 0.0 and _choca_en(o, 1 - mundo, h, dist):
			## El eco choca: se rompe, pero Lía sigue.
			poder_t["eco"] = 0.0
			inmune = 0.4
			if not bot:
				_salpicar(PX, _y(1 - mundo, h + 30.0), 10)
				_avisar(Idioma.t("El eco se ha roto"))
			return


func _remolinos() -> void:
	if h > 4.0 or cambio_t > 0.0:
		return
	for x: Variant in obs:
		var o: Dictionary = x as Dictionary
		if str(o["tipo"]) != "remolino" or int(o["m"]) != mundo or bool(o.get("usado", false)):
			continue
		var ax: float = float(o["x"])
		if ax < dist + MEDIO_J and ax + float(o["w"]) > dist - MEDIO_J:
			o["usado"] = true
			## Te arrastra al otro lado (sin combo).
			cambio_desde = mundo
			mundo = 1 - mundo
			cambio_t = T_CAMBIO
			racha_px = 0.0
			if not bot:
				_salpicar(PX, WL, 20, Color(0.6, 0.85, 1.0))
				Audio.play("agua", 0.05, 0.0, 0.6)
				Juice.vibrate(25)
			return


func _golpe(o: Dictionary) -> void:
	if burbuja:
		burbuja = false
		_tramo_ok = false
		inmune = 0.9
		if not bot:
			_salpicar(PX, _y(mundo, h + 36.0), 22, Datos.PODERES["burbuja"]["color"] as Color)
			Audio.play("ui_error", 0.05, -2.0)
			Juice.vibrate(40)
		return
	vivo = false
	causa = "%s/%s" % [str(o.get("patron", "?")), str(o["tipo"])]
	if bot:
		return
	_sacudir = 1.0
	Juice.vibrate(120)
	Audio.play("choque", 0.0, 0.0)
	_salpicar(PX, _y(mundo, h + 36.0), 30, _bufanda["color"] as Color)
	await get_tree().create_timer(0.7).timeout
	_fin()


# ------------------------------------------------------------------ generación

func _generar() -> void:
	while gen_x < dist + HORIZONTE_GEN:
		var gm: int = int(gen_x / PX_POR_M / float(Datos.METROS_MUNDO))
		if gm > _tramo_mundo:
			_tramo_mundo = gm
			tramo = 5 + mini(gm, 4)
			_eventos.append([gen_x - 200.0, "tramo_ini"])
		var candidatos: Array = Datos.PATRONES.filter(func(p: Variant) -> bool: return int((p as Dictionary)["n"]) <= dificultad)
		if tramo > 0:
			candidatos = Datos.PATRONES.filter(func(p: Variant) -> bool: return str((p as Dictionary)["id"]) in ["zigzag", "cambio", "cruce", "techo", "tijera"] and int((p as Dictionary)["n"]) <= maxi(dificultad, 2))
		var p: Dictionary = candidatos[rng.randi() % candidatos.size()] as Dictionary
		if dist < 40.0 * PX_POR_M and gen_x < 2600.0:
			## Los primeros, de enseñar: un salto y un cambio.
			p = Datos.PATRONES[0 if gen_x < 1400.0 else 3] as Dictionary
		var arriba_a: bool = rng.randf() < 0.5
		for ob: Variant in (p["obs"] as Array):
			var a: Array = ob as Array
			var t: Dictionary = Datos.TIPOS[str(a[2])] as Dictionary
			var m: int = (0 if arriba_a else 1) if str(a[1]) == "A" else (1 if arriba_a else 0)
			obs.append({"x": gen_x + float(a[0]), "m": m, "tipo": str(a[2]), "w": float(t["w"]), "h0": float(t["h0"]), "h1": float(t["h1"]),
				"patron": str(p["id"]), "var": rng.randi() % 3, "fase": rng.randf() * TAU, "periodo": rng.randf_range(1.3, 1.8)})
		var fin: float = gen_x + float(p["largo"])
		var hueco: float = maxf(300.0, vel * 0.8) + rng.randf_range(0.0, 260.0)
		if tramo > 0:
			hueco = maxf(260.0, vel * 0.62) + rng.randf_range(0.0, 80.0)
			_estela(gen_x - 220.0, fin + hueco * 0.6)
			tramo -= 1
			if tramo == 0:
				_eventos.append([fin + 40.0, "tramo_fin"])
			gen_x = fin + hueco
			continue
		_luces_sobre(p, gen_x, arriba_a)
		_hueco(fin, fin + hueco)
		gen_x = fin + hueco


## Arcos de luces encima de lo que hay que saltar: enseñan el salto.
func _luces_sobre(p: Dictionary, x0: float, arriba_a: bool) -> void:
	if rng.randf() > 0.55:
		return
	for ob: Variant in (p["obs"] as Array):
		var a: Array = ob as Array
		var tipo: String = str(a[2])
		if tipo != "roca" and tipo != "tronco":
			continue
		var m: int = (0 if arriba_a else 1) if str(a[1]) == "A" else (1 if arriba_a else 0)
		var cx: float = x0 + float(a[0]) + float((Datos.TIPOS[tipo] as Dictionary)["w"]) / 2.0
		for i: int in 5:
			var f: float = (i - 2) / 2.0
			luces.append({"x": cx + f * 110.0, "m": m, "h": 40.0 + 110.0 * (1.0 - f * f)})
		return


## Estela de luces por el mundo que está libre en cada punto: marca el camino del tramo.
func _estela(x0: float, x1: float) -> void:
	var x: float = x0
	while x < x1:
		var libre: Array = [0, 1].filter(func(m: Variant) -> bool:
			for o: Variant in obs:
				var d: Dictionary = o as Dictionary
				if int(d["m"]) == int(m) and float(d["x"]) < x + 30.0 and float(d["x"]) + float(d["w"]) > x - 30.0:
					return false
			return true)
		if libre.size() == 1:
			luces.append({"x": x, "m": int(libre[0]), "h": 20.0})
		x += 42.0


func _hueco(x0: float, x1: float) -> void:
	var largo: float = x1 - x0
	var m: int = rng.randi() % 2
	var metros: float = x0 / PX_POR_M
	if Estado.siguiente_recuerdo() >= 0 and metros > prox_recuerdo and not reto:
		prox_recuerdo += Datos.METROS_RECUERDO * (1.0 + rng.randf() * 0.5)
		objetos.append({"x": x0 + largo * 0.5, "m": m, "h": 95.0, "id": "recuerdo"})
		return
	if metros > prox_poder:
		prox_poder = metros + rng.randf_range(260.0, 420.0)
		var ids: Array = ["iman", "eco", "calma", "burbuja", "turbo", "iman", "burbuja", "turbo"]
		var pid: String = "estrella" if rng.randf() < (0.3 if str(_corredor.get("id", "")) == "luna" else 0.12) else str(ids[rng.randi() % ids.size()])
		objetos.append({"x": x0 + largo * 0.5, "m": m, "h": 26.0, "id": pid})
		return
	if rng.randf() < 0.7 and largo > 260.0:
		var nl: int = int(minf(8.0, (largo - 140.0) / 46.0))
		var alto: float = 14.0 if rng.randf() < 0.6 else 120.0
		for i: int in nl:
			luces.append({"x": x0 + 90.0 + i * 46.0, "m": m, "h": alto})


func _recoger() -> void:
	var iman: bool = float(poder_t["iman"]) > 0.0
	var eco: bool = float(poder_t["eco"]) > 0.0
	for x: Variant in luces:
		var l: Dictionary = x as Dictionary
		if bool(l.get("tomada", false)):
			continue
		var dx: float = float(l["x"]) - dist
		if dx > 260.0 or dx < -40.0:
			continue
		var mismo: bool = int(l["m"]) == mundo or eco
		if iman and dx < 240.0:
			## El imán las trae (de los dos mundos).
			l["x"] = lerpf(float(l["x"]), dist, 0.2)
			l["h"] = lerpf(float(l["h"]), h + 30.0, 0.2)
			l["m"] = mundo
			mismo = true
		if mismo and absf(dx) < 26.0 and float(l["h"]) > h - 10.0 and float(l["h"]) < h + ALTO_J + 10.0:
			l["tomada"] = true
			var v: int = 2 if float(poder_t["calma"]) > 0.0 else 1
			if float(poder_t["estrella"]) > 0.0:
				v *= 3
			if str(_corredor.get("id", "")) == "zorro" and luces_carrera % 4 == 0:
				v += 1
			luces_carrera += v
			stats["luces"] = int(stats["luces"]) + v
			puntos += 5.0 * Estado.n("reflejo")
			if not bot:
				Audio.play("luz", 0.06, -9.0, 1.0 + (luces_carrera % 8) * 0.05)
				_chispas(PX, _y(int(l["m"]), float(l["h"])), Datos.mundo(mundo_i)["acento"] as Color)
	for x: Variant in objetos:
		var o: Dictionary = x as Dictionary
		if bool(o.get("tomada", false)):
			continue
		var dx: float = float(o["x"]) - dist
		if absf(dx) < 32.0 and (int(o["m"]) == mundo or eco) and float(o["h"]) > h - 16.0 and float(o["h"]) < h + ALTO_J + 16.0:
			o["tomada"] = true
			_tomar(str(o["id"]))


func _tomar(id: String) -> void:
	if id == "recuerdo":
		var i: int = Estado.ganar_recuerdo()
		if i >= 0:
			recuerdos_carrera.append(i)
			Estado.guardar()
			if not bot:
				_avisar(Idioma.t("Fragmento de espejo %d/%d") % [i + 1, Datos.RECUERDOS.size()])
				Audio.play("ui_reward", 0.0, -2.0, 0.8)
				Consejo.mostrar(_hud.get_child(0) as Control, "recuerdos")
				pausa = not Consejo._abierto.is_empty()
		return
	stats["poderes"] = int(stats["poderes"]) + 1
	if id == "burbuja":
		burbuja = true
	else:
		poder_t[id] = Estado.duracion(id) * (1.4 if str(_corredor.get("id", "")) == "buho" else 1.0) * (2.0 if id == "estrella" and str(_corredor.get("id", "")) == "luna" else 1.0)
	if not bot:
		_avisar(Idioma.t(str((Datos.PODERES[id] as Dictionary)["nombre"])))
		Audio.play("ui_big", 0.0, -4.0)
		Juice.vibrate(20)
		if id == "eco":
			Consejo.mostrar(_hud.get_child(0) as Control, "eco")
			pausa = not Consejo._abierto.is_empty()


func _limpiar() -> void:
	var corte: float = dist - 400.0
	obs = obs.filter(func(o: Variant) -> bool: return float((o as Dictionary)["x"]) + float((o as Dictionary)["w"]) > corte)
	luces = luces.filter(func(o: Variant) -> bool: return float((o as Dictionary)["x"]) > corte and not bool((o as Dictionary).get("tomada", false)))
	objetos = objetos.filter(func(o: Variant) -> bool: return float((o as Dictionary)["x"]) > corte and not bool((o as Dictionary).get("tomada", false)))


# ------------------------------------------------------------------ para el bot: ¿sobrevivo si hago esto?

## Simula `plan` ([[segundos, "saltar"|"cambiar"], ...]) durante `horizonte` segundos. Devuelve el
## tiempo que aguanta (== horizonte si no choca). No cuenta eco ni burbuja (prudente).
func simular(plan: Array, horizonte: float) -> float:
	var sm: int = mundo
	var shh: float = h
	var svh: float = vh
	var ssu: bool = en_suelo
	var sx: float = dist
	var t: float = 0.0
	var dt: float = 1.0 / 60.0
	var i: int = 0
	var usados: Array = []
	while t < horizonte:
		while i < plan.size() and float((plan[i] as Array)[0]) <= t + 0.0001:
			var acc: String = str((plan[i] as Array)[1])
			if acc == "saltar" and ssu:
				svh = V0
				ssu = false
			elif acc == "cambiar":
				sm = 1 - sm
			i += 1
		if not ssu:
			svh -= G * dt
			shh += svh * dt
			if shh <= 0.0:
				shh = 0.0
				svh = 0.0
				ssu = true
		sx += vel * dt
		for x: Variant in obs:
			var o: Dictionary = x as Dictionary
			if float(o["x"]) > sx + 200.0:
				continue
			if str(o["tipo"]) == "remolino":
				if ssu and int(o["m"]) == sm and not bool(o.get("usado", false)) and not usados.has(o) \
						and float(o["x"]) < sx + MEDIO_J and float(o["x"]) + float(o["w"]) > sx - MEDIO_J:
					usados.append(o)
					sm = 1 - sm
				continue
			if _choca_en(o, sm, shh, sx, t_carrera + t):
				return t
		t += dt
	return horizonte


# ------------------------------------------------------------------ dibujo

func _y(m: int, alto: float) -> float:
	return WL - SUELO - alto if m == 0 else WL + SUELO + alto


func _draw() -> void:
	var m: Dictionary = Datos.mundo(mundo_i)
	var mp: Dictionary = Datos.mundo(mundo_prev)
	## Cielo arriba (gradiente + pintura) y su reflejo abajo.
	for lado: int in 2:
		if lado == 1:
			draw_set_transform(Vector2(0, 2.0 * WL), 0.0, Vector2(1, -1))
		_cielo(mp, 1.0)
		if mezcla < 1.0:
			_cielo(m, mezcla)
		else:
			_cielo(m, 1.0)
		_siluetas(m, 0.18, m["lejos"] as Color, 140.0, 1)
		_siluetas(m, 0.42, (m["lejos"] as Color).lerp(m["suelo"] as Color, 0.55), 90.0, 2)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _cielo(m: Dictionary, a: float) -> void:
	var arr: Color = m["arriba"] as Color
	var hor: Color = m["horizonte"] as Color
	arr.a = a
	hor.a = a
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(720, 0), Vector2(720, WL), Vector2(0, WL)]),
		PackedColorArray([arr, arr, hor, hor]))
	var tx: Texture2D = _cielos.get(str(m["cielo"])) as Texture2D
	if tx != null:
		var ts: Vector2 = tx.get_size()
		var alto_src: float = ts.y * float(m.get("corte", 0.9))
		var sw: float = minf(ts.x, alto_src * 720.0 / (WL - SUELO * 0.5))
		var src: Rect2 = Rect2((ts.x - sw) / 2.0, alto_src - sw * (WL - SUELO * 0.5) / 720.0, sw, sw * (WL - SUELO * 0.5) / 720.0)
		draw_texture_rect_region(tx, Rect2(0, 0, 720, WL - SUELO * 0.5), src, Color(1, 1, 1, a))


## Siluetas lejanas con parallax; su forma depende del mundo.
func _siluetas(m: Dictionary, par: float, col: Color, alto: float, capa: int) -> void:
	var base: float = WL - SUELO + 2.0
	var off: float = dist * par
	var pts: PackedVector2Array = PackedVector2Array()
	pts.append(Vector2(0, base))
	var tipo: String = str(m["id"])
	var paso_x: float = 10.0
	var x: float = 0.0
	while x <= 730.0:
		var u: float = (x + off) / (90.0 * capa)
		var y: float = 0.0
		match tipo:
			"bosque":
				var fr: float = fposmod(u * 2.0, 1.0)
				y = alto * (0.45 + 0.4 * absf(sin(floor(u * 2.0) * 12.9898))) * (1.0 - absf(fr - 0.5) * 2.0)
			"ciudad":
				var bl: float = floor(u * 1.6)
				y = alto * (0.3 + 0.6 * absf(sin(bl * 7.13 + capa)))
			"glaciar":
				var fr2: float = fposmod(u * 1.3, 1.0)
				y = alto * (0.35 + 0.55 * absf(sin(floor(u * 1.3) * 3.3 + capa))) * (1.0 - absf(fr2 - 0.5) * 2.0) + alto * 0.12
			"cielo":
				y = alto * 0.18 * (1.0 + sin(u * 2.0)) * (0.5 + 0.5 * sin(u * 0.7 + capa))
			_:
				y = alto * (0.35 + 0.25 * sin(u * 1.1 + capa) + 0.15 * sin(u * 2.7 + capa * 2.0))
		pts.append(Vector2(x, base - maxf(0.0, y)))
		x += paso_x
	pts.append(Vector2(720, base))
	draw_colored_polygon(pts, col)


func _dibujar_capa() -> void:
	var m: Dictionary = Datos.mundo(mundo_i)
	var suelo: Color = m["suelo"] as Color
	var acento: Color = m["acento"] as Color
	for lado: int in 2:
		if lado == 1:
			_capa.draw_set_transform(Vector2(0, 2.0 * WL), 0.0, Vector2(1, -1))
		var col_obj: Color = suelo if lado == 0 else suelo.lerp(m["agua"] as Color, 0.35)
		## Orilla con hierba.
		_capa.draw_rect(Rect2(0, WL - SUELO, 720, SUELO), col_obj)
		var gx: float = -fmod(dist, 24.0)
		while gx < 724.0:
			var hh: float = 6.0 + 5.0 * absf(sin((gx + dist) * 0.37))
			_capa.draw_colored_polygon(PackedVector2Array([Vector2(gx, WL - SUELO + 1), Vector2(gx + 6, WL - SUELO - hh), Vector2(gx + 12, WL - SUELO + 1)]), col_obj)
			gx += 24.0
		for x: Variant in obs:
			var o: Dictionary = x as Dictionary
			if str(o["tipo"]) == "pez":
				_pez(o, lado)
			elif int(o["m"]) == lado:
				_obstaculo(o, col_obj, acento, lado)
		for x: Variant in luces:
			var l: Dictionary = x as Dictionary
			if int(l["m"]) == lado:
				_luz(float(l["x"]) - dist + PX, WL - SUELO - float(l["h"]), acento if lado == 0 else (acento as Color).lerp(Color("9fe8ff"), 0.5))
		for x: Variant in objetos:
			var ob: Dictionary = x as Dictionary
			if int(ob["m"]) == lado:
				_objeto(ob)
		_dibujar_fantasma(lado)
		## Lía (o su reflejo, más tenue; con eco, las dos enteras).
		var en_este: bool = mundo == lado
		var alfa: float = 1.0 if en_este or float(poder_t["eco"]) > 0.0 else 0.28
		var hy: float = h
		if cambio_t > 0.0:
			## Cruzando el agua: baja hacia la orilla de un lado y sale por el otro.
			var f: float = cambio_t / T_CAMBIO
			if lado == mundo:
				hy = h - (SUELO + 30.0) * f
				alfa = 1.0 - f * 0.6
			else:
				hy = h - (SUELO + 30.0) * (1.0 - f)
				alfa = 0.28 + f * 0.5
		if vivo or en_este:
			_lia(PX, WL - SUELO - hy, alfa, lado == 1 and not en_este)
		if burbuja and en_este:
			_capa.draw_arc(Vector2(PX, WL - SUELO - hy - 46.0), 66.0, 0.0, TAU, 40, Color(0.62, 0.9, 1.0, 0.55 + 0.2 * sin(tiempo * 5.0)), 4.0, true)
	_capa.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	## La línea del agua.
	var brillo: Color = acento
	brillo.a = 0.55
	_capa.draw_line(Vector2(0, WL), Vector2(720, WL), brillo, 3.0)
	for i: int in 14:
		var sx: float = fposmod(i * 61.0 - dist * 0.9 + sin(tiempo + i) * 20.0, 760.0) - 20.0
		var c: Color = acento
		c.a = 0.3 + 0.3 * sin(tiempo * 3.0 + i)
		_capa.draw_line(Vector2(sx, WL), Vector2(sx + 14.0 + 10.0 * sin(i * 1.7), WL), c, 2.0)
	_dibujar_motas()
	_dibujar_particulas()
	if _destello > 0.0:
		_capa.draw_rect(Rect2(Vector2.ZERO, get_viewport_rect().size + Vector2(0, 40)), Color(1, 0.97, 0.92, _destello * 0.55))


func _obstaculo(o: Dictionary, col: Color, acento: Color, lado: int = 0) -> void:
	var x0: float = float(o["x"]) - dist + PX - float(o["w"]) / 2.0 + float(o["w"]) / 2.0
	var w: float = float(o["w"])
	if x0 > 760.0 or x0 + w < -40.0:
		return
	var base: float = WL - SUELO
	var tipo: String = str(o["tipo"])
	var mid: String = str(Datos.mundo(mundo_i)["id"])
	var luz: Color = acento
	luz.a = 0.75
	## Obstáculos pintados (si están): roca, tronco y pilar de cada mundo.
	var clave: String = "o_%s_%s" % [mid, "roca" if tipo == "alta" else tipo]
	var ptx: Texture2D = _tex_obs.get(clave) as Texture2D
	if bool(o.get("roto", false)):
		## Sale volando dando vueltas (turbo o estrella).
		var tr: float = tiempo - float(o.get("roto_en", tiempo))
		if ptx == null or tr > 1.1 or lado != 0:
			return
		var c: Vector2 = Vector2(x0 + w / 2.0 + 320.0 * tr, base - 60.0 - 520.0 * tr + 700.0 * tr * tr)
		var alr: float = float(o.get("h1", 80.0)) + 14.0
		var anr: float = alr * ptx.get_size().x / ptx.get_size().y
		_capa.draw_set_transform(c, tr * 9.0, Vector2.ONE * (1.0 - tr * 0.3))
		_capa.draw_texture_rect(ptx, Rect2(-anr / 2.0, -alr / 2.0, anr, alr), false, Color(1, 1, 1, clampf(1.2 - tr, 0.0, 1.0)))
		_capa.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		return
	if ptx != null:
		## Luz del mundo sobre el obstáculo (y más fría y apagada en el reflejo).
		var luzm: Color = Datos.mundo(mundo_i)["horizonte"] as Color
		var tinte: Color = Color.WHITE.lerp(luzm, 0.22) if lado == 0 else Color(0.72, 0.82, 1.0, 0.92).lerp(Datos.mundo(mundo_i)["agua"] as Color, 0.25)
		## Sombra de contacto.
		_capa.draw_set_transform(Vector2(x0 + w / 2.0, base + 2.0) if lado == 0 else Vector2(x0 + w / 2.0, 2.0 * WL - base - 2.0), 0.0, Vector2(1.0, 0.2))
		_capa.draw_circle(Vector2.ZERO, w * 0.75 + 10.0, Color(0, 0, 0, 0.35))
		if lado == 0:
			_capa.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			_capa.draw_set_transform(Vector2(0, 2.0 * WL), 0.0, Vector2(1, -1))
		match tipo:
			"roca", "alta":
				var al: float = float(o["h1"]) + 14.0
				var an: float = maxf(w + 20.0, al * ptx.get_size().x / ptx.get_size().y)
				_capa.draw_texture_rect(ptx, Rect2(x0 + w / 2.0 - an / 2.0, base - al + 4.0, an, al), false, tinte)
				_matas(x0 + w / 2.0 - an / 2.0, an, base, col)
				return
			"tronco":
				var al2: float = float(o["h1"]) + 16.0
				_capa.draw_texture_rect(ptx, Rect2(x0 - 10.0, base - al2 + 6.0, w + 20.0, al2), false, tinte)
				_matas(x0 - 10.0, w + 20.0, base, col)
				return
			"muro":
				var an2: float = w + 26.0
				_capa.draw_texture_rect(ptx, Rect2(x0 - 13.0, -10.0, an2, base + 14.0), false, tinte)
				_matas(x0 - 13.0, an2, base, col)
				return
	if tipo == "remolino":
		## Espiral girando sobre la orilla de ese mundo.
		var cx: float = x0 + w / 2.0
		for k: int in 4:
			var r: float = w * 0.5 * (1.0 - k * 0.22)
			var a0: float = -tiempo * (5.0 + k) + k
			var c: Color = Color(0.65, 0.88, 1.0, 0.85 - k * 0.15)
			_capa.draw_arc(Vector2(cx, base + 6.0), r, a0, a0 + PI * 1.3, 18, c, 3.0, true)
		return
	match tipo:
		"roca", "alta":
			var alto: float = float(o["h1"]) + (6.0 if tipo == "roca" else 10.0)
			var pts: PackedVector2Array
			if mid == "ciudad":
				pts = PackedVector2Array([Vector2(x0, base), Vector2(x0, base - alto), Vector2(x0 + w, base - alto), Vector2(x0 + w, base)])
			elif mid == "glaciar" or mid == "cielo":
				pts = PackedVector2Array([Vector2(x0 - 4, base), Vector2(x0 + w * 0.42, base - alto), Vector2(x0 + w * 0.6, base - alto * 0.8), Vector2(x0 + w + 4, base)])
			else:
				pts = PackedVector2Array([Vector2(x0 - 6, base), Vector2(x0, base - alto * 0.6), Vector2(x0 + w * 0.3, base - alto), Vector2(x0 + w * 0.75, base - alto * 0.9), Vector2(x0 + w + 6, base - alto * 0.35), Vector2(x0 + w + 8, base)])
			_capa.draw_colored_polygon(pts, col)
			_capa.draw_polyline(PackedVector2Array([pts[1], pts[2]]), luz, 2.0, true)
		"tronco":
			var alto2: float = float(o["h1"]) + 4.0
			_capa.draw_rect(Rect2(x0, base - alto2, w, alto2), col)
			_capa.draw_circle(Vector2(x0 + w, base - alto2 / 2.0), alto2 / 2.0, col)
			_capa.draw_circle(Vector2(x0, base - alto2 / 2.0), alto2 / 2.0, col)
			_capa.draw_line(Vector2(x0, base - alto2), Vector2(x0 + w, base - alto2), luz, 2.0)
		"rama":
			var y1: float = base - float(o["h0"]) + 4.0
			if mid == "ciudad":
				_capa.draw_line(Vector2(x0 + w / 2.0, -10), Vector2(x0 + w / 2.0, y1 - 40), col, 4.0)
				_capa.draw_rect(Rect2(x0, y1 - 44, w, 44), col)
				var farol: Color = acento
				farol.a = 0.9
				_capa.draw_circle(Vector2(x0 + w / 2.0, y1 - 22), 9.0, farol)
			elif mid == "glaciar":
				var k: float = x0
				while k < x0 + w:
					_capa.draw_colored_polygon(PackedVector2Array([Vector2(k, -10), Vector2(k + 16, -10), Vector2(k + 8, y1 - 4 * sin(k))]), col)
					k += 16.0
				_capa.draw_rect(Rect2(x0 - 4, -10, w + 8, y1 * 0.7), col)
			else:
				_capa.draw_rect(Rect2(x0, -10, w, y1 - 20.0 + 10.0), col)
				_capa.draw_colored_polygon(PackedVector2Array([Vector2(x0 - 14, y1 - 30), Vector2(x0 + w + 14, y1 - 30), Vector2(x0 + w * 0.7, y1), Vector2(x0 + w * 0.3, y1 + 4)]), col)
			_capa.draw_line(Vector2(x0, y1 - 2), Vector2(x0 + w, y1 - 2), luz, 2.0)
		"muro":
			_capa.draw_rect(Rect2(x0, -10, w, base + 10), col)
			_capa.draw_line(Vector2(x0, -10), Vector2(x0, base), luz, 2.0)
			if mid == "ciudad":
				var vy: float = base - 60.0
				while vy > 20.0:
					var vent: Color = acento
					vent.a = 0.5 if int(vy / 50.0 + float(o["var"])) % 3 == 0 else 0.12
					_capa.draw_rect(Rect2(x0 + 14, vy, 12, 18), vent)
					_capa.draw_rect(Rect2(x0 + 38, vy, 12, 18), vent)
					vy -= 56.0
			elif mid == "bosque":
				_capa.draw_colored_polygon(PackedVector2Array([Vector2(x0 - 24, base), Vector2(x0, base - 60), Vector2(x0 + w, base - 60), Vector2(x0 + w + 24, base)]), col)
			elif mid == "glaciar" or mid == "cielo":
				var c2: Color = acento
				c2.a = 0.25
				_capa.draw_rect(Rect2(x0 + 6, -10, 10, base + 10), c2)


## Ambiente de cada mundo: pétalos, luciérnagas, chispas de farol, nieve o estrellas fugaces.
func _dibujar_motas() -> void:
	var id: String = str(Datos.mundo(mundo_i)["id"])
	var ac: Color = Datos.mundo(mundo_i)["acento"] as Color
	for mt: Variant in _motas:
		var d: Dictionary = mt as Dictionary
		var x: float = float(d["x"]) - 10.0
		var f: float = float(d["f"])
		var z: float = float(d["z"])
		var y: float = float(d["y"])
		var c: Color = ac
		match id:
			"lago":
				y += sin(f * 1.3) * 18.0 + fmod(f * 20.0 * z, 80.0)
				c = Color(1.0, 0.75, 0.8, 0.5 * z)
				_capa.draw_colored_polygon(PackedVector2Array([Vector2(x, y), Vector2(x + 5 * z, y + 2), Vector2(x + 2, y + 5 * z)]), c)
			"bosque":
				y += sin(f * 0.9) * 26.0
				c.a = (0.35 + 0.45 * maxf(0.0, sin(f * 3.0))) * z
				_capa.draw_circle(Vector2(x, y), 2.6 * z + 1.0, c)
			"ciudad":
				y -= fmod(f * 30.0 * z, 200.0)
				c.a = 0.5 * z * (1.0 - fmod(f * 30.0 * z, 200.0) / 200.0)
				_capa.draw_circle(Vector2(x, y), 1.8 * z + 0.6, c)
			"glaciar":
				y = fposmod(y + f * 40.0 * z, WL - SUELO - 20.0) + 10.0
				_capa.draw_circle(Vector2(x + sin(f * 2.0) * 8.0, y), 2.2 * z + 0.8, Color(1, 1, 1, 0.6 * z))
			"coral":
				y -= fmod(f * 26.0 * z, 300.0)
				_capa.draw_arc(Vector2(x, y), 2.5 * z + 1.5, 0.0, TAU, 10, Color(0.85, 1.0, 1.0, 0.5 * z), 1.2)
			"otono":
				y += sin(f * 1.1) * 22.0 + fmod(f * 26.0 * z, 120.0)
				_capa.draw_colored_polygon(PackedVector2Array([Vector2(x, y), Vector2(x + 6 * z, y + 3), Vector2(x + 2, y + 7 * z)]), Color(1.0, 0.55 + 0.2 * z, 0.2, 0.7 * z))
			"desierto":
				_capa.draw_line(Vector2(x, y), Vector2(x + 18.0 * z, y + 1.0), Color(1.0, 0.9, 0.6, 0.35 * z), 1.5)
			"tormenta":
				var ry: float = fposmod(y + f * 500.0 * z, WL - SUELO)
				_capa.draw_line(Vector2(x, ry), Vector2(x - 5, ry + 14), Color(0.75, 0.85, 1.0, 0.45 * z), 1.2)
				if fmod(tiempo, 6.0) < 0.003 and not bot:
					_destello = 0.7
			"aurora":
				y = fposmod(y + f * 30.0 * z, WL - SUELO - 20.0) + 10.0
				_capa.draw_circle(Vector2(x + sin(f * 2.0) * 8.0, y), 2.0 * z + 0.8, Color(0.85, 1.0, 0.95, 0.65 * z))
			_:
				var k: float = fmod(f * 0.4 + z, 1.0)
				if k < 0.08:
					var p: Vector2 = Vector2(x + k * 900.0, y * 0.5 + k * 400.0)
					_capa.draw_line(p, p - Vector2(40, 18) * z, Color(1, 0.9, 1.0, 0.7 * (1.0 - k / 0.08)), 2.0)
				else:
					_capa.draw_circle(Vector2(x, y * 0.6), 1.2 * z, Color(1, 1, 1, 0.3 + 0.3 * sin(f * 4.0)))


## Un sonido corto hecho con código: barrido de tono (de f0 a f1) con envolvente y algo de ruido.
static func _tono(f0: float, f1: float, dur: float, decae: float, ruido: float, arm: float = 0.0) -> AudioStreamWAV:
	var rate: int = 22050
	var n: int = int(rate * dur)
	var datos: PackedByteArray = PackedByteArray()
	datos.resize(n * 2)
	var fase: float = 0.0
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = int(f0 * 13.0 + f1)
	for i: int in n:
		var t: float = float(i) / rate
		var fr: float = lerpf(f0, f1, minf(1.0, t / dur))
		fase += TAU * fr / rate
		var env: float = minf(1.0, t * 200.0) * exp(-t * decae)
		var v: float = (sin(fase) + arm * sin(fase * 2.0)) * env * 0.5 + r.randf_range(-1.0, 1.0) * ruido * env
		datos.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
	var w: AudioStreamWAV = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = datos
	return w


static var _sonidos_hechos: bool = false


## Sonido de cruzar el agua: un «plop» hecho con código (barrido de tono + espuma).
func _preparar_sonidos() -> void:
	if not _sonidos_hechos:
		_sonidos_hechos = true
		Audio.register("salto", _tono(300.0, 720.0, 0.18, 9.0, 0.12))
		Audio.register("luz", _tono(1320.0, 1760.0, 0.16, 18.0, 0.0, 0.35))
		Audio.register("choque", _tono(180.0, 55.0, 0.5, 6.0, 0.45))
		Audio.register("rozar", _tono(900.0, 1500.0, 0.22, 10.0, 0.05, 0.5))
	if _sonido_agua == null:
		var rate: int = 22050
		var n: int = int(rate * 0.32)
		var datos: PackedByteArray = PackedByteArray()
		datos.resize(n * 2)
		var fase: float = 0.0
		var r: RandomNumberGenerator = RandomNumberGenerator.new()
		r.seed = 7
		for i: int in n:
			var t: float = float(i) / rate
			var fr: float = lerpf(820.0, 210.0, minf(1.0, t / 0.12))
			fase += TAU * fr / rate
			var env: float = exp(-t * 14.0)
			var espuma: float = r.randf_range(-1.0, 1.0) * exp(-t * 22.0) * 0.25
			var v: float = (sin(fase) * env * 0.55 + espuma) * 0.8
			datos.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 32000.0))
		_sonido_agua = AudioStreamWAV.new()
		_sonido_agua.format = AudioStreamWAV.FORMAT_16_BITS
		_sonido_agua.mix_rate = rate
		_sonido_agua.data = datos
	Audio.register("agua", _sonido_agua)


func _pez(o: Dictionary, lado: int) -> void:
	var hp: float = _alto_pez(o, t_carrera)
	if (0 if hp >= 0.0 else 1) != lado:
		return
	var x: float = float(o["x"]) - dist + PX + float(o["w"]) / 2.0
	if x < -60.0 or x > 780.0:
		return
	var hf: float = absf(hp)
	var y: float = WL - SUELO - hf
	## Dirección del salto (sube o baja) para girarlo.
	var dh: float = _alto_pez(o, t_carrera + 0.05) - hp
	var ang: float = atan2(-dh * (1.0 if lado == 0 else -1.0), 8.0)
	var tx: Texture2D = _tex_pez
	_capa.draw_set_transform(Vector2(x, y) if lado == 0 else Vector2(x, 2.0 * WL - y), ang if lado == 0 else -ang, Vector2(1, 1 if lado == 0 else -1))
	if tx != null:
		var ts: Vector2 = tx.get_size()
		var alto: float = 46.0
		var ancho: float = alto * ts.x / ts.y
		_capa.draw_texture_rect(tx, Rect2(-ancho / 2.0, -alto / 2.0, ancho, alto), false)
	else:
		_capa.draw_circle(Vector2.ZERO, 26.0, Color(1.0, 0.6, 0.3, 0.2))
		_capa.draw_colored_polygon(PackedVector2Array([Vector2(-22, 0), Vector2(-6, -11), Vector2(16, -6), Vector2(22, 0), Vector2(16, 6), Vector2(-6, 11)]), Color("ff8a4c"))
		_capa.draw_colored_polygon(PackedVector2Array([Vector2(-20, 0), Vector2(-34, -12), Vector2(-30, 0), Vector2(-34, 12)]), Color("ffd2b0"))
		_capa.draw_circle(Vector2(13, -2), 2.5, Color(0.1, 0.05, 0.1))
	## Restablece la transformación del lado.
	if lado == 1:
		_capa.draw_set_transform(Vector2(0, 2.0 * WL), 0.0, Vector2(1, -1))
	else:
		_capa.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


## Matas de hierba delante de la base de un obstáculo: lo «planta» en la orilla.
func _matas(x0: float, ancho: float, base: float, col: Color) -> void:
	var x: float = x0 - 4.0
	var k: int = 0
	while x < x0 + ancho + 4.0:
		var alto: float = 8.0 + float((k * 37) % 9)
		_capa.draw_colored_polygon(PackedVector2Array([Vector2(x, base + 3.0), Vector2(x + 4.0, base - alto), Vector2(x + 8.0, base + 3.0)]), col)
		x += 7.0
		k += 1


var _tex_luz: Texture2D = null
var _tex_pw: Dictionary = {}


func _luz(x: float, y: float, c: Color) -> void:
	if x < -20.0 or x > 740.0:
		return
	var p: float = 0.8 + 0.2 * sin(tiempo * 6.0 + x * 0.05)
	if _tex_luz == null:
		_tex_luz = Estilo.tex("r_luz")
	if _tex_luz != null:
		## Moneda pintada que gira (se estrecha y se ensancha) y brilla.
		var giro: float = absf(cos(tiempo * 3.0 + x * 0.02))
		_capa.draw_circle(Vector2(x, y), 17.0 * p, Color(c, 0.22))
		_capa.draw_texture_rect(_tex_luz, Rect2(x - 14.0 * (0.25 + 0.75 * giro), y - 14.0, 28.0 * (0.25 + 0.75 * giro), 28.0), false, Color(1, 1, 1, c.a if c.a < 1.0 else 1.0))
		return
	var halo: Color = c
	halo.a = 0.25
	_capa.draw_circle(Vector2(x, y), 13.0 * p, halo)
	_capa.draw_circle(Vector2(x, y), 6.0 * p, c)
	_capa.draw_circle(Vector2(x, y), 2.5, Color(1, 1, 1, 0.9))


func _objeto(o: Dictionary) -> void:
	var x: float = float(o["x"]) - dist + PX
	var y: float = WL - SUELO - float(o["h"]) + sin(tiempo * 3.0) * 5.0
	if x < -40.0 or x > 760.0:
		return
	var id: String = str(o["id"])
	if id == "recuerdo":
		var r: float = 20.0
		var a: float = tiempo * 1.5
		var pts: PackedVector2Array = PackedVector2Array([Vector2(x + cos(a) * r * 0.6, y - r), Vector2(x + r * 0.7, y), Vector2(x - cos(a) * r * 0.6, y + r), Vector2(x - r * 0.7, y)])
		_capa.draw_circle(Vector2(x, y), 34.0, Color(1, 1, 1, 0.15 + 0.1 * sin(tiempo * 4.0)))
		_capa.draw_colored_polygon(pts, Color(0.92, 0.97, 1.0, 0.95))
		_capa.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0.6, 0.85, 1.0), 2.0, true)
		return
	var col: Color = (Datos.PODERES[id] as Dictionary)["color"] as Color
	var halo: Color = col
	halo.a = 0.25
	var tid: String = {"burbuja": "r_pw_escudo", "iman": "r_pw_iman", "turbo": "r_pw_turbo", "estrella": "r_pw_estrella", "eco": "r_pw_eco"}.get(id, "")
	if tid != "" and not _tex_pw.has(tid):
		_tex_pw[tid] = Estilo.tex(tid) if ResourceLoader.exists("res://assets/libre/%s.png" % tid) else null
	var tp: Texture2D = _tex_pw.get(tid) as Texture2D
	if tp != null:
		## Icono pintado que flota, late y brilla.
		var lat: float = 1.0 + 0.08 * sin(tiempo * 5.0)
		_capa.draw_circle(Vector2(x, y), 34.0 * lat, halo)
		_capa.draw_texture_rect(tp, Rect2(x - 26.0 * lat, y - 26.0 * lat, 52.0 * lat, 52.0 * lat), false)
		return
	_capa.draw_circle(Vector2(x, y), 28.0, halo)
	_capa.draw_circle(Vector2(x, y), 19.0, col)
	var tinta: Color = Color(0.1, 0.08, 0.2)
	match id:
		"burbuja":
			_capa.draw_arc(Vector2(x, y), 10.0, 0.0, TAU, 20, tinta, 3.0)
		"iman":
			_capa.draw_arc(Vector2(x, y + 2), 9.0, PI, TAU, 16, tinta, 4.0)
			_capa.draw_line(Vector2(x - 9, y + 2), Vector2(x - 9, y + 9), tinta, 4.0)
			_capa.draw_line(Vector2(x + 9, y + 2), Vector2(x + 9, y + 9), tinta, 4.0)
		"eco":
			_capa.draw_circle(Vector2(x - 4, y - 5), 4.0, tinta)
			_capa.draw_circle(Vector2(x + 4, y + 5), 4.0, Color(tinta, 0.5))
		"calma":
			_capa.draw_line(Vector2(x - 10, y - 4), Vector2(x + 10, y - 4), tinta, 3.0)
			_capa.draw_line(Vector2(x - 10, y + 4), Vector2(x + 10, y + 4), tinta, 3.0)


## Lía: silueta con bufanda al viento. `pies_y` es donde pisa (en coordenadas de arriba).
const K: float = 1.3


func _lia(x: float, pies_y: float, alfa: float, reflejo: bool, d_anim: float = -1.0, en_aire: int = -1) -> void:
	if _tex_corredor != null and d_anim < 0.0:
		var ts: Vector2 = _tex_corredor.get_size()
		var alto: float = 120.0
		var ancho: float = alto * ts.x / ts.y
		var fase_c: float = dist / 26.0
		var bote_c: float = 0.0 if h > 2.0 else absf(sin(fase_c)) * 5.0
		var esc_y: float = 1.0 - (0.0 if h > 2.0 else 0.04 * absf(sin(fase_c)))
		var col: Color = Color(1, 1, 1, alfa) if not reflejo else Color(0.75, 0.85, 1.0, alfa)
		_capa.draw_texture_rect(_tex_corredor, Rect2(x - ancho / 2.0, pies_y - alto * esc_y - bote_c, ancho, alto * esc_y), false, col)
		return
	var cuerpo: Color = Color(0.07, 0.05, 0.12, alfa) if not reflejo else Color(0.75, 0.85, 1.0, alfa)
	var fase: float = (dist if d_anim < 0.0 else d_anim) / 26.0
	var aire: bool = h > 2.0 if en_aire < 0 else en_aire == 1
	var P: Callable = func(dx: float, dy: float) -> Vector2: return Vector2(x + dx * K, pies_y + dy * K)
	var bote: float = 0.0 if aire else absf(sin(fase)) * 2.5
	## Piernas
	var p1: float = 4.0 if aire else sin(fase) * 13.0
	var p2: float = -8.0 if aire else -sin(fase) * 13.0
	var lev: float = 10.0 if aire else 0.0
	_capa.draw_line(P.call(0.0, -30.0 - bote), P.call(p1, -lev - maxf(0.0, -cos(fase)) * 7.0), cuerpo, 6.5 * K, true)
	_capa.draw_line(P.call(0.0, -30.0 - bote), P.call(p2, -lev * 0.6 - maxf(0.0, cos(fase)) * 7.0), cuerpo, 6.5 * K, true)
	## Vestido
	_capa.draw_colored_polygon(PackedVector2Array([P.call(-6.0, -58.0 - bote), P.call(7.0, -58.0 - bote), P.call(15.0, -28.0 - bote), P.call(-14.0, -28.0 - bote)]), cuerpo)
	## Brazos
	var b: float = sin(fase) * 11.0
	_capa.draw_line(P.call(0.0, -54.0 - bote), P.call(-b - 5.0, -40.0 - bote), cuerpo, 4.5 * K, true)
	_capa.draw_line(P.call(0.0, -54.0 - bote), P.call(b + 5.0, -40.0 - bote), cuerpo, 4.5 * K, true)
	## Cabeza y pelo
	var cab: Vector2 = P.call(2.0, -68.0 - bote)
	_capa.draw_circle(cab, 10.5 * K, cuerpo)
	_capa.draw_colored_polygon(PackedVector2Array([cab + Vector2(-9, -7) * K, cab + Vector2(-26, 3 + sin(tiempo * 9.0) * 3.0) * K, cab + Vector2(-8, 7) * K]), cuerpo)
	## Bufanda
	var bc: Color = _color_bufanda()
	bc.a = alfa
	var pts: PackedVector2Array = PackedVector2Array()
	var cuello: Vector2 = P.call(1.0, -57.0 - bote)
	for i: int in 10:
		var t: float = i / 9.0
		pts.append(cuello + Vector2(-t * 54.0, sin(tiempo * 12.0 - t * 5.0) * 7.0 * t + t * (10.0 if aire else 3.0)) * K)
	_capa.draw_polyline(pts, bc, 7.5 * K, true)


## El fantasma de tu récord: dónde ibas a estas alturas de tu mejor carrera.
func _dibujar_fantasma(lado: int) -> void:
	if _fantasma.size() < 2:
		return
	var i: int = int(t_carrera * 10.0)
	if i >= _fantasma.size() - 1:
		if not _fantasma_superado and vivo:
			_fantasma_superado = true
			_logro("fantasma")
			_texto_flotante(Idioma.t("¡Has pasado tu récord!"), Vector2(360, WL - 200.0), Estilo.ORO)
			Audio.play("ui_reward", 0.0, -2.0, 1.2)
		return
	var a: Array = _fantasma[i] as Array
	var b: Array = _fantasma[i + 1] as Array
	var f: float = t_carrera * 10.0 - i
	if int(a[1]) != lado:
		return
	var gd: float = lerpf(float(a[0]), float(b[0]), f)
	var gh: float = lerpf(float(a[2]), float(b[2]), f)
	var sx: float = PX + (gd - dist)
	if sx < -60.0 or sx > 780.0:
		return
	_lia(sx, WL - SUELO - gh, 0.32, true, gd, 1 if gh > 2.0 else 0)
	if absf(sx - PX) > 90.0:
		var fnt: Font = Estilo.fuente()
		_capa.draw_string(fnt, Vector2(sx - 60.0, WL - SUELO - gh - 132.0), Idioma.t("tu récord"), HORIZONTAL_ALIGNMENT_CENTER, 120, 18, Color(1, 1, 1, 0.55))


func _color_bufanda() -> Color:
	var id: String = str(_bufanda["id"])
	if id == "arcoiris":
		return Color.from_hsv(fposmod(tiempo * 0.3, 1.0), 0.6, 1.0)
	if id == "estrellas":
		return (_bufanda["color"] as Color).lerp(Color.WHITE, 0.3 + 0.3 * sin(tiempo * 7.0))
	return _bufanda["color"] as Color


# ------------------------------------------------------------------ partículas y textos

func _salpicar(x: float, y: float, n: int, col: Color = Color(0.85, 0.95, 1.0)) -> void:
	for i: int in n:
		var a: float = rng.randf_range(0.0, TAU)
		var v: float = rng.randf_range(80.0, 340.0)
		_particulas.append({"p": Vector2(x, y), "v": Vector2(cos(a), sin(a)) * v, "t": rng.randf_range(0.3, 0.6), "c": col, "r": rng.randf_range(2.0, 5.0)})


func _chispas(x: float, y: float, col: Color) -> void:
	for i: int in 5:
		var a: float = rng.randf_range(0.0, TAU)
		_particulas.append({"p": Vector2(x, y), "v": Vector2(cos(a), sin(a)) * 120.0, "t": 0.3, "c": col, "r": 2.5})


func _actualizar_particulas(dt: float) -> void:
	for p: Variant in _particulas:
		var d: Dictionary = p as Dictionary
		d["p"] = (d["p"] as Vector2) + (d["v"] as Vector2) * dt
		d["v"] = (d["v"] as Vector2) * 0.94
		d["t"] = float(d["t"]) - dt
	_particulas = _particulas.filter(func(p: Variant) -> bool: return float((p as Dictionary)["t"]) > 0.0)
	for tx: Variant in _textos:
		var d2: Dictionary = tx as Dictionary
		d2["t"] = float(d2["t"]) - dt
		d2["p"] = (d2["p"] as Vector2) + Vector2(0, -40.0 * dt)
	_textos = _textos.filter(func(p: Variant) -> bool: return float((p as Dictionary)["t"]) > 0.0)


func _dibujar_particulas() -> void:
	for p: Variant in _particulas:
		var d: Dictionary = p as Dictionary
		var c: Color = d["c"] as Color
		c.a = clampf(float(d["t"]) * 2.5, 0.0, 1.0)
		_capa.draw_circle(d["p"] as Vector2, float(d["r"]), c)
	var f: Font = Estilo.fuente()
	for tx: Variant in _textos:
		var d2: Dictionary = tx as Dictionary
		var c2: Color = d2["c"] as Color
		c2.a = clampf(float(d2["t"]) * 2.0, 0.0, 1.0)
		_capa.draw_string_outline(f, (d2["p"] as Vector2) - Vector2(150, 0), str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 300, 30, 6, Color(0.05, 0.03, 0.1, c2.a))
		_capa.draw_string(f, (d2["p"] as Vector2) - Vector2(150, 0), str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 300, 30, c2)


func _texto_flotante(s: String, p: Vector2, c: Color) -> void:
	_textos.append({"s": s, "p": p, "c": c, "t": 1.0})


func _avisar(s: String) -> void:
	_l_aviso.text = s
	var tw: Tween = _l_aviso.create_tween()
	tw.tween_property(_l_aviso, "modulate:a", 1.0, 0.2)
	tw.tween_interval(1.6)
	tw.tween_property(_l_aviso, "modulate:a", 0.0, 0.5)


# ------------------------------------------------------------------ HUD, pausa, fin

func _hud_refrescar() -> void:
	var raiz: Node = _hud.get_child(0)
	for lado: int in 2:
		var pista: Label = raiz.get_node_or_null("Pista%d" % lado) as Label
		if pista != null:
			if dist > 60.0 * PX_POR_M:
				pista.queue_free()
				continue
			pista.text = Idioma.t("Toca aquí para saltar") if lado == mundo else Idioma.t("Toca aquí para cruzar al otro lado")
			pista.modulate.a = 0.55 + 0.35 * sin(tiempo * 4.0)
	_l_metros.text = "%d m" % int(dist / PX_POR_M)
	_l_luces.text = "✦ %d" % luces_carrera
	_l_combo.text = ("combo x%d" % combo) if combo > 1 else ""
	var activos: Array = []
	for k: String in poder_t.keys():
		if float(poder_t[k]) > 0.0:
			activos.append([k, float(poder_t[k]) / maxf(0.1, Estado.duracion(k))])
	if _barras.get_child_count() != activos.size():
		for c: Node in _barras.get_children():
			c.queue_free()
		for a: Variant in activos:
			var pb: ProgressBar = Estilo.barra((Datos.PODERES[str((a as Array)[0])] as Dictionary)["color"] as Color, 14.0)
			pb.max_value = 1.0
			pb.custom_minimum_size = Vector2(220, 14)
			_barras.add_child(pb)
	for i: int in mini(activos.size(), _barras.get_child_count()):
		(_barras.get_child(i) as ProgressBar).value = float((activos[i] as Array)[1])


func _logro(id: String) -> void:
	if bot:
		return
	var l: Dictionary = Estado.logro(id)
	if not l.is_empty():
		_avisar(Idioma.t("Logro: %s") % Idioma.t(str(l["nombre"])) + "  +%d ✦" % int(l["premio"]))
		Audio.play("ui_reward", 0.0, -2.0, 1.2)


func _misiones_en_vivo() -> void:
	var mm: int = int(stats["metros"])
	if mm >= 1000:
		_logro("m1000")
	if mm >= 3000:
		_logro("m3000")
	if mm >= 7000:
		_logro("m7000")
	if mundo_i >= 9:
		_logro("mundos")
	if int(stats["combo"]) >= 8:
		_logro("combo8")
	if int(stats["cambios"]) >= 60:
		_logro("cambios60")
	if int(stats.get("tramos", 0)) >= 5:
		_logro("espejos5")
	if luces_carrera >= 500:
		_logro("luces500")
	if (Estado.d["recuerdos"] as Array).size() >= Datos.RECUERDOS.size():
		_logro("recuerdos")
	for m: Variant in Estado.comprobar_misiones(stats):
		_avisar(Idioma.t("Misión cumplida: ") + Estado.texto_mision(m as Dictionary))
		Audio.play("ui_reward", 0.0, -3.0)
		Estado.guardar()


func _pista_mundo() -> void:
	var p: String = str(Datos.mundo(mundo_i)["musica"])
	if p != _pista:
		_pista = p
		Audio.play_track(p)


func abrir_pausa() -> void:
	if not vivo or not _modal.is_empty():
		return
	pausa = true
	_modal = Estilo.modal(_hud.get_child(0) as Control, Idioma.t("Pausa"), 560.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	for x: Variant in (Estado.d["misiones"] as Array):
		var ms: Dictionary = x as Dictionary
		vb.add_child(Estilo.etiqueta(("✓ " if bool(ms["hecha"]) else "· ") + Estado.texto_mision(ms), 21,
			Estilo.VERDE if bool(ms["hecha"]) else Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
	var bc: Button = Estilo.boton(Idioma.t("Seguir corriendo"), true, 84)
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 76)
	ba.pressed.connect(func() -> void: Consejo.ajustes(_hud.get_child(0) as Control))
	vb.add_child(ba)
	var bs: Button = Estilo.boton(Idioma.t("Salir"), false, 76)
	bs.pressed.connect(func() -> void:
		_cerrar_modal()
		vivo = false
		_terminar())
	vb.add_child(bs)


func _cerrar_modal() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and vivo and not bot:
		abrir_pausa()


## Choque: ofrecer seguir (una vez) con anuncio o con luces; si no, resultados.
func _fin() -> void:
	if revivido:
		_terminar()
		return
	pausa = true
	_modal = Estilo.modal(_hud.get_child(0) as Control, Idioma.t("¡Te has caído al agua!"), 580.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta("%d m" % int(dist / PX_POR_M), 44, Estilo.TEXTO))
	var coste: int = 150 + int(dist / PX_POR_M / 4.0)
	if Ads.rewarded_available():
		var bad: Button = Estilo.boton(Idioma.t("Ver un anuncio y seguir"), true, 84)
		bad.pressed.connect(func() -> void: _revivir_anuncio(bad))
		vb.add_child(bad)
	var bl: Button = Estilo.boton(Idioma.t("Seguir por %d luces") % coste, false, 80)
	bl.disabled = Estado.n("luces") + luces_carrera < coste
	bl.pressed.connect(func() -> void:
		if luces_carrera >= coste:
			luces_carrera -= coste
		else:
			Estado.d["luces"] = Estado.n("luces") - (coste - luces_carrera)
			luces_carrera = 0
			Estado.guardar()
		_revivir())
	vb.add_child(bl)
	var bn: Button = Estilo.boton(Idioma.t("No, gracias"), false, 76)
	bn.pressed.connect(func() -> void:
		_cerrar_modal()
		_terminar())
	vb.add_child(bn)


func _revivir_anuncio(b: Button) -> void:
	b.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "revivir":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("revivir")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		_revivir()
	else:
		b.disabled = false


func _revivir() -> void:
	_cerrar_modal()
	revivido = true
	vivo = true
	inmune = 2.0
	h = 0.0
	vh = 0.0
	en_suelo = true
	## Fuera lo que tenías delante.
	obs = obs.filter(func(o: Variant) -> bool: return float((o as Dictionary)["x"]) > dist + 700.0 or float((o as Dictionary)["x"]) < dist - 100.0)
	pausa = false
	_avisar(Idioma.t("¡Sigue!"))


func _terminar() -> void:
	pausa = true
	var metros: int = int(dist / PX_POR_M)
	var nuevas: Array = Estado.comprobar_misiones(stats)
	var r: Dictionary = Estado.acabar_carrera(metros, luces_carrera, int(puntos), reto)
	var premio: int = Estado.subir_reflejo()
	if Estado.n("reflejo") >= 10:
		_logro("reflejo10")
	if bool(r["record"]) and not bot:
		Save.set_setting("reflejo_fantasma", _grabacion)
	if not reto and Online.available():
		Online.submit(1, int(puntos))
	_modal = Estilo.modal(_hud.get_child(0) as Control, Idioma.t("¡Nuevo récord!") if bool(r["record"]) else Idioma.t("Carrera terminada"), 600.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta("%d m" % metros, 48, Estilo.TEXTO))
	vb.add_child(Estilo.etiqueta(Idioma.t("Puntos: %d   ·   Luces: %d") % [int(puntos), luces_carrera], 26, Estilo.ORO))
	if reto:
		vb.add_child(Estilo.etiqueta(Idioma.t("Reto del día · tu mejor: %d") % Estado.n("reto_record"), 22, Estilo.NIEBLA))
	for m: Variant in nuevas:
		vb.add_child(Estilo.etiqueta("✓ " + Estado.texto_mision(m as Dictionary), 21, Estilo.VERDE, HORIZONTAL_ALIGNMENT_CENTER, true))
	if premio > 0:
		vb.add_child(Estilo.etiqueta(Idioma.t("¡Nivel de reflejo %d! +%d luces") % [Estado.n("reflejo"), premio], 26, Estilo.VERDE))
	for i: Variant in recuerdos_carrera:
		var l: Label = Estilo.etiqueta("«" + Idioma.t(str(Datos.RECUERDOS[int(i)])) + "»", 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true)
		l.custom_minimum_size = Vector2(540, 0)
		vb.add_child(l)
	if luces_carrera > 0 and Ads.rewarded_available():
		var bd: Button = Estilo.boton(Idioma.t("Ver un anuncio: luces x2"), false, 76)
		bd.pressed.connect(func() -> void: _doblar(bd))
		vb.add_child(bd)
	var bo: Button = Estilo.boton(Idioma.t("Otra vez"), true, 88)
	bo.pressed.connect(func() -> void:
		Ads.show_interstitial("fin_carrera")
		Kit.change_scene("res://libre/juego.tscn"))
	vb.add_child(bo)
	var bi: Button = Estilo.boton(Idioma.t("Inicio"), false, 76)
	bi.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bi)
	Audio.play_track("fin", false)


func _doblar(b: Button) -> void:
	b.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "doblar":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("doblar")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		Estado.d["luces"] = Estado.n("luces") + luces_carrera
		Estado.guardar()
		b.text = Idioma.t("¡+%d luces!") % luces_carrera

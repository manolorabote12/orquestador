class_name Estado
extends RefCounted
## Partida guardada de El Reflejo: luces, récords, mejoras, bufandas, misiones, nivel de reflejo y recuerdos.

const CLAVE: String = "reflejo"

static var d: Dictionary = {}
static var _cargado: bool = false
## Lo que se pasa de una escena a otra (p. ej. {"reto": true}).
static var partida: Dictionary = {}


static func cargar() -> void:
	if _cargado:
		return
	_cargado = true
	Idioma.iniciar()
	var v: Variant = Save.get_setting(CLAVE, {})
	d = (v as Dictionary).duplicate(true) if v is Dictionary else {}
	var base: Dictionary = {"luces": 0, "record": 0, "carreras": 0, "metros_total": 0, "mejoras": {}, "bufandas": ["roja"],
		"bufanda": "roja", "misiones": [], "nivel_misiones": 0, "reflejo": 1, "recuerdos": [], "reto_dia": -1,
		"reto_record": 0, "consejos": {}, "regalo": -1}
	for k: String in base.keys():
		if not d.has(k):
			d[k] = base[k]
	if (d["misiones"] as Array).size() < 3:
		_rellenar_misiones()


static func guardar() -> void:
	Save.set_setting(CLAVE, d)


static func n(k: String) -> int:
	return int(d.get(k, 0))


static func dia_de_hoy() -> int:
	var t: Dictionary = Time.get_date_dict_from_system()
	return int(t["year"]) * 10000 + int(t["month"]) * 100 + int(t["day"])


# ------------------------------------------------------------------ mejoras y bufandas

static func nivel_mejora(id: String) -> int:
	return int((d["mejoras"] as Dictionary).get(id, 0))


static func coste_mejora(id: String) -> int:
	var nv: int = nivel_mejora(id)
	return -1 if nv >= Datos.NIVEL_MAX_MEJORA else int(Datos.COSTE_MEJORA[nv])


static func mejorar(id: String) -> bool:
	var c: int = coste_mejora(id)
	if c < 0 or n("luces") < c:
		return false
	d["luces"] = n("luces") - c
	(d["mejoras"] as Dictionary)[id] = nivel_mejora(id) + 1
	guardar()
	return true


static func duracion(poder: String) -> float:
	var p: Dictionary = Datos.PODERES[poder] as Dictionary
	return float(p["base"]) + float(p["por_nivel"]) * nivel_mejora(poder)


static func tiene_bufanda(id: String) -> bool:
	return (d["bufandas"] as Array).has(id)


static func comprar_bufanda(id: String) -> bool:
	var b: Dictionary = Datos.bufanda(id)
	if tiene_bufanda(id):
		d["bufanda"] = id
		guardar()
		return true
	if n("luces") < int(b["precio"]):
		return false
	d["luces"] = n("luces") - int(b["precio"])
	(d["bufandas"] as Array).append(id)
	d["bufanda"] = id
	guardar()
	return true


## Compras con dinero real (tienda del kit) llegan al monedero: se pasan a luces.
static func cobrar_monedero() -> int:
	var w: int = Save.wallet()
	if w <= 0:
		return 0
	Save.add_wallet(-w)
	d["luces"] = n("luces") + w
	guardar()
	return w


# ------------------------------------------------------------------ misiones

static func _rellenar_misiones() -> void:
	var ms: Array = d["misiones"] as Array
	var usados: Array = ms.map(func(m: Variant) -> String: return str((m as Dictionary)["tipo"]))
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = n("nivel_misiones") * 131 + ms.size() * 17 + n("carreras")
	var intentos: int = 0
	while ms.size() < 3 and intentos < 50:
		intentos += 1
		var t: Dictionary = Datos.MISIONES[rng.randi() % Datos.MISIONES.size()] as Dictionary
		if usados.has(str(t["tipo"])):
			continue
		usados.append(str(t["tipo"]))
		var nv: int = n("nivel_misiones")
		ms.append({"tipo": str(t["tipo"]), "meta": int(t["base"]) + int(t["paso"]) * nv, "hecha": false})
	d["misiones"] = ms


static func texto_mision(m: Dictionary) -> String:
	for t: Variant in Datos.MISIONES:
		if str((t as Dictionary)["tipo"]) == str(m["tipo"]):
			return Idioma.t(str((t as Dictionary)["texto"])) % int(m["meta"])
	return "?"


## Al acabar (o durante) una carrera: marca las misiones cumplidas. Devuelve las nuevas cumplidas.
static func comprobar_misiones(stats: Dictionary) -> Array:
	var nuevas: Array = []
	for x: Variant in (d["misiones"] as Array):
		var m: Dictionary = x as Dictionary
		if bool(m["hecha"]):
			continue
		if int(stats.get(str(m["tipo"]), 0)) >= int(m["meta"]):
			m["hecha"] = true
			nuevas.append(m)
	return nuevas


static func misiones_completas() -> bool:
	return (d["misiones"] as Array).all(func(m: Variant) -> bool: return bool((m as Dictionary)["hecha"]))


## Las tres hechas: sube el nivel de reflejo (multiplicador) y llegan tres nuevas.
static func subir_reflejo() -> int:
	if not misiones_completas():
		return 0
	d["reflejo"] = mini(n("reflejo") + 1, Datos.NIVEL_MAX_REFLEJO)
	d["nivel_misiones"] = n("nivel_misiones") + 1
	d["misiones"] = []
	_rellenar_misiones()
	var premio: int = 100 + 25 * n("nivel_misiones")
	d["luces"] = n("luces") + premio
	guardar()
	return premio


# ------------------------------------------------------------------ recuerdos

static func siguiente_recuerdo() -> int:
	var r: Array = d["recuerdos"] as Array
	return r.size() if r.size() < Datos.RECUERDOS.size() else -1


static func ganar_recuerdo() -> int:
	var i: int = siguiente_recuerdo()
	if i >= 0:
		(d["recuerdos"] as Array).append(i)
	return i


# ------------------------------------------------------------------ fin de carrera

static func acabar_carrera(metros: int, luces: int, puntos: int, reto: bool) -> Dictionary:
	var out: Dictionary = {"record": false, "luces": luces}
	d["carreras"] = n("carreras") + 1
	d["metros_total"] = n("metros_total") + metros
	d["luces"] = n("luces") + luces
	if reto:
		if dia_de_hoy() != n("reto_dia"):
			d["reto_dia"] = dia_de_hoy()
			d["reto_record"] = 0
		if puntos > n("reto_record"):
			d["reto_record"] = puntos
	elif puntos > n("record"):
		d["record"] = puntos
		out["record"] = true
	guardar()
	return out

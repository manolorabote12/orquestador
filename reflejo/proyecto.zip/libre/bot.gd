extends RefCounted
## Bot de El Reflejo: juega carreras de verdad (sin pantalla) decidiendo con juego.simular():
## prueba no hacer nada, saltar, cambiar y cambiar+saltar, y mira si sobrevive el siguiente segundo.
## Si un bot que ve el futuro choca, el patrón es injusto: lo dice con su nombre.

const META_M: int = 7200
const CARRERAS: int = 4


static func jugar(tree: SceneTree) -> Dictionary:
	var res: Array = []
	var muertes: Dictionary = {}
	var t0: int = Time.get_ticks_msec()
	var poderes: int = 0
	var recuerdos: int = 0
	for c: int in CARRERAS:
		Estado.partida = {"bot": true, "semilla": 1000 + c * 37}
		tree.change_scene_to_file("res://libre/juego.tscn")
		for _i: int in 3:
			await tree.process_frame
		var j: Node = tree.current_scene
		if j == null or not j.has_method("paso"):
			return {"ok": false, "error": "no cargo la carrera"}
		var pasos: int = 0
		var plan: Array = []
		while bool(j.get("vivo")) and int(j.get("dist")) / 40 < META_M:
			if pasos % 3 == 0:
				plan = _decidir(j)
				for acc: Variant in plan:
					if str(acc) == "saltar":
						j.call("saltar")
					elif str(acc) == "cambiar":
						j.call("cambiar")
			j.call("paso", 1.0 / 60.0)
			pasos += 1
			if pasos % 600 == 0:
				await tree.process_frame
		var m: int = int(j.get("dist")) / 40
		var st: Dictionary = j.get("stats") as Dictionary
		poderes += int(st.get("poderes", 0))
		recuerdos += (j.get("recuerdos_carrera") as Array).size()
		res.append({"tramos": int(st.get("tramos", 0)), "guardianes": int(st.get("guardianes", 0)), "metros": m, "luces": int(j.get("luces_carrera")), "cambios": int(st["cambios"]), "saltos": int(st["saltos"]), "rozar": int(st["rozar"]),
			"causa": "" if bool(j.get("vivo")) else str(j.get("causa"))})
		if not bool(j.get("vivo")):
			var k: String = str(j.get("causa"))
			muertes[k] = int(muertes.get(k, 0)) + 1
	var total: int = 0
	var llegan: int = 0
	for r: Variant in res:
		total += int((r as Dictionary)["metros"])
		if int((r as Dictionary)["metros"]) >= META_M:
			llegan += 1
	return {"ok": llegan >= CARRERAS - 1, "carreras": res, "media_m": total / CARRERAS, "llegan": llegan, "muertes": muertes,
		"poderes": poderes, "recuerdos": recuerdos, "segundos": (Time.get_ticks_msec() - t0) / 1000.0}


## Elige la primera opción que aguanta 0,9 s (con una segunda decisión a los 0,3 s).
static func _decidir(j: Node) -> Array:
	## Invencible (turbo o estrella): no hace falta esquivar; se queda en su mundo y en el suelo.
	if bool(j.call("invencible")) and float(j.get("poder_t")["turbo"]) + float(j.get("poder_t")["estrella"]) > 1.0:
		return []
	var opciones: Array = [[], ["saltar"], ["cambiar"], ["cambiar", "saltar"]]
	var luego: Array = [[], [[0.3, "saltar"]], [[0.3, "cambiar"]], [[0.3, "cambiar"], [0.3, "saltar"]], [[0.15, "saltar"]], [[0.15, "cambiar"]]]
	var mejor: Array = []
	var mejor_t: float = -1.0
	for o: Variant in opciones:
		var base: Array = []
		for a: Variant in (o as Array):
			base.append([0.0, str(a)])
		for l: Variant in luego:
			var plan: Array = base.duplicate()
			plan.append_array(l as Array)
			var t: float = float(j.call("simular", plan, 0.9))
			if t >= 0.9:
				return o as Array
			if t > mejor_t:
				mejor_t = t
				mejor = o as Array
	return mejor

extends "res://kit/mod_base.gd"

const CORAL: Color = Color(1.0, 0.42, 0.34)
const MAR: Color = Color(0.2, 0.85, 0.9)
const ARENA: Color = Color(1.0, 0.86, 0.45)
const ESPUMA: Color = Color(0.92, 1.0, 1.0)

var _t: float = 0.0
var _last_toast: float = -10.0
var _last_flash: float = -10.0
var _last_shake: float = -10.0
var _combo: int = 0
var _combo_time: float = -10.0
var _decor: Array = []
var _bubble_timer: float = 4.0


func on_level_start() -> void:
	_combo = 0
	_clear_decor()
	_spawn_decor()
	var p: Node2D = player()
	if p != null:
		burst(p.position, MAR, 22)
	flash_screen(Color(0.2, 0.85, 0.9, 0.25), 0.25)
	_say("\u00a1Sube la marea!", MAR, true)


func on_tick(delta: float) -> void:
	_t += delta
	if _combo > 0 and _t - _combo_time > 4.0:
		_combo = 0
	_bubble_timer -= delta
	if _bubble_timer <= 0.0:
		_bubble_timer = 5.0
		var p: Node2D = player()
		if p != null:
			var off: Vector2 = Vector2(randf_range(-260.0, 260.0), randf_range(-180.0, 180.0))
			burst(p.position + off, ESPUMA, 3)


func on_event(event_name: String, data: Dictionary) -> void:
	var p: Node2D = player()
	var at: Vector2 = Vector2.ZERO
	var has_pos: bool = false
	if p != null:
		at = p.position
		has_pos = true
	match event_name:
		"arena_live_start":
			_say("\u00a1A pelear!", CORAL, true)
			_flash(Color(1.0, 0.42, 0.34, 0.2), 0.2)
		"arena_live_match":
			if has_pos:
				burst(at, ARENA, 10)
		"super":
			if has_pos:
				burst(at, ARENA, 30)
			_shake(5.0)
			_flash(Color(1.0, 0.86, 0.45, 0.35), 0.18)
			_say("\u00a1S\u00daPER PINZA!", ARENA, true)
			play_sound("power", 1.1)
		"rival_out":
			_combo += 1
			_combo_time = _t
			if has_pos:
				burst(at, CORAL, 24)
			_shake(4.0)
			if _combo >= 3:
				_flash(Color(1.0, 0.42, 0.34, 0.25), 0.15)
				_say("\u00a1Racha x" + str(_combo) + "!", CORAL, true)
			elif _combo == 2:
				_say("\u00a1Doble pinzazo!", ARENA, false)
			else:
				_say("\u00a1Rival fuera!", CORAL, false)
		"coop_wave":
			_say("\u00a1Otra oleada!", MAR, false)
			if has_pos:
				burst(at, MAR, 14)
		"death":
			if has_pos:
				burst(at, ESPUMA, 18)
			_shake(7.0)
			_flash(Color(1.0, 0.2, 0.2, 0.3), 0.25)
			_say("\u00a1Ay, esa ola!", ESPUMA, true)
			_combo = 0
		"level_complete":
			if has_pos:
				burst(at, ARENA, 40)
				burst(at, MAR, 30)
			_shake(5.0)
			_flash(Color(1.0, 1.0, 1.0, 0.4), 0.3)
			_say("\u00a1Victoria, Capit\u00e1n!", ARENA, true)
			play_sound("win", 1.0)
		"arena_live_end":
			if has_pos:
				burst(at, MAR, 16)


func _say(text: String, col: Color, force: bool) -> void:
	if not force and _t - _last_toast < 1.5:
		return
	if _t - _last_toast < 0.5:
		return
	_last_toast = _t
	toast(text, col)


func _flash(col: Color, secs: float) -> void:
	if _t - _last_flash < 0.8:
		return
	_last_flash = _t
	flash_screen(col, secs)


func _shake(amount: float) -> void:
	if _t - _last_shake < 0.3:
		return
	_last_shake = _t
	shake(amount)


func _clear_decor() -> void:
	for n: Variant in _decor:
		if n is Node and is_instance_valid(n):
			(n as Node).queue_free()
	_decor.clear()


func _spawn_decor() -> void:
	if game == null or not is_instance_valid(game):
		return
	var p: Node2D = player()
	var center: Vector2 = Vector2(576.0, 324.0)
	if p != null:
		center = p.position
	for i: int in range(12):
		var d: Polygon2D = Polygon2D.new()
		var kind: int = i % 3
		if kind == 0:
			d.polygon = _star(9.0, 4.0)
			d.color = Color(1.0, 0.5, 0.4, 0.55)
		elif kind == 1:
			d.polygon = _circle(6.0)
			d.color = Color(1.0, 0.92, 0.8, 0.5)
		else:
			d.polygon = _circle(4.0)
			d.color = Color(0.5, 0.95, 1.0, 0.4)
		d.position = center + Vector2(randf_range(-520.0, 520.0), randf_range(-320.0, 320.0))
		d.rotation = randf() * TAU
		d.z_index = -1
		game.add_child(d)
		_decor.append(d)
		var tw: Tween = d.create_tween()
		tw.set_loops()
		var y0: float = d.position.y
		tw.tween_property(d, "position:y", y0 - 4.0, 1.4 + randf() * 0.8).set_trans(Tween.TRANS_SINE)
		tw.tween_property(d, "position:y", y0 + 4.0, 1.4 + randf() * 0.8).set_trans(Tween.TRANS_SINE)


func _star(r_out: float, r_in: float) -> PackedVector2Array:
	var pts: PackedVector2Array = PackedVector2Array()
	for k: int in range(10):
		var r: float = r_out if k % 2 == 0 else r_in
		var a: float = float(k) * TAU / 10.0 - PI * 0.5
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts


func _circle(r: float) -> PackedVector2Array:
	var pts: PackedVector2Array = PackedVector2Array()
	for k: int in range(10):
		var a: float = float(k) * TAU / 10.0
		pts.append(Vector2(cos(a), sin(a)) * r)
	return pts

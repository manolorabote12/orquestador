extends "res://kit/mod_base.gd"

const SEA: Color = Color(0.25, 0.8, 0.9)
const SAND: Color = Color(1.0, 0.85, 0.5)
const CORAL: Color = Color(1.0, 0.45, 0.35)
const GOLD: Color = Color(1.0, 0.82, 0.2)

var _deco: CanvasLayer = null
var _cd: float = 0.0
var _kills: int = 0
var _kill_timer: float = 0.0
var _hit_cd: float = 0.0


func on_level_start() -> void:
	_kills = 0
	_kill_timer = 0.0
	_cd = 0.0
	_hit_cd = 0.0
	_build_deco()
	var p: Node2D = player()
	if p != null:
		burst(p.global_position, SEA, 18)
	flash_screen(Color(0.3, 0.85, 0.95, 0.3), 0.25)
	toast("\u00a1Marea alta!", SEA)


func on_tick(delta: float) -> void:
	if _cd > 0.0:
		_cd -= delta
	if _hit_cd > 0.0:
		_hit_cd -= delta
	if _kill_timer > 0.0:
		_kill_timer -= delta
		if _kill_timer <= 0.0:
			_kills = 0


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"super":
			var at: Vector2 = _pos(data)
			burst(at, GOLD, 26)
			burst(at, CORAL, 14)
			shake(5.0)
			flash_screen(Color(1.0, 0.8, 0.3, 0.3), 0.18)
			_say("\u00a1S\u00daPER PINZA!", GOLD)
			play_sound("power", 1.1)
		"rival_out":
			_on_rival_out(data)
		"hit", "hurt":
			if _hit_cd <= 0.0:
				_hit_cd = 0.25
				burst(_pos(data), SAND, 8)
				shake(2.5)
		"coop_wave":
			flash_screen(Color(0.2, 0.6, 0.9, 0.25), 0.2)
			_say("\u00a1Llega la ola!", SEA)
			shake(3.0)
		"arena_live_start":
			flash_screen(Color(1, 1, 1, 0.25), 0.15)
			_say("\u00a1A la arena!", SAND)
		"death":
			var p: Node2D = player()
			if p != null:
				burst(p.global_position, CORAL, 20)
			shake(7.0)
			flash_screen(Color(1.0, 0.3, 0.25, 0.3), 0.3)
			_say("\u00a1Ay, cangrejo!", CORAL)
		"level_complete":
			var q: Node2D = player()
			if q != null:
				burst(q.global_position, GOLD, 40)
				burst(q.global_position, SEA, 24)
			shake(5.0)
			flash_screen(Color(1.0, 0.9, 0.5, 0.4), 0.4)
			_cd = 0.0
			_say("\u00a1Corona para ti!", GOLD)
			play_sound("win", 1.0)


func _on_rival_out(data: Dictionary) -> void:
	_kills += 1
	_kill_timer = 4.0
	var at: Vector2 = _pos(data)
	burst(at, CORAL, 16)
	burst(at, SAND, 8)
	shake(4.0)
	if _kills == 2:
		flash_screen(Color(1.0, 0.7, 0.3, 0.2), 0.12)
		_say("\u00a1Doble!", CORAL)
	elif _kills == 3:
		flash_screen(Color(1.0, 0.6, 0.2, 0.25), 0.15)
		_say("\u00a1Triple!", GOLD)
	elif _kills >= 4:
		flash_screen(Color(1.0, 0.8, 0.2, 0.3), 0.18)
		_say("\u00a1Racha x" + str(_kills) + "!", GOLD)
	else:
		_say("\u00a1Fuera!", SAND)


func _say(text: String, col: Color) -> void:
	if _cd > 0.0:
		return
	_cd = 0.7
	toast(text, col)


func _pos(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	var v2: Variant = data.get("position", null)
	if v2 is Vector2:
		return v2 as Vector2
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2.ZERO


func _build_deco() -> void:
	if _deco != null and is_instance_valid(_deco):
		_deco.queue_free()
	_deco = CanvasLayer.new()
	_deco.layer = 2
	add_child(_deco)
	var size: Vector2 = get_viewport().get_visible_rect().size
	# Espuma de marea en el borde inferior y superior
	for i: int in range(2):
		var foam: ColorRect = ColorRect.new()
		foam.mouse_filter = Control.MOUSE_FILTER_IGNORE
		foam.color = Color(0.7, 0.95, 1.0, 0.10)
		foam.size = Vector2(size.x, 14.0)
		foam.position = Vector2(0.0, 0.0 if i == 0 else size.y - 14.0)
		_deco.add_child(foam)
		var tw: Tween = foam.create_tween()
		tw.set_loops()
		tw.tween_property(foam, "color:a", 0.22, 1.4 + 0.4 * float(i))
		tw.tween_property(foam, "color:a", 0.06, 1.4 + 0.4 * float(i))
	# Burbujas suaves que suben
	for j: int in range(8):
		var b: Polygon2D = Polygon2D.new()
		var pts: PackedVector2Array = PackedVector2Array()
		var r: float = randf_range(3.0, 7.0)
		for k: int in range(10):
			var a: float = TAU * float(k) / 10.0
			pts.append(Vector2(cos(a), sin(a)) * r)
		b.polygon = pts
		b.color = Color(0.8, 0.97, 1.0, 0.18)
		var x: float = randf_range(0.0, size.x)
		b.position = Vector2(x, size.y + 10.0)
		_deco.add_child(b)
		var dur: float = randf_range(6.0, 11.0)
		var tb: Tween = b.create_tween()
		tb.set_loops()
		tb.tween_interval(randf_range(0.0, 4.0))
		tb.tween_property(b, "position:y", -10.0, dur).from(size.y + 10.0)
		tb.parallel().tween_property(b, "position:x", x + randf_range(-30.0, 30.0), dur).from(x)

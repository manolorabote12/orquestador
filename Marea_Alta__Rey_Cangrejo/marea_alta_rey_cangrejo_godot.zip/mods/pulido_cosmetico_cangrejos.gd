extends "res://kit/mod_base.gd"

const TURQUOISE: Color = Color(0.2, 0.85, 0.9)
const CORAL: Color = Color(1.0, 0.45, 0.35)
const SAND: Color = Color(1.0, 0.9, 0.5)
const FOAM: Color = Color(0.9, 1.0, 1.0)

var _t: float = 0.0
var _last_hit: float = -10.0
var _last_hurt: float = -10.0
var _last_kill: float = -10.0
var _combo: int = 0
var _amb: CanvasLayer = null
var _specks: Array = []
var _speeds: PackedVector2Array = PackedVector2Array()
var _phase: PackedFloat32Array = PackedFloat32Array()


func on_level_start() -> void:
	_combo = 0
	_last_kill = -10.0
	_build_ambient()
	var p: Node2D = player()
	if p != null:
		burst(p.global_position, TURQUOISE, 18)
	flash_screen(Color(0.6, 1.0, 1.0, 0.3), 0.2)
	toast("\u00a1Sube la marea!", TURQUOISE)
	play_sound("coin", 1.2)


func _build_ambient() -> void:
	if _amb != null and is_instance_valid(_amb):
		_amb.queue_free()
	_specks.clear()
	_speeds = PackedVector2Array()
	_phase = PackedFloat32Array()
	_amb = CanvasLayer.new()
	_amb.layer = 4
	add_child(_amb)
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i: int in range(16):
		var s: Polygon2D = Polygon2D.new()
		var r: float = 2.0 + float(i % 3) * 1.5
		s.polygon = PackedVector2Array([Vector2(0, -r), Vector2(r, 0), Vector2(0, r), Vector2(-r, 0)])
		var c: Color = FOAM if i % 2 == 0 else SAND
		c.a = 0.22
		s.color = c
		var fx: float = float((i * 97) % 100) / 100.0
		var fy: float = float((i * 53) % 100) / 100.0
		s.position = Vector2(size.x * fx, size.y * fy)
		_amb.add_child(s)
		_specks.append(s)
		_speeds.append(Vector2(8.0 + float(i % 4) * 5.0, -4.0 - float(i % 3) * 3.0))
		_phase.append(float(i) * 0.7)


func on_tick(delta: float) -> void:
	_t += delta
	if _amb == null or not is_instance_valid(_amb):
		return
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i: int in range(_specks.size()):
		var s: Polygon2D = _specks[i] as Polygon2D
		if s == null or not is_instance_valid(s):
			continue
		var v: Vector2 = _speeds[i]
		s.position += Vector2(v.x, v.y + sin(_t * 1.5 + _phase[i]) * 6.0) * delta
		if s.position.x > size.x + 10.0:
			s.position.x = -10.0
		if s.position.y < -10.0:
			s.position.y = size.y + 10.0
		if s.position.y > size.y + 10.0:
			s.position.y = -10.0


func _pos(data: Dictionary) -> Vector2:
	var v: Variant = data.get("pos", null)
	if v is Vector2:
		return v as Vector2
	v = data.get("position", null)
	if v is Vector2:
		return v as Vector2
	var p: Node2D = player()
	if p != null:
		return p.global_position
	return Vector2.ZERO


func on_event(event_name: String, data: Dictionary) -> void:
	match event_name:
		"hit", "boss_hit":
			if _t - _last_hit > 0.15:
				_last_hit = _t
				burst(_pos(data), SAND, 8)
				shake(2.0)
		"hurt":
			if _t - _last_hurt > 0.6:
				_last_hurt = _t
				flash_screen(Color(1.0, 0.3, 0.25, 0.25), 0.15)
				shake(4.0)
				var p: Node2D = player()
				if p != null:
					burst(p.global_position, CORAL, 10)
		"super":
			var p2: Node2D = player()
			if p2 != null:
				burst(p2.global_position, CORAL, 30)
			flash_screen(Color(1.0, 0.7, 0.3, 0.35), 0.2)
			shake(7.0)
			toast("\u00a1S\u00daPER PINZA!", CORAL)
			play_sound("power", 1.1)
		"rival_out":
			if _t - _last_kill < 4.0:
				_combo += 1
			else:
				_combo = 1
			_last_kill = _t
			burst(_pos(data), CORAL, 20)
			shake(4.0)
			if _combo == 1:
				toast("\u00a1Rival fuera!", SAND)
			elif _combo == 2:
				toast("\u00a1Doble pinza!", CORAL)
				flash_screen(Color(1.0, 0.6, 0.3, 0.2), 0.12)
			elif _combo >= 3:
				toast("\u00a1Racha de marea x" + str(_combo) + "!", TURQUOISE)
				flash_screen(Color(0.5, 1.0, 1.0, 0.25), 0.15)
		"coop_wave":
			toast("\u00a1Oleada amiga!", TURQUOISE)
			burst(_pos(data), TURQUOISE, 14)
		"arena_live_start":
			toast("\u00a1A la arena!", SAND)
			flash_screen(Color(1, 1, 1, 0.2), 0.12)
		"arena_live_match":
			toast("\u00a1Rival a la vista!", CORAL)
			shake(2.5)
		"arena_live_end":
			toast("\u00a1Fin del combate!", TURQUOISE)
		"death":
			flash_screen(Color(0.1, 0.2, 0.4, 0.4), 0.3)
			shake(5.0)
			toast("\u00a1Arriba, Capit\u00e1n!", CORAL)
		"level_complete":
			var p3: Node2D = player()
			if p3 != null:
				burst(p3.global_position, SAND, 40)
				burst(p3.global_position, TURQUOISE, 30)
			flash_screen(Color(1.0, 0.95, 0.6, 0.4), 0.3)
			shake(5.0)
			toast("\u00a1Victoria crust\u00e1cea!", SAND)
			play_sound("win", 1.0)

extends Node2D
## Bajo la Luna Roja: la reina recorre el valle a lomos de su ciervo. De día paga brasas para reclutar,
## armar y construir; de noche las sombras salen de las grietas de los dos extremos y atacan los muros.
## Cada noche hay una luna distinta. Cerrar las dos grietas libera el valle.
## Toda la lógica va en paso(dt) para que el bot pueda jugar sin pantalla.

const MAIN: String = "res://libre/main.tscn"
const ANCHO: float = 1280.0
const ALTO: float = 720.0
const S: float = Datos.SUELO
const VEL_REINA: float = 210.0
var MAX_BRASAS: int = 40
const RADIO_SITIO: float = 80.0

const SHADER_LUZ: String = """
shader_type canvas_item;
uniform vec4 luces[24];
uniform int n_luces = 0;
uniform vec4 noche : source_color = vec4(0.03, 0.04, 0.12, 0.0);
void fragment() {
	vec2 p = FRAGCOORD.xy;
	float luz = 0.0;
	for (int i = 0; i < 24; i++) {
		if (i >= n_luces) { break; }
		vec4 l = luces[i];
		float d = distance(p, l.xy);
		luz = max(luz, (1.0 - smoothstep(l.z * 0.25, l.z, d)) * l.w);
	}
	COLOR = vec4(noche.rgb, noche.a * (1.0 - luz));
}
"""

## Estado
var valle: int = 0
var datos_valle: Dictionary = {}
var dia: int = 1
var fase: String = "dia"
var t_fase: float = 0.0
var luna: String = "creciente"
var luna_hoy: String = "creciente"
var brasas: int = 8
var vivo: bool = true
var ganado: bool = false
var pausa: bool = false
var bot: bool = false
var eterna: bool = false
var tiempo: float = 0.0

var reina: Dictionary = {"x": 0.0, "dir": 1, "mov": 0.0, "corre": 0.0, "inmune": 0.0}
var sitios: Array = []
var gente: Array = []
var criaturas: Array = []
var flechas: Array = []
var ciervos: Array = []
var suelo_brasas: Array = []
var herramientas: Dictionary = {"arquero": 0, "constructor": 0, "granjero": 0, "lancero": 0}
var mercader: bool = false
var por_salir: Array = []
var noches_jefe: int = 0
var causa: String = ""
## Habilidades de la reina y efectos.
var cd_destello: float = 0.0
var cd_cuerno: float = 0.0
var cuerno_t: float = 0.0
var _flash: float = 0.0
var _b_destello: Button
var _b_cuerno: Button
var revivido: bool = false
var stats: Dictionary = {"construidos": 0, "abatidas": 0, "perdidos": 0, "jefes": 0}

var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var cam: float = 0.0
var _mover_ui: int = 0
var _t_pulsado: float = 0.0
var _particulas: Array = []
var _textos: Array = []
var _tex: Dictionary = {}
var _arboles: Array = []
var _arbol_id: String = "lr_arbol"
var _luz: ColorRect
var _mat_luz: ShaderMaterial
var _hud: CanvasLayer
var _raiz: Control
var _l_brasas: Label
var _l_dia: Label
var _l_aviso: Label
var _b_accion: Button
var _barra_dia: ProgressBar
var _mini: Control
var _l_guia: Label
var _modal: Dictionary = {}
var _sitio_cerca: Dictionary = {}
var _pista: String = ""
var _sacudir: float = 0.0


func _ready() -> void:
	Estado.cargar()
	bot = bool(Estado.partida.get("bot", false))
	if bot:
		rng.seed = int(Estado.partida.get("semilla", 1))
	else:
		rng.randomize()
	valle = mini(Estado.valle_actual(), Datos.VALLES.size() - 1) if not bot else int(Estado.partida.get("valle", 0))
	eterna = Estado.valle_actual() >= Datos.VALLES.size() and not bot
	datos_valle = Datos.VALLES[valle] as Dictionary
	_arbol_id = ["lr_arbol", "lr_arbol_muerto", "lr_arbol_quemado"][valle]
	for id: String in ["lr_reina", "lr_vagabundo", "lr_aldeano", "lr_arquero", "lr_constructor", "lr_granjero", "lr_lancero", "lr_sombra",
			"lr_bruto", "lr_alado", "lr_jefe", "lr_muro1", "lr_muro2", "lr_muro3", "lr_torre", "lr_granja", "lr_hoguera", "lr_portal",
			"lr_ciervo", "lr_mercader", "lr_arbol", "lr_campamento", "lr_cofre", "lr_cielo_dia", "lr_cielo_tarde", "lr_cielo_noche",
			"lr_cielo_roja", "lr_montes", "lr_bosque", "lr_caballero", "lr_bruja", "lr_cazadora", "lr_santuario", "lr_ahogado", "lr_golem",
			"lr_arbol_muerto", "lr_arbol_quemado", "lr_cielo_dia_cienaga", "lr_cielo_noche_cienaga", "lr_cielo_dia_ceniza", "lr_cielo_noche_ceniza"]:
		_tex[id] = null if bot else Estilo.tex(id)
	_montar_valle()
	var g: Dictionary = Estado.d["guardada"] as Dictionary
	if not bot and not bool(Estado.partida.get("nuevo", false)) and not g.is_empty() and int(g.get("valle", -1)) == valle:
		_restaurar(g)
	if not bot:
		_montar_luz()
		_hacer_hud()
		_pista_fase()
		if Consejo.mostrar(_raiz, "inicio"):
			pausa = true
		_avisar(Idioma.t(str(datos_valle["nombre"])) if not eterna else Idioma.t("Luna eterna"))


func _montar_valle() -> void:
	sitios.clear()
	for s: Variant in Datos.SITIOS:
		var d: Dictionary = s as Dictionary
		var lados: Array = [-1, 1] if bool(d["doble"]) else [0]
		for lado: Variant in lados:
			var x: float = float(d["x"]) * (float(lado) if int(lado) != 0 else 1.0)
			var st: Dictionary = {"tipo": str(d["tipo"]), "x": x, "lado": int(lado) if int(lado) != 0 else (1 if x > 0 else (-1 if x < 0 else 0)),
				"nivel": 0, "costes": (d["niveles"] as Array).duplicate(), "req": int(d.get("nivel_hoguera", 1)), "hp": 0.0, "trabajo": 0.0, "obj": 0}
			match st["tipo"]:
				"hoguera":
					st["nivel"] = 1
					st["costes"] = [6, 12]
				"campamento":
					st["vagos"] = 3
				"cofre":
					st["abierto"] = false
				"santuario":
					st["heroe"] = str((Datos.HEROES_VALLE[valle] as Array)[0 if int(lado) < 0 else 1])
					st["rescatado"] = false
				"grieta":
					st["hp"] = 260.0 * float(datos_valle["fuerza"])
					st["cerrada"] = false
					st["asalto"] = false
			sitios.append(st)
	## Árboles del bosque (se talan solos al construir muros lejos: decorado).
	_arboles.clear()
	var x2: float = -Datos.BORDE
	while x2 < Datos.BORDE:
		if absf(x2) > 500.0:
			_arboles.append({"x": x2 + rng.randf_range(-40, 40), "esc": rng.randf_range(0.7, 1.15), "capa": rng.randi() % 2})
		x2 += rng.randf_range(90.0, 220.0)
	brasas = int(datos_valle["brasas"]) + (4 if eterna else 0) + 4 * Estado.mejora("inicio")
	MAX_BRASAS = 40 + 10 * Estado.mejora("bolsa")
	## Dos aldeanos para empezar.
	for i: int in 2:
		_nueva_persona("aldeano", rng.randf_range(-80, 80))
	for c: Variant in sitios:
		var cs: Dictionary = c as Dictionary
		if str(cs["tipo"]) == "campamento":
			for k: int in int(cs["vagos"]):
				_nueva_persona("vagabundo", float(cs["x"]) + rng.randf_range(-60, 60))
	luna = _luna_de(dia)


func _nueva_persona(oficio: String, x: float) -> Dictionary:
	var lado: int = 1 if _contar_lado(oficio, 1) < _contar_lado(oficio, -1) else -1
	var p: Dictionary = {"oficio": oficio, "x": x, "dir": 1, "obj": x, "t": rng.randf() * 3.0, "cd": 0.0, "lado": lado, "trabajo": null, "asalto": false}
	gente.append(p)
	return p


func _contar_lado(oficio: String, lado: int) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == oficio and int((g as Dictionary)["lado"]) == lado).size()


func contar(oficio: String) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == oficio).size()


func _luna_de(n: int) -> String:
	if n % 5 == 0:
		return "roja"
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = n * 977 + valle * 31 + (int(Estado.partida.get("semilla", 0)) if bot else 0)
	var op: Array = ["creciente", "creciente", "llena", "nueva", "azul"]
	return str(op[r.randi() % op.size()])


# ------------------------------------------------------------------ guardar / restaurar (al amanecer)

func _foto() -> Dictionary:
	var oficios: Array = []
	for g: Variant in gente:
		oficios.append([str((g as Dictionary)["oficio"]), snappedf(float((g as Dictionary)["x"]), 1.0), int((g as Dictionary)["lado"]), str((g as Dictionary).get("heroe", ""))])
	var st: Array = []
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		st.append({"nivel": int(d["nivel"]), "hp": float(d["hp"]), "vagos": int(d.get("vagos", 0)), "abierto": bool(d.get("abierto", false)),
			"cerrada": bool(d.get("cerrada", false)), "rescatado": bool(d.get("rescatado", false))})
	return {"valle": valle, "dia": dia, "brasas": brasas, "gente": oficios, "sitios": st, "herr": herramientas.duplicate(), "reina": float(reina["x"])}


func _restaurar(g: Dictionary) -> void:
	dia = int(g.get("dia", 1))
	brasas = int(g.get("brasas", brasas))
	reina["x"] = float(g.get("reina", 0.0))
	gente.clear()
	for o: Variant in (g.get("gente", []) as Array):
		var a: Array = o as Array
		var p: Dictionary = _nueva_persona(str(a[0]), float(a[1]))
		p["lado"] = int(a[2])
		if a.size() > 3 and str(a[3]) != "":
			p["heroe"] = str(a[3])
			p["hab_t"] = 4.0
	var st: Array = g.get("sitios", []) as Array
	for i: int in mini(st.size(), sitios.size()):
		var d: Dictionary = st[i] as Dictionary
		var s: Dictionary = sitios[i] as Dictionary
		s["nivel"] = int(d["nivel"])
		s["hp"] = float(d["hp"])
		if s.has("vagos"):
			s["vagos"] = int(d["vagos"])
		if s.has("abierto"):
			s["abierto"] = bool(d["abierto"])
		if s.has("cerrada"):
			s["cerrada"] = bool(d["cerrada"])
		if s.has("rescatado"):
			s["rescatado"] = bool(d.get("rescatado", false))
	var hr: Variant = g.get("herr", {})
	if hr is Dictionary:
		for k: String in herramientas.keys():
			herramientas[k] = int((hr as Dictionary).get(k, 0))
	luna = _luna_de(dia)


# ------------------------------------------------------------------ entrada

func _unhandled_input(e: InputEvent) -> void:
	if bot or not vivo or pausa:
		return
	if e is InputEventScreenTouch:
		var t: InputEventScreenTouch = e as InputEventScreenTouch
		var vx: float = t.position.x / get_viewport_rect().size.x * ANCHO
		if t.pressed:
			_mover_ui = -1 if vx < ANCHO * 0.36 else (1 if vx > ANCHO * 0.64 else 0)
			_t_pulsado = 0.0
		else:
			_mover_ui = 0
	elif e is InputEventScreenDrag:
		var dr: InputEventScreenDrag = e as InputEventScreenDrag
		var vx2: float = dr.position.x / get_viewport_rect().size.x * ANCHO
		var nuevo: int = -1 if vx2 < ANCHO * 0.36 else (1 if vx2 > ANCHO * 0.64 else 0)
		if nuevo != 0:
			_mover_ui = nuevo
	elif e is InputEventKey:
		var k: InputEventKey = e as InputEventKey
		if k.echo:
			return
		if k.keycode in [KEY_A, KEY_LEFT]:
			_mover_ui = -1 if k.pressed else (0 if _mover_ui == -1 else _mover_ui)
		elif k.keycode in [KEY_D, KEY_RIGHT]:
			_mover_ui = 1 if k.pressed else (0 if _mover_ui == 1 else _mover_ui)
		elif k.keycode == KEY_SPACE and k.pressed:
			accion()


## Para el bot y los controles: -1 izquierda, 0 parar, 1 derecha.
func mover(dir: int) -> void:
	_mover_ui = dir


# ------------------------------------------------------------------ bucle

func _physics_process(dt: float) -> void:
	if bot:
		return
	if pausa:
		if Consejo._abierto.is_empty() and _modal.is_empty():
			pausa = false
		return
	paso(dt)


func _process(dt: float) -> void:
	if bot:
		return
	tiempo += dt
	cam = lerpf(cam, clampf(float(reina["x"]), -Datos.BORDE + ANCHO / 2.0, Datos.BORDE - ANCHO / 2.0), minf(1.0, dt * 4.0))
	_actualizar_particulas(dt)
	if _sacudir > 0.0:
		_sacudir = maxf(0.0, _sacudir - dt * 2.5)
		position = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1)) * 10.0 * _sacudir
	else:
		position = Vector2.ZERO
	_actualizar_luz()
	_hud_refrescar()
	if _mini != null:
		_mini.queue_redraw()
	queue_redraw()


func paso(dt: float) -> void:
	if not vivo or ganado:
		return
	tiempo += dt if bot else 0.0
	_avanzar_fase(dt)
	cd_destello = maxf(0.0, cd_destello - dt)
	cd_cuerno = maxf(0.0, cd_cuerno - dt)
	cuerno_t = maxf(0.0, cuerno_t - dt)
	_mover_reina(dt)
	_gente(dt)
	_criaturas(dt)
	_flechas(dt)
	_ciervos(dt)
	_recoger_brasas(dt)
	_obras(dt)


func _duracion_fase() -> float:
	match fase:
		"dia":
			return Datos.T_DIA
		"tarde":
			return Datos.T_TARDE
		"noche":
			return Datos.T_NOCHE + minf(25.0, dia * 1.2)
	return Datos.T_ALBA


func _avanzar_fase(dt: float) -> void:
	t_fase += dt
	if fase == "noche":
		_soltar_sombras(dt)
	if t_fase < _duracion_fase():
		return
	t_fase = 0.0
	match fase:
		"dia":
			fase = "tarde"
			luna = _luna_de(dia)
			if not bot:
				var l: Dictionary = Datos.LUNAS[luna] as Dictionary
				_avisar(Idioma.t("Esta noche: ") + Idioma.t(str(l["nombre"])) + "\n" + Idioma.t(str(l["texto"])))
				Audio.play("ui_swoosh", 0.0, -4.0, 0.6)
				if Consejo.mostrar(_raiz, "noche"):
					pausa = true
			for g: Variant in gente:
				(g as Dictionary)["asalto"] = false
		"tarde":
			fase = "noche"
			_empezar_noche()
		"noche":
			fase = "alba"
			for c: Variant in criaturas:
				(c as Dictionary)["huye"] = true
		"alba":
			fase = "dia"
			dia += 1
			_amanecer()
	if not bot:
		_pista_fase()


func _empezar_noche() -> void:
	luna_hoy = luna
	var l: Dictionary = Datos.LUNAS[luna] as Dictionary
	mercader = luna == "azul"
	por_salir.clear()
	var fuerza: float = float(datos_valle["fuerza"]) * (1.0 + (dia - 1) * 0.02 if eterna else 1.0)
	var total: int = int(round((0.5 + dia * 1.25) * float(l["cantidad"]) * fuerza))
	var lados: Array = []
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "grieta" and not bool(d["cerrada"]):
			lados.append(int(d["lado"]))
	if lados.is_empty():
		return
	var dur: float = _duracion_fase() * 0.7
	for i: int in total:
		var tipo: String = "sombra"
		if dia >= int((Datos.CRIATURAS["bruto"] as Dictionary)["desde"]) and i % 4 == 3:
			tipo = "bruto"
		elif dia >= int((Datos.CRIATURAS["alado"] as Dictionary)["desde"]) and i % 5 == 4:
			tipo = "alado"
		por_salir.append({"t": rng.randf_range(2.0, dur), "tipo": tipo, "lado": int(lados[i % lados.size()])})
	if luna == "roja":
		por_salir.append({"t": dur * 0.45, "tipo": "jefe", "lado": int(lados[rng.randi() % lados.size()])})
	por_salir.sort_custom(func(a: Variant, b: Variant) -> bool: return float((a as Dictionary)["t"]) < float((b as Dictionary)["t"]))
	if not bot:
		Juice.vibrate(30)


func _soltar_sombras(_dt: float) -> void:
	while not por_salir.is_empty() and float((por_salir[0] as Dictionary)["t"]) <= t_fase:
		var p: Dictionary = por_salir.pop_front() as Dictionary
		var tipo: String = str(p["tipo"])
		var vari: Dictionary = Datos.VARIANTES[valle if not eterna else rng.randi() % Datos.VARIANTES.size()] as Dictionary
		if vari.has(tipo) and rng.randf() < 0.6:
			tipo = str(vari[tipo])
		var c: Dictionary = Datos.CRIATURAS[tipo] as Dictionary
		var lado: int = int(p["lado"])
		var hp: float = float(c["hp"]) * float(datos_valle["fuerza"]) * (1.0 + dia * 0.03)
		criaturas.append({"tipo": tipo, "x": lado * (Datos.BORDE - 260.0) + rng.randf_range(-30, 30), "lado": lado, "hp": hp, "hpmax": hp, "cd": 0.0,
			"huye": false, "vuela": bool(c.get("vuela", false)), "t": rng.randf() * 3.0, "golpe": 0.0})
		if tipo == "jefe" and not bot:
			_avisar(Idioma.t("¡Algo enorme sale de la grieta!"))
			_sacudir = 0.8
			Juice.vibrate(80)


func _amanecer() -> void:
	criaturas.clear()
	mercader = false
	## El fuego cobra: una brasa por cada tres de los tuyos, que caen junto a la hoguera.
	var gente_util: int = gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) != "vagabundo").size()
	for i: int in int(gente_util / 3.0):
		_soltar_brasa(rng.randf_range(-60, 60))
	## Los campamentos atraen a más vagabundos.
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "campamento" and int(d["vagos"]) < 4:
			d["vagos"] = int(d["vagos"]) + 1
			_nueva_persona("vagabundo", float(d["x"]) + rng.randf_range(-60, 60))
	## Ciervos para los arqueros.
	for i: int in 2 + rng.randi() % 3:
		var lado: int = -1 if rng.randf() < 0.5 else 1
		ciervos.append({"x": lado * rng.randf_range(1600.0, 3000.0), "dir": lado, "t": rng.randf() * 4.0, "hp": 3.0})
	if luna_hoy == "roja" and not bot:
		stats["jefes"] = int(stats["jefes"]) + 0
	Estado.d["mejor_noche"] = maxi(Estado.n("mejor_noche"), dia - 1)
	Estado.d["noches_total"] = Estado.n("noches_total") + 1
	if eterna:
		Estado.d["eterna_record"] = maxi(Estado.n("eterna_record"), dia - 1)
	if not bot:
		Estado.d["guardada"] = _foto()
		Estado.guardar()
		_avisar(Idioma.t("Amanece el día %d") % dia)
		if dia == 3 and Consejo.mostrar(_raiz, "luna"):
			pausa = true
		elif (_soldados_lado(-1) >= 3 or _soldados_lado(1) >= 3) and Consejo.mostrar(_raiz, "grieta"):
			pausa = true
		Audio.play("ui_reward", 0.0, -4.0, 0.8)
	## ¿Valle libre?
	var abiertas: int = sitios.filter(func(s: Variant) -> bool: return str((s as Dictionary)["tipo"]) == "grieta" and not bool((s as Dictionary)["cerrada"])).size()
	if abiertas == 0 and not eterna:
		_ganar()


# ------------------------------------------------------------------ reina

func _mover_reina(dt: float) -> void:
	reina["inmune"] = maxf(0.0, float(reina["inmune"]) - dt)
	if _mover_ui != 0:
		_t_pulsado += dt
		reina["corre"] = minf(1.0, float(reina["corre"]) + dt * (1.5 if _t_pulsado > 0.5 else 0.0))
		var v: float = VEL_REINA * (1.0 + 0.8 * float(reina["corre"]))
		reina["x"] = clampf(float(reina["x"]) + _mover_ui * v * dt, -Datos.BORDE + 60.0, Datos.BORDE - 60.0)
		reina["dir"] = _mover_ui
		reina["mov"] = float(reina["mov"]) + dt * (1.0 + float(reina["corre"]))
	else:
		reina["corre"] = 0.0
		_t_pulsado = 0.0
	_sitio_cerca = _sitio_mas_cerca()


func _sitio_mas_cerca() -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = RADIO_SITIO
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		var dd: float = absf(float(d["x"]) - float(reina["x"]))
		if dd < md and not opcion(d).is_empty():
			md = dd
			mejor = d
	if mercader and absf(float(reina["x"]) - 90.0) < RADIO_SITIO:
		return {"tipo": "mercader", "x": 90.0}
	return mejor


## Lo que se puede hacer en un sitio ahora mismo: {"texto", "coste"} o {} si nada.
func opcion(s: Dictionary) -> Dictionary:
	var tipo: String = str(s["tipo"])
	var hog: int = nivel_hoguera()
	match tipo:
		"mercader":
			return {"texto": Idioma.t("Mercader fantasma: 2 herramientas"), "coste": 5}
		"campamento":
			var hay: bool = gente.any(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == "vagabundo" and absf(float((g as Dictionary)["x"]) - float(s["x"])) < 300.0)
			return {"texto": Idioma.t("Reclutar vagabundo"), "coste": 1} if hay else {}
		"cofre":
			return {} if bool(s["abierto"]) or fase == "noche" else {"texto": Idioma.t("Abrir el cofre"), "coste": 0}
		"santuario":
			if bool(s["rescatado"]) or fase != "dia":
				return {}
			var hn: String = Idioma.t(str((Datos.HEROES[str(s["heroe"])] as Dictionary)["nombre"]))
			return {"texto": Idioma.t("Rescatar: %s") % hn, "coste": 5 if Estado.mejora("heroes") > 0 else 10}
		"grieta":
			if bool(s["cerrada"]) or fase != "dia" or bool(s["asalto"]):
				return {}
			var sold: int = _soldados_lado(int(s["lado"]))
			if sold < 3:
				return {"texto": Idioma.t("Necesitas 3 soldados en este lado para asaltar"), "coste": -1}
			return {"texto": Idioma.t("Asaltar la grieta (%d soldados)") % sold, "coste": int((s["costes"] as Array)[0])}
	if s.has("obj") and int(s["obj"]) > int(s["nivel"]):
		return {}
	if tipo.begins_with("tienda_"):
		var of: String = tipo.substr(7)
		if hog < int(s["req"]):
			return {"texto": Idioma.t("Mejora la hoguera para desbloquear"), "coste": -1}
		return {"texto": Idioma.t("Comprar herramienta: %s") % Idioma.t(str((Datos.OFICIOS[of] as Dictionary)["nombre"])), "coste": int((Datos.OFICIOS[of] as Dictionary)["coste"])}
	var costes: Array = s["costes"] as Array
	var nv: int = int(s["nivel"]) if tipo != "hoguera" else int(s["nivel"]) - 1
	if nv >= costes.size():
		if tipo == "muro" and float(s["hp"]) < _vida_muro(int(s["nivel"])) * 0.99 and int(s["nivel"]) > 0:
			return {"texto": Idioma.t("Reparar muro"), "coste": 2}
		return {}
	if tipo != "hoguera" and hog < int(s["req"]):
		return {"texto": Idioma.t("Mejora la hoguera para desbloquear"), "coste": -1}
	var nombre: String = Idioma.t(str(Datos.NOMBRES_SITIO[tipo]))
	if tipo == "muro":
		nombre = Idioma.t(str(Datos.NOMBRES_MURO[int(s["nivel"]) + 1]))
		if int(s["nivel"]) > 0 and float(s["hp"]) < _vida_muro(int(s["nivel"])) * 0.5:
			return {"texto": Idioma.t("Reparar muro"), "coste": 2}
	elif tipo == "hoguera":
		nombre = Idioma.t("Avivar la hoguera (nivel %d)") % (int(s["nivel"]) + 1)
	return {"texto": nombre, "coste": int(costes[nv])}


func _vida_muro(nv: int) -> float:
	return float(Datos.VIDA_MURO[nv]) * (1.0 + 0.25 * Estado.mejora("muros"))


func nivel_hoguera() -> int:
	return int((sitios[0] as Dictionary)["nivel"])


func _soldados_lado(lado: int) -> int:
	var n: int = 0
	for g: Variant in gente:
		var d: Dictionary = g as Dictionary
		if int(d["lado"]) != lado:
			continue
		if str(d["oficio"]) == "lancero" or str(d["oficio"]) == "arquero":
			n += 1
		elif str(d["oficio"]) == "heroe":
			n += 3
	return n


## Pagar en el sitio que tienes al lado.
func accion() -> bool:
	if _sitio_cerca.is_empty():
		return false
	var s: Dictionary = _sitio_cerca
	var o: Dictionary = opcion(s) if str(s["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
	if o.is_empty() or int(o["coste"]) < 0:
		return false
	var coste: int = int(o["coste"])
	if brasas < coste:
		if not bot:
			_texto(Idioma.t("Faltan brasas"), Vector2(float(reina["x"]), S - 190.0), Estilo.ROJO)
			Audio.play("ui_error", 0.0, -6.0)
		return false
	brasas -= coste
	if not bot:
		for i: int in coste:
			_particulas.append({"p": Vector2(float(reina["x"]), S - 120.0), "v": Vector2(rng.randf_range(-60, 60), rng.randf_range(-260, -160)),
				"t": 0.6, "c": Color("ffb347"), "r": 5.0, "g": 700.0})
		Audio.play("ui_coin", 0.1, -4.0, 0.9)
	var tipo: String = str(s["tipo"])
	match tipo:
		"mercader":
			var ofs: Array = ["arquero", "constructor", "granjero", "lancero"]
			for i: int in 2:
				var of: String = str(ofs[rng.randi() % ofs.size()])
				herramientas[of] = int(herramientas[of]) + 1
			mercader = false
		"campamento":
			for g: Variant in gente:
				var d: Dictionary = g as Dictionary
				if str(d["oficio"]) == "vagabundo" and absf(float(d["x"]) - float(s["x"])) < 300.0:
					d["oficio"] = "aldeano"
					s["vagos"] = maxi(0, int(s["vagos"]) - 1)
					break
		"santuario":
			s["rescatado"] = true
			var hp: Dictionary = _nueva_persona("heroe", float(s["x"]))
			hp["heroe"] = str(s["heroe"])
			hp["lado"] = int(s["lado"])
			hp["hab_t"] = 3.0
			if not bot:
				_avisar(Idioma.t("¡%s se une a tu causa!") % Idioma.t(str((Datos.HEROES[str(s["heroe"])] as Dictionary)["nombre"])))
				_flash = 0.5
				Audio.play("ui_big", 0.0, -2.0, 1.1)
				for i: int in 24:
					var a: float = rng.randf_range(0.0, TAU)
					_particulas.append({"p": Vector2(float(s["x"]), S - 90.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 260), "t": 0.9, "c": Color(1.0, 0.85, 0.4), "r": 3.5, "g": 120.0})
		"cofre":
			s["abierto"] = true
			for i: int in 8 + valle * 2:
				_soltar_brasa(float(s["x"]) + rng.randf_range(-40, 40))
		"grieta":
			s["asalto"] = true
			for g: Variant in gente:
				var d2: Dictionary = g as Dictionary
				if int(d2["lado"]) == int(s["lado"]) and (str(d2["oficio"]) in ["lancero", "arquero", "heroe"]):
					d2["asalto"] = true
			if not bot:
				_avisar(Idioma.t("¡Al asalto! Vuelven al atardecer."))
		_:
			if tipo.begins_with("tienda_"):
				var of2: String = tipo.substr(7)
				herramientas[of2] = int(herramientas[of2]) + 1
			elif tipo == "muro" and opcion(s).get("texto", "") == Idioma.t("Reparar muro"):
				s["obj"] = int(s["nivel"])
				s["trabajo"] = 2.5
				s["reparar"] = true
			else:
				s["obj"] = int(s["nivel"]) + 1
				s["trabajo"] = _trabajo_de(s)
	return true


func _trabajo_de(s: Dictionary) -> float:
	match str(s["tipo"]):
		"muro":
			return float(Datos.TRABAJO_MURO[int(s["obj"])])
		"torre":
			return 8.0
		"granja":
			return 5.0
		"hoguera":
			return 6.0
	return 3.0


## Obras: los constructores trabajan donde haya algo pendiente; al acabar, sube el nivel.
func _obras(_dt: float) -> void:
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if not d.has("obj") or int(d["obj"]) <= int(d["nivel"]) and not bool(d.get("reparar", false)):
			continue
		if float(d["trabajo"]) <= 0.0:
			if bool(d.get("reparar", false)):
				d["reparar"] = false
				d["hp"] = _vida_muro(int(d["nivel"]))
			else:
				d["nivel"] = int(d["obj"])
				if str(d["tipo"]) == "muro":
					d["hp"] = _vida_muro(int(d["nivel"]))
				stats["construidos"] = int(stats["construidos"]) + 1
				if not bot:
					_texto(Idioma.t("¡Terminado!"), Vector2(float(d["x"]), S - 220.0), Estilo.ORO)
					Audio.play("ui_big", 0.0, -6.0)
			d["obj"] = int(d["nivel"])


func pendientes() -> Array:
	return sitios.filter(func(s: Variant) -> bool:
		var d: Dictionary = s as Dictionary
		return d.has("obj") and (int(d["obj"]) > int(d["nivel"]) or bool(d.get("reparar", false))))


# ------------------------------------------------------------------ gente

## Muro en pie más exterior de un lado (o {} si no hay).
func muro_exterior(lado: int) -> Dictionary:
	var mejor: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "muro" and int(d["lado"]) == lado and int(d["nivel"]) > 0 and float(d["hp"]) > 0.0:
			if mejor.is_empty() or absf(float(d["x"])) > absf(float(mejor["x"])):
				mejor = d
	return mejor


func _torre_lado(lado: int) -> Dictionary:
	var mejor: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "torre" and int(d["lado"]) == lado and int(d["nivel"]) > 0:
			var m: Dictionary = muro_exterior(lado)
			if not m.is_empty() and absf(float(d["x"])) < absf(float(m["x"])):
				if mejor.is_empty() or absf(float(d["x"])) > absf(float(mejor["x"])):
					mejor = d
	return mejor


func _gente(dt: float) -> void:
	var noche: bool = fase == "noche" or fase == "tarde"
	var vista: float = float((Datos.LUNAS[luna_hoy] as Dictionary)["vista"]) if fase == "noche" else 1.0
	for g: Variant in gente:
		var p: Dictionary = g as Dictionary
		p["t"] = float(p["t"]) + dt
		p["cd"] = maxf(0.0, float(p["cd"]) - dt)
		var of: String = str(p["oficio"])
		var lado: int = int(p["lado"])
		var m: Dictionary = muro_exterior(lado)
		var dentro: float = absf(float(m["x"])) - 60.0 if not m.is_empty() else 140.0
		match of:
			"vagabundo":
				if fmod(float(p["t"]), 4.0) < dt:
					p["obj"] = float(p["x"]) + rng.randf_range(-120, 120)
				_andar(p, float(p["obj"]), 40.0, dt)
			"aldeano":
				## Si hay una herramienta en una tienda, va a por ella.
				var tomada: bool = false
				for of2: String in herramientas.keys():
					if int(herramientas[of2]) > 0:
						var tx: float = _x_tienda(of2)
						if _andar(p, tx, 120.0, dt):
							herramientas[of2] = int(herramientas[of2]) - 1
							p["oficio"] = of2
							p["lado"] = 1 if _contar_lado(of2, 1) < _contar_lado(of2, -1) else -1
							if not bot:
								_texto(Idioma.t(str((Datos.OFICIOS[of2] as Dictionary)["nombre"])), Vector2(float(p["x"]), S - 150.0), Estilo.ORO)
						tomada = true
						break
				if not tomada:
					if fmod(float(p["t"]), 5.0) < dt:
						p["obj"] = rng.randf_range(-120, 120)
					_andar(p, float(p["obj"]), 50.0, dt)
			"constructor":
				var pend: Array = pendientes()
				var obra: Dictionary = {}
				if not noche:
					var md: float = 1e9
					for o: Variant in pend:
						var dd: float = absf(float((o as Dictionary)["x"]) - float(p["x"]))
						if dd < md:
							md = dd
							obra = o as Dictionary
				if not obra.is_empty():
					if _andar(p, float(obra["x"]) - signf(float(obra["x"])) * 30.0, 90.0, dt):
						obra["trabajo"] = float(obra["trabajo"]) - dt
						p["trabaja"] = true
						p["dir"] = 1 if float(obra["x"]) > float(p["x"]) else -1
						if not bot and fmod(float(p["t"]), 0.5) < dt:
							Audio.play("ui_tick", 0.2, -14.0, 0.6)
				else:
					_andar(p, lado * 60.0, 70.0, dt)
			"granjero":
				var granja: Dictionary = {}
				for s: Variant in sitios:
					var d: Dictionary = s as Dictionary
					if str(d["tipo"]) == "granja" and int(d["nivel"]) > 0 and int(d["lado"]) == lado:
						granja = d
				if not granja.is_empty() and not noche:
					if _andar(p, float(granja["x"]), 70.0, dt) and fmod(float(p["t"]), 11.0) < dt:
						_soltar_brasa(float(granja["x"]) + rng.randf_range(-30, 30))
				else:
					_andar(p, lado * 80.0, 60.0, dt)
			"heroe":
				_heroe(p, dt, m, dentro, noche)
			"arquero", "lancero":
				if bool(p["asalto"]) and fase == "dia":
					_asaltar(p, dt)
					continue
				var puesto: float = lado * dentro
				var torre: Dictionary = _torre_lado(lado) if of == "arquero" else {}
				if of == "arquero" and not torre.is_empty() and _arqueros_en_torre(lado) < 2:
					puesto = float(torre["x"])
					p["torre"] = true
				else:
					p["torre"] = false
				if of == "lancero":
					puesto = lado * (absf(float(m["x"])) - 30.0) if not m.is_empty() else lado * 120.0
				if not noche and of == "arquero":
					## De día: caza.
					var ci: Dictionary = _ciervo_cerca(float(p["x"]), 900.0)
					if not ci.is_empty():
						if absf(float(ci["x"]) - float(p["x"])) > 380.0:
							_andar(p, float(ci["x"]), 75.0, dt)
						elif float(p["cd"]) <= 0.0:
							_disparar(p, float(ci["x"]), S - 40.0, true)
						continue
					puesto = lado * (dentro + 120.0)
				_andar(p, puesto + (rng.randf_range(-1, 1) if false else 0.0), 85.0, dt)
				## Disparar / pinchar.
				if float(p["cd"]) <= 0.0:
					var alcance: float = (430.0 + (180.0 if bool(p.get("torre", false)) else 0.0)) * vista if of == "arquero" else 85.0
					var obj: Dictionary = _criatura_cerca(float(p["x"]), alcance, of == "arquero")
					if not obj.is_empty():
						if of == "arquero":
							_disparar(p, float(obj["x"]), _y_criatura(obj) - 30.0, false)
						else:
							_herir(obj, 5.0 * _buff())
							p["cd"] = 0.9
							p["ataca"] = 0.25
							p["dir"] = 1 if float(obj["x"]) > float(p["x"]) else -1
							if not bot:
								Audio.play("ui_tick", 0.2, -8.0, 0.5)
	gente = gente.filter(func(g: Variant) -> bool: return not bool((g as Dictionary).get("muerto", false)))


func _buff() -> float:
	return 1.6 if cuerno_t > 0.0 else 1.0


## Héroes: se ponen en el muro de su lado, pelean y lanzan su habilidad cada cierto tiempo.
func _heroe(p: Dictionary, dt: float, m: Dictionary, dentro: float, noche: bool) -> void:
	var id: String = str(p.get("heroe", "caballero"))
	var h: Dictionary = Datos.HEROES[id] as Dictionary
	var lado: int = int(p["lado"])
	p["aturdido"] = maxf(0.0, float(p.get("aturdido", 0.0)) - dt)
	if float(p["aturdido"]) > 0.0:
		return
	p["hab_t"] = float(p.get("hab_t", 0.0)) - dt
	if bool(p["asalto"]) and fase == "dia":
		_asaltar(p, dt)
		return
	var hueco: float = {"caballero": 0.0, "bruja": 70.0, "cazadora": 130.0}.get(id, 0.0)
	var puesto: float = lado * ((absf(float(m["x"])) - 25.0) if not m.is_empty() and id == "caballero" else dentro - hueco)
	if not noche:
		puesto = lado * (dentro + 60.0)
	_andar(p, puesto, 110.0, dt)
	var alcance: float = float(h["alcance"])
	if float(p["cd"]) <= 0.0:
		var obj: Dictionary = _criatura_cerca(float(p["x"]), alcance, id != "caballero")
		if not obj.is_empty():
			p["dir"] = 1 if float(obj["x"]) > float(p["x"]) else -1
			p["ataca"] = 0.25
			p["cd"] = float(h["cd"]) * (0.7 if cuerno_t > 0.0 else 1.0)
			match id:
				"caballero":
					_herir(obj, float(h["dano"]) * _buff())
					if not bot:
						_chispas(Vector2(float(obj["x"]), S - 70.0), Color(1.0, 0.9, 0.5), 5)
						Audio.play("ui_tick", 0.15, -6.0, 0.7)
				"bruja":
					var ox: float = float(p["x"])
					var oy: float = S - 90.0
					var dx: float = float(obj["x"]) - ox
					var t: float = maxf(0.3, absf(dx) / 520.0)
					flechas.append({"x": ox, "y": oy, "vx": dx / t, "vy": (S - 40.0 - oy - 0.5 * 900.0 * t * t) / t, "t": 0.0, "caza": false,
						"dano": float(h["dano"]) * _buff(), "aoe": 80.0, "col": Color(0.45, 1.0, 0.35), "bola": true})
					if not bot:
						Audio.play("ui_swoosh", 0.1, -8.0, 0.7)
				"cazadora":
					_disparar(p, float(obj["x"]), _y_criatura(obj) - 30.0, false)
					p["cd"] = float(h["cd"]) * (0.7 if cuerno_t > 0.0 else 1.0)
					(flechas.back() as Dictionary)["dano"] = float(h["dano"]) * _buff()
					(flechas.back() as Dictionary)["estrella"] = true
	## Habilidad especial.
	if float(p["hab_t"]) <= 0.0 and not _criatura_cerca(float(p["x"]), 520.0, true).is_empty():
		p["hab_t"] = float(h["hab_cd"])
		var x: float = float(p["x"])
		match id:
			"caballero":
				for c: Variant in criaturas:
					var d: Dictionary = c as Dictionary
					if absf(float(d["x"]) - x) < 240.0:
						_herir(d, 15.0 * _buff())
						d["x"] = float(d["x"]) + int(d["lado"]) * 140.0
						d["aturdido"] = 1.2
				if not bot:
					for i: int in 36:
						var a: float = i / 36.0 * TAU
						_particulas.append({"p": Vector2(x, S - 40.0), "v": Vector2(cos(a) * 420.0, sin(a) * 120.0 - 40.0), "t": 0.5, "c": Color(1.0, 0.85, 0.45), "r": 4.0})
					_sacudir = 0.5
					_parar(0.06)
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Estilo.ORO)
			"bruja":
				var obj2: Dictionary = _criatura_cerca(x, 520.0, true)
				_explosion(float(obj2["x"]), 210.0, 25.0 * _buff(), Color(0.4, 1.0, 0.3))
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(0.6, 1.0, 0.5))
			"cazadora":
				for i: int in 9:
					var obj3: Dictionary = _criatura_cerca(x + rng.randf_range(-400, 400), 520.0, true)
					if obj3.is_empty():
						continue
					var tx: float = float(obj3["x"]) + rng.randf_range(-20, 20)
					flechas.append({"x": tx - 160.0 * int(obj3["lado"]), "y": -40.0 - i * 40.0, "vx": 160.0 * int(obj3["lado"]), "vy": 700.0, "t": 0.0,
						"caza": false, "dano": 6.0 * _buff(), "estrella": true})
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(0.75, 0.85, 1.0))


## Explosión en el suelo: daña a todas las sombras cerca.
func _explosion(x: float, radio: float, dano: float, col: Color) -> void:
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if absf(float(d["x"]) - x) < radio:
			_herir(d, dano)
	if bot:
		return
	for i: int in int(10 + radio / 10.0):
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": Vector2(x, S - 10.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, radio * 1.6), "t": rng.randf_range(0.4, 0.8), "c": col if i % 2 else col.lightened(0.5), "r": rng.randf_range(3, 7), "g": 300.0})
	_sacudir = maxf(_sacudir, radio / 500.0)
	Audio.play("ui_big", 0.1, -8.0, 1.4)


## Fragmentos de luna: moneda de las mejoras permanentes.
func _ganar_fragmentos(n: int, p: Vector2) -> void:
	if bot:
		return
	Estado.d["fragmentos"] = Estado.n("fragmentos") + n
	Estado.guardar()
	_texto(Idioma.t("+%d fragmentos de luna") % n, p, Color(1.0, 0.45, 0.45))
	for i: int in 14:
		var a: float = rng.randf_range(0.0, TAU)
		_particulas.append({"p": p, "v": Vector2(cos(a), sin(a)) * rng.randf_range(60, 200), "t": 1.0, "c": Color(1.0, 0.3, 0.35), "r": 4.0, "g": -40.0})


## Parón de impacto: congela un instante para que el golpe se note.
func _parar(t: float) -> void:
	if bot:
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(t, true, false, true).timeout
	Engine.time_scale = 1.0


## Habilidad de la reina: el farol estalla en luz y quema a las sombras cercanas.
func destello() -> bool:
	if cd_destello > 0.0:
		return false
	var radio: float = 330.0 * (1.0 + 0.15 * Estado.mejora("farol"))
	cd_destello = 35.0 * (1.0 - 0.2 * Estado.mejora("farol"))
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if absf(float(d["x"]) - float(reina["x"])) < radio:
			_herir(d, 20.0)
			d["aturdido"] = 2.0
	if not bot:
		_flash = 1.0
		_sacudir = 0.7
		Juice.vibrate(70)
		Audio.play("ui_big", 0.0, 0.0, 1.6)
		_parar(0.08)
		for i: int in 40:
			var a: float = i / 40.0 * TAU
			_particulas.append({"p": Vector2(float(reina["x"]), S - 120.0), "v": Vector2(cos(a), sin(a)) * 520.0, "t": 0.45, "c": Color(1.0, 0.95, 0.7), "r": 5.0})
	return true


## Habilidad de la reina: el cuerno de guerra. Tus soldados pegan más y más rápido un rato.
func cuerno() -> bool:
	if cd_cuerno > 0.0:
		return false
	cd_cuerno = 60.0
	cuerno_t = 12.0
	if not bot:
		_avisar(Idioma.t("¡A las armas!"))
		Juice.vibrate(40)
		Audio.play("ui_big", 0.0, -2.0, 0.55)
		for g: Variant in gente:
			var d: Dictionary = g as Dictionary
			if str(d["oficio"]) in ["arquero", "lancero", "heroe"]:
				for i: int in 6:
					_particulas.append({"p": Vector2(float(d["x"]), S - 60.0), "v": Vector2(rng.randf_range(-40, 40), rng.randf_range(-160, -80)), "t": 0.8, "c": Color(1.0, 0.8, 0.3), "r": 3.0})
	return true


func _arqueros_en_torre(lado: int) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == "arquero" and int((g as Dictionary)["lado"]) == lado and bool((g as Dictionary).get("torre", false))).size()


func _x_tienda(of: String) -> float:
	for s: Variant in sitios:
		if str((s as Dictionary)["tipo"]) == "tienda_" + of:
			return float((s as Dictionary)["x"])
	return 0.0


## Mueve hacia x; devuelve true si ha llegado.
func _andar(p: Dictionary, x: float, vel: float, dt: float) -> bool:
	var dx: float = x - float(p["x"])
	if absf(dx) < 6.0:
		return true
	p["dir"] = 1 if dx > 0 else -1
	p["x"] = float(p["x"]) + signf(dx) * minf(absf(dx), vel * dt)
	p["anda"] = true
	return absf(x - float(p["x"])) < 6.0


func _asaltar(p: Dictionary, dt: float) -> void:
	var lado: int = int(p["lado"])
	var gr: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "grieta" and int(d["lado"]) == lado:
			gr = d
	if gr.is_empty() or bool(gr["cerrada"]):
		p["asalto"] = false
		return
	var objetivo: float = float(gr["x"]) - lado * (60.0 if str(p["oficio"]) == "lancero" or str(p.get("heroe", "")) == "caballero" else 300.0)
	if _andar(p, objetivo, 110.0, dt) and float(p["cd"]) <= 0.0:
		p["cd"] = 1.0
		var dano_a: float = 6.0 if str(p["oficio"]) == "lancero" else 3.0
		if str(p["oficio"]) == "heroe":
			dano_a = float((Datos.HEROES[str(p["heroe"])] as Dictionary)["asalto"])
		gr["hp"] = float(gr["hp"]) - dano_a * _buff()
		if not bot:
			_chispas(Vector2(float(gr["x"]), S - 160.0), Color("ff3b3b"), 4)
		if float(gr["hp"]) <= 0.0:
			gr["cerrada"] = true
			gr["asalto"] = false
			_ganar_fragmentos(2, Vector2(float(gr["x"]), S - 200.0))
			if not bot:
				_avisar(Idioma.t("¡Grieta cerrada!"))
				_sacudir = 1.0
				Juice.vibrate(100)
				Audio.play("ui_big", 0.0, 0.0, 0.7)
			for g: Variant in gente:
				(g as Dictionary)["asalto"] = false


func _ciervo_cerca(x: float, r: float) -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = r
	for c: Variant in ciervos:
		var dd: float = absf(float((c as Dictionary)["x"]) - x)
		if dd < md:
			md = dd
			mejor = c as Dictionary
	return mejor


func _criatura_cerca(x: float, r: float, aire: bool) -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = r
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if bool(d["vuela"]) and not aire:
			continue
		var dd: float = absf(float(d["x"]) - x)
		if dd < md:
			md = dd
			mejor = d
	return mejor


func _disparar(p: Dictionary, tx: float, ty: float, caza: bool) -> void:
	p["cd"] = 1.25 * (0.65 if cuerno_t > 0.0 else 1.0)
	p["ataca"] = 0.25
	var ox: float = float(p["x"])
	var oy: float = S - (220.0 if bool(p.get("torre", false)) else 70.0)
	var dx: float = tx - ox
	var vx: float = signf(dx) * 640.0
	var t: float = maxf(0.15, absf(dx) / 640.0)
	var vy: float = (ty - oy - 0.5 * 900.0 * t * t) / t
	flechas.append({"x": ox, "y": oy, "vx": vx, "vy": vy, "t": 0.0, "caza": caza, "dano": 3.0 * _buff()})
	p["dir"] = 1 if dx > 0 else -1
	if not bot:
		Audio.play("ui_swoosh", 0.25, -14.0, 1.4)


func _flechas(dt: float) -> void:
	for f: Variant in flechas:
		var a: Dictionary = f as Dictionary
		a["t"] = float(a["t"]) + dt
		a["vy"] = float(a["vy"]) + 900.0 * dt
		a["x"] = float(a["x"]) + float(a["vx"]) * dt
		a["y"] = float(a["y"]) + float(a["vy"]) * dt
		if bool(a["caza"]):
			for c: Variant in ciervos:
				var cd: Dictionary = c as Dictionary
				if absf(float(cd["x"]) - float(a["x"])) < 30.0 and float(a["y"]) > S - 90.0:
					cd["hp"] = float(cd["hp"]) - 3.0
					a["fin"] = true
					if float(cd["hp"]) <= 0.0:
						cd["muerto"] = true
						for i: int in 2:
							_soltar_brasa(float(cd["x"]) + rng.randf_range(-20, 20))
					break
		else:
			for c: Variant in criaturas:
				var d: Dictionary = c as Dictionary
				var cy: float = _y_criatura(d)
				var alto: float = float((Datos.CRIATURAS[str(d["tipo"])] as Dictionary)["alto"])
				if absf(float(d["x"]) - float(a["x"])) < 26.0 + alto * 0.2 and float(a["y"]) > cy - alto and float(a["y"]) < cy + 10.0:
					if float(a.get("aoe", 0.0)) > 0.0:
						_explosion(float(a["x"]), float(a["aoe"]), float(a["dano"]), a.get("col", Color(0.4, 1.0, 0.3)) as Color)
					else:
						_herir(d, float(a.get("dano", 3.0)))
					a["fin"] = true
					break
		if float(a["y"]) > S + 4.0 or float(a["t"]) > 3.0:
			if float(a.get("aoe", 0.0)) > 0.0 and not bool(a.get("fin", false)):
				_explosion(float(a["x"]), float(a["aoe"]), float(a["dano"]), a.get("col", Color(0.4, 1.0, 0.3)) as Color)
			a["fin"] = true
	flechas = flechas.filter(func(f: Variant) -> bool: return not bool((f as Dictionary).get("fin", false)))
	ciervos = ciervos.filter(func(c: Variant) -> bool: return not bool((c as Dictionary).get("muerto", false)))


func _ciervos(dt: float) -> void:
	for c: Variant in ciervos:
		var d: Dictionary = c as Dictionary
		d["t"] = float(d["t"]) + dt
		if fmod(float(d["t"]), 5.0) < dt:
			d["dir"] = -int(d["dir"]) if rng.randf() < 0.5 else int(d["dir"])
		var nx: float = float(d["x"]) + int(d["dir"]) * 35.0 * dt
		var m: Dictionary = muro_exterior(1 if nx > 0 else -1)
		var limite: float = absf(float(m["x"])) + 200.0 if not m.is_empty() else 900.0
		if absf(nx) < limite or absf(nx) > Datos.BORDE - 400.0:
			d["dir"] = -int(d["dir"])
		else:
			d["x"] = nx


# ------------------------------------------------------------------ sombras

func _y_criatura(c: Dictionary) -> float:
	if bool(c["vuela"]):
		return S - 170.0 + sin(float(c["t"]) * 3.0) * 20.0
	return S


func _criaturas(dt: float) -> void:
	var dia_ya: bool = fase == "alba" or fase == "dia"
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		var info: Dictionary = Datos.CRIATURAS[str(d["tipo"])] as Dictionary
		d["t"] = float(d["t"]) + dt
		d["cd"] = maxf(0.0, float(d["cd"]) - dt)
		d["golpe"] = maxf(0.0, float(d["golpe"]) - dt)
		var lado: int = int(d["lado"])
		var v: float = float(info["vel"])
		if float(d.get("aturdido", 0.0)) > 0.0:
			d["aturdido"] = float(d["aturdido"]) - dt
			continue
		if bool(d["huye"]) or dia_ya:
			d["x"] = float(d["x"]) + lado * v * 1.6 * dt
			if dia_ya:
				d["hp"] = float(d["hp"]) - 15.0 * dt
			if absf(float(d["x"])) > Datos.BORDE - 200.0:
				d["fuera"] = true
			continue
		## Muro que le corta el paso (los alados vuelan por encima).
		var muro: Dictionary = {}
		if not bool(d["vuela"]):
			for s: Variant in sitios:
				var w: Dictionary = s as Dictionary
				if str(w["tipo"]) == "muro" and int(w["lado"]) == lado and int(w["nivel"]) > 0 and float(w["hp"]) > 0.0 \
						and absf(float(w["x"])) < absf(float(d["x"])) + 2.0:
					if muro.is_empty() or absf(float(w["x"])) > absf(float(muro["x"])):
						muro = w
		if not muro.is_empty() and absf(float(d["x"]) - float(muro["x"])) < 46.0:
			if float(d["cd"]) <= 0.0:
				d["cd"] = 1.0
				muro["hp"] = float(muro["hp"]) - float(info["dano"]) * (1.0 + dia * 0.02)
				if not bot:
					_chispas(Vector2(float(muro["x"]), S - 80.0), Color(0.6, 0.5, 0.4), 3)
					if absf(float(muro["x"]) - cam) < 700.0:
						Audio.play("ui_tick", 0.2, -10.0, 0.4)
				if float(muro["hp"]) <= 0.0:
					muro["nivel"] = 0
					muro["hp"] = 0.0
					muro["obj"] = 0
					if not bot:
						_avisar(Idioma.t("¡Han roto un muro!"))
						_sacudir = 0.6
			continue
		## Avanza hacia el fuego.
		d["x"] = float(d["x"]) - lado * v * dt
		## Ataca a quien encuentre.
		if float(d["cd"]) > 0.0:
			continue
		if absf(float(d["x"]) - float(reina["x"])) < 40.0 and float(reina["inmune"]) <= 0.0:
			d["cd"] = 1.2
			_golpe_reina(d)
			d["huye"] = true
			continue
		for g: Variant in gente:
			var p: Dictionary = g as Dictionary
			if str(p["oficio"]) == "vagabundo" or float(p.get("aturdido", 0.0)) > 0.0:
				continue
			if absf(float(d["x"]) - float(p["x"])) < 30.0 and str(p["oficio"]) == "heroe":
				d["cd"] = 1.2
				p["aturdido"] = 4.0
				d["huye"] = true
				if not bot:
					_texto(Idioma.t("¡Herido!"), Vector2(float(p["x"]), S - 170.0), Estilo.ROJO)
				break
			if absf(float(d["x"]) - float(p["x"])) < 30.0:
				d["cd"] = 1.2
				## Pierde la herramienta y huye: vuelve a ser vagabundo.
				p["oficio"] = "vagabundo"
				p["asalto"] = false
				p["obj"] = lado * 2300.0
				d["huye"] = true
				stats["perdidos"] = int(stats["perdidos"]) + 1
				if not bot:
					_texto(Idioma.t("¡Le han quitado la herramienta!"), Vector2(float(p["x"]), S - 160.0), Estilo.ROJO)
				break
	for c: Variant in criaturas:
		var d2: Dictionary = c as Dictionary
		if float(d2["hp"]) <= 0.0 and not bool(d2.get("fuera", false)):
			d2["fuera"] = true
			stats["abatidas"] = int(stats["abatidas"]) + 1
			if str(d2["tipo"]) == "jefe":
				stats["jefes"] = int(stats["jefes"]) + 1
				Estado.d["jefes"] = Estado.n("jefes") + 1
				for i: int in 6:
					_soltar_brasa(float(d2["x"]) + rng.randf_range(-60, 60))
				_ganar_fragmentos(3, Vector2(float(d2["x"]), S - 260.0))
			if not bot:
				var alto_c: float = float((Datos.CRIATURAS[str(d2["tipo"])] as Dictionary)["alto"])
				for i: int in int(8 + alto_c / 10.0):
					var a: float = rng.randf_range(0.0, TAU)
					_particulas.append({"p": Vector2(float(d2["x"]), _y_criatura(d2) - alto_c * 0.5), "v": Vector2(cos(a), sin(a)) * rng.randf_range(60, 220),
						"t": rng.randf_range(0.5, 1.0), "c": Color(0.06, 0.02, 0.06, 0.8) if i % 3 else Color(1.0, 0.25, 0.1, 0.9), "r": rng.randf_range(3, 9), "g": -30.0})
				Audio.play("ui_tick", 0.2, -8.0, 0.35)
	criaturas = criaturas.filter(func(c: Variant) -> bool: return not bool((c as Dictionary).get("fuera", false)))


func _herir(c: Dictionary, dano: float) -> void:
	c["hp"] = float(c["hp"]) - dano
	c["golpe"] = 0.15
	if not bot and dano >= 6.0:
		_textos.append({"s": "%d" % int(round(dano)), "x": float(c["x"]) + rng.randf_range(-20, 20), "y": _y_criatura(c) - float((Datos.CRIATURAS[str(c["tipo"])] as Dictionary)["alto"]) - 10.0,
			"c": Color(1.0, 0.9, 0.5) if dano < 15.0 else Color(1.0, 0.55, 0.3), "t": 0.8})


func _golpe_reina(c: Dictionary) -> void:
	reina["inmune"] = 1.6
	if brasas > 0:
		var pierde: int = mini(brasas, 3 if str(c["tipo"]) != "jefe" else 8)
		brasas -= pierde
		if not bot:
			_texto(Idioma.t("-%d brasas") % pierde, Vector2(float(reina["x"]), S - 200.0), Estilo.ROJO)
			_sacudir = 0.5
			Juice.vibrate(60)
			Audio.play("ui_error", 0.0, -2.0)
		return
	## Sin brasas: la corona cae.
	vivo = false
	causa = "%s/dia%d" % [str(c["tipo"]), dia]
	if not bot:
		_sacudir = 1.0
		Juice.vibrate(150)
		_perder()


# ------------------------------------------------------------------ brasas por el suelo

func _soltar_brasa(x: float) -> void:
	suelo_brasas.append({"x": x, "y": S - 60.0, "vy": rng.randf_range(-260.0, -140.0), "vx": rng.randf_range(-40, 40), "t": 0.0})


func _recoger_brasas(dt: float) -> void:
	for b: Variant in suelo_brasas:
		var d: Dictionary = b as Dictionary
		d["t"] = float(d["t"]) + dt
		if (float(d["y"]) < S - 8.0 or float(d["vy"]) < 0.0) and float(d["t"]) <= 0.6:
			d["vy"] = float(d["vy"]) + 900.0 * dt
			d["y"] = minf(S - 8.0, float(d["y"]) + float(d["vy"]) * dt)
			d["x"] = float(d["x"]) + float(d["vx"]) * dt
		if float(d["t"]) > 0.6 and absf(float(d["x"]) - float(reina["x"])) < 170.0 and brasas < MAX_BRASAS:
			## Las brasas cercanas vuelan hacia la reina.
			d["x"] = lerpf(float(d["x"]), float(reina["x"]), minf(1.0, dt * 7.0))
			d["y"] = lerpf(float(d["y"]), S - 110.0, minf(1.0, dt * 5.0))
		if float(d["t"]) > 0.4 and absf(float(d["x"]) - float(reina["x"])) < 40.0 and brasas < MAX_BRASAS:
			d["fin"] = true
			brasas += 1
			if not bot:
				Audio.play("ui_coin", 0.15, -10.0, 1.2)
	suelo_brasas = suelo_brasas.filter(func(b: Variant) -> bool: return not bool((b as Dictionary).get("fin", false)) and float((b as Dictionary)["t"]) < 120.0)


# ------------------------------------------------------------------ ganar / perder

func _ganar() -> void:
	ganado = true
	if bot:
		return
	Estado.d["fragmentos"] = Estado.n("fragmentos") + 3
	Estado.ganar_valle()
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("¡Valle liberado!"), 720.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Has cerrado las dos grietas en %d días.") % dia, 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true))
	vb.add_child(Estilo.etiqueta(Idioma.t("Sombras abatidas: %d   ·   Obras: %d") % [int(stats["abatidas"]), int(stats["construidos"])], 22, Estilo.NIEBLA))
	var sig: String = Idioma.t("Siguiente valle") if Estado.valle_actual() < Datos.VALLES.size() else Idioma.t("Luna eterna")
	var b: Button = Estilo.boton(sig, true, 84)
	b.pressed.connect(func() -> void:
		Estado.partida = {"nuevo": true}
		Kit.change_scene("res://libre/juego.tscn"))
	vb.add_child(b)
	var bi: Button = Estilo.boton(Idioma.t("Inicio"), false, 72)
	bi.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bi)
	Audio.play_track("victoria", false)


func _perder() -> void:
	await get_tree().create_timer(0.8).timeout
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("La corona ha caído"), 680.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Aguantaste %d noches.") % (dia - 1), 28, Estilo.TEXTO))
	var g: Dictionary = Estado.d["guardada"] as Dictionary
	if not revivido and not g.is_empty() and Ads.rewarded_available():
		var ba: Button = Estilo.boton(Idioma.t("Ver un anuncio: volver al último amanecer"), true, 84)
		ba.pressed.connect(func() -> void: _revivir(ba))
		vb.add_child(ba)
	if not g.is_empty():
		var bv: Button = Estilo.boton(Idioma.t("Volver al último amanecer (-25% brasas)"), false, 76)
		bv.pressed.connect(func() -> void:
			var g2: Dictionary = (Estado.d["guardada"] as Dictionary).duplicate(true)
			g2["brasas"] = int(int(g2.get("brasas", 0)) * 0.75)
			Estado.d["guardada"] = g2
			Estado.guardar()
			Estado.partida = {}
			Kit.change_scene("res://libre/juego.tscn"))
		vb.add_child(bv)
	var bn: Button = Estilo.boton(Idioma.t("Empezar el valle de nuevo"), false, 72)
	bn.pressed.connect(func() -> void:
		Estado.d["guardada"] = {}
		Estado.guardar()
		Estado.partida = {"nuevo": true}
		Kit.change_scene("res://libre/juego.tscn"))
	vb.add_child(bn)
	var bi: Button = Estilo.boton(Idioma.t("Inicio"), false, 72)
	bi.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bi)


func _revivir(b: Button) -> void:
	b.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "corona":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("corona")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		Estado.partida = {"revivido": true}
		Kit.change_scene("res://libre/juego.tscn")
	else:
		b.disabled = false


# ------------------------------------------------------------------ dibujo

func _sx(x: float) -> float:
	return x - cam + ANCHO / 2.0


## Textura apoyada en el suelo, centrada en x, con alto dado. Si no hay textura, un bloque de color.
func _sprite(id: String, x: float, alto: float, flip: bool = false, mod: Color = Color.WHITE, y_pie: float = S, inclina: float = 0.0, esc: Vector2 = Vector2.ONE) -> void:
	var sx: float = _sx(x)
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		draw_rect(Rect2(sx - alto * 0.25, y_pie - alto, alto * 0.5, alto), mod.darkened(0.5))
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	if sx + ancho < -50.0 or sx - ancho > ANCHO + 50.0:
		return
	if inclina != 0.0 or esc != Vector2.ONE:
		## Se escala y gira desde los pies: así se aplasta y se estira al andar sin despegarse del suelo.
		draw_set_transform(Vector2(sx, y_pie), inclina, Vector2((-1.0 if flip else 1.0) * esc.x, esc.y))
		draw_texture_rect(tx, Rect2(-ancho / 2.0, -alto, ancho, alto), false, mod)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		return
	draw_texture_rect(tx, Rect2(sx + (ancho / 2.0 if flip else -ancho / 2.0), y_pie - alto, -ancho if flip else ancho, alto), false, mod)


func _cielo_valle(id: String) -> String:
	var v: String = str(datos_valle["id"])
	if v == "ciervo":
		return id
	var alt: String = {"lr_cielo_dia": "lr_cielo_dia_" + v, "lr_cielo_tarde": "lr_cielo_dia_" + v, "lr_cielo_noche": "lr_cielo_noche_" + v}.get(id, id)
	return alt if _tex.get(alt) != null else id


func _cielo_id() -> Array:
	## [id actual, id siguiente, mezcla]
	var f: float = t_fase / _duracion_fase()
	match fase:
		"dia":
			return ["lr_cielo_dia", "lr_cielo_tarde", clampf((f - 0.85) / 0.15, 0.0, 1.0)]
		"tarde":
			return ["lr_cielo_tarde", "lr_cielo_roja" if luna == "roja" else "lr_cielo_noche", f]
		"noche":
			return ["lr_cielo_roja" if luna_hoy == "roja" else "lr_cielo_noche", "lr_cielo_noche", 0.0]
	return ["lr_cielo_roja" if luna_hoy == "roja" else "lr_cielo_noche", "lr_cielo_dia", t_fase / Datos.T_ALBA]


func _draw() -> void:
	var tinte: Color = datos_valle["tinte"] as Color
	var c: Array = _cielo_id()
	var cielo_t: Color = tinte
	if fase == "noche" or fase == "alba":
		cielo_t = tinte * ({"nueva": Color(0.45, 0.45, 0.55), "azul": Color(0.7, 0.85, 1.25), "llena": Color(1.1, 1.1, 1.15)}.get(luna_hoy, Color.WHITE) as Color)
	for k: int in 2:
		var tx: Texture2D = _tex.get(_cielo_valle(str(c[k]))) as Texture2D
		var a: float = 1.0 if k == 0 else float(c[2])
		if a <= 0.0:
			continue
		if tx != null:
			var ts: Vector2 = tx.get_size()
			var off: float = fposmod(cam * 0.03, ts.x * 0.3)
			draw_texture_rect_region(tx, Rect2(0, 0, ANCHO, S + 20.0), Rect2(off, 0, ts.x * 0.7, ts.y * 0.92), Color(cielo_t, a))
		else:
			draw_rect(Rect2(0, 0, ANCHO, S), Color(0.3, 0.35, 0.5, a))
	_astros()
	_bosque_lejano(0.22, Color(0.16, 0.2, 0.24) * tinte, 150.0, 1)
	_bosque_lejano(0.4, Color(0.09, 0.12, 0.13) * tinte, 110.0, 2)
	for ar: Variant in _arboles:
		var a2: Dictionary = ar as Dictionary
		if int(a2["capa"]) == 0:
			_sprite(_arbol_id, float(a2["x"]) * 0.85 + cam * 0.15, 380.0 * float(a2["esc"]), false, tinte.darkened(0.45))
	## Suelo: tierra con degradado y piedrecitas que se mueven con la cámara.
	var tierra: Color = datos_valle["suelo"] as Color
	draw_polygon(PackedVector2Array([Vector2(0, S - 4.0), Vector2(ANCHO, S - 4.0), Vector2(ANCHO, ALTO), Vector2(0, ALTO)]),
		PackedColorArray([tierra.lightened(0.08), tierra.lightened(0.08), tierra.darkened(0.45), tierra.darkened(0.45)]))
	var px: float = -fposmod(cam, 53.0)
	while px < ANCHO + 53.0:
		var k: float = floor((px + cam) / 53.0)
		var py: float = S + 18.0 + fposmod(k * 37.0, 90.0)
		draw_circle(Vector2(px + fposmod(k * 17.0, 40.0), py), 2.0 + fposmod(k, 3.0), tierra.lightened(0.15))
		px += 53.0
	var hb: Color = datos_valle["hierba"] as Color
	var gx: float = -fposmod(cam, 18.0)
	while gx < ANCHO + 18.0:
		var hh: float = 5.0 + 6.0 * absf(sin((gx + cam) * 0.21))
		draw_colored_polygon(PackedVector2Array([Vector2(gx, S), Vector2(gx + 6, S - hh), Vector2(gx + 12, S)]), hb)
		gx += 18.0
	draw_rect(Rect2(0, S, ANCHO, 6), hb.darkened(0.2))
	for ar2: Variant in _arboles:
		var a3: Dictionary = ar2 as Dictionary
		if int(a3["capa"]) == 1:
			_sprite(_arbol_id, float(a3["x"]), 460.0 * float(a3["esc"]), false, tinte.darkened(0.2))
	_dibujar_sitios()
	for ci: Variant in ciervos:
		var cd: Dictionary = ci as Dictionary
		_sprite("lr_ciervo", float(cd["x"]), 88.0, int(cd["dir"]) < 0, tinte, S + 4.0 - absf(sin(float(cd["t"]) * 6.0)) * 3.0)
	for g: Variant in gente:
		_dibujar_persona(g as Dictionary)
	if mercader:
		_sprite("lr_mercader", 90.0, 130.0, false, Color(0.8, 0.95, 1.0, 0.75 + 0.2 * sin(tiempo * 3.0)), S - 6.0 + sin(tiempo * 2.0) * 6.0)
	_dibujar_reina()
	for cr: Variant in criaturas:
		_dibujar_criatura(cr as Dictionary)
	for f: Variant in flechas:
		var a4: Dictionary = f as Dictionary
		var p: Vector2 = Vector2(_sx(float(a4["x"])), float(a4["y"]))
		var v: Vector2 = Vector2(float(a4["vx"]), float(a4["vy"])).normalized()
		var n: Vector2 = Vector2(-v.y, v.x)
		if bool(a4.get("bola", false)):
			draw_circle(p, 16.0, Color(0.4, 1.0, 0.3, 0.25))
			draw_circle(p, 9.0, Color(0.5, 1.0, 0.4))
			draw_circle(p, 4.0, Color(0.9, 1.0, 0.8))
			if not bot and fmod(float(a4["t"]), 0.04) < 0.02:
				_particulas.append({"p": Vector2(float(a4["x"]), float(a4["y"])), "v": Vector2.ZERO, "t": 0.35, "c": Color(0.4, 1.0, 0.3, 0.6), "r": 5.0})
			continue
		if bool(a4.get("estrella", false)):
			draw_line(p - v * 40.0, p, Color(0.8, 0.9, 1.0, 0.35), 6.0)
			draw_line(p - v * 30.0, p, Color(0.9, 0.95, 1.0), 2.5)
			draw_circle(p, 4.0, Color(1, 1, 0.85))
			continue
		draw_line(p - v * 30.0, p, Color(0.55, 0.38, 0.2), 2.5)
		draw_colored_polygon(PackedVector2Array([p + v * 8.0, p + n * 3.5, p - n * 3.5]), Color(0.8, 0.82, 0.85))
		draw_colored_polygon(PackedVector2Array([p - v * 30.0, p - v * 22.0 + n * 5.0, p - v * 24.0]), Color(0.85, 0.85, 0.8))
		draw_colored_polygon(PackedVector2Array([p - v * 30.0, p - v * 22.0 - n * 5.0, p - v * 24.0]), Color(0.75, 0.75, 0.7))
	for b: Variant in suelo_brasas:
		var bd: Dictionary = b as Dictionary
		var bp: Vector2 = Vector2(_sx(float(bd["x"])), float(bd["y"]))
		draw_circle(bp, 11.0, Color(1.0, 0.5, 0.1, 0.25 + 0.1 * sin(tiempo * 6.0 + float(bd["x"]))))
		draw_circle(bp, 5.5, Color("ffb347"))
		draw_circle(bp, 2.5, Color("fff2c4"))
	_ambiente()
	_dibujar_particulas()
	if _flash > 0.0:
		draw_rect(Rect2(0, 0, ANCHO, ALTO), Color(1.0, 0.96, 0.85, _flash * 0.6))
		_flash = maxf(0.0, _flash - get_process_delta_time() * 2.5)
	_dibujar_coste()


## Sol y luna que cruzan el cielo; estrellas que titilan de noche; pájaros de día.
func _astros() -> void:
	var f: float = t_fase / _duracion_fase()
	var noche: float = _oscuridad()
	if fase == "dia" or fase == "tarde":
		## Pájaros
		for i: int in 5:
			var bx: float = fposmod(tiempo * (38.0 + i * 6.0) + i * 260.0 - cam * 0.1, ANCHO + 200.0) - 100.0
			var by: float = 150.0 + i * 22.0 + sin(tiempo * 1.3 + i) * 12.0
			var al: float = sin(tiempo * 8.0 + i * 2.0) * 6.0
			var c: Color = Color(0.1, 0.08, 0.1, 0.6 * (1.0 - noche))
			draw_line(Vector2(bx - 9, by - al), Vector2(bx, by), c, 2.0)
			draw_line(Vector2(bx, by), Vector2(bx + 9, by - al), c, 2.0)
	if noche > 0.05:
		for i: int in 60:
			var stx: float = fposmod(i * 211.7 - cam * 0.02, ANCHO)
			var sty: float = fposmod(i * 97.3, 360.0) + 10.0
			var br: float = (0.4 + 0.6 * absf(sin(tiempo * (1.0 + fposmod(i * 0.37, 2.0)) + i))) * noche
			draw_circle(Vector2(stx, sty), 1.0 + fposmod(i, 3.0) * 0.5, Color(1, 1, 1, br * 0.8))


## Ambiente por delante: niebla nocturna, luciérnagas, y el tiempo de cada valle (lluvia, ceniza).
func _ambiente() -> void:
	var noche: float = _oscuridad()
	var id: String = str(datos_valle["id"])
	if noche > 0.1:
		for i: int in 7:
			var fx: float = fposmod(i * 300.0 - cam * 0.6 + tiempo * (12.0 + i * 3.0), ANCHO + 600.0) - 300.0
			var fy: float = S - 30.0 - (i % 3) * 22.0
			draw_circle(Vector2(fx, fy), 140.0 + (i % 2) * 60.0, Color(0.6, 0.65, 0.8, 0.05 * noche))
		for i: int in 24:
			var lx: float = fposmod(i * 173.0 - cam * 0.9 + sin(tiempo * 0.7 + i) * 40.0, ANCHO)
			var ly: float = S - 40.0 - fposmod(i * 61.0, 220.0) + sin(tiempo * 1.1 + i * 2.0) * 18.0
			var a: float = maxf(0.0, sin(tiempo * 2.3 + i * 1.7)) * noche
			draw_circle(Vector2(lx, ly), 2.2, Color(0.85, 1.0, 0.5, a))
			draw_circle(Vector2(lx, ly), 6.0, Color(0.85, 1.0, 0.5, a * 0.25))
	if id == "cienaga":
		for i: int in 70:
			var rx: float = fposmod(i * 89.0 + tiempo * 120.0 - cam * 0.5, ANCHO + 40.0) - 20.0
			var ry: float = fposmod(i * 137.0 + tiempo * 620.0, ALTO)
			draw_line(Vector2(rx, ry), Vector2(rx - 6, ry + 18), Color(0.7, 0.78, 0.85, 0.3), 1.2)
	elif id == "ceniza":
		for i: int in 45:
			var ax: float = fposmod(i * 113.0 + sin(tiempo * 0.5 + i) * 60.0 - cam * 0.7 + tiempo * 15.0, ANCHO)
			var ay: float = fposmod(i * 71.0 + tiempo * 40.0, ALTO)
			var brasa: bool = i % 6 == 0
			draw_circle(Vector2(ax, ay), 2.0 if not brasa else 2.4, Color(1.0, 0.45, 0.15, 0.8) if brasa else Color(0.55, 0.5, 0.5, 0.5))


## Pinos lejanos en silueta, con parallax.
func _bosque_lejano(par: float, col: Color, alto: float, capa: int) -> void:
	var noche: float = _oscuridad()
	col = col.darkened(noche * 0.3)
	var pts: PackedVector2Array = PackedVector2Array([Vector2(0, S)])
	var off: float = cam * par
	var x: float = -fposmod(off, 14.0)
	while x <= ANCHO + 14.0:
		var u: float = (x + off) / 14.0
		var k: float = floor(u)
		var fr: float = u - k
		var h: float = alto * (0.55 + 0.45 * absf(sin(k * 12.9898 + capa * 3.1)))
		pts.append(Vector2(x, S - h * (1.0 - absf(fr - 0.5) * 2.0) - alto * 0.25))
		x += 7.0
	pts.append(Vector2(ANCHO, S))
	draw_colored_polygon(pts, col)


func _capa_repetida(id: String, par: float, alto: float, y: float, mod: Color) -> void:
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	var x0: float = -fposmod(cam * par, ancho)
	while x0 < ANCHO:
		draw_texture_rect(tx, Rect2(x0, y, ancho, alto), false, mod)
		x0 += ancho - 1.0


func _dibujar_sitios() -> void:
	var tinte: Color = datos_valle["tinte"] as Color
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		var x: float = float(d["x"])
		if absf(_sx(x) - ANCHO / 2.0) > ANCHO:
			continue
		var tipo: String = str(d["tipo"])
		var nv: int = int(d["nivel"])
		match tipo:
			"hoguera":
				_sprite("lr_hoguera", x, 150.0 + nv * 25.0, false, tinte)
				if not bot and fmod(tiempo, 0.25) < 0.02:
					_particulas.append({"p": Vector2(x + rng.randf_range(-10, 10), S - 110.0 - nv * 12.0), "v": Vector2(rng.randf_range(5, 25), rng.randf_range(-50, -30)), "t": 2.0, "c": Color(0.3, 0.28, 0.3, 0.1), "r": rng.randf_range(8, 14), "g": -5.0})
				if not bot and fmod(tiempo, 0.12) < 0.02:
					_particulas.append({"p": Vector2(x, S - 60.0 - nv * 10.0), "v": Vector2(rng.randf_range(-20, 20), rng.randf_range(-120, -60)), "t": 0.9, "c": Color(1.0, 0.6, 0.2), "r": 2.5, "mundo": true})
			"muro":
				if nv > 0:
					var vida: float = float(d["hp"]) / _vida_muro(nv)
					_muro(x, nv, vida, tinte)
					if vida < 0.99:
						var sx: float = _sx(x)
						draw_rect(Rect2(sx - 40, S - [0.0, 140.0, 185.0, 225.0][nv], 80, 7), Color(0, 0, 0, 0.6))
						draw_rect(Rect2(sx - 40, S - [0.0, 140.0, 185.0, 225.0][nv], 80 * vida, 7), Estilo.ROJO.lerp(Estilo.VERDE, vida))
				else:
					_marcador(x, d)
			"torre":
				if nv > 0:
					_sprite("lr_torre", x, 300.0, false, tinte)
				else:
					_marcador(x, d)
			"granja":
				if nv > 0:
					_granja(x, tinte)
				else:
					_marcador(x, d)
			"campamento":
				_sprite("lr_campamento", x, 80.0, int(d["lado"]) < 0, tinte, S + 4.0)
			"cofre":
				if not bool(d["abierto"]):
					_sprite("lr_cofre", x, 50.0, false, tinte, S + 4.0)
			"santuario":
				_sprite("lr_santuario", x, 150.0, false, tinte, S + 6.0)
				if not bool(d["rescatado"]):
					var hid: String = str(d["heroe"])
					var hx: Dictionary = Datos.HEROES[hid] as Dictionary
					_sprite(str(hx["tex"]), x, 110.0, int(d["lado"]) > 0, Color(0.75, 0.8, 1.0, 0.7 + 0.2 * sin(tiempo * 2.0)), S + 2.0 - sin(tiempo * 1.5) * 4.0)
			"grieta":
				var vivo_g: bool = not bool(d["cerrada"])
				var m: Color = tinte if vivo_g else Color(0.4, 0.4, 0.45, 0.6)
				_sprite("lr_portal", x, 260.0 + (sin(tiempo * 2.0) * 6.0 if vivo_g else 0.0), int(d["lado"]) > 0, m, S + 10.0)
			_:
				if tipo.begins_with("tienda_"):
					var of: String = tipo.substr(7)
					var sx2: float = _sx(x)
					var toldo: Color = {"arquero": Color("3f6b3a"), "constructor": Color("8a5a24"), "granjero": Color("b8902e"), "lancero": Color("8c2a22")}[of] * tinte
					draw_rect(Rect2(sx2 - 40, S - 34, 80, 34), Color("4a321c") * tinte)
					draw_line(Vector2(sx2 - 38, S), Vector2(sx2 - 38, S - 96), Color("3b2716"), 5.0)
					draw_line(Vector2(sx2 + 38, S), Vector2(sx2 + 38, S - 96), Color("3b2716"), 5.0)
					draw_colored_polygon(PackedVector2Array([Vector2(sx2 - 50, S - 86), Vector2(sx2, S - 116), Vector2(sx2 + 50, S - 86)]), toldo)
					for k: int in 5:
						var fx: float = sx2 - 50.0 + k * 20.0
						draw_colored_polygon(PackedVector2Array([Vector2(fx, S - 86), Vector2(fx + 20, S - 86), Vector2(fx + 10, S - 74)]), toldo.darkened(0.15 * (k % 2)))
					for i: int in int(herramientas[of]):
						_icono_oficio(of, Vector2(sx2 - 18 + i * 14, S - 52))
					if int(herramientas[of]) == 0:
						_icono_oficio(of, Vector2(sx2, S - 52), 0.35)
		if d.has("obj") and (int(d["obj"]) > nv or bool(d.get("reparar", false))):
			## Andamio con la obra en marcha.
			var sx3: float = _sx(x)
			var tot: float = maxf(0.1, _trabajo_de(d))
			var pr: float = 1.0 - float(d["trabajo"]) / tot
			draw_rect(Rect2(sx3 - 36, S - 120, 72, 8), Color(0, 0, 0, 0.6))
			draw_rect(Rect2(sx3 - 36, S - 120, 72 * clampf(pr, 0.0, 1.0), 8), Estilo.ORO)
			draw_line(Vector2(sx3 - 30, S), Vector2(sx3 - 30, S - 110), Color(0.5, 0.35, 0.2), 4.0)
			draw_line(Vector2(sx3 + 30, S), Vector2(sx3 + 30, S - 110), Color(0.5, 0.35, 0.2), 4.0)
			draw_line(Vector2(sx3 - 30, S - 60), Vector2(sx3 + 30, S - 60), Color(0.5, 0.35, 0.2), 3.0)


## Muros dibujados de lado: empalizada de troncos, muro de piedra y muralla con almenas y pinchos.
func _muro(x: float, nv: int, vida: float, tinte: Color) -> void:
	var sx: float = _sx(x)
	var dano: Color = Color(1, 1, 1).lerp(Color(1.0, 0.55, 0.5), (1.0 - vida) * 0.6)
	match nv:
		1:
			for i: int in 5:
				var lx: float = sx - 30.0 + i * 15.0
				var alto: float = 105.0 + (i % 2) * 14.0
				var c: Color = Color("5a3d24").lerp(Color("6e4c2e"), (i % 2) * 0.6) * tinte * dano
				draw_rect(Rect2(lx - 7, S - alto, 14, alto), c)
				draw_colored_polygon(PackedVector2Array([Vector2(lx - 7, S - alto), Vector2(lx, S - alto - 16), Vector2(lx + 7, S - alto)]), c)
				draw_line(Vector2(lx - 5, S - alto + 6), Vector2(lx - 5, S - 4), Color(0, 0, 0, 0.25), 2.0)
			draw_rect(Rect2(sx - 38, S - 70, 76, 8), Color("3b2716") * tinte)
			draw_rect(Rect2(sx - 38, S - 35, 76, 8), Color("3b2716") * tinte)
		2, 3:
			var alto2: float = 150.0 if nv == 2 else 200.0
			var ancho: float = 70.0 if nv == 2 else 84.0
			var piedra: Color = (Color("57503f") if nv == 2 else Color("4a4540")) * tinte * dano
			draw_rect(Rect2(sx - ancho / 2.0, S - alto2, ancho, alto2), piedra)
			var fila: int = 0
			var y: float = S - 22.0
			while y > S - alto2:
				var off: float = 0.0 if fila % 2 == 0 else 12.0
				var bx: float = sx - ancho / 2.0 - off
				while bx < sx + ancho / 2.0:
					var x0: float = maxf(bx, sx - ancho / 2.0)
					var x1: float = minf(bx + 24.0, sx + ancho / 2.0)
					draw_rect(Rect2(x0 + 1, y + 1, x1 - x0 - 2, 20), piedra.lightened(0.06 * ((fila + int(bx)) % 3)))
					bx += 24.0
				y -= 22.0
				fila += 1
			## almenas
			var k: int = 0
			var ax: float = sx - ancho / 2.0
			while ax < sx + ancho / 2.0 - 4.0:
				if k % 2 == 0:
					draw_rect(Rect2(ax, S - alto2 - 18, 14, 18), piedra)
				ax += 14.0
				k += 1
			## Antorcha en lo alto del muro.
			var llama: float = sin(tiempo * 17.0 + x) * 2.0
			draw_line(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 30.0), Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 6.0), Color("3b2716"), 3.0)
			draw_circle(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 2.0 + llama), 7.0, Color(1.0, 0.55, 0.15, 0.9))
			draw_circle(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 3.0 + llama), 3.5, Color(1.0, 0.9, 0.5))
			if nv == 3:
				for i: int in 4:
					var px: float = sx - ancho / 2.0 + 10.0 + i * 21.0
					draw_colored_polygon(PackedVector2Array([Vector2(px - 4, S - alto2 - 18), Vector2(px, S - alto2 - 40), Vector2(px + 4, S - alto2 - 18)]), Color("2d2b30"))
				draw_line(Vector2(sx, S - alto2 - 18), Vector2(sx, S - alto2 - 80), Color("3b2716"), 3.0)
				draw_colored_polygon(PackedVector2Array([Vector2(sx, S - alto2 - 80), Vector2(sx + 34, S - alto2 - 70), Vector2(sx, S - alto2 - 58)]), Color("a2231c") * tinte)
			draw_line(Vector2(sx - ancho / 2.0, S - alto2), Vector2(sx - ancho / 2.0, S), Color(0, 0, 0, 0.35), 3.0)
			draw_line(Vector2(sx + ancho / 2.0, S - alto2), Vector2(sx + ancho / 2.0, S), Color(1, 0.9, 0.7, 0.18), 2.0)


func _granja(x: float, tinte: Color) -> void:
	var sx: float = _sx(x)
	draw_rect(Rect2(sx - 90, S - 6, 180, 10), Color("3a2a16") * tinte)
	for i: int in 22:
		var bx: float = sx - 84.0 + i * 8.0
		var mece: float = sin(tiempo * 1.8 + i * 0.5) * 4.0
		var alto: float = 46.0 + (i * 37 % 11)
		draw_line(Vector2(bx, S), Vector2(bx + mece, S - alto), Color("b8902e") * tinte, 2.0)
		draw_circle(Vector2(bx + mece, S - alto), 4.0, Color("e3b94a") * tinte)
	for i: int in 2:
		var fx: float = sx - 96.0 + i * 192.0
		draw_line(Vector2(fx, S), Vector2(fx, S - 34), Color("4a321c") * tinte, 4.0)
	draw_line(Vector2(sx - 96, S - 24), Vector2(sx + 96, S - 24), Color("4a321c") * tinte, 3.0)


## Sombra aplastada en el suelo (elipse).
func _sombra_suelo(x: float, r: float, a: float) -> void:
	draw_set_transform(Vector2(_sx(x), S + 2.0), 0.0, Vector2(1.0, 0.22))
	draw_circle(Vector2.ZERO, r, Color(0, 0, 0, a))
	draw_circle(Vector2.ZERO, r * 0.6, Color(0, 0, 0, a * 0.6))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _icono_oficio(of: String, p: Vector2, a: float = 1.0) -> void:
	var c: Color = Color(0.9, 0.85, 0.7, a)
	match of:
		"arquero":
			draw_arc(p, 14.0, -PI / 2.0 - 1.0, -PI / 2.0 + 1.0, 10, c, 3.0)
		"constructor":
			draw_line(p + Vector2(-6, 12), p + Vector2(6, -8), c, 3.0)
			draw_rect(Rect2(p + Vector2(0, -14), Vector2(14, 8)), c)
		"granjero":
			draw_line(p + Vector2(-4, 14), p + Vector2(4, -12), c, 3.0)
			draw_arc(p + Vector2(-4, -12), 10.0, -PI, -PI / 4.0, 8, c, 3.0)
		"lancero":
			draw_line(p + Vector2(0, 16), p + Vector2(0, -16), c, 3.0)
			draw_colored_polygon(PackedVector2Array([p + Vector2(-5, -14), p + Vector2(0, -24), p + Vector2(5, -14)]), c)


## Marcador de un sitio vacío: estaca con banderín.
func _marcador(x: float, d: Dictionary) -> void:
	var sx: float = _sx(x)
	var o: Dictionary = opcion(d)
	var col: Color = Color(0.9, 0.75, 0.4, 0.8) if not o.is_empty() and int(o["coste"]) >= 0 else Color(0.5, 0.5, 0.5, 0.5)
	draw_line(Vector2(sx, S), Vector2(sx, S - 54), Color(0.35, 0.25, 0.15), 4.0)
	draw_colored_polygon(PackedVector2Array([Vector2(sx, S - 54), Vector2(sx + 26, S - 46), Vector2(sx, S - 38)]), col)


func _dibujar_persona(p: Dictionary) -> void:
	var of: String = str(p["oficio"])
	var tid: String = "lr_" + of if of != "aldeano" else "lr_aldeano"
	if of == "heroe":
		tid = str((Datos.HEROES[str(p.get("heroe", "caballero"))] as Dictionary)["tex"])
	var anda: bool = bool(p.get("anda", false))
	var trabaja: bool = bool(p.get("trabaja", false))
	p["anda"] = false
	p["trabaja"] = false
	var t: float = float(p["t"])
	var paso_f: float = sin(t * 10.0)
	## Andar: rebote, aplastar y estirar a cada paso, y un poco de inclinación hacia delante.
	var bote: float = absf(paso_f) * 5.0 if anda else 0.0
	var esc: Vector2 = Vector2(1.0 + 0.05 * absf(paso_f), 1.0 - 0.05 * absf(paso_f)) if anda else Vector2(1.0, 1.0 + 0.012 * sin(t * 2.2))
	var incl: float = (0.06 + paso_f * 0.03) * int(p["dir"]) if anda else 0.0
	var dx: float = 0.0
	if trabaja and of == "constructor":
		## Martillazos: se inclina adelante y atrás.
		incl = sin(t * 16.0) * 0.16 * int(p["dir"])
		esc = Vector2(1.0, 1.0 - 0.04 * absf(sin(t * 16.0)))
	var ataca: float = float(p.get("ataca", 0.0))
	if ataca > 0.0:
		p["ataca"] = maxf(0.0, ataca - get_process_delta_time())
		if of == "lancero":
			dx = sin(ataca / 0.25 * PI) * 18.0 * int(p["dir"])
			incl = 0.12 * int(p["dir"])
		else:
			## Arquero: tensa el arco (se encoge) y suelta.
			esc = Vector2(1.0 - 0.08 * sin(ataca / 0.25 * PI), 1.0 + 0.04 * sin(ataca / 0.25 * PI))
	var y: float = S + 4.0 - bote - (155.0 if bool(p.get("torre", false)) else 0.0)
	var mod: Color = datos_valle["tinte"] as Color
	if of == "vagabundo":
		mod = mod.darkened(0.25)
	var alto_p: float = 96.0
	if of == "heroe":
		alto_p = 118.0
		if float(p.get("aturdido", 0.0)) > 0.0:
			mod = Color(0.55, 0.55, 0.6)
		else:
			## Halo del héroe.
			var hc: Color = {"caballero": Color(1.0, 0.85, 0.4), "bruja": Color(0.45, 1.0, 0.35), "cazadora": Color(0.7, 0.85, 1.0)}.get(str(p.get("heroe", "")), Color.WHITE)
			draw_circle(Vector2(_sx(float(p["x"])), S - 60.0), 54.0 + 4.0 * sin(t * 3.0), Color(hc, 0.06))
	## Sombra en el suelo.
	if not bool(p.get("torre", false)):
		_sombra_suelo(float(p["x"]) + dx, 22.0, 0.3)
	_sprite(tid, float(p["x"]) + dx, alto_p, int(p["dir"]) < 0, mod, y, incl, esc)
	if anda and fmod(t, 0.33) < 0.02 and not bot and absf(_sx(float(p["x"])) - ANCHO / 2.0) < ANCHO / 2.0:
		_particulas.append({"p": Vector2(float(p["x"]), S - 2.0), "v": Vector2(-int(p["dir"]) * 30.0, -20.0), "t": 0.4, "c": Color(0.6, 0.5, 0.4, 0.5), "r": 3.0, "g": 40.0})


func _dibujar_reina() -> void:
	var x: float = float(reina["x"])
	var m: float = float(reina["mov"])
	var andando: bool = _mover_ui != 0
	var bote: float = absf(sin(m * 7.0)) * (8.0 if float(reina["corre"]) > 0.5 else 4.0) if andando else sin(tiempo * 2.0) * 1.5
	_sombra_suelo(x, 60.0, 0.35)
	var esc_r: Vector2 = Vector2(1.0 + 0.03 * absf(sin(m * 7.0)), 1.0 - 0.03 * absf(sin(m * 7.0))) if andando else Vector2(1.0, 1.0 + 0.01 * sin(tiempo * 2.0))
	_sprite("lr_reina", x, 165.0, int(reina["dir"]) < 0, Color(1, 1, 1, 0.55 + 0.45 * absf(sin(tiempo * 20.0))) if float(reina["inmune"]) > 0.0 else Color.WHITE,
		S + 6.0 - bote, sin(m * 7.0) * 0.03 if andando else 0.0, esc_r)
	if andando and float(reina["corre"]) > 0.4 and fmod(m, 0.12) < 0.03 and not bot:
		for i: int in 2:
			_particulas.append({"p": Vector2(x - int(reina["dir"]) * 40.0, S - 4.0), "v": Vector2(-int(reina["dir"]) * rng.randf_range(40, 120), rng.randf_range(-70, -20)),
				"t": 0.6, "c": Color(0.55, 0.47, 0.38, 0.55), "r": rng.randf_range(4, 8), "g": 60.0})
	## Farol
	var fx: float = _sx(x) + int(reina["dir"]) * 30.0
	draw_circle(Vector2(fx, S - 118.0 - bote), 7.0, Color(1.0, 0.85, 0.5, 0.9))
	## Bolsa de brasas (puntitos sobre la cabeza cuando estás cerca de algo).
	if not _sitio_cerca.is_empty():
		var o: Dictionary = opcion(_sitio_cerca) if str(_sitio_cerca["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
		var coste: int = int(o.get("coste", -1))
		if coste > 0:
			var ancho_t: float = coste * 16.0
			for i: int in coste:
				var cx: float = _sx(x) - ancho_t / 2.0 + i * 16.0 + 8.0
				var lleno: bool = i < brasas
				draw_circle(Vector2(cx, S - 210.0), 6.5, Color("ffb347") if lleno else Color(0.3, 0.3, 0.35, 0.7))


func _dibujar_criatura(c: Dictionary) -> void:
	var info: Dictionary = Datos.CRIATURAS[str(c["tipo"])] as Dictionary
	var alto: float = float(info["alto"])
	var y: float = _y_criatura(c) + 4.0
	var t: float = float(c["t"])
	var bote: float = absf(sin(t * 8.0)) * 5.0
	var mod: Color = Color(1, 1, 1) if float(c["golpe"]) <= 0.0 else Color(2.0, 1.4, 1.4)
	if fase == "noche" and luna_hoy == "nueva":
		var dd: float = absf(float(c["x"]) - float(reina["x"]))
		mod.a = clampf(1.0 - (dd - 250.0) / 300.0, 0.15, 1.0)
	var esc: Vector2 = Vector2(1.0 + 0.07 * absf(sin(t * 8.0)), 1.0 - 0.07 * absf(sin(t * 8.0)))
	if bool(c["vuela"]):
		esc = Vector2(1.0, 1.0 + 0.12 * sin(t * 14.0))
	if str(c["tipo"]) == "jefe":
		## Aura roja que late.
		draw_circle(Vector2(_sx(float(c["x"])), y - alto * 0.5), alto * (0.55 + 0.05 * sin(t * 4.0)), Color(0.9, 0.05, 0.05, 0.12))
	elif not bool(c["vuela"]):
		_sombra_suelo(float(c["x"]), alto * 0.32, 0.35)
	_sprite(str(info["tex"]), float(c["x"]), alto, int(c["lado"]) < 0 if not bool(c["huye"]) else int(c["lado"]) > 0, mod, y - bote, sin(t * 8.0) * 0.06, esc)
	if not bot and fmod(t, 0.09) < 0.02:
		## Estela de humo negro.
		_particulas.append({"p": Vector2(float(c["x"]) + int(c["lado"]) * alto * 0.25, y - bote - alto * rng.randf_range(0.3, 0.8)), "v": Vector2(int(c["lado"]) * 30.0, rng.randf_range(-40, -10)),
			"t": 0.7, "c": Color(0.05, 0.02, 0.05, 0.55), "r": alto * 0.07 + 2.0, "g": -20.0})
	## Ojos que brillan (se ven en la oscuridad).
	var sx: float = _sx(float(c["x"]))
	var ojo: Color = Color(1.0, 0.15, 0.1, 0.9 * mod.a)
	draw_circle(Vector2(sx - 6.0 * int(c["lado"]), y - bote - alto * 0.72), 3.0 + alto * 0.012, ojo)
	if float(c["hp"]) < float(c["hpmax"]) and str(c["tipo"]) == "jefe":
		draw_rect(Rect2(sx - 70, y - alto - 24, 140, 8), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(sx - 70, y - alto - 24, 140 * float(c["hp"]) / float(c["hpmax"]), 8), Color("ff3b3b"))


func _dibujar_coste() -> void:
	pass


# ------------------------------------------------------------------ luz y noche

func _montar_luz() -> void:
	var capa: CanvasLayer = CanvasLayer.new()
	capa.layer = 1
	add_child(capa)
	_luz = ColorRect.new()
	_luz.size = Vector2(ANCHO, ALTO)
	_luz.set_anchors_preset(Control.PRESET_FULL_RECT)
	_luz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh: Shader = Shader.new()
	sh.code = SHADER_LUZ
	_mat_luz = ShaderMaterial.new()
	_mat_luz.shader = sh
	_luz.material = _mat_luz
	capa.add_child(_luz)


func _oscuridad() -> float:
	var l: Dictionary = Datos.LUNAS[luna_hoy if fase == "noche" or fase == "alba" else luna] as Dictionary
	var maxo: float = float(l["oscuridad"])
	var f: float = t_fase / _duracion_fase()
	match fase:
		"tarde":
			return maxo * f
		"noche":
			return maxo
		"alba":
			return maxo * (1.0 - f)
	return 0.0


func _actualizar_luz() -> void:
	var osc: float = _oscuridad()
	var es_roja: bool = (fase == "noche" or fase == "alba") and luna_hoy == "roja"
	var col: Color = Color(0.25, 0.02, 0.04, osc) if es_roja else Color(0.02, 0.03, 0.12, osc)
	_mat_luz.set_shader_parameter("noche", col)
	var luces: Array = []
	var vs: Vector2 = get_viewport_rect().size
	var k: float = vs.x / ANCHO
	var mk: Callable = func(x: float, y: float, r: float, i: float) -> void:
		var sx: float = _sx(x)
		if sx > -r and sx < ANCHO + r and luces.size() < 24:
			## FRAGCOORD va de abajo arriba en algunos backends: se calcula en píxeles de ventana.
			luces.append(Vector4(sx * k, (ALTO - y) * k if false else y * k, r * k, i))
	mk.call(float(reina["x"]) + int(reina["dir"]) * 30.0, S - 118.0, 300.0, 1.0)
	var nh: int = nivel_hoguera()
	mk.call(0.0, S - 70.0, 360.0 + nh * 70.0 + sin(tiempo * 9.0) * 12.0, 1.0)
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "torre" and int(d["nivel"]) > 0:
			mk.call(float(d["x"]), S - 270.0, 220.0, 0.85)
		elif str(d["tipo"]) == "muro" and int(d["nivel"]) >= 2:
			mk.call(float(d["x"]), S - 150.0, 160.0, 0.7)
		elif str(d["tipo"]) == "grieta" and not bool(d["cerrada"]):
			mk.call(float(d["x"]), S - 120.0, 260.0, 0.6)
	if mercader:
		mk.call(90.0, S - 80.0, 170.0, 0.8)
	_mat_luz.set_shader_parameter("luces", luces)
	_mat_luz.set_shader_parameter("n_luces", luces.size())


# ------------------------------------------------------------------ partículas y textos

func _chispas(p: Vector2, c: Color, n: int) -> void:
	if bot:
		return
	for i: int in n:
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": p, "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 220), "t": 0.5, "c": c, "r": 3.0, "g": 500.0, "mundo": true})


func _actualizar_particulas(dt: float) -> void:
	for q: Variant in _particulas:
		var d: Dictionary = q as Dictionary
		d["v"] = (d["v"] as Vector2) + Vector2(0, float(d.get("g", 0.0)) * dt)
		d["p"] = (d["p"] as Vector2) + (d["v"] as Vector2) * dt
		d["t"] = float(d["t"]) - dt
	_particulas = _particulas.filter(func(q: Variant) -> bool: return float((q as Dictionary)["t"]) > 0.0)
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		d2["t"] = float(d2["t"]) - dt
		d2["y"] = float(d2["y"]) - 30.0 * dt
	_textos = _textos.filter(func(q: Variant) -> bool: return float((q as Dictionary)["t"]) > 0.0)


func _dibujar_particulas() -> void:
	for q: Variant in _particulas:
		var d: Dictionary = q as Dictionary
		var c: Color = d["c"] as Color
		c.a = clampf(float(d["t"]) * 2.0, 0.0, 1.0)
		var p: Vector2 = d["p"] as Vector2
		draw_circle(Vector2(_sx(p.x), p.y), float(d["r"]), c)
	var f: Font = Estilo.fuente()
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		var c2: Color = d2["c"] as Color
		c2.a = clampf(float(d2["t"]) * 2.0, 0.0, 1.0)
		var pos: Vector2 = Vector2(_sx(float(d2["x"])) - 200.0, float(d2["y"]))
		draw_string_outline(f, pos, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 400, 24, 6, Color(0, 0, 0, c2.a * 0.8))
		draw_string(f, pos, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 400, 24, c2)


func _texto(s: String, p: Vector2, c: Color) -> void:
	if bot:
		return
	_textos.append({"s": s, "x": p.x, "y": p.y, "c": c, "t": 1.4})


# ------------------------------------------------------------------ HUD

func _hacer_hud() -> void:
	_hud = CanvasLayer.new()
	_hud.layer = 2
	add_child(_hud)
	_raiz = Control.new()
	_raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(_raiz)
	_l_brasas = Estilo.etiqueta("", 34, Color("ffcf7a"), HORIZONTAL_ALIGNMENT_LEFT)
	_l_brasas.position = Vector2(28, 16)
	_l_brasas.size = Vector2(400, 48)
	_raiz.add_child(_l_brasas)
	_l_dia = Estilo.etiqueta("", 26, Estilo.TEXTO)
	_l_dia.position = Vector2(390, 10)
	_l_dia.size = Vector2(500, 40)
	_raiz.add_child(_l_dia)
	_barra_dia = Estilo.barra(Color("ffcf7a"), 10.0)
	_barra_dia.position = Vector2(440, 52)
	_barra_dia.size = Vector2(400, 10)
	_barra_dia.max_value = 1.0
	_raiz.add_child(_barra_dia)
	_mini = Control.new()
	_mini.position = Vector2(340, 70)
	_mini.size = Vector2(600, 30)
	_mini.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mini.draw.connect(_dibujar_mini)
	_raiz.add_child(_mini)
	_l_aviso = Estilo.etiqueta("", 30, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_aviso.position = Vector2(240, 112)
	_l_aviso.size = Vector2(800, 120)
	_l_aviso.modulate.a = 0.0
	_raiz.add_child(_l_aviso)
	_l_guia = Estilo.etiqueta("", 22, Color(1.0, 0.92, 0.75), HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_guia.position = Vector2(240, 560)
	_l_guia.size = Vector2(800, 50)
	_l_guia.add_theme_constant_override("outline_size", 8)
	_l_guia.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	_l_guia.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_l_guia)
	_b_accion = Estilo.boton("", true, 84)
	_b_accion.position = Vector2(440, 616)
	_b_accion.size = Vector2(400, 84)
	_b_accion.add_theme_font_size_override("font_size", 24)
	_b_accion.pressed.connect(func() -> void: accion())
	_b_accion.visible = false
	_raiz.add_child(_b_accion)
	_b_destello = Estilo.boton("", false, 76)
	_b_destello.position = Vector2(24, 70)
	_b_destello.size = Vector2(170, 64)
	_b_destello.add_theme_font_size_override("font_size", 19)
	_b_destello.pressed.connect(func() -> void: destello())
	_raiz.add_child(_b_destello)
	_b_cuerno = Estilo.boton("", false, 76)
	_b_cuerno.position = Vector2(24, 142)
	_b_cuerno.size = Vector2(170, 64)
	_b_cuerno.add_theme_font_size_override("font_size", 19)
	_b_cuerno.pressed.connect(func() -> void: cuerno())
	_raiz.add_child(_b_cuerno)
	var bp: Button = Estilo.boton("II", false, 72)
	bp.position = Vector2(1190, 14)
	bp.size = Vector2(76, 72)
	bp.pressed.connect(abrir_pausa)
	_raiz.add_child(bp)
	for lado: int in [-1, 1]:
		var fl: Label = Estilo.etiqueta("‹‹" if lado < 0 else "››", 64, Color(1, 1, 1, 0.22))
		fl.position = Vector2(20 if lado < 0 else 1160, 560)
		fl.size = Vector2(100, 90)
		fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_raiz.add_child(fl)


func _hud_refrescar() -> void:
	_l_brasas.text = "● %d / %d" % [brasas, MAX_BRASAS]
	_b_destello.text = Idioma.t("Destello") if cd_destello <= 0.0 else "%d s" % ceili(cd_destello)
	_b_destello.disabled = cd_destello > 0.0
	_b_cuerno.text = Idioma.t("Cuerno") if cd_cuerno <= 0.0 else "%d s" % ceili(cd_cuerno)
	_b_cuerno.disabled = cd_cuerno > 0.0
	var l: Dictionary = Datos.LUNAS[luna if fase == "dia" or fase == "tarde" else luna_hoy] as Dictionary
	var nombre_fase: String = {"dia": Idioma.t("Día"), "tarde": Idioma.t("Atardecer"), "noche": Idioma.t("Noche"), "alba": Idioma.t("Alba")}[fase]
	_l_dia.text = "%s %d   ·   %s" % [nombre_fase, dia, Idioma.t(str(l["nombre"]))]
	_l_dia.add_theme_color_override("font_color", (l["color"] as Color).lerp(Estilo.TEXTO, 0.4))
	_barra_dia.value = 1.0 - t_fase / _duracion_fase()
	var guia: String = _guia() if dia <= 4 and valle == 0 else ""
	_l_guia.text = guia
	_l_guia.visible = guia != ""
	_l_guia.modulate.a = 0.75 + 0.25 * sin(tiempo * 3.0)
	var o: Dictionary = {}
	if not _sitio_cerca.is_empty():
		o = opcion(_sitio_cerca) if str(_sitio_cerca["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
	_b_accion.visible = not o.is_empty()
	if not o.is_empty():
		var coste: int = int(o["coste"])
		_b_accion.text = str(o["texto"]) + (("   ● %d" % coste) if coste > 0 else "")
		_b_accion.disabled = coste < 0 or brasas < coste


## Mapa del valle: fuego, muros por nivel, torres, grietas, sombras (rojo) y la reina (oro).
func _dibujar_mini() -> void:
	var w: float = _mini.size.x
	var k: float = w / (Datos.BORDE * 2.0)
	var y: float = 15.0
	_mini.draw_rect(Rect2(0, 4, w, 22), Color(0.05, 0.03, 0.04, 0.6))
	_mini.draw_line(Vector2(0, y + 6), Vector2(w, y + 6), Color(0.4, 0.33, 0.25, 0.8), 2.0)
	var vx0: float = (cam - ANCHO / 2.0 + Datos.BORDE) * k
	_mini.draw_rect(Rect2(vx0, 4, ANCHO * k, 22), Color(1, 1, 1, 0.08))
	_mini.draw_rect(Rect2(vx0, 4, ANCHO * k, 22), Color(1, 1, 1, 0.25), false, 1.0)
	for st: Variant in sitios:
		var d: Dictionary = st as Dictionary
		var mx: float = (float(d["x"]) + Datos.BORDE) * k
		match str(d["tipo"]):
			"hoguera":
				_mini.draw_circle(Vector2(mx, y + 2), 5.0, Color(1.0, 0.55, 0.15))
			"muro":
				if int(d["nivel"]) > 0:
					_mini.draw_rect(Rect2(mx - 2, y + 6 - 6 - int(d["nivel"]) * 3, 4, 6 + int(d["nivel"]) * 3), Color(0.75, 0.7, 0.6))
			"torre":
				if int(d["nivel"]) > 0:
					_mini.draw_rect(Rect2(mx - 1.5, y - 8, 3, 14), Color(0.6, 0.45, 0.3))
			"grieta":
				_mini.draw_circle(Vector2(mx, y + 2), 5.0, Color(0.9, 0.1, 0.1) if not bool(d["cerrada"]) else Color(0.4, 0.4, 0.4))
			"cofre":
				if not bool(d["abierto"]):
					_mini.draw_rect(Rect2(mx - 2, y + 2, 4, 4), Color(0.9, 0.75, 0.3))
	for c: Variant in criaturas:
		_mini.draw_circle(Vector2((float((c as Dictionary)["x"]) + Datos.BORDE) * k, y + 4), 2.0, Color(1.0, 0.2, 0.15))
	_mini.draw_circle(Vector2((float(reina["x"]) + Datos.BORDE) * k, y + 2), 4.0, Color("ffcf7a"))
	_mini.draw_arc(Vector2((float(reina["x"]) + Datos.BORDE) * k, y + 2), 6.0, 0.0, TAU, 12, Color(1, 1, 1, 0.7), 1.0)


## Qué conviene hacer ahora (solo los primeros días del primer valle).
func _guia() -> String:
	if fase == "noche" or fase == "tarde":
		return Idioma.t("Vuelve junto al fuego: las sombras vienen de los extremos.")
	var aldeanos: int = contar("aldeano")
	var cons: int = contar("constructor")
	var arq: int = contar("arquero")
	if aldeanos + cons + arq < 3:
		return Idioma.t("Cabalga hasta un campamento (‹‹ o ››) y recluta vagabundos.")
	if cons == 0 and int(herramientas["constructor"]) == 0:
		return Idioma.t("Compra martillos en el puesto de la derecha del fuego.")
	if arq == 0 and int(herramientas["arquero"]) == 0:
		return Idioma.t("Compra arcos en el puesto de la izquierda del fuego.")
	if muro_exterior(-1).is_empty() or muro_exterior(1).is_empty():
		return Idioma.t("Levanta una empalizada a cada lado antes de que anochezca.")
	if brasas < 4:
		return Idioma.t("Abre los cofres y recoge las brasas de los ciervos y las granjas.")
	return Idioma.t("Aviva la hoguera para desbloquear torres, granjas y más.")


func _avisar(s: String) -> void:
	if bot or _l_aviso == null:
		return
	_l_aviso.text = s
	var tw: Tween = _l_aviso.create_tween()
	tw.tween_property(_l_aviso, "modulate:a", 1.0, 0.25)
	tw.tween_interval(2.6)
	tw.tween_property(_l_aviso, "modulate:a", 0.0, 0.6)


func _pista_fase() -> void:
	var p: String = "dia"
	if fase == "noche" or fase == "tarde":
		p = "luna_roja" if luna == "roja" or luna_hoy == "roja" else "noche"
	if p != _pista:
		_pista = p
		Audio.play_track(p)


func abrir_pausa() -> void:
	if not _modal.is_empty() or not vivo:
		return
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("Pausa"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Arqueros %d · Constructores %d · Granjeros %d · Lanceros %d") % [contar("arquero"), contar("constructor"), contar("granjero"), contar("lancero")], 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	if Estado.n("reserva") > 0:
		var br: Button = Estilo.boton(Idioma.t("Sacar brasas de la reserva (%d)") % Estado.n("reserva"), false, 72)
		br.pressed.connect(func() -> void:
			var cuanto: int = mini(Estado.n("reserva"), MAX_BRASAS - brasas)
			brasas += cuanto
			Estado.d["reserva"] = Estado.n("reserva") - cuanto
			Estado.guardar()
			br.queue_free())
		vb.add_child(br)
	var bc: Button = Estilo.boton(Idioma.t("Seguir"), true, 80)
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 72)
	ba.pressed.connect(func() -> void: Consejo.ajustes(_raiz))
	vb.add_child(ba)
	var bs: Button = Estilo.boton(Idioma.t("Guardar y salir"), false, 72)
	bs.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bs)


func _cerrar_modal() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and vivo and not bot and _modal.is_empty():
		abrir_pausa()

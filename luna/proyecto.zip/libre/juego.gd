extends Node2D
## Bajo la Luna Roja: la reina recorre el valle a lomos de su ciervo. De día paga brasas para reclutar,
## armar y construir; de noche las sombras salen de las grietas de los dos extremos y atacan los muros.
## Cada noche hay una luna distinta. Cerrar las dos grietas libera el valle.
## Toda la lógica va en paso(dt) para que el bot pueda jugar sin pantalla.

const MAIN: String = "res://libre/main.tscn"
## Ancho y alto visibles: en móviles alargados (20:9) se ve más mundo a los lados.
var ANCHO: float = 1280.0
var ALTO: float = 720.0
var _anclas: Array = []
var _agua: ColorRect
## Animaciones por hojas (assets/libre/anim/<id>_<anim>.png, celdas de 256): quien dibuja elige _anim antes de _sprite.
var _anim: String = ""
var _anim_t: float = 0.0
var _anim_bucle: bool = true
var _hojas: Dictionary = {}
var _muertes: Array = []
## v6: efectos pintados en el mundo y botones de definitiva de los héroes.
var _fx: Array = []
## v7: zonas, decorado, fauna y luz del valle.
var atm: Atmosfera = Atmosfera.new()
var _b_heroes: Array = []
var _barra_jefe: ProgressBar
## v7: clima de la noche y temporizador de rayos.
var clima: String = "despejado"
var _t_rayo: float = 3.0
var _rayo: float = 0.0
var _rayo_x: float = 0.0
const Y_AGUA: float = Datos.SUELO + 16.0
const SHADER_AGUA: String = """
shader_type canvas_item;
uniform sampler2D pantalla : hint_screen_texture, filter_linear;
uniform float y_agua = 0.85;
uniform float y_eje = 0.83;
uniform vec4 tinte : source_color = vec4(0.55, 0.72, 0.85, 1.0);
uniform float calma = 1.0;
uniform float luna_a = 0.0;
uniform vec4 luna_c : source_color = vec4(1.0, 0.95, 0.85, 1.0);
void fragment() {
	vec2 uv = SCREEN_UV;
	float d = max(uv.y - y_agua, 0.0);
	float onda = (sin(uv.y * 260.0 + TIME * 2.2) * 0.0035 + sin(uv.y * 95.0 - TIME * 1.4 + uv.x * 6.0) * 0.0025) * calma * (0.4 + d * 5.0);
	vec2 src = vec2(uv.x + onda, y_eje - d * 1.1);
	vec4 c = texture(pantalla, src);
	float fondo = clamp(d * 2.2, 0.0, 0.6);
	vec3 col = mix(c.rgb * tinte.rgb * 0.92, tinte.rgb * 0.22, fondo);
	float brillo = smoothstep(0.93, 1.0, sin(uv.x * 70.0 + sin(uv.y * 420.0 + TIME * 1.5) * 2.5 + TIME * 0.6)) * 0.16 * (1.0 - fondo) * calma;
	float orilla = smoothstep(0.012, 0.0, d) * 0.25;
	// Camino de luz de la luna sobre el agua: rielando con las ondas.
	float camino = exp(-pow((uv.x + onda * 4.0 - 0.56) * 7.0, 2.0));
	float riel = smoothstep(0.55, 1.0, sin(uv.y * 520.0 + TIME * 3.0 + sin(uv.x * 40.0) * 3.0)) * camino * luna_a;
	COLOR = vec4(col + vec3(brillo) + vec3(orilla) + luna_c.rgb * (riel * 0.55 + camino * luna_a * 0.12), 1.0);
}
"""
const S: float = Datos.SUELO
const VEL_REINA: float = 210.0
var MAX_BRASAS: int = 40
const RADIO_SITIO: float = 80.0

const SHADER_LUZ: String = """
shader_type canvas_item;
uniform vec4 luces[24];
uniform int n_luces = 0;
uniform vec4 noche : source_color = vec4(0.03, 0.04, 0.12, 0.0);
void fragment() {
	vec2 p = FRAGCOORD.xy;
	float luz = 0.0;
	for (int i = 0; i < 24; i++) {
		if (i >= n_luces) { break; }
		vec4 l = luces[i];
		float d = distance(p, l.xy);
		luz = max(luz, (1.0 - smoothstep(l.z * 0.25, l.z, d)) * l.w);
	}
	COLOR = vec4(noche.rgb, noche.a * (1.0 - luz));
}
"""

## Estado
var valle: int = 0
var datos_valle: Dictionary = {}
var dia: int = 1
var fase: String = "dia"
var t_fase: float = 0.0
var luna: String = "creciente"
var luna_hoy: String = "creciente"
var brasas: int = 8
var vivo: bool = true
var ganado: bool = false
var pausa: bool = false
var bot: bool = false
var eterna: bool = false
var tiempo: float = 0.0

var reina: Dictionary = {"x": 0.0, "dir": 1, "mov": 0.0, "corre": 0.0, "inmune": 0.0}
var sitios: Array = []
var gente: Array = []
var criaturas: Array = []
var flechas: Array = []
var ciervos: Array = []
var suelo_brasas: Array = []
var herramientas: Dictionary = {"arquero": 0, "constructor": 0, "granjero": 0, "lancero": 0}
var mercader: bool = false
var por_salir: Array = []
var noches_jefe: int = 0
var causa: String = ""
## Habilidades de la reina y efectos.
var cd_destello: float = 0.0
var _muro_roto: bool = false
var cd_cuerno: float = 0.0
var cd_montura: float = 0.0
var _b_montura: Button
var cuerno_t: float = 0.0
var _flash: float = 0.0
var montura: String = ""
var _jefe_id: String = "ciervo"
## Luz de ambiente que tiñe sprites y edificios (día, atardecer, noche, luna roja).
var _amb: Color = Color.WHITE
var _b_destello: Button
var _b_cuerno: Button
var revivido: bool = false
var stats: Dictionary = {"construidos": 0, "abatidas": 0, "perdidos": 0, "jefes": 0}

var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var cam: float = 0.0
var _mover_ui: int = 0
var _t_pulsado: float = 0.0
var _particulas: Array = []
var _textos: Array = []
var _tex: Dictionary = {}
var _arboles: Array = []
var _arbol_id: String = "lr_arbol"
var _luz: ColorRect
var _mat_luz: ShaderMaterial
var _hud: CanvasLayer
var _raiz: Control
var _l_brasas: Label
var _l_dia: Label
var _l_aviso: Label
var _b_accion: Button
var _barra_dia: ProgressBar
var _mini: Control
var _l_guia: Label
var _modal: Dictionary = {}
var _sitio_cerca: Dictionary = {}
var _pista: String = ""
var _sacudir: float = 0.0


func _ready() -> void:
	Estado.cargar()
	bot = bool(Estado.partida.get("bot", false))
	if bot:
		rng.seed = int(Estado.partida.get("semilla", 1))
	else:
		rng.randomize()
	valle = mini(Estado.valle_actual(), Datos.VALLES.size() - 1) if not bot else int(Estado.partida.get("valle", 0))
	eterna = Estado.valle_actual() >= Datos.VALLES.size() and not bot
	datos_valle = Datos.VALLES[valle] as Dictionary
	_arbol_id = str(Datos.ARBOLES[valle])
	for id: String in ["lr_reina", "lr_vagabundo", "lr_aldeano", "lr_arquero", "lr_constructor", "lr_granjero", "lr_lancero", "lr_sombra",
			"lr_bruto", "lr_alado", "lr_jefe", "lr_ariete", "lr_torre_asedio", "lr_muro1", "lr_muro2", "lr_muro3", "lr_torre", "lr_granja", "lr_hoguera", "lr_portal",
			"lr_ciervo", "lr_mercader", "lr_arbol", "lr_campamento", "lr_cofre", "lr_cielo_dia", "lr_cielo_tarde", "lr_cielo_noche",
			"lr_cielo_roja", "lr_montes", "lr_bosque", "lr_caballero", "lr_bruja", "lr_cazadora", "lr_santuario", "lr_ahogado", "lr_golem",
			"lr_arbol_muerto", "lr_arbol_quemado", "lr_cielo_dia_cienaga", "lr_cielo_noche_cienaga", "lr_cielo_dia_ceniza", "lr_cielo_noche_ceniza",
			"lr_arbol_nieve", "lr_arbol_desierto", "lr_arbol_ruinas", "lr_cielo_dia_nieve", "lr_cielo_noche_nieve", "lr_cielo_dia_desierto",
			"lr_cielo_noche_desierto", "lr_cielo_dia_ruinas", "lr_cielo_noche_ruinas", "lr_lobo", "lr_escorpion", "lr_espectro", "lr_monje",
			"lr_ingeniera", "lr_druida", "lr_catapulta"]:
		_tex[id] = null if bot else Estilo.tex(id)
	_jefe_id = str(datos_valle["id"]) if not eterna else str((Datos.VALLES[rng.randi() % Datos.VALLES.size()] as Dictionary)["id"])
	montura = str(Estado.partida.get("montura", "")) if bot else Estado.montura()
	if not bot:
		var ids2: Array = ["lr_jefe_" + _jefe_id, "lr_reina_caballo", "lr_reina_oso", "lr_reina_grifo", "lr_reina_lobo", "lr_reina_dragon", "lr_portal2",
			"lr_capa_lejos_" + str(datos_valle["id"]), "lr_capa_medio_" + str(datos_valle["id"]),
			"lr_puesto_arquero", "lr_puesto_constructor", "lr_puesto_granjero", "lr_puesto_lancero"]
		for h: Variant in (Datos.HITOS[str(datos_valle["id"])] as Array):
			ids2.append(str(h))
		## v7: capas de zona, primer plano, decorado y fauna.
		for id3: Variant in Atmosfera.CAPA_ZONA.values():
			ids2.append(str(id3))
		ids2.append_array(["lr_bio_montana_lejos", "lr_cerca_ramas", "lr_cerca_hierba", "lr_cerca_helechos", "lr_cerca_juncos",
			"lr_f_pajaro", "lr_f_conejo", "lr_f_murcielago", "lr_f_buho", "lr_f_pez", "lr_f_ciervo_blanco"])
		for z3: Variant in Atmosfera.DECOR.values():
			for dd3: Variant in z3 as Array:
				if not ids2.has(str((dd3 as Array)[0])):
					ids2.append(str((dd3 as Array)[0]))
		for id2: Variant in ids2:
			_tex[str(id2)] = Estilo.tex(str(id2)) if Estilo.existe(str(id2)) else null
	_montar_valle()
	var g: Dictionary = Estado.d["guardada"] as Dictionary
	if not bot and not bool(Estado.partida.get("nuevo", false)) and not g.is_empty() and int(g.get("valle", -1)) == valle:
		_restaurar(g)
	if not bot:
		_montar_agua()
		_montar_luz()
		_hacer_hud()
		_pista_fase()
		if Consejo.mostrar(_raiz, "inicio"):
			pausa = true
		elif not eterna and dia == 1 and t_fase < 1.0:
			_capitulo()
		_avisar(Idioma.t(str(datos_valle["nombre"])) if not eterna else Idioma.t("Luna eterna"))


func _montar_valle() -> void:
	sitios.clear()
	for s: Variant in Datos.SITIOS:
		var d: Dictionary = s as Dictionary
		var lados: Array = [-1, 1] if bool(d["doble"]) else [0]
		for lado: Variant in lados:
			var x: float = float(d["x"]) * (float(lado) if int(lado) != 0 else 1.0)
			var st: Dictionary = {"tipo": str(d["tipo"]), "x": x, "lado": int(lado) if int(lado) != 0 else (1 if x > 0 else (-1 if x < 0 else 0)),
				"nivel": 0, "costes": (d["niveles"] as Array).duplicate(), "req": int(d.get("nivel_hoguera", 1)), "hp": 0.0, "trabajo": 0.0, "obj": 0}
			match st["tipo"]:
				"hoguera":
					st["nivel"] = 1
					st["costes"] = [6, 12]
				"campamento":
					st["vagos"] = 3
				"cofre":
					st["abierto"] = false
				"santuario":
					st["heroe"] = str((Datos.HEROES_VALLE[valle] as Array)[0 if int(lado) < 0 else 1])
					st["rescatado"] = false
				"grieta":
					st["hp"] = 260.0 * float(datos_valle["fuerza"])
					st["cerrada"] = false
					st["asalto"] = false
			sitios.append(st)
	## Árboles del bosque (se talan solos al construir muros lejos: decorado).
	_arboles.clear()
	var x2: float = -Datos.BORDE
	while x2 < Datos.BORDE:
		var cerca_hito: bool = Datos.X_HITOS.any(func(h: Variant) -> bool: return absf(absf(x2) - float(h)) < 260.0)
		if absf(x2) > 500.0 and not cerca_hito and absf(absf(x2) - Datos.X_GRIETA) > 220.0:
			_arboles.append({"x": x2 + rng.randf_range(-40, 40), "esc": rng.randf_range(0.7, 1.15), "capa": rng.randi() % 2})
		var z2: String = Atmosfera.zona_en(x2)
		x2 += rng.randf_range(80.0, 170.0) if z2 in ["profundo", "antiguo"] else (rng.randf_range(420.0, 800.0) if z2 in ["prado", "lago", "pueblo"] else rng.randf_range(150.0, 360.0))
	atm.preparar(str(datos_valle["id"]), Datos.BORDE, Datos.X_HITOS + [Datos.X_GRIETA, 0.0])
	## Tesoros de las tierras salvajes (v7): cofres antiguos que premian explorar lejos de día.
	if not eterna:
		for lado2: int in [-1, 1]:
			for xt: float in [6400.0, 9600.0]:
				sitios.append({"tipo": "cofre", "x": lado2 * xt, "lado": lado2, "abierto": false, "nivel": 0, "hp": 0.0, "antiguo": true})
	## En los valles duros quedan en pie las empalizadas del reino anterior.
	if valle >= 3 or eterna:
		for st2: Variant in sitios:
			var w: Dictionary = st2 as Dictionary
			if str(w["tipo"]) == "muro" and absf(float(w["x"])) < 700.0:
				w["nivel"] = 1
				w["obj"] = 1
				w["hp"] = _vida_muro(1)
	brasas = int(datos_valle["brasas"]) + (4 if eterna else 0) + 4 * Estado.mejora("inicio")
	MAX_BRASAS = 40 + 10 * Estado.mejora("bolsa")
	## Dos aldeanos para empezar.
	for i: int in 2:
		_nueva_persona("aldeano", rng.randf_range(-80, 80))
	for c: Variant in sitios:
		var cs: Dictionary = c as Dictionary
		if str(cs["tipo"]) == "campamento":
			for k: int in int(cs["vagos"]):
				_nueva_persona("vagabundo", float(cs["x"]) + rng.randf_range(-60, 60))
	luna = _luna_de(dia)


func _nueva_persona(oficio: String, x: float) -> Dictionary:
	var lado: int = 1 if _contar_lado(oficio, 1) < _contar_lado(oficio, -1) else -1
	var p: Dictionary = {"oficio": oficio, "x": x, "dir": 1, "obj": x, "t": rng.randf() * 3.0, "cd": 0.0, "lado": lado, "trabajo": null, "asalto": false}
	gente.append(p)
	return p


func _contar_lado(oficio: String, lado: int) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == oficio and int((g as Dictionary)["lado"]) == lado).size()


func contar(oficio: String) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == oficio).size()


func _luna_de(n: int) -> String:
	if n % 5 == 0:
		return "roja"
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = n * 977 + valle * 31 + (int(Estado.partida.get("semilla", 0)) if bot else 0)
	var op: Array = ["creciente", "creciente", "llena", "nueva", "azul"]
	return str(op[r.randi() % op.size()])


# ------------------------------------------------------------------ guardar / restaurar (al amanecer)

func _foto() -> Dictionary:
	var oficios: Array = []
	for g: Variant in gente:
		oficios.append([str((g as Dictionary)["oficio"]), snappedf(float((g as Dictionary)["x"]), 1.0), int((g as Dictionary)["lado"]), str((g as Dictionary).get("heroe", ""))])
	var st: Array = []
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		st.append({"nivel": int(d["nivel"]), "hp": float(d["hp"]), "vagos": int(d.get("vagos", 0)), "abierto": bool(d.get("abierto", false)),
			"cerrada": bool(d.get("cerrada", false)), "rescatado": bool(d.get("rescatado", false))})
	return {"valle": valle, "dia": dia, "brasas": brasas, "gente": oficios, "sitios": st, "herr": herramientas.duplicate(), "reina": float(reina["x"])}


func _restaurar(g: Dictionary) -> void:
	dia = int(g.get("dia", 1))
	brasas = int(g.get("brasas", brasas))
	reina["x"] = float(g.get("reina", 0.0))
	gente.clear()
	for o: Variant in (g.get("gente", []) as Array):
		var a: Array = o as Array
		var p: Dictionary = _nueva_persona(str(a[0]), float(a[1]))
		p["lado"] = int(a[2])
		if a.size() > 3 and str(a[3]) != "":
			p["heroe"] = str(a[3])
			p["hab_t"] = 4.0
	var st: Array = g.get("sitios", []) as Array
	for i: int in mini(st.size(), sitios.size()):
		var d: Dictionary = st[i] as Dictionary
		var s: Dictionary = sitios[i] as Dictionary
		s["nivel"] = int(d["nivel"])
		s["hp"] = float(d["hp"])
		if s.has("vagos"):
			s["vagos"] = int(d["vagos"])
		if s.has("abierto"):
			s["abierto"] = bool(d["abierto"])
		if s.has("cerrada"):
			s["cerrada"] = bool(d["cerrada"])
		if s.has("rescatado"):
			s["rescatado"] = bool(d.get("rescatado", false))
	var hr: Variant = g.get("herr", {})
	if hr is Dictionary:
		for k: String in herramientas.keys():
			herramientas[k] = int((hr as Dictionary).get(k, 0))
	luna = _luna_de(dia)


# ------------------------------------------------------------------ entrada

func _unhandled_input(e: InputEvent) -> void:
	if bot or not vivo or pausa:
		return
	if e is InputEventScreenTouch:
		var t: InputEventScreenTouch = e as InputEventScreenTouch
		var vx: float = t.position.x / get_viewport_rect().size.x * ANCHO
		if t.pressed:
			_mover_ui = -1 if vx < ANCHO * 0.36 else (1 if vx > ANCHO * 0.64 else 0)
			_t_pulsado = 0.0
		else:
			_mover_ui = 0
	elif e is InputEventScreenDrag:
		var dr: InputEventScreenDrag = e as InputEventScreenDrag
		var vx2: float = dr.position.x / get_viewport_rect().size.x * ANCHO
		var nuevo: int = -1 if vx2 < ANCHO * 0.36 else (1 if vx2 > ANCHO * 0.64 else 0)
		if nuevo != 0:
			_mover_ui = nuevo
	elif e is InputEventKey:
		var k: InputEventKey = e as InputEventKey
		if k.echo:
			return
		if k.keycode in [KEY_A, KEY_LEFT]:
			_mover_ui = -1 if k.pressed else (0 if _mover_ui == -1 else _mover_ui)
		elif k.keycode in [KEY_D, KEY_RIGHT]:
			_mover_ui = 1 if k.pressed else (0 if _mover_ui == 1 else _mover_ui)
		elif k.keycode == KEY_SPACE and k.pressed:
			accion()


## Para el bot y los controles: -1 izquierda, 0 parar, 1 derecha.
func mover(dir: int) -> void:
	_mover_ui = dir


# ------------------------------------------------------------------ bucle

func _physics_process(dt: float) -> void:
	if bot:
		return
	if pausa:
		if Consejo._abierto.is_empty() and _modal.is_empty():
			pausa = false
		return
	paso(dt)


func _process(dt: float) -> void:
	if bot:
		return
	tiempo += dt
	var vs: Vector2 = get_viewport_rect().size
	if vs.x != ANCHO or vs.y != ALTO:
		ANCHO = vs.x
		ALTO = vs.y
		_colocar_hud()
	cam = lerpf(cam, clampf(float(reina["x"]), -Datos.BORDE + ANCHO / 2.0, Datos.BORDE - ANCHO / 2.0), minf(1.0, dt * 4.0))
	_actualizar_particulas(dt)
	if _sacudir > 0.0:
		_sacudir = maxf(0.0, _sacudir - dt * 2.5)
		position = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 1)) * 10.0 * _sacudir
	else:
		position = Vector2.ZERO
	_actualizar_luz()
	_amb = _luz_ambiente()
	atm.fauna_paso(self, dt)
	if _agua != null:
		## El agua sigue al mundo (temblores incluidos) y se queda en la orilla.
		_agua.position = Vector2(-position.x, Y_AGUA)
		(_agua.material as ShaderMaterial).set_shader_parameter("y_agua", (Y_AGUA + position.y) / ALTO)
		(_agua.material as ShaderMaterial).set_shader_parameter("luna_a", _oscuridad() * (0.4 if luna_hoy == "nueva" else 1.0))
		(_agua.material as ShaderMaterial).set_shader_parameter("luna_c", Color(1.0, 0.45, 0.35) if luna_hoy == "roja" else Color(0.95, 0.95, 1.0))
		(_agua.material as ShaderMaterial).set_shader_parameter("y_eje", (S - 6.0 + position.y) / ALTO)
	_hud_refrescar()
	if _mini != null:
		_mini.queue_redraw()
	queue_redraw()


func paso(dt: float) -> void:
	if not vivo or ganado:
		return
	tiempo += dt if bot else 0.0
	_avanzar_fase(dt)
	cd_destello = maxf(0.0, cd_destello - dt)
	cd_cuerno = maxf(0.0, cd_cuerno - dt)
	cd_montura = maxf(0.0, cd_montura - dt)
	cuerno_t = maxf(0.0, cuerno_t - dt)
	_mover_reina(dt)
	_gente(dt)
	_criaturas(dt)
	_flechas(dt)
	_ciervos(dt)
	_recoger_brasas(dt)
	_obras(dt)
	_catapultas(dt)
	_clima(dt)


## Tormenta: rayos que caen sobre las sombras.
func _clima(dt: float) -> void:
	_rayo = maxf(0.0, _rayo - dt)
	if clima != "tormenta" or fase != "noche":
		return
	_t_rayo -= dt
	if _t_rayo > 0.0 or criaturas.is_empty():
		return
	_t_rayo = rng.randf_range(4.0, 8.0)
	var c: Dictionary = criaturas[rng.randi() % criaturas.size()] as Dictionary
	_herir(c, 18.0)
	c["aturdido"] = 1.0
	_rayo = 0.35
	_rayo_x = float(c["x"])
	if not bot:
		_flash = maxf(_flash, 0.45)
		Audio.play("ui_big", 0.2, -6.0, 1.6)
		_chispas(Vector2(_rayo_x, S - 40.0), Color(0.8, 0.9, 1.0), 14)


func _duracion_fase() -> float:
	match fase:
		"dia":
			return Datos.T_DIA
		"tarde":
			return Datos.T_TARDE
		"noche":
			return Datos.T_NOCHE + minf(25.0, dia * 1.2)
	return Datos.T_ALBA


func _avanzar_fase(dt: float) -> void:
	var antes: float = t_fase
	t_fase += dt
	if fase == "dia" and dia >= 2 and antes < _duracion_fase() * 0.35 and t_fase >= _duracion_fase() * 0.35:
		_evento_dia()
	if fase == "noche":
		_soltar_sombras(dt)
	if t_fase < _duracion_fase():
		return
	t_fase = 0.0
	match fase:
		"dia":
			fase = "tarde"
			luna = _luna_de(dia)
			if not bot:
				var l: Dictionary = Datos.LUNAS[luna] as Dictionary
				_avisar(Idioma.t("Esta noche: ") + Idioma.t(str(l["nombre"])) + "\n" + Idioma.t(str(l["texto"])))
				Audio.play("ui_swoosh", 0.0, -4.0, 0.6)
				if Consejo.mostrar(_raiz, "noche"):
					pausa = true
			for g: Variant in gente:
				(g as Dictionary)["asalto"] = false
		"tarde":
			fase = "noche"
			_empezar_noche()
		"noche":
			fase = "alba"
			for c: Variant in criaturas:
				(c as Dictionary)["huye"] = true
		"alba":
			fase = "dia"
			dia += 1
			_amanecer()
	if not bot:
		_pista_fase()


## Eventos del día (v7): pasan cosas en el valle mientras construyes.
func _evento_dia() -> void:
	if rng.randf() > 0.4:
		return
	var tipo: String = ["refugiados", "estrellas", "ciervo_blanco", "cofre_perdido"][rng.randi() % 4]
	var lado: int = -1 if rng.randf() < 0.5 else 1
	match tipo:
		"refugiados":
			for i: int in 3:
				_nueva_persona("vagabundo", lado * rng.randf_range(700.0, 1100.0))
			if not bot:
				_avisar(Idioma.t("Una caravana de refugiados llega al valle. Dales herramientas."))
		"estrellas":
			for i: int in 8:
				var bx: float = float(reina["x"]) + rng.randf_range(-500, 500)
				suelo_brasas.append({"x": bx, "y": -40.0 - i * 60.0, "vx": 0.0, "vy": 0.0, "t": 0.0})
			if not bot:
				_avisar(Idioma.t("¡Lluvia de estrellas! Recoge las brasas que caen."))
		"ciervo_blanco":
			ciervos.append({"x": lado * rng.randf_range(1800.0, 2600.0), "dir": lado, "t": 0.0, "hp": 9.0, "blanco": true})
			if not bot:
				_avisar(Idioma.t("Un ciervo blanco cruza el valle. Si tus arqueros lo cazan, la luna te premiará."))
		"cofre_perdido":
			sitios.append({"tipo": "cofre", "x": lado * rng.randf_range(900.0, 1700.0), "lado": lado, "abierto": false, "nivel": 0, "hp": 0.0})
			if not bot:
				_avisar(Idioma.t("Alguien ha visto un cofre perdido en el bosque."))


func _empezar_noche() -> void:
	luna_hoy = luna
	_muro_roto = false
	var l: Dictionary = Datos.LUNAS[luna] as Dictionary
	mercader = luna == "azul"
	por_salir.clear()
	## En los valles duros, la fuerza sube poco a poco las primeras 8 noches (te da tiempo a montar el campamento).
	var fuerza_valle: float = float(datos_valle["fuerza"])
	var fuerza: float = (1.0 + (fuerza_valle - 1.0) * minf(1.0, dia / 8.0)) * (1.0 + (dia - 1) * 0.02 if eterna else 1.0)
	var total: int = int(round((0.5 + dia * 1.25) * float(l["cantidad"]) * fuerza))
	var lados: Array = []
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "grieta" and not bool(d["cerrada"]):
			lados.append(int(d["lado"]))
	if lados.is_empty():
		return
	var dur: float = _duracion_fase() * 0.7
	for i: int in total:
		var tipo: String = "sombra"
		if dia >= int((Datos.CRIATURAS["bruto"] as Dictionary)["desde"]) and i % 4 == 3:
			tipo = "bruto"
		elif dia >= int((Datos.CRIATURAS["alado"] as Dictionary)["desde"]) and i % 5 == 4:
			tipo = "alado"
		por_salir.append({"t": rng.randf_range(2.0, dur), "tipo": tipo, "lado": int(lados[i % lados.size()])})
	if luna == "roja":
		por_salir.append({"t": dur * 0.45, "tipo": "jefe", "lado": int(lados[rng.randi() % lados.size()])})
	## Asedios (v7): arietes que revientan muros y torres que sueltan sombras al otro lado.
	var asedio: bool = (luna == "roja" and dia >= 10) or (dia >= 8 and rng.randf() < 0.1)
	if asedio:
		por_salir.append({"t": dur * 0.3, "tipo": "ariete", "lado": int(lados[rng.randi() % lados.size()])})
		if dia >= 10:
			por_salir.append({"t": dur * 0.5, "tipo": "torre_asedio", "lado": int(lados[rng.randi() % lados.size()])})
		if not bot:
			_avisar(Idioma.t("¡Máquinas de asedio en el horizonte!"))
	## Clima de la noche.
	clima = "despejado"
	if dia >= 3 and luna != "roja":
		var total_p: int = 0
		for k: Variant in Datos.CLIMAS.keys():
			total_p += int((Datos.CLIMAS[k] as Dictionary)["peso"])
		var tirada: int = rng.randi() % total_p
		for k: Variant in Datos.CLIMAS.keys():
			tirada -= int((Datos.CLIMAS[k] as Dictionary)["peso"])
			if tirada < 0:
				clima = str(k)
				break
	if clima != "despejado" and not bot:
		_avisar("%s\n%s" % [Idioma.t(str((Datos.CLIMAS[clima] as Dictionary)["nombre"])), Idioma.t(str((Datos.CLIMAS[clima] as Dictionary)["texto"]))])
	por_salir.sort_custom(func(a: Variant, b: Variant) -> bool: return float((a as Dictionary)["t"]) < float((b as Dictionary)["t"]))
	if not bot:
		Juice.vibrate(30)


func _soltar_sombras(_dt: float) -> void:
	while not por_salir.is_empty() and float((por_salir[0] as Dictionary)["t"]) <= t_fase:
		var p: Dictionary = por_salir.pop_front() as Dictionary
		var tipo: String = str(p["tipo"])
		var vari: Dictionary = Datos.VARIANTES[valle if not eterna else rng.randi() % Datos.VARIANTES.size()] as Dictionary
		if vari.has(tipo) and rng.randf() < 0.6:
			tipo = str(vari[tipo])
		var c: Dictionary = Datos.CRIATURAS[tipo] as Dictionary
		var lado: int = int(p["lado"])
		var hp: float = float(c["hp"]) * (1.0 + (float(datos_valle["fuerza"]) - 1.0) * minf(1.0, dia / 8.0)) * (1.0 + dia * 0.03)
		if not bot and Datos.BESTIARIO.has(tipo):
			var vistos: Array = Estado.d.get("vistos", []) as Array
			if not vistos.has(tipo):
				vistos.append(tipo)
				Estado.d["vistos"] = vistos
		var elite: bool = tipo in ["sombra", "bruto", "ahogado", "lobo", "golem", "escorpion"] and dia >= 8 and rng.randf() < 0.08
		hp *= (2.0 if elite else 1.0) * (1.15 if clima == "eclipse" else 1.0)
		criaturas.append({"tipo": tipo, "x": lado * (Datos.X_GRIETA - 10.0) + rng.randf_range(-30, 30), "lado": lado, "hp": hp, "hpmax": hp, "cd": 0.0, "sale": 1.0,
			"huye": false, "vuela": bool(c.get("vuela", false)), "t": rng.randf() * 3.0, "golpe": 0.0, "elite": elite})
		if tipo == "jefe":
			criaturas[criaturas.size() - 1]["hab_t"] = 5.0
		if not bot:
			for s2: Variant in sitios:
				var g: Dictionary = s2 as Dictionary
				if str(g["tipo"]) == "grieta" and int(g["lado"]) == lado:
					g["ruge"] = 1.0 if tipo != "jefe" else 2.0
					if absf(float(g["x"]) - cam) < ANCHO * 0.7:
						_sacudir = maxf(_sacudir, 0.25 if tipo != "jefe" else 0.9)
						Audio.play("ui_big", 0.15, -12.0 if tipo != "jefe" else -2.0, 0.35 if tipo != "jefe" else 0.25)
					var cx: float = float(g["x"])
					for i: int in (10 if tipo != "jefe" else 40):
						var a: float = rng.randf_range(0.0, TAU)
						_particulas.append({"p": Vector2(cx, S - 140.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 260), "t": rng.randf_range(0.4, 0.9),
							"c": Color(0.7, 0.1, 0.8, 0.8) if i % 2 else Color(1.0, 0.2, 0.2, 0.8), "r": rng.randf_range(3, 7), "g": 60.0})
		if tipo == "jefe" and not bot:
			_cinematica_jefe()
			_avisar(Idioma.t("¡%s sale de la grieta!") % Idioma.t(str((Datos.JEFES[_jefe_id] as Dictionary)["nombre"])))
			_sacudir = 0.8
			Juice.vibrate(80)


func _amanecer() -> void:
	criaturas.clear()
	mercader = false
	## El fuego cobra: una brasa por cada tres de los tuyos, que caen junto a la hoguera.
	var gente_util: int = gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) != "vagabundo").size()
	for i: int in int(gente_util / 3.0):
		_soltar_brasa(rng.randf_range(-60, 60))
	## Los campamentos atraen a más vagabundos.
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "campamento" and int(d["vagos"]) < 4:
			d["vagos"] = int(d["vagos"]) + 1
			_nueva_persona("vagabundo", float(d["x"]) + rng.randf_range(-60, 60))
	## Ciervos para los arqueros.
	for i: int in 2 + rng.randi() % 3:
		var lado: int = -1 if rng.randf() < 0.5 else 1
		ciervos.append({"x": lado * rng.randf_range(1600.0, 3000.0), "dir": lado, "t": rng.randf() * 4.0, "hp": 3.0})
	## Los héroes que siguen en pie ganan experiencia (se guarda entre valles).
	for g: Variant in gente:
		var hp_: Dictionary = g as Dictionary
		if str(hp_["oficio"]) == "heroe":
			var hid: String = str(hp_.get("heroe", "caballero"))
			var sube: int = Estado.sumar_xp(hid, 6 + int(hp_.get("xp_hab", 0)) + (6 if luna_hoy == "roja" else 0))
			hp_["xp_hab"] = 0
			if sube > 0 and not bot:
				_avisar(Idioma.t("¡%s sube a nivel %d!") % [Idioma.t(str((Datos.HEROES[hid] as Dictionary)["nombre"])), sube] + (("\n" + Idioma.t("Aprende: %s") % Idioma.t(str((Datos.HEROES_V6[hid] as Dictionary)["talento"]))) if sube == 3 else ""))
	if luna_hoy == "roja" and not bot:
		stats["jefes"] = int(stats["jefes"]) + 0
	Estado.d["mejor_noche"] = maxi(Estado.n("mejor_noche"), dia - 1)
	Estado.d["noches_total"] = Estado.n("noches_total") + 1
	if eterna:
		Estado.d["eterna_record"] = maxi(Estado.n("eterna_record"), dia - 1)
	if dia >= 11:
		_logro("noche10")
	if eterna and dia >= 21:
		_logro("eterna20")
	if luna_hoy == "roja" and not _muro_roto:
		_logro("sin_muros")
	if not bot:
		Estado.d["guardada"] = _foto()
		Estado.guardar()
		_avisar(Idioma.t("Amanece el día %d") % dia)
		if dia == 3 and Consejo.mostrar(_raiz, "luna"):
			pausa = true
		elif (_soldados_lado(-1) >= 3 or _soldados_lado(1) >= 3) and Consejo.mostrar(_raiz, "grieta"):
			pausa = true
		Audio.play("ui_reward", 0.0, -4.0, 0.8)
	## ¿Valle libre?
	var abiertas: int = sitios.filter(func(s: Variant) -> bool: return str((s as Dictionary)["tipo"]) == "grieta" and not bool((s as Dictionary)["cerrada"])).size()
	if abiertas == 0 and not eterna:
		_ganar()


# ------------------------------------------------------------------ reina

func _mover_reina(dt: float) -> void:
	reina["inmune"] = maxf(0.0, float(reina["inmune"]) - dt)
	reina["galope"] = maxf(0.0, float(reina.get("galope", 0.0)) - dt)
	reina["iman"] = maxf(0.0, float(reina.get("iman", 0.0)) - dt)
	if _mover_ui != 0:
		_t_pulsado += dt
		reina["corre"] = minf(1.0, float(reina["corre"]) + dt * (1.5 if _t_pulsado > 0.5 else 0.0))
		var v: float = VEL_REINA * (1.0 + 0.8 * float(reina["corre"])) * (1.4 if montura == "caballo" else 1.25 if montura == "grifo" else 1.3 if montura == "lobo" else 1.35 if montura == "dragon" else 1.0) * (1.8 if float(reina.get("galope", 0.0)) > 0.0 else 1.0)
		reina["x"] = clampf(float(reina["x"]) + _mover_ui * v * dt, -Datos.BORDE + 60.0, Datos.BORDE - 60.0)
		reina["dir"] = _mover_ui
		reina["mov"] = float(reina["mov"]) + dt * (1.0 + float(reina["corre"]))
	else:
		reina["corre"] = 0.0
		_t_pulsado = 0.0
	_sitio_cerca = _sitio_mas_cerca()


func _sitio_mas_cerca() -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = RADIO_SITIO
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		var dd: float = absf(float(d["x"]) - float(reina["x"]))
		if dd < md and not opcion(d).is_empty():
			md = dd
			mejor = d
	if mercader and absf(float(reina["x"]) - 90.0) < RADIO_SITIO:
		return {"tipo": "mercader", "x": 90.0}
	return mejor


## Lo que se puede hacer en un sitio ahora mismo: {"texto", "coste"} o {} si nada.
func opcion(s: Dictionary) -> Dictionary:
	var tipo: String = str(s["tipo"])
	var hog: int = nivel_hoguera()
	match tipo:
		"mercader":
			return {"texto": Idioma.t("Mercader fantasma: 2 herramientas"), "coste": 5}
		"campamento":
			var hay: bool = gente.any(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == "vagabundo" and absf(float((g as Dictionary)["x"]) - float(s["x"])) < 300.0)
			return {"texto": Idioma.t("Reclutar vagabundo"), "coste": 1} if hay else {}
		"cofre":
			return {} if bool(s["abierto"]) or fase == "noche" else {"texto": Idioma.t("Abrir el cofre"), "coste": 0}
		"santuario":
			if bool(s["rescatado"]) or fase != "dia":
				return {}
			var hn: String = Idioma.t(str((Datos.HEROES[str(s["heroe"])] as Dictionary)["nombre"]))
			return {"texto": Idioma.t("Rescatar: %s") % hn, "coste": 5 if Estado.mejora("heroes") > 0 else 10}
		"grieta":
			if bool(s["cerrada"]) or fase != "dia" or bool(s["asalto"]):
				return {}
			var sold: int = _soldados_lado(int(s["lado"]))
			if sold < 3:
				return {"texto": Idioma.t("Necesitas 3 soldados en este lado para asaltar"), "coste": -1}
			return {"texto": Idioma.t("Asaltar la grieta (%d soldados)") % sold, "coste": int((s["costes"] as Array)[0])}
	if s.has("obj") and int(s["obj"]) > int(s["nivel"]):
		return {}
	if tipo.begins_with("tienda_"):
		var of: String = tipo.substr(7)
		if hog < int(s["req"]):
			return {"texto": Idioma.t("Mejora la hoguera para desbloquear"), "coste": -1}
		return {"texto": Idioma.t("Comprar herramienta: %s") % Idioma.t(str((Datos.OFICIOS[of] as Dictionary)["nombre"])), "coste": int((Datos.OFICIOS[of] as Dictionary)["coste"])}
	var costes: Array = s["costes"] as Array
	var nv: int = int(s["nivel"]) if tipo != "hoguera" else int(s["nivel"]) - 1
	if nv >= costes.size():
		if tipo == "muro" and float(s["hp"]) < _vida_muro(int(s["nivel"])) * 0.99 and int(s["nivel"]) > 0:
			return {"texto": Idioma.t("Reparar muro"), "coste": 2}
		return {}
	if tipo != "hoguera" and hog < int(s["req"]):
		return {"texto": Idioma.t("Mejora la hoguera para desbloquear"), "coste": -1}
	var nombre: String = Idioma.t(str(Datos.NOMBRES_SITIO[tipo]))
	if tipo == "muro":
		nombre = Idioma.t(str(Datos.NOMBRES_MURO[int(s["nivel"]) + 1]))
		if int(s["nivel"]) > 0 and float(s["hp"]) < _vida_muro(int(s["nivel"])) * 0.5:
			return {"texto": Idioma.t("Reparar muro"), "coste": 2}
	elif tipo == "hoguera":
		nombre = Idioma.t("Avivar la hoguera (nivel %d)") % (int(s["nivel"]) + 1)
	return {"texto": nombre, "coste": int(costes[nv])}


func _vida_muro(nv: int) -> float:
	return float(Datos.VIDA_MURO[nv]) * (1.0 + 0.25 * Estado.mejora("muros"))


func nivel_hoguera() -> int:
	return int((sitios[0] as Dictionary)["nivel"])


func _soldados_lado(lado: int) -> int:
	var n: int = 0
	for g: Variant in gente:
		var d: Dictionary = g as Dictionary
		if int(d["lado"]) != lado:
			continue
		if str(d["oficio"]) == "lancero" or str(d["oficio"]) == "arquero":
			n += 1
		elif str(d["oficio"]) == "heroe":
			n += 3
	return n


## Pagar en el sitio que tienes al lado.
func accion() -> bool:
	if _sitio_cerca.is_empty():
		return false
	var s: Dictionary = _sitio_cerca
	var o: Dictionary = opcion(s) if str(s["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
	if o.is_empty() or int(o["coste"]) < 0:
		return false
	var coste: int = int(o["coste"])
	if brasas < coste:
		if not bot:
			_texto(Idioma.t("Faltan brasas"), Vector2(float(reina["x"]), S - 190.0), Estilo.ROJO)
			Audio.play("ui_error", 0.0, -6.0)
		return false
	brasas -= coste
	if not bot:
		for i: int in coste:
			_particulas.append({"p": Vector2(float(reina["x"]), S - 120.0), "v": Vector2(rng.randf_range(-60, 60), rng.randf_range(-260, -160)),
				"t": 0.6, "c": Color("ffb347"), "r": 5.0, "g": 700.0})
		Audio.play("ui_coin", 0.1, -4.0, 0.9)
	var tipo: String = str(s["tipo"])
	match tipo:
		"mercader":
			var ofs: Array = ["arquero", "constructor", "granjero", "lancero"]
			for i: int in 2:
				var of: String = str(ofs[rng.randi() % ofs.size()])
				herramientas[of] = int(herramientas[of]) + 1
			mercader = false
		"campamento":
			for g: Variant in gente:
				var d: Dictionary = g as Dictionary
				if str(d["oficio"]) == "vagabundo" and absf(float(d["x"]) - float(s["x"])) < 300.0:
					d["oficio"] = "aldeano"
					s["vagos"] = maxi(0, int(s["vagos"]) - 1)
					break
		"santuario":
			s["rescatado"] = true
			var hp: Dictionary = _nueva_persona("heroe", float(s["x"]))
			hp["heroe"] = str(s["heroe"])
			hp["lado"] = int(s["lado"])
			hp["hab_t"] = 3.0
			_logro("heroe")
			if contar("heroe") >= 2:
				_logro("tres_heroes")
			if not bot:
				_avisar(Idioma.t("¡%s se une a tu causa!") % Idioma.t(str((Datos.HEROES[str(s["heroe"])] as Dictionary)["nombre"])))
				_flash = 0.5
				Audio.play("ui_big", 0.0, -2.0, 1.1)
				for i: int in 24:
					var a: float = rng.randf_range(0.0, TAU)
					_particulas.append({"p": Vector2(float(s["x"]), S - 90.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 260), "t": 0.9, "c": Color(1.0, 0.85, 0.4), "r": 3.5, "g": 120.0})
		"cofre":
			s["abierto"] = true
			for i: int in (8 + valle * 2) * (2 if bool(s.get("antiguo", false)) else 1):
				_soltar_brasa(float(s["x"]) + rng.randf_range(-40, 40))
			if bool(s.get("antiguo", false)):
				_ganar_fragmentos(1, Vector2(float(s["x"]), S - 140.0))
				if not bot:
					_avisar(Idioma.t("¡Un tesoro del reino antiguo!"))
					_poner_fx("lr_fx_impacto", float(s["x"]), S - 60.0, 220.0, 0.6)
		"grieta":
			s["asalto"] = true
			for g: Variant in gente:
				var d2: Dictionary = g as Dictionary
				if int(d2["lado"]) == int(s["lado"]) and (str(d2["oficio"]) in ["lancero", "arquero", "heroe"]):
					d2["asalto"] = true
			if not bot:
				_avisar(Idioma.t("¡Al asalto! Vuelven al atardecer."))
		_:
			if tipo.begins_with("tienda_"):
				var of2: String = tipo.substr(7)
				herramientas[of2] = int(herramientas[of2]) + 1
			elif tipo == "muro" and opcion(s).get("texto", "") == Idioma.t("Reparar muro"):
				s["obj"] = int(s["nivel"])
				s["trabajo"] = 2.5
				s["reparar"] = true
			else:
				s["obj"] = int(s["nivel"]) + 1
				s["trabajo"] = _trabajo_de(s)
	return true


func _trabajo_de(s: Dictionary) -> float:
	match str(s["tipo"]):
		"muro":
			return float(Datos.TRABAJO_MURO[int(s["obj"])])
		"torre":
			return 8.0
		"granja":
			return 5.0
		"catapulta":
			return 8.0
		"hoguera":
			return 6.0
	return 3.0


## Obras: los constructores trabajan donde haya algo pendiente; al acabar, sube el nivel.
func _obras(_dt: float) -> void:
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if not d.has("obj") or int(d["obj"]) <= int(d["nivel"]) and not bool(d.get("reparar", false)):
			continue
		if float(d["trabajo"]) <= 0.0:
			if bool(d.get("reparar", false)):
				d["reparar"] = false
				d["hp"] = _vida_muro(int(d["nivel"]))
			else:
				d["nivel"] = int(d["obj"])
				if str(d["tipo"]) == "muro":
					d["hp"] = _vida_muro(int(d["nivel"]))
				stats["construidos"] = int(stats["construidos"]) + 1
				if str(d["tipo"]) == "muro":
					_logro("muro")
					if int(d["nivel"]) >= 3:
						_logro("muralla")
				elif str(d["tipo"]) == "catapulta":
					_logro("catapulta")
				if not bot:
					_texto(Idioma.t("¡Terminado!"), Vector2(float(d["x"]), S - 220.0), Estilo.ORO)
					Audio.play("ui_big", 0.0, -6.0)
			d["obj"] = int(d["nivel"])


func pendientes() -> Array:
	return sitios.filter(func(s: Variant) -> bool:
		var d: Dictionary = s as Dictionary
		return d.has("obj") and (int(d["obj"]) > int(d["nivel"]) or bool(d.get("reparar", false))))


# ------------------------------------------------------------------ gente

## Muro en pie más exterior de un lado (o {} si no hay).
func muro_exterior(lado: int) -> Dictionary:
	var mejor: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "muro" and int(d["lado"]) == lado and int(d["nivel"]) > 0 and float(d["hp"]) > 0.0:
			if mejor.is_empty() or absf(float(d["x"])) > absf(float(mejor["x"])):
				mejor = d
	return mejor


func _torre_lado(lado: int) -> Dictionary:
	var mejor: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "torre" and int(d["lado"]) == lado and int(d["nivel"]) > 0:
			var m: Dictionary = muro_exterior(lado)
			if not m.is_empty() and absf(float(d["x"])) < absf(float(m["x"])):
				if mejor.is_empty() or absf(float(d["x"])) > absf(float(mejor["x"])):
					mejor = d
	return mejor


func _gente(dt: float) -> void:
	var noche: bool = fase == "noche" or fase == "tarde"
	var vista: float = (float((Datos.LUNAS[luna_hoy] as Dictionary)["vista"]) * (0.7 if clima == "niebla" else 1.0)) if fase == "noche" else 1.0
	for g: Variant in gente:
		var p: Dictionary = g as Dictionary
		p["t"] = float(p["t"]) + dt
		p["cd"] = maxf(0.0, float(p["cd"]) - dt)
		var of: String = str(p["oficio"])
		var lado: int = int(p["lado"])
		var m: Dictionary = muro_exterior(lado)
		var dentro: float = absf(float(m["x"])) - 60.0 if not m.is_empty() else 140.0
		match of:
			"vagabundo":
				if fmod(float(p["t"]), 4.0) < dt:
					p["obj"] = float(p["x"]) + rng.randf_range(-120, 120)
				_andar(p, float(p["obj"]), 40.0, dt)
			"aldeano":
				## Si hay una herramienta en una tienda, va a por ella.
				var tomada: bool = false
				for of2: String in herramientas.keys():
					if int(herramientas[of2]) > 0:
						var tx: float = _x_tienda(of2)
						if _andar(p, tx, 120.0, dt):
							herramientas[of2] = int(herramientas[of2]) - 1
							p["oficio"] = of2
							p["lado"] = 1 if _contar_lado(of2, 1) < _contar_lado(of2, -1) else -1
							if not bot:
								_texto(Idioma.t(str((Datos.OFICIOS[of2] as Dictionary)["nombre"])), Vector2(float(p["x"]), S - 150.0), Estilo.ORO)
						tomada = true
						break
				if not tomada:
					if fmod(float(p["t"]), 5.0) < dt:
						p["obj"] = rng.randf_range(-120, 120)
					_andar(p, float(p["obj"]), 50.0, dt)
			"constructor":
				var pend: Array = pendientes()
				var obra: Dictionary = {}
				if not noche:
					var md: float = 1e9
					for o: Variant in pend:
						var dd: float = absf(float((o as Dictionary)["x"]) - float(p["x"]))
						if dd < md:
							md = dd
							obra = o as Dictionary
				if not obra.is_empty():
					if _andar(p, float(obra["x"]) - signf(float(obra["x"])) * 30.0, 90.0, dt):
						obra["trabajo"] = float(obra["trabajo"]) - dt
						p["trabaja"] = true
						p["dir"] = 1 if float(obra["x"]) > float(p["x"]) else -1
						if not bot and fmod(float(p["t"]), 0.5) < dt:
							Audio.play("ui_tick", 0.2, -14.0, 0.6)
				else:
					_andar(p, lado * 60.0, 70.0, dt)
			"granjero":
				var granja: Dictionary = {}
				for s: Variant in sitios:
					var d: Dictionary = s as Dictionary
					if str(d["tipo"]) == "granja" and int(d["nivel"]) > 0 and int(d["lado"]) == lado:
						granja = d
				if not granja.is_empty() and not noche:
					if _andar(p, float(granja["x"]), 70.0, dt) and fmod(float(p["t"]), 11.0 / (1.0 + 0.4 * Estado.mejora("granjas"))) < dt:
						_soltar_brasa(float(granja["x"]) + rng.randf_range(-30, 30))
				else:
					_andar(p, lado * 80.0, 60.0, dt)
			"heroe":
				_heroe(p, dt, m, dentro, noche)
			"arquero", "lancero":
				if bool(p["asalto"]) and fase == "dia":
					_asaltar(p, dt)
					continue
				var puesto: float = lado * dentro
				var torre: Dictionary = _torre_lado(lado) if of == "arquero" else {}
				if of == "arquero" and not torre.is_empty() and _arqueros_en_torre(lado) < 2:
					puesto = float(torre["x"])
					p["torre"] = true
				else:
					p["torre"] = false
				if of == "lancero":
					puesto = lado * (absf(float(m["x"])) - 30.0) if not m.is_empty() else lado * 120.0
				if not noche and of == "arquero":
					## De día: caza.
					var ci: Dictionary = _ciervo_cerca(float(p["x"]), 900.0)
					if not ci.is_empty():
						if absf(float(ci["x"]) - float(p["x"])) > 380.0:
							_andar(p, float(ci["x"]), 75.0, dt)
						elif float(p["cd"]) <= 0.0:
							_disparar(p, float(ci["x"]), S - 40.0, true)
						continue
					puesto = lado * (dentro + 120.0)
				_andar(p, puesto + (rng.randf_range(-1, 1) if false else 0.0), 85.0, dt)
				## Disparar / pinchar.
				if float(p["cd"]) <= 0.0:
					var alcance: float = (430.0 + (180.0 if bool(p.get("torre", false)) else 0.0)) * vista if of == "arquero" else 85.0
					var obj: Dictionary = _criatura_cerca(float(p["x"]), alcance, of == "arquero")
					if not obj.is_empty():
						if of == "arquero":
							_disparar(p, float(obj["x"]), _y_criatura(obj) - 30.0, false)
						else:
							_herir(obj, 5.0 * _buff())
							p["cd"] = 0.9
							p["ataca"] = 0.25
							p["dir"] = 1 if float(obj["x"]) > float(p["x"]) else -1
							if not bot:
								Audio.play("ui_tick", 0.2, -8.0, 0.5)
	gente = gente.filter(func(g: Variant) -> bool: return not bool((g as Dictionary).get("muerto", false)))


## Catapultas: lanzan una roca a la sombra más lejana de su lado.
func _catapultas(dt: float) -> void:
	for s2: Variant in sitios:
		var d: Dictionary = s2 as Dictionary
		if str(d["tipo"]) != "catapulta" or int(d["nivel"]) <= 0:
			continue
		d["cd"] = maxf(0.0, float(d.get("cd", 0.0)) - dt)
		d["tiro"] = maxf(0.0, float(d.get("tiro", 0.0)) - dt)
		if float(d["cd"]) > 0.0:
			continue
		var lado: int = int(d["lado"])
		var obj: Dictionary = {}
		for c: Variant in criaturas:
			var cr: Dictionary = c as Dictionary
			if int(cr["lado"]) != lado or bool(cr["vuela"]) or absf(float(cr["x"]) - float(d["x"])) > 950.0:
				continue
			if obj.is_empty() or absf(float(cr["x"])) > absf(float(obj["x"])):
				obj = cr
		if obj.is_empty():
			continue
		d["cd"] = 4.0
		d["tiro"] = 0.4
		var ox: float = float(d["x"])
		var oy: float = S - 90.0
		var dx: float = float(obj["x"]) - ox
		var t: float = maxf(0.6, absf(dx) / 420.0)
		flechas.append({"x": ox, "y": oy, "vx": dx / t, "vy": (S - 30.0 - oy - 0.5 * 900.0 * t * t) / t, "t": 0.0, "caza": false,
			"dano": 18.0 * (1.0 + 0.25 * Estado.mejora("catapultas")) * _buff(), "aoe": 110.0, "col": Color(0.75, 0.65, 0.55), "roca": true})
		if not bot:
			Audio.play("ui_swoosh", 0.1, -4.0, 0.5)


func _logro(id: String) -> void:
	if bot:
		return
	var l: Dictionary = Estado.logro(id)
	if not l.is_empty():
		_avisar(Idioma.t("Logro: %s") % Idioma.t(str(l["nombre"])) + "   +%d ◆" % int(l["premio"]))
		Audio.play("ui_reward", 0.0, -2.0, 1.2)


func _buff() -> float:
	return 1.6 if cuerno_t > 0.0 else 1.0


## Héroes: se ponen en el muro de su lado, pelean y lanzan su habilidad cada cierto tiempo.
func _heroe(p: Dictionary, dt: float, m: Dictionary, dentro: float, noche: bool) -> void:
	var id: String = str(p.get("heroe", "caballero"))
	var h: Dictionary = Datos.HEROES[id] as Dictionary
	var lado: int = int(p["lado"])
	p["aturdido"] = maxf(0.0, float(p.get("aturdido", 0.0)) - dt)
	if float(p["aturdido"]) > 0.0:
		return
	p["hab_t"] = float(p.get("hab_t", 0.0)) - dt
	if bool(p["asalto"]) and fase == "dia":
		_asaltar(p, dt)
		return
	var hueco: float = {"caballero": 0.0, "monje": 15.0, "bruja": 70.0, "druida": 90.0, "ingeniera": 110.0, "cazadora": 130.0}.get(id, 0.0)
	var puesto: float = lado * ((absf(float(m["x"])) - 25.0) if not m.is_empty() and id in ["caballero", "monje"] else dentro - hueco)
	if not noche:
		puesto = lado * (dentro + 60.0)
	_andar(p, puesto, 110.0, dt)
	var alcance: float = float(h["alcance"])
	var nv: int = Estado.nivel_heroe(id)
	var fh: float = (1.0 + 0.2 * Estado.mejora("fuerza_heroes")) * _buff() * (1.0 + 0.12 * float(nv - 1))
	if noche:
		p["carga"] = minf(100.0, float(p.get("carga", 0.0)) + dt * 1.6)
	if float(p["cd"]) <= 0.0:
		var obj: Dictionary = _criatura_cerca(float(p["x"]), alcance, id != "caballero")
		if not obj.is_empty():
			p["dir"] = 1 if float(obj["x"]) > float(p["x"]) else -1
			p["ataca"] = 0.25
			p["cd"] = float(h["cd"]) * (0.7 if cuerno_t > 0.0 else 1.0)
			match id:
				"caballero", "monje":
					_herir(obj, float(h["dano"]) * fh)
					if not bot:
						_chispas(Vector2(float(obj["x"]), S - 70.0), Color(1.0, 0.9, 0.5), 5)
						Audio.play("ui_tick", 0.15, -6.0, 0.7)
				"bruja":
					var ox: float = float(p["x"])
					var oy: float = S - 90.0
					var dx: float = float(obj["x"]) - ox
					var t: float = maxf(0.3, absf(dx) / 520.0)
					flechas.append({"x": ox, "y": oy, "vx": dx / t, "vy": (S - 40.0 - oy - 0.5 * 900.0 * t * t) / t, "t": 0.0, "caza": false,
						"dano": float(h["dano"]) * _buff(), "aoe": 80.0, "col": Color(0.45, 1.0, 0.35), "bola": true})
					if not bot:
						Audio.play("ui_swoosh", 0.1, -8.0, 0.7)
				"ingeniera":
					## Virote que atraviesa: daña a todo lo que hay en la línea hasta el objetivo.
					for c2: Variant in criaturas:
						var d2: Dictionary = c2 as Dictionary
						if signf(float(d2["x"]) - float(p["x"])) == signf(float(obj["x"]) - float(p["x"])) and absf(float(d2["x"]) - float(p["x"])) <= absf(float(obj["x"]) - float(p["x"])) + 20.0:
							_herir(d2, float(h["dano"]) * fh)
					if not bot:
						var y0: float = S - 70.0
						for k: int in 10:
							_particulas.append({"p": Vector2(lerpf(float(p["x"]), float(obj["x"]), k / 10.0), y0), "v": Vector2.ZERO, "t": 0.25, "c": Color(1.0, 0.7, 0.3, 0.8), "r": 3.0})
						Audio.play("ui_swoosh", 0.1, -6.0, 1.6)
				"druida":
					_herir(obj, float(h["dano"]) * fh)
					obj["aturdido"] = 0.6
					if not bot:
						_chispas(Vector2(float(obj["x"]), S - 30.0), Color(0.4, 0.8, 0.3), 6)
				"cazadora":
					_disparar(p, float(obj["x"]), _y_criatura(obj) - 30.0, false)
					p["cd"] = float(h["cd"]) * (0.7 if cuerno_t > 0.0 else 1.0)
					(flechas.back() as Dictionary)["dano"] = float(h["dano"]) * fh
					(flechas.back() as Dictionary)["estrella"] = true
	## Talento (desde nivel 3): segunda habilidad automática.
	p["tal_t"] = float(p.get("tal_t", 8.0)) - dt
	p["cast"] = maxf(0.0, float(p.get("cast", 0.0)) - dt)
	if nv >= 3 and float(p["tal_t"]) <= 0.0 and not _criatura_cerca(float(p["x"]), 520.0, true).is_empty():
		p["tal_t"] = 18.0
		_talento(p, id, fh)
	## Habilidad especial.
	if float(p["hab_t"]) <= 0.0 and not _criatura_cerca(float(p["x"]), 520.0, true).is_empty():
		p["hab_t"] = float(h["hab_cd"])
		p["carga"] = minf(100.0, float(p.get("carga", 0.0)) + 6.0)
		p["xp_hab"] = int(p.get("xp_hab", 0)) + 1
		p["cast"] = 1.0
		var x: float = float(p["x"])
		_poner_fx(str((Datos.HEROES_V6[id] as Dictionary)["fx"]), x + int(p.get("dir", 1)) * 160.0, S - 110.0, 190.0, 0.7)
		match id:
			"caballero":
				for c: Variant in criaturas:
					var d: Dictionary = c as Dictionary
					if absf(float(d["x"]) - x) < 240.0:
						_herir(d, 15.0 * _buff())
						d["x"] = float(d["x"]) + int(d["lado"]) * 140.0
						d["aturdido"] = 1.2
						_herir(d, 0.0)
				if not bot:
					for i: int in 36:
						var a: float = i / 36.0 * TAU
						_particulas.append({"p": Vector2(x, S - 40.0), "v": Vector2(cos(a) * 420.0, sin(a) * 120.0 - 40.0), "t": 0.5, "c": Color(1.0, 0.85, 0.45), "r": 4.0})
					_sacudir = 0.5
					_parar(0.06)
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Estilo.ORO)
			"monje":
				for c: Variant in criaturas:
					var d: Dictionary = c as Dictionary
					if absf(float(d["x"]) - x) < 200.0:
						_herir(d, 10.0 * fh)
						d["aturdido"] = 2.5
				if not bot:
					for i: int in 30:
						var a: float = i / 30.0 * TAU
						_particulas.append({"p": Vector2(x + cos(a) * 60.0, S - 70.0 + sin(a) * 30.0), "v": Vector2(-sin(a), cos(a) * 0.4) * 380.0, "t": 0.4, "c": Color(1.0, 0.65, 0.2), "r": 4.0})
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(1.0, 0.7, 0.3))
					_parar(0.05)
			"ingeniera":
				var ob4: Dictionary = _criatura_cerca(x, 560.0, false)
				if not ob4.is_empty():
					_explosion(float(ob4["x"]), 170.0, 30.0 * fh, Color(1.0, 0.55, 0.15))
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(1.0, 0.6, 0.2))
			"druida":
				## Repara el muro más dañado de su lado y atrapa a las sombras cercanas.
				var peor: Dictionary = {}
				for s2: Variant in sitios:
					var w: Dictionary = s2 as Dictionary
					if str(w["tipo"]) == "muro" and int(w["nivel"]) > 0 and int(w["lado"]) == int(p["lado"]):
						if peor.is_empty() or float(w["hp"]) / _vida_muro(int(w["nivel"])) < float(peor["hp"]) / _vida_muro(int(peor["nivel"])):
							peor = w
				if not peor.is_empty():
					peor["hp"] = minf(_vida_muro(int(peor["nivel"])), float(peor["hp"]) + _vida_muro(int(peor["nivel"])) * 0.35)
				for c: Variant in criaturas:
					var d3: Dictionary = c as Dictionary
					if absf(float(d3["x"]) - x) < 420.0 and not bool(d3["vuela"]):
						d3["aturdido"] = 3.0
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(0.5, 0.9, 0.4))
					if not peor.is_empty():
						_chispas(Vector2(float(peor["x"]), S - 120.0), Color(0.5, 1.0, 0.4), 16)
			"bruja":
				var obj2: Dictionary = _criatura_cerca(x, 520.0, true)
				_explosion(float(obj2["x"]), 210.0, 25.0 * fh, Color(0.4, 1.0, 0.3))
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(0.6, 1.0, 0.5))
			"cazadora":
				for i: int in 9:
					var obj3: Dictionary = _criatura_cerca(x + rng.randf_range(-400, 400), 520.0, true)
					if obj3.is_empty():
						continue
					var tx: float = float(obj3["x"]) + rng.randf_range(-20, 20)
					flechas.append({"x": tx - 160.0 * int(obj3["lado"]), "y": -40.0 - i * 40.0, "vx": 160.0 * int(obj3["lado"]), "vy": 700.0, "t": 0.0,
						"caza": false, "dano": 6.0 * _buff(), "estrella": true})
				if not bot:
					_texto(Idioma.t(str(h["hab"])), Vector2(x, S - 210.0), Color(0.75, 0.85, 1.0))


# ------------------------------------------------------------------ héroes v6: talentos y definitivas

func _talento(p: Dictionary, id: String, fh: float) -> void:
	p["cast"] = 1.0
	var x: float = float(p["x"])
	var dir: int = int(p.get("dir", 1))
	var v6: Dictionary = Datos.HEROES_V6[id] as Dictionary
	_poner_fx(str(v6["fx"]), x + dir * 200.0, S - 110.0, 230.0, 0.8)
	match id:
		"caballero":
			for c: Variant in criaturas:
				var d: Dictionary = c as Dictionary
				var dx: float = (float(d["x"]) - x) * dir
				if dx > -40.0 and dx < 340.0:
					_herir(d, 20.0 * fh)
					d["x"] = float(d["x"]) + dir * 120.0
					d["aturdido"] = 1.0
			p["x"] = x + dir * 120.0
		"bruja":
			for k: int in 3:
				var ob: Dictionary = _criatura_cerca(x + rng.randf_range(-300, 300), 500.0, true)
				if not ob.is_empty():
					_explosion(float(ob["x"]), 160.0, 14.0 * fh, Color(0.45, 1.0, 0.35))
		"monje":
			for c: Variant in criaturas:
				var d2: Dictionary = c as Dictionary
				if absf(float(d2["x"]) - x) < 260.0:
					_herir(d2, 12.0 * fh)
					d2["aturdido"] = 4.0
		"ingeniera":
			var ob2: Dictionary = _criatura_cerca(x, 600.0, false)
			if not ob2.is_empty():
				var sgn: float = signf(float(ob2["x"]) - x)
				for k: int in 5:
					_explosion(x + sgn * (140.0 + k * 100.0), 120.0, 18.0 * fh, Color(1.0, 0.55, 0.15))
		"druida":
			for s2: Variant in sitios:
				var w: Dictionary = s2 as Dictionary
				if str(w["tipo"]) == "muro" and int(w["nivel"]) > 0 and int(w["lado"]) == int(p["lado"]):
					w["hp"] = minf(_vida_muro(int(w["nivel"])), float(w["hp"]) + _vida_muro(int(w["nivel"])) * 0.2)
			for c: Variant in criaturas:
				var d3: Dictionary = c as Dictionary
				if absf(float(d3["x"]) - x) < 600.0 and not bool(d3["vuela"]):
					d3["aturdido"] = maxf(float(d3.get("aturdido", 0.0)), 2.0)
		"cazadora":
			for c: Variant in criaturas:
				var d4: Dictionary = c as Dictionary
				var dx2: float = (float(d4["x"]) - x) * dir
				if dx2 > 0.0 and dx2 < 900.0:
					_herir(d4, 25.0 * fh)
	if not bot:
		_texto(Idioma.t(str(v6["talento"])), Vector2(x, S - 240.0), v6["col"] as Color)
		Audio.play("ui_big", 0.1, -10.0, 1.2)


## La definitiva de un héroe: la lanza el jugador desde su retrato cuando está cargada.
func definitiva(p: Dictionary) -> bool:
	if float(p.get("carga", 0.0)) < 100.0 or not gente.has(p):
		return false
	p["carga"] = 0.0
	p["cast"] = 1.0
	var id: String = str(p.get("heroe", "caballero"))
	var v6: Dictionary = Datos.HEROES_V6[id] as Dictionary
	var x: float = float(p["x"])
	var fh: float = (1.0 + 0.2 * Estado.mejora("fuerza_heroes")) * _buff() * (1.0 + 0.12 * float(Estado.nivel_heroe(id) - 1))
	var lado: int = int(p["lado"])
	match id:
		"caballero":
			for c: Variant in criaturas:
				var d: Dictionary = c as Dictionary
				if absf(float(d["x"]) - x) < 600.0:
					_herir(d, 40.0 * fh)
					d["x"] = float(d["x"]) + int(d["lado"]) * 200.0
					d["aturdido"] = 2.0
		"bruja":
			var k: float = -900.0
			while k <= 900.0:
				_explosion(x + k, 130.0, 35.0 * fh, Color(0.45, 1.0, 0.35))
				k += 150.0
		"monje":
			for c: Variant in criaturas:
				var d2: Dictionary = c as Dictionary
				if absf(float(d2["x"]) - x) < 700.0:
					_herir(d2, 20.0 * fh)
					d2["aturdido"] = 5.0
		"ingeniera":
			for k2: int in 8:
				_explosion(x + lado * (120.0 + k2 * 110.0), 150.0, 50.0 * fh, Color(1.0, 0.55, 0.15))
		"druida":
			for s2: Variant in sitios:
				var w: Dictionary = s2 as Dictionary
				if str(w["tipo"]) == "muro" and int(w["nivel"]) > 0:
					w["hp"] = _vida_muro(int(w["nivel"]))
			for c: Variant in criaturas:
				var d3: Dictionary = c as Dictionary
				if not bool(d3["vuela"]):
					d3["aturdido"] = 5.0
		"cazadora":
			for i: int in 30:
				var ob: Dictionary = _criatura_cerca(x + rng.randf_range(-700, 700), 800.0, true)
				if ob.is_empty():
					break
				var tx: float = float(ob["x"]) + rng.randf_range(-30, 30)
				flechas.append({"x": tx - 160.0 * int(ob["lado"]), "y": -40.0 - i * 30.0, "vx": 160.0 * int(ob["lado"]), "vy": 760.0, "t": 0.0,
					"caza": false, "dano": 12.0 * fh, "estrella": true})
	if not bot:
		_poner_fx(str(v6["fx"]), x, S - 160.0, 520.0, 1.2)
		_poner_fx(str(v6["fx"]), x - 380.0, S - 120.0, 320.0, 1.0)
		_poner_fx(str(v6["fx"]), x + 380.0, S - 120.0, 320.0, 1.0)
		_avisar("%s: %s" % [Idioma.t(str((Datos.HEROES[id] as Dictionary)["nombre"])), Idioma.t(str(v6["def"]))])
		_flash = 0.6
		_sacudir = 0.9
		_parar(0.12)
		Audio.play("ui_big", 0.0, -2.0, 0.8)
	return true


## Efecto pintado en el mundo (lr_fx_*): crece, gira un poco y se desvanece.
func _poner_fx(tex: String, x: float, y: float, tam: float, dur: float) -> void:
	if bot or (_tex_fx(tex) == null and _hoja(tex, "anim") == null):
		return
	_fx.append({"tex": tex, "x": x, "y": y, "tam": tam, "t": 0.0, "dur": dur, "rot": rng.randf_range(-0.4, 0.4)})


func _tex_fx(tex: String) -> Texture2D:
	if not _tex.has(tex):
		_tex[tex] = Estilo.tex(tex) if Estilo.existe(tex) else null
	return _tex[tex] as Texture2D


func _dibujar_fx(dt: float) -> void:
	var i: int = _fx.size() - 1
	while i >= 0:
		var f: Dictionary = _fx[i] as Dictionary
		f["t"] = float(f["t"]) + dt
		var u: float = float(f["t"]) / float(f["dur"])
		if u >= 1.0:
			_fx.remove_at(i)
			i -= 1
			continue
		var hoja: Texture2D = _hoja(str(f["tex"]), "anim")
		if hoja != null:
			## Efecto animado por la IA (Wan): un fotograma por momento, sin escalar.
			var nf: int = maxi(1, int(hoja.get_width() / 256.0))
			var fr: int = mini(nf - 1, int(u * nf))
			var lado2: float = float(f["tam"]) * 1.25
			draw_texture_rect_region(hoja, Rect2(_sx(float(f["x"])) - lado2 / 2.0, float(f["y"]) - lado2 / 2.0, lado2, lado2), Rect2(fr * 256.0, 0, 256, 256), Color(1.15, 1.1, 1.05, 1.0 - smoothstep(0.85, 1.0, u)))
			i -= 1
			continue
		var tx: Texture2D = _tex_fx(str(f["tex"]))
		var esc: float = (0.4 + 0.7 * minf(1.0, u * 3.0)) * (1.0 + 0.2 * u)
		var a: float = minf(1.0, u * 6.0) * (1.0 - smoothstep(0.6, 1.0, u))
		var lado: float = float(f["tam"]) * esc
		draw_set_transform(Vector2(_sx(float(f["x"])), float(f["y"])), float(f["rot"]) + u * 0.6, Vector2.ONE)
		draw_texture_rect(tx, Rect2(-lado / 2.0, -lado / 2.0, lado, lado), false, Color(1.2, 1.15, 1.1, a))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		i -= 1


## Explosión en el suelo: daña a todas las sombras cerca.
func _explosion(x: float, radio: float, dano: float, col: Color) -> void:
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if absf(float(d["x"]) - x) < radio:
			_herir(d, dano)
	if bot:
		return
	var fxe: String = "lr_fx_verde" if col.g > col.r else ("lr_fx_bomba" if col.r > 0.8 and col.b < 0.4 else "lr_fx_impacto")
	_poner_fx(fxe, x, S - radio * 0.45, radio * 1.7, 0.7)
	for i: int in int(10 + radio / 10.0):
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": Vector2(x, S - 10.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, radio * 1.6), "t": rng.randf_range(0.4, 0.8), "c": col if i % 2 else col.lightened(0.5), "r": rng.randf_range(3, 7), "g": 300.0})
	_sacudir = maxf(_sacudir, radio / 500.0)
	Audio.play("ui_big", 0.1, -8.0, 1.4)


## Fragmentos de luna: moneda de las mejoras permanentes.
func _ganar_fragmentos(n: int, p: Vector2) -> void:
	if bot:
		return
	Estado.d["fragmentos"] = Estado.n("fragmentos") + n
	Estado.guardar()
	_texto(Idioma.t("+%d fragmentos de luna") % n, p, Color(1.0, 0.45, 0.45))
	for i: int in 14:
		var a: float = rng.randf_range(0.0, TAU)
		_particulas.append({"p": p, "v": Vector2(cos(a), sin(a)) * rng.randf_range(60, 200), "t": 1.0, "c": Color(1.0, 0.3, 0.35), "r": 4.0, "g": -40.0})


## Parón de impacto: congela un instante para que el golpe se note.
func _parar(t: float) -> void:
	if bot:
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(t, true, false, true).timeout
	Engine.time_scale = 1.0


## Habilidad de la reina: el farol estalla en luz y quema a las sombras cercanas.
func destello() -> bool:
	if cd_destello > 0.0:
		return false
	var radio: float = 330.0 * (1.0 + 0.15 * Estado.mejora("farol"))
	cd_destello = 35.0 * (1.0 - 0.2 * Estado.mejora("farol")) * (0.7 if montura == "grifo" else 1.0)
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if absf(float(d["x"]) - float(reina["x"])) < radio:
			_herir(d, 20.0)
			d["aturdido"] = 2.0
	if not bot:
		_flash = 1.0
		_sacudir = 0.7
		Juice.vibrate(70)
		Audio.play("ui_big", 0.0, 0.0, 1.6)
		_parar(0.08)
		for i: int in 40:
			var a: float = i / 40.0 * TAU
			_particulas.append({"p": Vector2(float(reina["x"]), S - 120.0), "v": Vector2(cos(a), sin(a)) * 520.0, "t": 0.45, "c": Color(1.0, 0.95, 0.7), "r": 5.0})
	return true


## Habilidad de la reina: el cuerno de guerra. Tus soldados pegan más y más rápido un rato.
## Poder de la montura (v7).
func poder_montura() -> bool:
	if montura == "" or cd_montura > 0.0:
		return false
	cd_montura = 25.0
	var x: float = float(reina["x"])
	var dir: int = int(reina["dir"])
	match montura:
		"caballo":
			reina["galope"] = 5.0
		"oso":
			for c: Variant in criaturas:
				var d: Dictionary = c as Dictionary
				if absf(float(d["x"]) - x) < 260.0:
					_herir(d, 25.0)
					d["aturdido"] = 2.0
			if not bot:
				_sacudir = 0.6
				_chispas(Vector2(x, S - 60.0), Color(0.8, 0.6, 0.4), 24)
		"grifo":
			reina["inmune"] = 4.0
			reina["iman"] = 4.0
		"lobo":
			for c: Variant in criaturas:
				var d2: Dictionary = c as Dictionary
				if absf(float(d2["x"]) - x) < 520.0 and str(d2["tipo"]) != "jefe":
					d2["x"] = float(d2["x"]) + signf(float(d2["x"]) - x) * 260.0
					d2["aturdido"] = 3.0
		"dragon":
			for k: int in 5:
				_explosion(x + dir * (110.0 + k * 110.0), 110.0, 25.0, Color(1.0, 0.35, 0.1))
	if not bot:
		_avisar(Idioma.t(str((Datos.PODER_MONTURA[montura] as Dictionary)["nombre"])) + "!")
		Juice.vibrate(50)
		Audio.play("ui_big", 0.0, -4.0, 0.7)
	return true


func cuerno() -> bool:
	if cd_cuerno > 0.0:
		return false
	cd_cuerno = 60.0 - 10.0 * Estado.mejora("cuerno")
	cuerno_t = 12.0 + 4.0 * Estado.mejora("cuerno")
	if not bot:
		_avisar(Idioma.t("¡A las armas!"))
		Juice.vibrate(40)
		Audio.play("ui_big", 0.0, -2.0, 0.55)
		for g: Variant in gente:
			var d: Dictionary = g as Dictionary
			if str(d["oficio"]) in ["arquero", "lancero", "heroe"]:
				for i: int in 6:
					_particulas.append({"p": Vector2(float(d["x"]), S - 60.0), "v": Vector2(rng.randf_range(-40, 40), rng.randf_range(-160, -80)), "t": 0.8, "c": Color(1.0, 0.8, 0.3), "r": 3.0})
	return true


func _arqueros_en_torre(lado: int) -> int:
	return gente.filter(func(g: Variant) -> bool: return str((g as Dictionary)["oficio"]) == "arquero" and int((g as Dictionary)["lado"]) == lado and bool((g as Dictionary).get("torre", false))).size()


func _x_tienda(of: String) -> float:
	for s: Variant in sitios:
		if str((s as Dictionary)["tipo"]) == "tienda_" + of:
			return float((s as Dictionary)["x"])
	return 0.0


## Mueve hacia x; devuelve true si ha llegado.
func _andar(p: Dictionary, x: float, vel: float, dt: float) -> bool:
	var dx: float = x - float(p["x"])
	if absf(dx) < 6.0:
		return true
	p["dir"] = 1 if dx > 0 else -1
	p["x"] = float(p["x"]) + signf(dx) * minf(absf(dx), vel * dt)
	p["anda"] = true
	return absf(x - float(p["x"])) < 6.0


func _asaltar(p: Dictionary, dt: float) -> void:
	var lado: int = int(p["lado"])
	var gr: Dictionary = {}
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "grieta" and int(d["lado"]) == lado:
			gr = d
	if gr.is_empty() or bool(gr["cerrada"]):
		p["asalto"] = false
		return
	var objetivo: float = float(gr["x"]) - lado * (60.0 if str(p["oficio"]) == "lancero" or str(p.get("heroe", "")) == "caballero" else 300.0)
	if _andar(p, objetivo, 110.0, dt) and float(p["cd"]) <= 0.0:
		p["cd"] = 1.0
		var dano_a: float = 6.0 if str(p["oficio"]) == "lancero" else 3.0
		if str(p["oficio"]) == "heroe":
			dano_a = float((Datos.HEROES[str(p["heroe"])] as Dictionary)["asalto"])
		gr["hp"] = float(gr["hp"]) - dano_a * _buff()
		if not bot:
			_chispas(Vector2(float(gr["x"]), S - 160.0), Color("ff3b3b"), 4)
		if float(gr["hp"]) <= 0.0:
			gr["cerrada"] = true
			gr["asalto"] = false
			_ganar_fragmentos(2, Vector2(float(gr["x"]), S - 200.0))
			_logro("grieta")
			if not bot:
				_avisar(Idioma.t("¡Grieta cerrada!"))
				_sacudir = 1.0
				Juice.vibrate(100)
				Audio.play("ui_big", 0.0, 0.0, 0.7)
			for g: Variant in gente:
				(g as Dictionary)["asalto"] = false


func _ciervo_cerca(x: float, r: float) -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = r
	for c: Variant in ciervos:
		var dd: float = absf(float((c as Dictionary)["x"]) - x)
		if dd < md:
			md = dd
			mejor = c as Dictionary
	return mejor


func _criatura_cerca(x: float, r: float, aire: bool) -> Dictionary:
	var mejor: Dictionary = {}
	var md: float = r
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		if bool(d["vuela"]) and not aire:
			continue
		var dd: float = absf(float(d["x"]) - x)
		if dd < md:
			md = dd
			mejor = d
	return mejor


func _disparar(p: Dictionary, tx: float, ty: float, caza: bool) -> void:
	p["cd"] = 1.25 * (0.65 if cuerno_t > 0.0 else 1.0)
	p["ataca"] = 0.25
	var ox: float = float(p["x"])
	var oy: float = S - (220.0 if bool(p.get("torre", false)) else 70.0)
	var dx: float = tx - ox
	var vx: float = signf(dx) * 640.0
	var t: float = maxf(0.15, absf(dx) / 640.0)
	var vy: float = (ty - oy - 0.5 * 900.0 * t * t) / t
	flechas.append({"x": ox, "y": oy, "vx": vx, "vy": vy, "t": 0.0, "caza": caza, "dano": 3.0 * _buff() * (1.0 + 0.2 * Estado.mejora("arqueros"))})
	p["dir"] = 1 if dx > 0 else -1
	if not bot:
		Audio.play("ui_swoosh", 0.25, -14.0, 1.4)


func _flechas(dt: float) -> void:
	for f: Variant in flechas:
		var a: Dictionary = f as Dictionary
		a["t"] = float(a["t"]) + dt
		a["vy"] = float(a["vy"]) + 900.0 * dt
		a["x"] = float(a["x"]) + float(a["vx"]) * dt
		a["y"] = float(a["y"]) + float(a["vy"]) * dt
		if bool(a["caza"]):
			for c: Variant in ciervos:
				var cd: Dictionary = c as Dictionary
				if absf(float(cd["x"]) - float(a["x"])) < 30.0 and float(a["y"]) > S - 90.0:
					cd["hp"] = float(cd["hp"]) - 3.0
					a["fin"] = true
					if float(cd["hp"]) <= 0.0:
						cd["muerto"] = true
						for i: int in (6 if bool(cd.get("blanco", false)) else 2):
							_soltar_brasa(float(cd["x"]) + rng.randf_range(-20, 20))
						if bool(cd.get("blanco", false)):
							_ganar_fragmentos(2, Vector2(float(cd["x"]), S - 160.0))
					break
		else:
			for c: Variant in criaturas:
				var d: Dictionary = c as Dictionary
				var cy: float = _y_criatura(d)
				var alto: float = float((Datos.CRIATURAS[str(d["tipo"])] as Dictionary)["alto"])
				if absf(float(d["x"]) - float(a["x"])) < 26.0 + alto * 0.2 and float(a["y"]) > cy - alto and float(a["y"]) < cy + 10.0:
					if float(a.get("aoe", 0.0)) > 0.0:
						_explosion(float(a["x"]), float(a["aoe"]), float(a["dano"]), a.get("col", Color(0.4, 1.0, 0.3)) as Color)
					else:
						var dmg: float = float(a.get("dano", 3.0))
						var critico: bool = rng.randf() < 0.12
						if critico:
							dmg *= 2.0
						_herir(d, dmg)
						if not (str(d["tipo"]) in ["jefe", "ariete", "torre_asedio", "golem"]):
							d["x"] = float(d["x"]) + signf(float(a["vx"])) * (14.0 if critico else 6.0)
						if not bot:
							_chispas(Vector2(float(a["x"]), float(a["y"])), (a.get("col", Color(1.0, 0.85, 0.5)) as Color) if bool(a.get("bola", false)) else (Color(0.8, 0.9, 1.0) if bool(a.get("estrella", false)) else Color(1.0, 0.85, 0.5)), 6 if critico else 3)
							if critico:
								_textos.append({"s": Idioma.t("¡Crítico!"), "x": float(d["x"]), "y": float(a["y"]) - 50.0, "c": Color(1.0, 0.8, 0.2), "t": 0.9, "pop": 1.0})
								_poner_fx("lr_fx_impacto", float(a["x"]), float(a["y"]), 90.0, 0.3)
								_parar(0.035)
					a["fin"] = true
					break
		if float(a["y"]) > S + 4.0 or float(a["t"]) > 3.0:
			if float(a.get("aoe", 0.0)) > 0.0 and not bool(a.get("fin", false)):
				_explosion(float(a["x"]), float(a["aoe"]), float(a["dano"]), a.get("col", Color(0.4, 1.0, 0.3)) as Color)
			a["fin"] = true
	flechas = flechas.filter(func(f: Variant) -> bool: return not bool((f as Dictionary).get("fin", false)))
	ciervos = ciervos.filter(func(c: Variant) -> bool: return not bool((c as Dictionary).get("muerto", false)))


func _ciervos(dt: float) -> void:
	for c: Variant in ciervos:
		var d: Dictionary = c as Dictionary
		d["t"] = float(d["t"]) + dt
		if fmod(float(d["t"]), 5.0) < dt:
			d["dir"] = -int(d["dir"]) if rng.randf() < 0.5 else int(d["dir"])
		var nx: float = float(d["x"]) + int(d["dir"]) * 35.0 * dt
		var m: Dictionary = muro_exterior(1 if nx > 0 else -1)
		var limite: float = absf(float(m["x"])) + 200.0 if not m.is_empty() else 900.0
		if absf(nx) < limite or absf(nx) > Datos.X_GRIETA - 300.0:
			d["dir"] = -int(d["dir"])
		else:
			d["x"] = nx


# ------------------------------------------------------------------ sombras

func _y_criatura(c: Dictionary) -> float:
	if bool(c["vuela"]):
		return S - 170.0 + sin(float(c["t"]) * 3.0) * 20.0
	return S


func _criaturas(dt: float) -> void:
	var dia_ya: bool = fase == "alba" or fase == "dia"
	for c: Variant in criaturas:
		var d: Dictionary = c as Dictionary
		var info: Dictionary = Datos.CRIATURAS[str(d["tipo"])] as Dictionary
		d["t"] = float(d["t"]) + dt
		d["cd"] = maxf(0.0, float(d["cd"]) - dt)
		d["golpe"] = maxf(0.0, float(d["golpe"]) - dt)
		var lado: int = int(d["lado"])
		var v: float = float(info["vel"]) * (1.12 if clima == "tormenta" else 1.0) * (1.1 if bool(d.get("elite", false)) else 1.0)
		if float(d.get("aturdido", 0.0)) > 0.0:
			d["aturdido"] = float(d["aturdido"]) - dt
			continue
		if float(d.get("sale", 0.0)) > 0.0:
			d["sale"] = float(d["sale"]) - dt * 1.4
			continue
		if float(d.get("bajo_tierra", 0.0)) > 0.0:
			d["bajo_tierra"] = float(d["bajo_tierra"]) - dt
			if float(d["bajo_tierra"]) <= 0.0:
				_salir_de_arena(d)
			continue
		if str(d["tipo"]) == "jefe" and not dia_ya:
			_jefe_habilidad(d, dt)
			if bool(d.get("fase2", false)):
				v *= 1.3
			if float(d.get("carga", 0.0)) > 0.0:
				d["carga"] = float(d["carga"]) - dt
				v *= 3.4
		if bool(d["huye"]) or dia_ya:
			d["x"] = float(d["x"]) + lado * v * 1.6 * dt
			if dia_ya:
				d["hp"] = float(d["hp"]) - 15.0 * dt
			if absf(float(d["x"])) > Datos.X_GRIETA + 120.0:
				d["fuera"] = true
			continue
		## Muro que le corta el paso (los alados vuelan por encima).
		var muro: Dictionary = {}
		if not bool(d["vuela"]):
			for s: Variant in sitios:
				var w: Dictionary = s as Dictionary
				if str(w["tipo"]) == "muro" and int(w["lado"]) == lado and int(w["nivel"]) > 0 and float(w["hp"]) > 0.0 \
						and absf(float(w["x"])) < absf(float(d["x"])) + 2.0:
					if muro.is_empty() or absf(float(w["x"])) > absf(float(muro["x"])):
						muro = w
		if not muro.is_empty() and absf(float(d["x"]) - float(muro["x"])) < 46.0 and str(d["tipo"]) == "torre_asedio":
			for k: int in 3:
				_invocar("sombra", float(muro["x"]) - lado * (40.0 + k * 30.0), lado)
			d["hp"] = 0.0
			_herir(d, 1.0)
			if not bot:
				_avisar(Idioma.t("¡La torre de asedio salta el muro!"))
				_sacudir = 0.5
			continue
		if not muro.is_empty() and absf(float(d["x"]) - float(muro["x"])) < 46.0:
			if float(d["cd"]) <= 0.0:
				d["cd"] = 1.0
				muro["hp"] = float(muro["hp"]) - float(info["dano"]) * (1.0 + dia * 0.02)
				if not bot:
					_chispas(Vector2(float(muro["x"]), S - 80.0), Color(0.6, 0.5, 0.4), 3)
					if absf(float(muro["x"]) - cam) < 700.0:
						Audio.play("ui_tick", 0.2, -10.0, 0.4)
				if float(muro["hp"]) <= 0.0:
					muro["nivel"] = 0
					muro["hp"] = 0.0
					muro["obj"] = 0
					_muro_roto = true
					if not bot:
						_avisar(Idioma.t("¡Han roto un muro!"))
						_sacudir = 0.6
			continue
		## Avanza hacia el fuego.
		d["x"] = float(d["x"]) - lado * v * dt
		## Ataca a quien encuentre.
		if float(d["cd"]) > 0.0:
			continue
		if absf(float(d["x"]) - float(reina["x"])) < 40.0 and float(reina["inmune"]) <= 0.0:
			d["cd"] = 1.2
			_golpe_reina(d)
			d["huye"] = str(d["tipo"]) != "jefe"
			continue
		for g: Variant in gente:
			var p: Dictionary = g as Dictionary
			if str(p["oficio"]) == "vagabundo" or float(p.get("aturdido", 0.0)) > 0.0:
				continue
			if absf(float(d["x"]) - float(p["x"])) < 30.0 and str(p["oficio"]) == "heroe":
				d["cd"] = 1.2
				p["aturdido"] = 4.0
				d["huye"] = true
				if not bot:
					_texto(Idioma.t("¡Herido!"), Vector2(float(p["x"]), S - 170.0), Estilo.ROJO)
				break
			if absf(float(d["x"]) - float(p["x"])) < 30.0:
				d["cd"] = 1.2
				## Pierde la herramienta y huye: vuelve a ser vagabundo.
				p["oficio"] = "vagabundo"
				p["asalto"] = false
				p["obj"] = lado * 2300.0
				d["huye"] = true
				stats["perdidos"] = int(stats["perdidos"]) + 1
				if not bot:
					_texto(Idioma.t("¡Le han quitado la herramienta!"), Vector2(float(p["x"]), S - 160.0), Estilo.ROJO)
				break
	for c: Variant in criaturas:
		var d2: Dictionary = c as Dictionary
		if float(d2["hp"]) <= 0.0 and not bool(d2.get("fuera", false)):
			d2["fuera"] = true
			stats["abatidas"] = int(stats["abatidas"]) + 1
			if not bot:
				Estado.d["abatidas_total"] = Estado.n("abatidas_total") + 1
				if Estado.n("abatidas_total") >= 500:
					_logro("sombras500")
				if Estado.n("abatidas_total") >= 3000:
					_logro("sombras3000")
			## Élites, máquinas de asedio y noches de eclipse sueltan brasas de premio.
			var premio: int = (2 if bool(d2.get("elite", false)) else 0) + (3 if str(d2["tipo"]) in ["ariete", "torre_asedio"] else 0) + (1 if clima == "eclipse" and rng.randf() < 0.5 else 0)
			for i: int in premio:
				_soltar_brasa(float(d2["x"]) + rng.randf_range(-50, 50))
			if str(d2["tipo"]) == "jefe":
				stats["jefes"] = int(stats["jefes"]) + 1
				Estado.d["jefes"] = Estado.n("jefes") + 1
				for i: int in 6:
					_soltar_brasa(float(d2["x"]) + rng.randf_range(-60, 60))
				_ganar_fragmentos(3, Vector2(float(d2["x"]), S - 260.0))
				_logro("jefe")
				if not bot:
					var jv: Array = Estado.d["jefes_valle"] as Array
					if not jv.has(_jefe_id):
						jv.append(_jefe_id)
					if jv.size() >= 6:
						_logro("jefes6")
					_avisar(Idioma.t("¡%s ha caído!") % Idioma.t(str((Datos.JEFES[_jefe_id] as Dictionary)["nombre"])))
					_parar(0.25)
					_flash = 0.8
					_sacudir = 1.2
			if not bot:
				_muertes.append({"tipo": str(d2["tipo"]), "x": float(d2["x"]), "lado": int(d2["lado"]), "t": 0.0, "vuela": bool(d2["vuela"]), "y": _y_criatura(d2) + 4.0})
				var alto_m: float = float((Datos.CRIATURAS[str(d2["tipo"])] as Dictionary)["alto"])
				_poner_fx("lr_fx_humo", float(d2["x"]), _y_criatura(d2) - alto_m * 0.4, alto_m * 1.3, 0.8)
				var alto_c: float = float((Datos.CRIATURAS[str(d2["tipo"])] as Dictionary)["alto"])
				for i: int in int(8 + alto_c / 10.0):
					var a: float = rng.randf_range(0.0, TAU)
					_particulas.append({"p": Vector2(float(d2["x"]), _y_criatura(d2) - alto_c * 0.5), "v": Vector2(cos(a), sin(a)) * rng.randf_range(60, 220),
						"t": rng.randf_range(0.5, 1.0), "c": Color(0.06, 0.02, 0.06, 0.8) if i % 3 else Color(1.0, 0.25, 0.1, 0.9), "r": rng.randf_range(3, 9), "g": -30.0})
				Audio.play("ui_tick", 0.2, -8.0, 0.35)
	criaturas = criaturas.filter(func(c: Variant) -> bool: return not bool((c as Dictionary).get("fuera", false)))


# ------------------------------------------------------------------ jefes de valle

func _jefe_habilidad(d: Dictionary, dt: float) -> void:
	var j: Dictionary = Datos.JEFES[_jefe_id] as Dictionary
	var f2: bool = bool(d.get("fase2", false))
	if not f2 and float(d["hp"]) < float(d["hpmax"]) * 0.5:
		d["fase2"] = true
		d["hab_t"] = 1.0
		if not bot:
			_avisar(Idioma.t("¡%s se enfurece!") % Idioma.t(str(j["nombre"])))
			_sacudir = 1.0
			_parar(0.15)
			Juice.vibrate(90)
			Audio.play("ui_big", 0.0, 0.0, 0.5)
			for i: int in 30:
				var a: float = rng.randf_range(0.0, TAU)
				_particulas.append({"p": Vector2(float(d["x"]), S - 140.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(100, 380), "t": 0.8, "c": Color(1.0, 0.15, 0.1), "r": rng.randf_range(4, 9), "g": 0.0})
	## Tercera fase (v6): al 25% desata su furia final, llama a su séquito y ataca el doble de rápido.
	var f3: bool = bool(d.get("fase3", false))
	if f2 and not f3 and float(d["hp"]) < float(d["hpmax"]) * 0.25:
		d["fase3"] = true
		f3 = true
		var pool: Array = ["sombra", "bruto"]
		for v: Variant in (Datos.VARIANTES[valle % Datos.VARIANTES.size()] as Dictionary).values():
			pool.append(str(v))
		for i: int in 3:
			_invocar(str(pool[rng.randi() % pool.size()]), float(d["x"]) + int(d["lado"]) * rng.randf_range(40, 160), int(d["lado"]))
		if not bot:
			_avisar(Idioma.t("¡%s desata su furia final!") % Idioma.t(str(j["nombre"])))
			_sacudir = 1.2
			_flash = 0.5
			_parar(0.2)
			Juice.vibrate(120)
			Audio.play("ui_big", 0.0, 2.0, 0.4)
	d["hab_t"] = float(d.get("hab_t", 4.0)) - dt * (2.2 if f3 else (1.6 if f2 else 1.0))
	if float(d["hab_t"]) > 0.0:
		return
	d["hab_t"] = float(j["cd"])
	var lado: int = int(d["lado"])
	var x: float = float(d["x"])
	var cerca_cam: bool = absf(x - cam) < 900.0
	if not bot and cerca_cam:
		_texto(Idioma.t(str(j["aviso"])), Vector2(x, S - 330.0), Color(1.0, 0.4, 0.3))
	match str(j["hab"]):
		"carga":
			d["carga"] = 1.1
			if not bot:
				Audio.play("ui_big", 0.1, -4.0, 0.7)
		"invoca":
			for i: int in (4 if f2 else 3):
				_invocar("ahogado", x + lado * rng.randf_range(30, 120), lado)
		"espectros":
			for i: int in (3 if f2 else 2):
				_invocar("espectro", x + lado * rng.randf_range(30, 120), lado)
		"fuego":
			for i: int in (4 if f2 else 3):
				_bola_fuego(x - lado * rng.randf_range(120.0, 620.0))
		"hielo":
			var r: float = 320.0
			for g: Variant in gente:
				var p: Dictionary = g as Dictionary
				if absf(float(p["x"]) - x) < r and str(p["oficio"]) != "vagabundo":
					p["aturdido"] = 3.0
			if absf(float(reina["x"]) - x) < r:
				reina["corre"] = 0.0
			if not bot:
				for i: int in 36:
					var a: float = rng.randf_range(-PI, 0.0)
					_particulas.append({"p": Vector2(x - lado * 60.0, S - 120.0), "v": Vector2(-lado * absf(cos(a)) * rng.randf_range(150, 420), sin(a) * rng.randf_range(20, 120)),
						"t": rng.randf_range(0.6, 1.1), "c": Color(0.75, 0.9, 1.0, 0.85), "r": rng.randf_range(4, 10), "g": -10.0})
				Audio.play("ui_whoosh", 0.1, -4.0, 0.6)
		"enterrar":
			d["bajo_tierra"] = 1.6
			if not bot:
				_chispas(Vector2(x, S - 20.0), Color(0.75, 0.6, 0.35), 20)
				Audio.play("ui_whoosh", 0.1, -6.0, 0.5)


## El escorpión reaparece más cerca del fuego, pero nunca al otro lado de un muro en pie.
func _salir_de_arena(d: Dictionary) -> void:
	var lado: int = int(d["lado"])
	var nx: float = float(d["x"]) - lado * 380.0
	for s2: Variant in sitios:
		var w: Dictionary = s2 as Dictionary
		if str(w["tipo"]) == "muro" and int(w["lado"]) == lado and int(w["nivel"]) > 0 and float(w["hp"]) > 0.0 and absf(float(w["x"])) < absf(float(d["x"])):
			if absf(nx) < absf(float(w["x"])) + 50.0:
				nx = float(w["x"]) + lado * 50.0
	d["x"] = nx
	if not bot:
		_chispas(Vector2(nx, S - 20.0), Color(0.75, 0.6, 0.35), 26)
		_sacudir = maxf(_sacudir, 0.5)
		Audio.play("ui_big", 0.1, -6.0, 0.8)


func _invocar(tipo: String, x: float, lado: int) -> void:
	var c: Dictionary = Datos.CRIATURAS[tipo] as Dictionary
	var hp: float = float(c["hp"]) * (1.0 + dia * 0.03)
	criaturas.append({"tipo": tipo, "x": x, "lado": lado, "hp": hp, "hpmax": hp, "cd": 1.0, "huye": false, "vuela": bool(c.get("vuela", false)),
		"t": rng.randf() * 3.0, "golpe": 0.0})
	if not bot:
		_chispas(Vector2(x, S - 40.0), Color(0.5, 0.1, 0.4), 10)


## Bola de fuego del dragón: daña muros y le quita la herramienta a quien pille.
func _bola_fuego(x: float) -> void:
	for s2: Variant in sitios:
		var w: Dictionary = s2 as Dictionary
		if str(w["tipo"]) == "muro" and int(w["nivel"]) > 0 and absf(float(w["x"]) - x) < 90.0:
			w["hp"] = maxf(1.0, float(w["hp"]) - 30.0)
	for g: Variant in gente:
		var p: Dictionary = g as Dictionary
		if absf(float(p["x"]) - x) < 70.0 and str(p["oficio"]) != "vagabundo":
			p["aturdido"] = 2.0
	if absf(float(reina["x"]) - x) < 60.0 and float(reina["inmune"]) <= 0.0:
		_golpe_reina({"tipo": "sombra"})
	if bot:
		return
	for i: int in 22:
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": Vector2(x, S - 10.0), "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 300), "t": rng.randf_range(0.4, 0.9),
			"c": Color(1.0, 0.45 + rng.randf() * 0.3, 0.1), "r": rng.randf_range(4, 9), "g": 280.0})
	_sacudir = maxf(_sacudir, 0.35)
	Audio.play("ui_big", 0.1, -10.0, 1.2)


func _herir(c: Dictionary, dano: float) -> void:
	c["hp"] = float(c["hp"]) - dano
	c["golpe"] = 0.15
	if not bot and dano >= 6.0:
		_textos.append({"s": "%d" % int(round(dano)), "x": float(c["x"]) + rng.randf_range(-20, 20), "y": _y_criatura(c) - float((Datos.CRIATURAS[str(c["tipo"])] as Dictionary)["alto"]) - 10.0,
			"c": Color(1.0, 0.9, 0.5) if dano < 15.0 else Color(1.0, 0.55, 0.3), "t": 0.8})


func _golpe_reina(c: Dictionary) -> void:
	reina["inmune"] = 1.6
	if brasas > 0:
		var pierde: int = mini(brasas, 3 if str(c["tipo"]) != "jefe" else 8)
		if montura == "lobo" or montura == "dragon":
			pierde = int(ceil(pierde * 0.75))
		if montura == "oso":
			pierde = int(ceil(pierde / 2.0))
			c["aturdido"] = 2.5
			if not bot:
				_texto(Idioma.t("¡Zarpazo!"), Vector2(float(c["x"]), S - 230.0), Color(1.0, 0.8, 0.4))
		brasas -= pierde
		if not bot:
			_texto(Idioma.t("-%d brasas") % pierde, Vector2(float(reina["x"]), S - 200.0), Estilo.ROJO)
			_sacudir = 0.5
			Juice.vibrate(60)
			Audio.play("ui_error", 0.0, -2.0)
		return
	## Sin brasas: la corona cae.
	vivo = false
	causa = "%s/dia%d" % [str(c["tipo"]), dia]
	if not bot:
		_sacudir = 1.0
		Juice.vibrate(150)
		_perder()


# ------------------------------------------------------------------ brasas por el suelo

func _soltar_brasa(x: float) -> void:
	suelo_brasas.append({"x": x, "y": S - 60.0, "vy": rng.randf_range(-260.0, -140.0), "vx": rng.randf_range(-40, 40), "t": 0.0})


func _recoger_brasas(dt: float) -> void:
	for b: Variant in suelo_brasas:
		var d: Dictionary = b as Dictionary
		d["t"] = float(d["t"]) + dt
		if (float(d["y"]) < S - 8.0 or float(d["vy"]) < 0.0) and float(d["t"]) <= 0.6:
			d["vy"] = float(d["vy"]) + 900.0 * dt
			d["y"] = minf(S - 8.0, float(d["y"]) + float(d["vy"]) * dt)
			d["x"] = float(d["x"]) + float(d["vx"]) * dt
		if float(d["t"]) > 0.6 and absf(float(d["x"]) - float(reina["x"])) < (900.0 if float(reina.get("iman", 0.0)) > 0.0 else 340.0 if montura == "grifo" else 170.0) and brasas < MAX_BRASAS:
			## Las brasas cercanas vuelan hacia la reina.
			d["x"] = lerpf(float(d["x"]), float(reina["x"]), minf(1.0, dt * 7.0))
			d["y"] = lerpf(float(d["y"]), S - 110.0, minf(1.0, dt * 5.0))
		if float(d["t"]) > 0.4 and absf(float(d["x"]) - float(reina["x"])) < 40.0 and brasas < MAX_BRASAS:
			d["fin"] = true
			brasas += 1
			if not bot:
				Audio.play("ui_coin", 0.15, -10.0, 1.2)
	suelo_brasas = suelo_brasas.filter(func(b: Variant) -> bool: return not bool((b as Dictionary).get("fin", false)) and float((b as Dictionary)["t"]) < 120.0)


# ------------------------------------------------------------------ ganar / perder

func _ganar() -> void:
	ganado = true
	if bot:
		return
	Estado.d["fragmentos"] = Estado.n("fragmentos") + 3
	Estado.ganar_valle()
	_logro("valle1")
	if Estado.n("valles_ganados") >= 3:
		_logro("valle3")
	if Estado.n("valles_ganados") >= 6:
		_logro("valle6")
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("¡Valle liberado!"), 720.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Has cerrado las dos grietas en %d días.") % dia, 26, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true))
	vb.add_child(Estilo.etiqueta(Idioma.t("Sombras abatidas: %d   ·   Obras: %d") % [int(stats["abatidas"]), int(stats["construidos"])], 22, Estilo.NIEBLA))
	var sig: String = Idioma.t("Siguiente valle") if Estado.valle_actual() < Datos.VALLES.size() else Idioma.t("Luna eterna")
	var b: Button = Estilo.boton(sig, true, 84)
	b.pressed.connect(func() -> void:
		Estado.partida = {"nuevo": true}
		Kit.change_scene("res://libre/juego.tscn"))
	vb.add_child(b)
	var bi: Button = Estilo.boton(Idioma.t("Inicio"), false, 72)
	bi.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bi)
	Audio.play_track("victoria", false)


func _perder() -> void:
	await get_tree().create_timer(0.8).timeout
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("La corona ha caído"), 680.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Aguantaste %d noches.") % (dia - 1), 28, Estilo.TEXTO))
	var g: Dictionary = Estado.d["guardada"] as Dictionary
	if not revivido and not g.is_empty() and Ads.rewarded_available():
		var ba: Button = Estilo.boton(Idioma.t("Ver un anuncio: volver al último amanecer"), true, 84)
		ba.pressed.connect(func() -> void: _revivir(ba))
		vb.add_child(ba)
	if not g.is_empty():
		var bv: Button = Estilo.boton(Idioma.t("Volver al último amanecer (-25% brasas)"), false, 76)
		bv.pressed.connect(func() -> void:
			var g2: Dictionary = (Estado.d["guardada"] as Dictionary).duplicate(true)
			g2["brasas"] = int(int(g2.get("brasas", 0)) * 0.75)
			Estado.d["guardada"] = g2
			Estado.guardar()
			Estado.partida = {}
			Kit.change_scene("res://libre/juego.tscn"))
		vb.add_child(bv)
	var bn: Button = Estilo.boton(Idioma.t("Empezar el valle de nuevo"), false, 72)
	bn.pressed.connect(func() -> void:
		Estado.d["guardada"] = {}
		Estado.guardar()
		Estado.partida = {"nuevo": true}
		Kit.change_scene("res://libre/juego.tscn"))
	vb.add_child(bn)
	var bi: Button = Estilo.boton(Idioma.t("Inicio"), false, 72)
	bi.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bi)


func _revivir(b: Button) -> void:
	b.disabled = true
	var ok: Array[bool] = [false]
	var f: Callable = func(pl: String) -> void:
		if pl == "corona":
			ok[0] = true
	Ads.reward_earned.connect(f)
	await Ads.show_rewarded("corona")
	Ads.reward_earned.disconnect(f)
	if ok[0]:
		Estado.partida = {"revivido": true}
		Kit.change_scene("res://libre/juego.tscn")
	else:
		b.disabled = false


# ------------------------------------------------------------------ dibujo

func _sx(x: float) -> float:
	return x - cam + ANCHO / 2.0


## Textura apoyada en el suelo, centrada en x, con alto dado. Si no hay textura, un bloque de color.
func _luz_ambiente() -> Color:
	var dia_c: Color = Color(1.0, 0.98, 0.94)
	var tarde_c: Color = Color(1.0, 0.8, 0.66)
	var noche_c: Color = Color(0.62, 0.68, 0.95)
	var l: String = luna_hoy if fase == "noche" or fase == "alba" else luna
	if l == "roja":
		noche_c = Color(0.95, 0.6, 0.6)
	elif l == "azul":
		noche_c = Color(0.6, 0.75, 1.05)
	elif l == "nueva":
		noche_c = Color(0.5, 0.52, 0.7)
	var f: float = t_fase / _duracion_fase()
	match fase:
		"dia":
			return dia_c.lerp(tarde_c, clampf((f - 0.8) / 0.2, 0.0, 1.0))
		"tarde":
			return tarde_c.lerp(noche_c, f)
		"noche":
			return noche_c
	return noche_c.lerp(dia_c, f)


func _sprite(id: String, x: float, alto: float, flip: bool = false, mod: Color = Color.WHITE, y_pie: float = S, inclina: float = 0.0, esc: Vector2 = Vector2.ONE) -> void:
	var sx: float = _sx(x)
	mod = Color(mod.r * _amb.r, mod.g * _amb.g, mod.b * _amb.b, mod.a)
	if _anim != "" and not bot and _sprite_hoja(id, sx, alto, flip, mod, y_pie):
		return
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		draw_rect(Rect2(sx - alto * 0.25, y_pie - alto, alto * 0.5, alto), mod.darkened(0.5))
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	if sx + ancho < -50.0 or sx - ancho > ANCHO + 50.0:
		return
	if inclina != 0.0 or esc != Vector2.ONE or flip:
		## Se escala y gira desde los pies: así se aplasta y se estira al andar sin despegarse del suelo.
		draw_set_transform(Vector2(sx, y_pie), inclina, Vector2((-1.0 if flip else 1.0) * esc.x, esc.y))
		draw_texture_rect(tx, Rect2(-ancho / 2.0, -alto, ancho, alto), false, mod)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		return
	draw_texture_rect(tx, Rect2(sx + (ancho / 2.0 if flip else -ancho / 2.0), y_pie - alto, -ancho if flip else ancho, alto), false, mod)


func _hoja(id: String, anim: String) -> Texture2D:
	var k: String = id + "|" + anim
	if not _hojas.has(k):
		var ruta: String = "res://assets/libre/anim/%s_%s.png" % [id, anim]
		_hojas[k] = load(ruta) as Texture2D if ResourceLoader.exists(ruta) else null
	return _hojas[k] as Texture2D


## Dibuja un fotograma de la hoja (el personaje ocupa el 72% de la celda y apoya los pies 8 px sobre su borde).
func _sprite_hoja(id: String, sx: float, alto: float, flip: bool, mod: Color, y_pie: float) -> bool:
	var tx: Texture2D = _hoja(id, _anim)
	if tx == null:
		return false
	var celda: float = 256.0
	var n: int = maxi(1, int(tx.get_width() / celda))
	var fps: float = 12.0 if _anim in ["walk", "run"] else 10.0
	var f: int = int(_anim_t * fps)
	f = posmod(f, n) if _anim_bucle else mini(f, n - 1)
	var esc: float = alto / (celda * 0.72) * float(Datos.AJUSTE_HOJA.get(id, 1.0))
	var lado: float = celda * esc
	if sx + lado < -50.0 or sx - lado > ANCHO + 50.0:
		return true
	draw_set_transform(Vector2(sx, y_pie + 8.0 * esc), 0.0, Vector2(-1.0 if flip else 1.0, 1.0))
	draw_texture_rect_region(tx, Rect2(-lado / 2.0, -lado, lado, lado), Rect2(f * celda, 0.0, celda, celda), mod)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	return true


func _cielo_valle(id: String) -> String:
	var v: String = str(datos_valle["id"])
	if v == "ciervo":
		return id
	var alt: String = {"lr_cielo_dia": "lr_cielo_dia_" + v, "lr_cielo_tarde": "lr_cielo_dia_" + v, "lr_cielo_noche": "lr_cielo_noche_" + v}.get(id, id)
	return alt if _tex.get(alt) != null else id


func _cielo_id() -> Array:
	## [id actual, id siguiente, mezcla]
	var f: float = t_fase / _duracion_fase()
	match fase:
		"dia":
			return ["lr_cielo_dia", "lr_cielo_tarde", clampf((f - 0.85) / 0.15, 0.0, 1.0)]
		"tarde":
			return ["lr_cielo_tarde", "lr_cielo_roja" if luna == "roja" else "lr_cielo_noche", f]
		"noche":
			return ["lr_cielo_roja" if luna_hoy == "roja" else "lr_cielo_noche", "lr_cielo_noche", 0.0]
	return ["lr_cielo_roja" if luna_hoy == "roja" else "lr_cielo_noche", "lr_cielo_dia", t_fase / Datos.T_ALBA]


func _draw() -> void:
	var tinte: Color = datos_valle["tinte"] as Color
	var c: Array = _cielo_id()
	var cielo_t: Color = tinte
	if fase == "noche" or fase == "alba":
		cielo_t = tinte * ({"nueva": Color(0.45, 0.45, 0.55), "azul": Color(0.7, 0.85, 1.25), "llena": Color(1.1, 1.1, 1.15)}.get(luna_hoy, Color.WHITE) as Color)
	for k: int in 2:
		var tx: Texture2D = _tex.get(_cielo_valle(str(c[k]))) as Texture2D
		var a: float = 1.0 if k == 0 else float(c[2])
		if a <= 0.0:
			continue
		if tx != null:
			var ts: Vector2 = tx.get_size()
			var off: float = fposmod(cam * 0.03, ts.x * 0.3)
			draw_texture_rect_region(tx, Rect2(0, 0, ANCHO, S + 20.0), Rect2(off, 0, ts.x * 0.7, ts.y * 0.92), Color(cielo_t, a))
		else:
			draw_rect(Rect2(0, 0, ANCHO, S), Color(0.3, 0.35, 0.5, a))
	_astros()
	atm.fondo(self, Color(0.45, 0.5, 0.58).lerp(Color(_amb.r * 0.5, _amb.g * 0.45, _amb.b * 0.55), 0.5), _oscuridad())
	## Bosque lejano con el color del aire (perspectiva atmosférica) y bruma encima.
	var aire: Color = Color(0.45, 0.5, 0.58).lerp(Color(_amb.r * 0.5, _amb.g * 0.45, _amb.b * 0.55), 0.5)
	var vid: String = str(datos_valle["id"])
	var noche_c: float = _oscuridad()
	var mod_lejos: Color = Color(cielo_t.r * _amb.r, cielo_t.g * _amb.g, cielo_t.b * _amb.b).lerp(aire, 0.35)
	if not _capa_pintada("lr_capa_lejos_" + vid, 0.12, 380.0, S + 10.0, mod_lejos):
		_bosque_lejano(0.22, Color(aire, 0.45), 150.0, 1)
	_bruma(S - 150.0, 0.18)
	if not _capa_pintada("lr_capa_medio_" + vid, 0.35, 300.0, S + 14.0, Color(_amb.r * 0.8, _amb.g * 0.8, _amb.b * 0.85).darkened(0.15 + 0.2 * noche_c)):
		_bosque_lejano(0.4, Color(aire.darkened(0.45), 0.75), 110.0, 2)
	atm.zona_medio(self, noche_c)
	_bruma(S - 70.0, 0.22)
	atm.rayos(self, noche_c)
	_hitos(tinte)
	for ar: Variant in _arboles:
		var a2: Dictionary = ar as Dictionary
		if int(a2["capa"]) == 0:
			_sprite(_arbol_id, float(a2["x"]) * 0.85 + cam * 0.15, 380.0 * float(a2["esc"]), false, tinte.darkened(0.45))
	atm.dibujar_decor(self, false)
	## Suelo: tierra con degradado y piedrecitas que se mueven con la cámara.
	var tierra: Color = datos_valle["suelo"] as Color
	tierra = Color(tierra.r * _amb.r, tierra.g * _amb.g, tierra.b * _amb.b)
	draw_polygon(PackedVector2Array([Vector2(0, S - 4.0), Vector2(ANCHO, S - 4.0), Vector2(ANCHO, ALTO), Vector2(0, ALTO)]),
		PackedColorArray([tierra.lightened(0.08), tierra.lightened(0.08), tierra.darkened(0.45), tierra.darkened(0.45)]))
	var px: float = -fposmod(cam, 53.0)
	while px < ANCHO + 53.0:
		var k: float = floor((px + cam) / 53.0)
		var py: float = S + 18.0 + fposmod(k * 37.0, 90.0)
		draw_circle(Vector2(px + fposmod(k * 17.0, 40.0), py), 2.0 + fposmod(k, 3.0), tierra.lightened(0.15))
		px += 53.0
	var hb: Color = datos_valle["hierba"] as Color
	var gx: float = -fposmod(cam, 18.0)
	while gx < ANCHO + 18.0:
		var hh: float = 5.0 + 6.0 * absf(sin((gx + cam) * 0.21))
		draw_colored_polygon(PackedVector2Array([Vector2(gx, S), Vector2(gx + 6, S - hh), Vector2(gx + 12, S)]), hb)
		gx += 18.0
	draw_rect(Rect2(0, S, ANCHO, 6), hb.darkened(0.2))
	for ar2: Variant in _arboles:
		var a3: Dictionary = ar2 as Dictionary
		if int(a3["capa"]) == 1:
			_sprite(_arbol_id, float(a3["x"]), 460.0 * float(a3["esc"]), false, tinte.darkened(0.2))
	atm.dibujar_decor(self, true)
	_dibujar_sitios()
	atm.dibujar_fauna(self)
	for ci: Variant in ciervos:
		var cd: Dictionary = ci as Dictionary
		_anim = "walk"
		_anim_t = float(cd["t"])
		var blanco: bool = bool(cd.get("blanco", false))
		if blanco:
			draw_circle(Vector2(_sx(float(cd["x"])), S - 50.0), 70.0 + 6.0 * sin(tiempo * 3.0), Color(1.0, 1.0, 0.9, 0.12))
		_sprite("lr_ciervo", float(cd["x"]), 104.0 if blanco else 88.0, int(cd["dir"]) < 0, Color(1.6, 1.6, 1.7) if blanco else tinte, S + 4.0 - absf(sin(float(cd["t"]) * 6.0)) * 3.0)
	_anim = ""
	for g: Variant in gente:
		_dibujar_persona(g as Dictionary)
	_dibujar_muertes()
	if mercader:
		_anim = "idle"
		_anim_t = tiempo
		_sprite("lr_mercader", 90.0, 130.0, false, Color(0.8, 0.95, 1.0, 0.75 + 0.2 * sin(tiempo * 3.0)), S - 6.0 + sin(tiempo * 2.0) * 6.0)
		_anim = ""
	_dibujar_reina()
	for cr: Variant in criaturas:
		_dibujar_criatura(cr as Dictionary)
	for f: Variant in flechas:
		var a4: Dictionary = f as Dictionary
		var p: Vector2 = Vector2(_sx(float(a4["x"])), float(a4["y"]))
		var v: Vector2 = Vector2(float(a4["vx"]), float(a4["vy"])).normalized()
		var n: Vector2 = Vector2(-v.y, v.x)
		if _proyectil_pintado(a4, p, v):
			continue
		if bool(a4.get("roca", false)):
			draw_circle(p, 13.0, Color(0.35, 0.32, 0.3))
			draw_circle(p + Vector2(-3, -3), 6.0, Color(0.5, 0.47, 0.44))
			continue
		if bool(a4.get("bola", false)):
			draw_circle(p, 16.0, Color(0.4, 1.0, 0.3, 0.25))
			draw_circle(p, 9.0, Color(0.5, 1.0, 0.4))
			draw_circle(p, 4.0, Color(0.9, 1.0, 0.8))
			if not bot and fmod(float(a4["t"]), 0.04) < 0.02:
				_particulas.append({"p": Vector2(float(a4["x"]), float(a4["y"])), "v": Vector2.ZERO, "t": 0.35, "c": Color(0.4, 1.0, 0.3, 0.6), "r": 5.0})
			continue
		if bool(a4.get("estrella", false)):
			draw_line(p - v * 40.0, p, Color(0.8, 0.9, 1.0, 0.35), 6.0)
			draw_line(p - v * 30.0, p, Color(0.9, 0.95, 1.0), 2.5)
			draw_circle(p, 4.0, Color(1, 1, 0.85))
			continue
		draw_line(p - v * 30.0, p, Color(0.55, 0.38, 0.2), 2.5)
		draw_colored_polygon(PackedVector2Array([p + v * 8.0, p + n * 3.5, p - n * 3.5]), Color(0.8, 0.82, 0.85))
		draw_colored_polygon(PackedVector2Array([p - v * 30.0, p - v * 22.0 + n * 5.0, p - v * 24.0]), Color(0.85, 0.85, 0.8))
		draw_colored_polygon(PackedVector2Array([p - v * 30.0, p - v * 22.0 - n * 5.0, p - v * 24.0]), Color(0.75, 0.75, 0.7))
	_hierba_delante()
	_dibujar_clima()
	for b: Variant in suelo_brasas:
		var bd: Dictionary = b as Dictionary
		var bp: Vector2 = Vector2(_sx(float(bd["x"])), float(bd["y"]))
		draw_circle(bp, 11.0, Color(1.0, 0.5, 0.1, 0.25 + 0.1 * sin(tiempo * 6.0 + float(bd["x"]))))
		draw_circle(bp, 5.5, Color("ffb347"))
		draw_circle(bp, 2.5, Color("fff2c4"))
	_ambiente()
	atm.noche_viva(self, _oscuridad())
	_dibujar_particulas()
	_dibujar_fx(get_process_delta_time())
	atm.primer_plano(self, _oscuridad())
	if _flash > 0.0:
		draw_rect(Rect2(0, 0, ANCHO, ALTO), Color(1.0, 0.96, 0.85, _flash * 0.6))
		_flash = maxf(0.0, _flash - get_process_delta_time() * 2.5)
	_dibujar_coste()


## Sol y luna que cruzan el cielo; estrellas que titilan de noche; pájaros de día.
func _astros() -> void:
	var f: float = t_fase / _duracion_fase()
	var noche: float = _oscuridad()
	if fase == "dia" or fase == "tarde":
		## Pájaros
		for i: int in 5:
			var bx: float = fposmod(tiempo * (38.0 + i * 6.0) + i * 260.0 - cam * 0.1, ANCHO + 200.0) - 100.0
			var by: float = 150.0 + i * 22.0 + sin(tiempo * 1.3 + i) * 12.0
			var al: float = sin(tiempo * 8.0 + i * 2.0) * 6.0
			var c: Color = Color(0.1, 0.08, 0.1, 0.6 * (1.0 - noche))
			draw_line(Vector2(bx - 9, by - al), Vector2(bx, by), c, 2.0)
			draw_line(Vector2(bx, by), Vector2(bx + 9, by - al), c, 2.0)
	if noche > 0.05:
		for i: int in 60:
			var stx: float = fposmod(i * 211.7 - cam * 0.02, ANCHO)
			var sty: float = fposmod(i * 97.3, 360.0) + 10.0
			var br: float = (0.4 + 0.6 * absf(sin(tiempo * (1.0 + fposmod(i * 0.37, 2.0)) + i))) * noche
			draw_circle(Vector2(stx, sty), 1.0 + fposmod(i, 3.0) * 0.5, Color(1, 1, 1, br * 0.8))


## Ambiente por delante: niebla nocturna, luciérnagas, y el tiempo de cada valle (lluvia, ceniza).
func _ambiente() -> void:
	var noche: float = _oscuridad()
	var id: String = str(datos_valle["id"])
	if noche > 0.1:
		for i: int in 7:
			var fx: float = fposmod(i * 300.0 - cam * 0.6 + tiempo * (12.0 + i * 3.0), ANCHO + 600.0) - 300.0
			var fy: float = S - 30.0 - (i % 3) * 22.0
			draw_circle(Vector2(fx, fy), 140.0 + (i % 2) * 60.0, Color(0.6, 0.65, 0.8, 0.05 * noche))
		for i: int in 24:
			var lx: float = fposmod(i * 173.0 - cam * 0.9 + sin(tiempo * 0.7 + i) * 40.0, ANCHO)
			var ly: float = S - 40.0 - fposmod(i * 61.0, 220.0) + sin(tiempo * 1.1 + i * 2.0) * 18.0
			var a: float = maxf(0.0, sin(tiempo * 2.3 + i * 1.7)) * noche
			draw_circle(Vector2(lx, ly), 2.2, Color(0.85, 1.0, 0.5, a))
			draw_circle(Vector2(lx, ly), 6.0, Color(0.85, 1.0, 0.5, a * 0.25))
	if id == "cienaga":
		for i: int in 70:
			var rx: float = fposmod(i * 89.0 + tiempo * 120.0 - cam * 0.5, ANCHO + 40.0) - 20.0
			var ry: float = fposmod(i * 137.0 + tiempo * 620.0, ALTO)
			draw_line(Vector2(rx, ry), Vector2(rx - 6, ry + 18), Color(0.7, 0.78, 0.85, 0.3), 1.2)
	elif id == "ceniza":
		for i: int in 45:
			var ax: float = fposmod(i * 113.0 + sin(tiempo * 0.5 + i) * 60.0 - cam * 0.7 + tiempo * 15.0, ANCHO)
			var ay: float = fposmod(i * 71.0 + tiempo * 40.0, ALTO)
			var brasa: bool = i % 6 == 0
			draw_circle(Vector2(ax, ay), 2.0 if not brasa else 2.4, Color(1.0, 0.45, 0.15, 0.8) if brasa else Color(0.55, 0.5, 0.5, 0.5))


## Pinos lejanos en silueta, con parallax.
func _bosque_lejano(par: float, col: Color, alto: float, capa: int) -> void:
	var noche: float = _oscuridad()
	col = Color(col.darkened(noche * 0.3), col.a)
	var pts: PackedVector2Array = PackedVector2Array([Vector2(0, S)])
	var off: float = cam * par
	var x: float = 0.0
	while x <= ANCHO + 12.0:
		var u: float = x + off
		var h: float = alto * (0.55 + 0.22 * sin(u * 0.006 + capa * 2.0) + 0.14 * sin(u * 0.019 + capa) + 0.07 * sin(u * 0.047))
		pts.append(Vector2(x, S - h))
		x += 12.0
	pts.append(Vector2(ANCHO, S))
	draw_colored_polygon(pts, col)


## Capa pintada que se repite (en espejo una sí y otra no, para que no se vea la costura). Devuelve false si no hay.
func _capa_pintada(id: String, par: float, alto: float, y_pie: float, mod: Color) -> bool:
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		return false
	var ts: Vector2 = tx.get_size()
	var ancho: float = round(alto * ts.x / ts.y)
	var off: float = cam * par
	var k: int = int(floor(off / ancho))
	var x0: float = round(k * ancho - off)
	while x0 < ANCHO:
		var espejo: bool = posmod(k, 2) == 1
		if espejo:
			## Un rectángulo de ancho negativo se recoloca solo: el espejo se hace con la transformación.
			draw_set_transform(Vector2(x0 + ancho, 0.0), 0.0, Vector2(-1.0, 1.0))
			draw_texture_rect(tx, Rect2(0.0, y_pie - alto, ancho + 1.0, alto), false, mod)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			draw_texture_rect(tx, Rect2(x0, y_pie - alto, ancho + 1.0, alto), false, mod)
		x0 += ancho
		k += 1
	return true


## Monumentos del valle: estatuas, torres, molinos... uno en cada tramo, en los dos lados.
func _hitos(tinte: Color) -> void:
	var lista: Array = Datos.HITOS[str(datos_valle["id"])] as Array
	for i: int in Datos.X_HITOS.size():
		for lado: int in [-1, 1]:
			var id: String = str(lista[(i + (0 if lado > 0 else 3)) % lista.size()])
			var x: float = float(Datos.X_HITOS[i]) * lado
			if _tex.get(id) == null or absf(_sx(x) - ANCHO / 2.0) > ANCHO:
				continue
			var alto: float = 330.0 + 40.0 * float(i % 3)
			_sombra_suelo(x, alto * 0.35, 0.35)
			_sprite(id, x, alto, lado < 0, tinte.darkened(0.12), S + 14.0)


## Franja de bruma que sube del suelo: funde las capas lejanas con el cielo.
func _bruma(y: float, a: float) -> void:
	var c: Color = Color(_amb.r * 0.75, _amb.g * 0.78, _amb.b * 0.85, 0.0)
	var c2: Color = Color(c, a)
	draw_polygon(PackedVector2Array([Vector2(0, y - 60.0), Vector2(ANCHO, y - 60.0), Vector2(ANCHO, S), Vector2(0, S)]), PackedColorArray([c, c, c2, c2]))


func _capa_repetida(id: String, par: float, alto: float, y: float, mod: Color) -> void:
	var tx: Texture2D = _tex.get(id) as Texture2D
	if tx == null:
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	var x0: float = -fposmod(cam * par, ancho)
	while x0 < ANCHO:
		draw_texture_rect(tx, Rect2(x0, y, ancho, alto), false, mod)
		x0 += ancho - 1.0


func _dibujar_sitios() -> void:
	var tinte: Color = datos_valle["tinte"] as Color
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		var x: float = float(d["x"])
		if absf(_sx(x) - ANCHO / 2.0) > ANCHO:
			continue
		var tipo: String = str(d["tipo"])
		var nv: int = int(d["nivel"])
		match tipo:
			"hoguera":
				_sprite("lr_hoguera", x, 150.0 + nv * 25.0, false, tinte)
				if not bot and fmod(tiempo, 0.25) < 0.02:
					_particulas.append({"p": Vector2(x + rng.randf_range(-10, 10), S - 110.0 - nv * 12.0), "v": Vector2(rng.randf_range(5, 25), rng.randf_range(-50, -30)), "t": 2.0, "c": Color(0.3, 0.28, 0.3, 0.05), "r": rng.randf_range(14, 24), "g": -5.0})
				if not bot and fmod(tiempo, 0.12) < 0.02:
					_particulas.append({"p": Vector2(x, S - 60.0 - nv * 10.0), "v": Vector2(rng.randf_range(-20, 20), rng.randf_range(-120, -60)), "t": 0.9, "c": Color(1.0, 0.6, 0.2), "r": 2.5, "mundo": true})
			"muro":
				if nv > 0:
					var vida: float = float(d["hp"]) / _vida_muro(nv)
					_muro(x, nv, vida, tinte)
					if vida < 0.99:
						var sx: float = _sx(x)
						draw_rect(Rect2(sx - 40, S - [0.0, 140.0, 185.0, 225.0][nv], 80, 7), Color(0, 0, 0, 0.6))
						draw_rect(Rect2(sx - 40, S - [0.0, 140.0, 185.0, 225.0][nv], 80 * vida, 7), Estilo.ROJO.lerp(Estilo.VERDE, vida))
				else:
					_marcador(x, d)
			"torre":
				if nv > 0:
					_sprite("lr_torre", x, 300.0, false, tinte)
				else:
					_marcador(x, d)
			"granja":
				if nv > 0:
					_granja(x, tinte)
				else:
					_marcador(x, d)
			"campamento":
				_sprite("lr_campamento", x, 80.0, int(d["lado"]) < 0, tinte, S + 4.0)
			"cofre":
				if not bool(d["abierto"]):
					if bool(d.get("antiguo", false)):
						## Cofre antiguo: más grande y con un brillo que se ve desde lejos.
						draw_circle(Vector2(_sx(x), S - 30.0), 60.0 + 6.0 * sin(tiempo * 3.0), Color(1.0, 0.85, 0.4, 0.13))
					_sprite("lr_cofre", x, 72.0 if bool(d.get("antiguo", false)) else 50.0, false, tinte, S + 4.0)
			"catapulta":
				if nv > 0:
					var tiro: float = float(d.get("tiro", 0.0))
					_sprite("lr_catapulta", x, 110.0, int(d["lado"]) < 0, tinte, S + 6.0, -sin(tiro / 0.4 * PI) * 0.08 * int(d["lado"]))
				else:
					_marcador(x, d)
			"santuario":
				_sprite("lr_santuario", x, 150.0, false, tinte, S + 6.0)
				if not bool(d["rescatado"]):
					var hid: String = str(d["heroe"])
					var hx: Dictionary = Datos.HEROES[hid] as Dictionary
					_sprite(str(hx["tex"]), x, 110.0, int(d["lado"]) > 0, Color(0.75, 0.8, 1.0, 0.7 + 0.2 * sin(tiempo * 2.0)), S + 2.0 - sin(tiempo * 1.5) * 4.0)
			"grieta":
				_portal(d, tinte)
			_:
				if tipo.begins_with("tienda_"):
					var of: String = tipo.substr(7)
					var sx2: float = _sx(x)
					if _tex.get("lr_puesto_" + of) != null:
						_sombra_suelo(x, 70.0, 0.4)
						_sprite("lr_puesto_" + of, x, 150.0, false, tinte, S + 6.0)
						if int(herramientas[of]) > 0:
							var tf: Font = Estilo.fuente()
							draw_string_outline(tf, Vector2(sx2 - 40, S - 156), "×%d" % int(herramientas[of]), HORIZONTAL_ALIGNMENT_CENTER, 80, 26, 6, Color(0, 0, 0, 0.85))
							draw_string(tf, Vector2(sx2 - 40, S - 156), "×%d" % int(herramientas[of]), HORIZONTAL_ALIGNMENT_CENTER, 80, 26, Color("ffd98a"))
						continue
					var toldo: Color = {"arquero": Color("3f6b3a"), "constructor": Color("8a5a24"), "granjero": Color("b8902e"), "lancero": Color("8c2a22")}[of] * tinte
					draw_rect(Rect2(sx2 - 40, S - 34, 80, 34), Color("4a321c") * tinte)
					draw_line(Vector2(sx2 - 38, S), Vector2(sx2 - 38, S - 96), Color("3b2716"), 5.0)
					draw_line(Vector2(sx2 + 38, S), Vector2(sx2 + 38, S - 96), Color("3b2716"), 5.0)
					draw_colored_polygon(PackedVector2Array([Vector2(sx2 - 50, S - 86), Vector2(sx2, S - 116), Vector2(sx2 + 50, S - 86)]), toldo)
					for k: int in 5:
						var fx: float = sx2 - 50.0 + k * 20.0
						draw_colored_polygon(PackedVector2Array([Vector2(fx, S - 86), Vector2(fx + 20, S - 86), Vector2(fx + 10, S - 74)]), toldo.darkened(0.15 * (k % 2)))
					for i: int in int(herramientas[of]):
						_icono_oficio(of, Vector2(sx2 - 18 + i * 14, S - 52))
					if int(herramientas[of]) == 0:
						_icono_oficio(of, Vector2(sx2, S - 52), 0.35)
		if d.has("obj") and (int(d["obj"]) > nv or bool(d.get("reparar", false))):
			## Andamio con la obra en marcha.
			var sx3: float = _sx(x)
			var tot: float = maxf(0.1, _trabajo_de(d))
			var pr: float = 1.0 - float(d["trabajo"]) / tot
			draw_rect(Rect2(sx3 - 36, S - 120, 72, 8), Color(0, 0, 0, 0.6))
			draw_rect(Rect2(sx3 - 36, S - 120, 72 * clampf(pr, 0.0, 1.0), 8), Estilo.ORO)
			draw_line(Vector2(sx3 - 30, S), Vector2(sx3 - 30, S - 110), Color(0.5, 0.35, 0.2), 4.0)
			draw_line(Vector2(sx3 + 30, S), Vector2(sx3 + 30, S - 110), Color(0.5, 0.35, 0.2), 4.0)
			draw_line(Vector2(sx3 - 30, S - 60), Vector2(sx3 + 30, S - 60), Color(0.5, 0.35, 0.2), 3.0)


## Grieta: un anillo de piedra bien plantado en el suelo con un remolino que gira, late y ruge al soltar criaturas.
func _portal(d: Dictionary, tinte: Color) -> void:
	var x: float = float(d["x"])
	var sx: float = _sx(x)
	var vivo_g: bool = not bool(d["cerrada"])
	var ruge: float = float(d.get("ruge", 0.0))
	d["ruge"] = maxf(0.0, ruge - get_process_delta_time() * 1.5)
	var nuevo: bool = _tex.get("lr_portal2") != null
	var c: Vector2 = Vector2(sx, S - (167.0 if nuevo else 125.0))
	## Escombros y sombra: que pese y no flote.
	_sombra_suelo(x, 170.0, 0.55)
	for i: int in 9:
		var rx: float = sx - 150.0 + i * 37.0
		draw_circle(Vector2(rx, S + 4.0), 10.0 + fposmod(i * 7.3, 12.0), Color(0.16, 0.13, 0.14) * tinte)
	var noche_p: bool = fase == "noche" or fase == "tarde"
	if vivo_g:
		var pulso: float = 1.0 + 0.05 * sin(tiempo * 3.0) + ruge * 0.3 + (0.08 if noche_p else 0.0)
		var r: float = (56.0 if nuevo else 70.0) * pulso
		## El hueco del anillo es ovalado: el remolino se estira en vertical.
		var ov: float = 1.55 if nuevo else 1.0
		draw_set_transform(c, 0.0, Vector2(1.0, ov))
		c = Vector2.ZERO
		draw_circle(c, r, Color(0.06, 0.0, 0.04, 0.95))
		var giro: float = tiempo * (1.6 + ruge * 4.0) * (1.0 if int(d["lado"]) > 0 else -1.0)
		## Espiral de tres brazos que gira y se traga la luz.
		for brazo: int in 3:
			var pts: PackedVector2Array = PackedVector2Array()
			for k: int in 26:
				var t: float = k / 25.0
				var ang: float = giro * 1.3 + brazo * TAU / 3.0 + t * 5.5
				pts.append(c + Vector2(cos(ang), sin(ang)) * r * (1.0 - t * 0.85))
			var col_b: Color = Color(1.0, 0.18, 0.25).lerp(Color(0.6, 0.1, 0.95), brazo / 3.0)
			col_b.a = 0.75 + 0.25 * ruge
			draw_polyline(pts, col_b, 7.0, true)
			draw_polyline(pts, Color(1.0, 0.6, 0.7, 0.35), 2.0, true)
		draw_arc(c, r * 0.97, 0.0, TAU, 40, Color(0.9, 0.1, 0.3, 0.6 + 0.3 * ruge), 4.0)
		draw_circle(c, 26.0 * pulso, Color(1.0, 0.3, 0.25, 0.55 + 0.3 * ruge))
		draw_circle(c, 10.0 * pulso, Color(1.0, 0.85, 0.8, 0.8))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		c = Vector2(sx, S - (167.0 if nuevo else 125.0))
		## Chispas que el remolino se traga.
		if not bot and rng.randf() < 0.35 and absf(sx - ANCHO / 2.0) < ANCHO:
			var a: float = rng.randf_range(0.0, TAU)
			var p0: Vector2 = c + Vector2(cos(a), sin(a)) * (r + 70.0)
			_particulas.append({"p": Vector2(x + p0.x - sx, p0.y), "v": (c - p0) * 1.6, "t": 0.6, "c": Color(0.9, 0.2, 0.6, 0.8), "r": 2.5})
	var m: Color = tinte if vivo_g else Color(0.45, 0.45, 0.5)
	if nuevo:
		_sprite("lr_portal2", x, 330.0, int(d["lado"]) > 0, m.lerp(Color(1.4, 0.6, 0.6), ruge * 0.5), S + 14.0)
	else:
		_sprite("lr_portal", x, 270.0, int(d["lado"]) > 0, m, S + 12.0)
		if vivo_g:
			draw_circle(c, 60.0, Color(0.6, 0.0, 0.2, 0.25 + 0.2 * ruge))


## Muros dibujados de lado: empalizada de troncos, muro de piedra y muralla con almenas y pinchos.
func _muro(x: float, nv: int, vida: float, tinte: Color) -> void:
	var sx: float = _sx(x)
	var dano: Color = Color(1, 1, 1).lerp(Color(1.0, 0.55, 0.5), (1.0 - vida) * 0.6)
	match nv:
		1:
			for i: int in 5:
				var lx: float = sx - 30.0 + i * 15.0
				var alto: float = 105.0 + (i % 2) * 14.0
				var c: Color = Color("5a3d24").lerp(Color("6e4c2e"), (i % 2) * 0.6) * tinte * dano
				draw_rect(Rect2(lx - 7, S - alto, 14, alto), c)
				draw_colored_polygon(PackedVector2Array([Vector2(lx - 7, S - alto), Vector2(lx, S - alto - 16), Vector2(lx + 7, S - alto)]), c)
				draw_line(Vector2(lx - 5, S - alto + 6), Vector2(lx - 5, S - 4), Color(0, 0, 0, 0.25), 2.0)
			draw_rect(Rect2(sx - 38, S - 70, 76, 8), Color("3b2716") * tinte)
			draw_rect(Rect2(sx - 38, S - 35, 76, 8), Color("3b2716") * tinte)
		2, 3:
			var alto2: float = 150.0 if nv == 2 else 200.0
			var ancho: float = 70.0 if nv == 2 else 84.0
			var piedra: Color = (Color("57503f") if nv == 2 else Color("4a4540")) * tinte * dano
			draw_rect(Rect2(sx - ancho / 2.0, S - alto2, ancho, alto2), piedra)
			var fila: int = 0
			var y: float = S - 22.0
			while y > S - alto2:
				var off: float = 0.0 if fila % 2 == 0 else 12.0
				var bx: float = sx - ancho / 2.0 - off
				while bx < sx + ancho / 2.0:
					var x0: float = maxf(bx, sx - ancho / 2.0)
					var x1: float = minf(bx + 24.0, sx + ancho / 2.0)
					draw_rect(Rect2(x0 + 1, y + 1, x1 - x0 - 2, 20), piedra.lightened(0.06 * ((fila + int(bx)) % 3)))
					bx += 24.0
				y -= 22.0
				fila += 1
			## almenas
			var k: int = 0
			var ax: float = sx - ancho / 2.0
			while ax < sx + ancho / 2.0 - 4.0:
				if k % 2 == 0:
					draw_rect(Rect2(ax, S - alto2 - 18, 14, 18), piedra)
				ax += 14.0
				k += 1
			## Antorcha en lo alto del muro.
			var llama: float = sin(tiempo * 17.0 + x) * 2.0
			draw_line(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 30.0), Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 6.0), Color("3b2716"), 3.0)
			draw_circle(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 2.0 + llama), 7.0, Color(1.0, 0.55, 0.15, 0.9))
			draw_circle(Vector2(sx + ancho / 2.0 - 6.0, S - alto2 + 3.0 + llama), 3.5, Color(1.0, 0.9, 0.5))
			if nv == 3:
				for i: int in 4:
					var px: float = sx - ancho / 2.0 + 10.0 + i * 21.0
					draw_colored_polygon(PackedVector2Array([Vector2(px - 4, S - alto2 - 18), Vector2(px, S - alto2 - 40), Vector2(px + 4, S - alto2 - 18)]), Color("2d2b30"))
				draw_line(Vector2(sx, S - alto2 - 18), Vector2(sx, S - alto2 - 80), Color("3b2716"), 3.0)
				draw_colored_polygon(PackedVector2Array([Vector2(sx, S - alto2 - 80), Vector2(sx + 34, S - alto2 - 70), Vector2(sx, S - alto2 - 58)]), Color("a2231c") * tinte)
			draw_line(Vector2(sx - ancho / 2.0, S - alto2), Vector2(sx - ancho / 2.0, S), Color(0, 0, 0, 0.35), 3.0)
			draw_line(Vector2(sx + ancho / 2.0, S - alto2), Vector2(sx + ancho / 2.0, S), Color(1, 0.9, 0.7, 0.18), 2.0)


func _granja(x: float, tinte: Color) -> void:
	var sx: float = _sx(x)
	draw_rect(Rect2(sx - 90, S - 6, 180, 10), Color("3a2a16") * tinte)
	for i: int in 22:
		var bx: float = sx - 84.0 + i * 8.0
		var mece: float = sin(tiempo * 1.8 + i * 0.5) * 4.0
		var alto: float = 46.0 + (i * 37 % 11)
		draw_line(Vector2(bx, S), Vector2(bx + mece, S - alto), Color("b8902e") * tinte, 2.0)
		draw_circle(Vector2(bx + mece, S - alto), 4.0, Color("e3b94a") * tinte)
	for i: int in 2:
		var fx: float = sx - 96.0 + i * 192.0
		draw_line(Vector2(fx, S), Vector2(fx, S - 34), Color("4a321c") * tinte, 4.0)
	draw_line(Vector2(sx - 96, S - 24), Vector2(sx + 96, S - 24), Color("4a321c") * tinte, 3.0)


## Matas de hierba por delante: tapan los pies y la base de edificios para que pisen el suelo.
## v7 «juice»: proyectiles pintados (lr_p_*) girados según su vuelo, con estela y brillo.
func _proyectil_pintado(a4: Dictionary, p: Vector2, v: Vector2) -> bool:
	var id: String = "lr_p_flecha"
	var largo: float = 54.0
	var col: Color = Color(1, 1, 1, 0)
	if bool(a4.get("roca", false)):
		id = "lr_p_roca"
		largo = 40.0
		col = Color(1.0, 0.5, 0.15, 0.5)
	elif bool(a4.get("bola", false)):
		id = "lr_p_bola"
		largo = 70.0
		col = (a4.get("col", Color(0.4, 1.0, 0.3)) as Color)
	elif bool(a4.get("estrella", false)):
		id = "lr_p_estrella"
		largo = 74.0
		col = Color(0.75, 0.85, 1.0, 0.8)
	var tx: Texture2D = _tex_fx(id)
	if tx == null:
		return false
	## Estela: las últimas posiciones, cada vez más finas y transparentes.
	var h: Array = a4.get("h", []) as Array
	h.append(Vector2(float(a4["x"]), float(a4["y"])))
	if h.size() > 9:
		h.pop_front()
	a4["h"] = h
	var ce: Color = col if col.a > 0.0 else Color(0.9, 0.85, 0.7, 0.35)
	for i: int in range(1, h.size()):
		var q0: Vector2 = h[i - 1] as Vector2
		var q1: Vector2 = h[i] as Vector2
		var k: float = float(i) / float(h.size())
		draw_line(Vector2(_sx(q0.x), q0.y), Vector2(_sx(q1.x), q1.y), Color(ce, ce.a * k * 0.8), 1.0 + k * (6.0 if col.a > 0.0 else 2.5), true)
	if col.a > 0.0:
		draw_circle(p, largo * 0.32, Color(col, 0.18))
		draw_circle(p, largo * 0.18, Color(col, 0.3))
	var ts: Vector2 = tx.get_size()
	var alto: float = largo * ts.y / ts.x
	var giro: float = v.angle() + (float(a4["t"]) * 9.0 if id == "lr_p_roca" else 0.0)
	draw_set_transform(p, giro, Vector2.ONE)
	draw_texture_rect(tx, Rect2(-largo * 0.75, -alto / 2.0, largo, alto), false)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	return true


func _dibujar_clima() -> void:
	if fase != "noche" and fase != "alba":
		return
	match clima:
		"tormenta":
			for i: int in 70:
				var rx: float = fposmod(i * 97.0 + tiempo * 900.0 * (0.8 + 0.2 * (i % 3)), ANCHO + 200.0) - 100.0
				var ry: float = fposmod(i * 53.0 + tiempo * 1300.0, ALTO)
				draw_line(Vector2(rx, ry), Vector2(rx - 10.0, ry + 26.0), Color(0.75, 0.82, 0.95, 0.28), 1.5)
			if _rayo > 0.0:
				var bx: float = _sx(_rayo_x)
				var pts: PackedVector2Array = PackedVector2Array([Vector2(bx + 40.0, 0.0)])
				var yy: float = 0.0
				while yy < S - 20.0:
					yy += rng.randf_range(40.0, 80.0)
					pts.append(Vector2(bx + rng.randf_range(-35.0, 35.0), minf(yy, S - 20.0)))
				draw_polyline(pts, Color(0.85, 0.92, 1.0, _rayo * 2.5), 5.0)
				draw_polyline(pts, Color(1, 1, 1, _rayo * 2.8), 2.0)
		"niebla":
			for k: int in 4:
				var yb: float = S - 40.0 - k * 70.0
				draw_rect(Rect2(0, yb - 60.0, ANCHO, 120.0), Color(0.7, 0.74, 0.8, 0.09 + 0.03 * sin(tiempo * 0.7 + k)))
		"eclipse":
			draw_rect(Rect2(0, 0, ANCHO, ALTO), Color(0.25, 0.0, 0.02, 0.16 + 0.04 * sin(tiempo * 1.5)))


func _hierba_delante() -> void:
	var hb: Color = (datos_valle["hierba"] as Color).darkened(0.25)
	hb = Color(hb.r * _amb.r, hb.g * _amb.g, hb.b * _amb.b)
	var gx: float = -fposmod(cam, 11.0)
	while gx < ANCHO + 11.0:
		var k: float = floor((gx + cam) / 11.0)
		var alto: float = 7.0 + fposmod(k * 7.31, 9.0)
		var mece: float = sin(tiempo * 1.6 + k * 0.7) * 2.0
		draw_colored_polygon(PackedVector2Array([Vector2(gx - 3, S + 6), Vector2(gx + mece, S + 6 - alto - 4.0), Vector2(gx + 4, S + 6)]), hb)
		if fposmod(k, 3.0) < 1.0:
			draw_colored_polygon(PackedVector2Array([Vector2(gx + 2, S + 6), Vector2(gx + 6 + mece, S + 6 - alto * 0.7), Vector2(gx + 8, S + 6)]), hb.darkened(0.15))
		gx += 11.0
	draw_rect(Rect2(0, S + 5.0, ANCHO, 4.0), hb.darkened(0.2))


## Sombra aplastada en el suelo (elipse).
func _sombra_suelo(x: float, r: float, a: float) -> void:
	draw_set_transform(Vector2(_sx(x), S + 2.0), 0.0, Vector2(1.0, 0.22))
	draw_circle(Vector2.ZERO, r, Color(0, 0, 0, a))
	draw_circle(Vector2.ZERO, r * 0.6, Color(0, 0, 0, a * 0.6))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _icono_oficio(of: String, p: Vector2, a: float = 1.0) -> void:
	var c: Color = Color(0.9, 0.85, 0.7, a)
	match of:
		"arquero":
			draw_arc(p, 14.0, -PI / 2.0 - 1.0, -PI / 2.0 + 1.0, 10, c, 3.0)
		"constructor":
			draw_line(p + Vector2(-6, 12), p + Vector2(6, -8), c, 3.0)
			draw_rect(Rect2(p + Vector2(0, -14), Vector2(14, 8)), c)
		"granjero":
			draw_line(p + Vector2(-4, 14), p + Vector2(4, -12), c, 3.0)
			draw_arc(p + Vector2(-4, -12), 10.0, -PI, -PI / 4.0, 8, c, 3.0)
		"lancero":
			draw_line(p + Vector2(0, 16), p + Vector2(0, -16), c, 3.0)
			draw_colored_polygon(PackedVector2Array([p + Vector2(-5, -14), p + Vector2(0, -24), p + Vector2(5, -14)]), c)


## Marcador de un sitio vacío: estaca con banderín.
func _marcador(x: float, d: Dictionary) -> void:
	var sx: float = _sx(x)
	var o: Dictionary = opcion(d)
	var col: Color = Color(0.9, 0.75, 0.4, 0.8) if not o.is_empty() and int(o["coste"]) >= 0 else Color(0.5, 0.5, 0.5, 0.5)
	draw_line(Vector2(sx, S), Vector2(sx, S - 54), Color(0.35, 0.25, 0.15), 4.0)
	draw_colored_polygon(PackedVector2Array([Vector2(sx, S - 54), Vector2(sx + 26, S - 46), Vector2(sx, S - 38)]), col)


func _dibujar_persona(p: Dictionary) -> void:
	var of: String = str(p["oficio"])
	var tid: String = "lr_" + of if of != "aldeano" else "lr_aldeano"
	if of == "heroe":
		tid = str((Datos.HEROES[str(p.get("heroe", "caballero"))] as Dictionary)["tex"])
	var anda: bool = bool(p.get("anda", false))
	var trabaja: bool = bool(p.get("trabaja", false))
	p["anda"] = false
	p["trabaja"] = false
	var t: float = float(p["t"])
	var paso_f: float = sin(t * 10.0)
	## Andar: rebote, aplastar y estirar a cada paso, y un poco de inclinación hacia delante.
	var bote: float = absf(paso_f) * 5.0 if anda else 0.0
	var esc: Vector2 = Vector2(1.0 + 0.05 * absf(paso_f), 1.0 - 0.05 * absf(paso_f)) if anda else Vector2(1.0, 1.0 + 0.012 * sin(t * 2.2))
	var incl: float = (0.06 + paso_f * 0.03) * int(p["dir"]) if anda else 0.0
	var dx: float = 0.0
	if trabaja and of == "constructor":
		## Martillazos: se inclina adelante y atrás.
		incl = sin(t * 16.0) * 0.16 * int(p["dir"])
		esc = Vector2(1.0, 1.0 - 0.04 * absf(sin(t * 16.0)))
	var ataca: float = float(p.get("ataca", 0.0))
	if ataca > 0.0:
		p["ataca"] = maxf(0.0, ataca - get_process_delta_time())
		if of == "lancero":
			dx = sin(ataca / 0.25 * PI) * 18.0 * int(p["dir"])
			incl = 0.12 * int(p["dir"])
		else:
			## Arquero: tensa el arco (se encoge) y suelta.
			esc = Vector2(1.0 - 0.08 * sin(ataca / 0.25 * PI), 1.0 + 0.04 * sin(ataca / 0.25 * PI))
	var y: float = S + 4.0 - bote - (155.0 if bool(p.get("torre", false)) else 0.0)
	var mod: Color = datos_valle["tinte"] as Color
	if of == "vagabundo":
		mod = mod.darkened(0.25)
	var alto_p: float = 96.0
	if of == "heroe":
		alto_p = 118.0
		if float(p.get("aturdido", 0.0)) > 0.0:
			mod = Color(0.55, 0.55, 0.6)
		else:
			## Halo del héroe.
			var hc: Color = {"caballero": Color(1.0, 0.85, 0.4), "bruja": Color(0.45, 1.0, 0.35), "cazadora": Color(0.7, 0.85, 1.0), "monje": Color(1.0, 0.65, 0.25),
				"ingeniera": Color(1.0, 0.55, 0.2), "druida": Color(0.5, 0.9, 0.4)}.get(str(p.get("heroe", "")), Color.WHITE)
			draw_circle(Vector2(_sx(float(p["x"])), S - 60.0), 54.0 + 4.0 * sin(t * 3.0), Color(hc, 0.06))
	## Sombra en el suelo.
	if not bool(p.get("torre", false)):
		_sombra_suelo(float(p["x"]) + dx, 22.0, 0.3)
	_anim = "attack" if (ataca > 0.0 or trabaja) else ("walk" if anda else "idle")
	_anim_t = t * (1.6 if ataca > 0.0 else 1.0)
	_anim_bucle = true
	## Lanzando una habilidad: su animación de conjuro (una vez).
	var cast: float = float(p.get("cast", 0.0))
	if cast > 0.0 and _hoja(tid, "cast") != null:
		_anim = "cast"
		_anim_t = 1.0 - cast
		_anim_bucle = false
	if _hoja(tid, _anim) == null and _anim == "idle" and of != "heroe":
		_anim = ""
	_sprite(tid, float(p["x"]) + dx, alto_p, int(p["dir"]) < 0, mod, y, incl, esc)
	_anim = ""
	if anda and fmod(t, 0.33) < 0.02 and not bot and absf(_sx(float(p["x"])) - ANCHO / 2.0) < ANCHO / 2.0:
		_particulas.append({"p": Vector2(float(p["x"]), S - 2.0), "v": Vector2(-int(p["dir"]) * 30.0, -20.0), "t": 0.4, "c": Color(0.6, 0.5, 0.4, 0.5), "r": 3.0, "g": 40.0})


func _dibujar_reina() -> void:
	var x: float = float(reina["x"])
	var m: float = float(reina["mov"])
	var andando: bool = _mover_ui != 0
	var bote: float = absf(sin(m * 7.0)) * (8.0 if float(reina["corre"]) > 0.5 else 4.0) if andando else sin(tiempo * 2.0) * 1.5
	## Con montura cambia la reina entera (va montada en otro animal) y es algo más grande.
	var id_reina: String = "lr_reina"
	var alto_reina: float = 165.0
	if montura != "" and _tex.get("lr_reina_" + montura) != null:
		id_reina = "lr_reina_" + montura
		alto_reina = 185.0 if montura != "grifo" else 200.0
	_sombra_suelo(x, 60.0 if id_reina == "lr_reina" else 85.0, 0.35)
	var esc_r: Vector2 = Vector2(1.0 + 0.03 * absf(sin(m * 7.0)), 1.0 - 0.03 * absf(sin(m * 7.0))) if andando else Vector2(1.0, 1.0 + 0.01 * sin(tiempo * 2.0))
	_anim = "run" if andando else "idle"
	_anim_t = m if andando else tiempo
	_sprite(id_reina, x, alto_reina, int(reina["dir"]) < 0, Color(1, 1, 1, 0.55 + 0.45 * absf(sin(tiempo * 20.0))) if float(reina["inmune"]) > 0.0 else Color.WHITE,
		S + 6.0 - bote, sin(m * 7.0) * 0.03 if andando else 0.0, esc_r)
	_anim = ""
	if andando and float(reina["corre"]) > 0.4 and fmod(m, 0.12) < 0.03 and not bot:
		for i: int in 2:
			_particulas.append({"p": Vector2(x - int(reina["dir"]) * 40.0, S - 4.0), "v": Vector2(-int(reina["dir"]) * rng.randf_range(40, 120), rng.randf_range(-70, -20)),
				"t": 0.6, "c": Color(0.55, 0.47, 0.38, 0.55), "r": rng.randf_range(4, 8), "g": 60.0})
	## Farol
	var fx: float = _sx(x) + int(reina["dir"]) * 30.0
	draw_circle(Vector2(fx, S - 118.0 * alto_reina / 165.0 - bote), 7.0, Color(1.0, 0.85, 0.5, 0.9))
	## Bolsa de brasas (puntitos sobre la cabeza cuando estás cerca de algo).
	if not _sitio_cerca.is_empty():
		var o: Dictionary = opcion(_sitio_cerca) if str(_sitio_cerca["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
		var coste: int = int(o.get("coste", -1))
		if coste > 0:
			var ancho_t: float = coste * 16.0
			for i: int in coste:
				var cx: float = _sx(x) - ancho_t / 2.0 + i * 16.0 + 8.0
				var lleno: bool = i < brasas
				draw_circle(Vector2(cx, S - 210.0), 6.5, Color("ffb347") if lleno else Color(0.3, 0.3, 0.35, 0.7))


func _dibujar_criatura(c: Dictionary) -> void:
	var info: Dictionary = Datos.CRIATURAS[str(c["tipo"])] as Dictionary
	var alto: float = float(info["alto"])
	var y: float = _y_criatura(c) + 4.0
	var t: float = float(c["t"])
	var bote: float = absf(sin(t * 8.0)) * 5.0
	var mod: Color = Color(1, 1, 1) if float(c["golpe"]) <= 0.0 else Color(2.0, 1.4, 1.4)
	if fase == "noche" and luna_hoy == "nueva":
		var dd: float = absf(float(c["x"]) - float(reina["x"]))
		mod.a = clampf(1.0 - (dd - 250.0) / 300.0, 0.15, 1.0)
	var esc: Vector2 = Vector2(1.0 + 0.07 * absf(sin(t * 8.0)), 1.0 - 0.07 * absf(sin(t * 8.0)))
	var sale: float = clampf(float(c.get("sale", 0.0)), 0.0, 1.0)
	if sale > 0.0:
		## Sale del remolino: crece desde el centro, oscuro y con humo violeta.
		esc = Vector2.ONE * (1.0 - sale * 0.85)
		mod = Color(mod.r * (1.0 - sale * 0.7), mod.g * (1.0 - sale * 0.9), mod.b * (1.0 - sale * 0.5), mod.a * (1.0 - sale * 0.6))
		y -= sale * 110.0
	if bool(c["vuela"]):
		esc = Vector2(1.0, 1.0 + 0.12 * sin(t * 14.0))
	if float(c["golpe"]) > 0.0:
		## Se encoge con el golpe (aplastar y estirar).
		esc *= Vector2(1.16, 0.86)
	if float(c.get("bajo_tierra", 0.0)) > 0.0:
		## Bajo la arena: solo un montículo que avanza.
		draw_circle(Vector2(_sx(float(c["x"])), S + 6.0), 40.0 + 6.0 * sin(t * 12.0), Color(0.55, 0.42, 0.25, 0.9))
		return
	var tex_id: String = str(info["tex"])
	if str(c["tipo"]) == "jefe" and _tex.get("lr_jefe_" + _jefe_id) != null:
		tex_id = "lr_jefe_" + _jefe_id
		alto *= 1.15
	if str(c["tipo"]) == "jefe":
		if bool(c.get("fase2", false)):
			mod = Color(mod.r * 1.3, mod.g * 0.8, mod.b * 0.8, mod.a)
		if float(c.get("carga", 0.0)) > 0.0:
			esc = Vector2(1.12, 0.92)
		## Aura roja que late.
		draw_circle(Vector2(_sx(float(c["x"])), y - alto * 0.5), alto * (0.55 + 0.05 * sin(t * 4.0)), Color(0.9, 0.05, 0.05, 0.12))
	elif not bool(c["vuela"]):
		_sombra_suelo(float(c["x"]), alto * 0.32, 0.35)
	if bool(c.get("elite", false)):
		alto *= 1.22
		mod = Color(mod.r * 1.15, mod.g * 0.75, mod.b * 1.2, mod.a)
		draw_circle(Vector2(_sx(float(c["x"])), y - alto * 0.45), alto * (0.5 + 0.04 * sin(t * 5.0)), Color(0.75, 0.1, 0.9, 0.13))
	_anim = "attack" if float(c["cd"]) > 0.6 and not bool(c["huye"]) else "walk"
	_anim_t = t if _anim == "walk" else (1.2 - float(c["cd"]))
	_anim_bucle = _anim == "walk"
	_sprite(tex_id, float(c["x"]), alto, int(c["lado"]) < 0 if not bool(c["huye"]) else int(c["lado"]) > 0, mod, y - bote, sin(t * 8.0) * 0.06, esc)
	_anim = ""
	_anim_bucle = true
	if not bot and fmod(t, 0.09) < 0.02:
		## Estela de humo negro.
		_particulas.append({"p": Vector2(float(c["x"]) + int(c["lado"]) * alto * 0.25, y - bote - alto * rng.randf_range(0.3, 0.8)), "v": Vector2(int(c["lado"]) * 30.0, rng.randf_range(-40, -10)),
			"t": 0.7, "c": Color(0.05, 0.02, 0.05, 0.55), "r": alto * 0.07 + 2.0, "g": -20.0})
	## Ojos que brillan (se ven en la oscuridad).
	var sx: float = _sx(float(c["x"]))
	var ojo: Color = Color(1.0, 0.15, 0.1, 0.9 * mod.a)
	if tex_id == str(info["tex"]):
		draw_circle(Vector2(sx - 6.0 * int(c["lado"]), y - bote - alto * 0.72), 3.0 + alto * 0.012, ojo)
	if float(c["hp"]) < float(c["hpmax"]) and str(c["tipo"]) == "jefe":
		draw_rect(Rect2(sx - 70, y - alto - 24, 140, 8), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(sx - 70, y - alto - 24, 140 * float(c["hp"]) / float(c["hpmax"]), 8), Color("ff3b3b"))
	if str(c["tipo"]) == "jefe" and not bot:
		var nom: String = Idioma.t(str((Datos.JEFES[_jefe_id] as Dictionary)["nombre"]))
		draw_string(ThemeDB.fallback_font, Vector2(sx - 140, y - alto - 34), nom, HORIZONTAL_ALIGNMENT_CENTER, 280, 20, Color(1.0, 0.75, 0.7))


## Criaturas que mueren: su animación de muerte (si la tienen) antes de desaparecer.
func _dibujar_muertes() -> void:
	var dt: float = get_process_delta_time()
	for m: Variant in _muertes:
		var d: Dictionary = m as Dictionary
		d["t"] = float(d["t"]) + dt
		var info: Dictionary = Datos.CRIATURAS[str(d["tipo"])] as Dictionary
		var tid: String = str(info["tex"])
		var jefe: bool = str(d["tipo"]) == "jefe"
		if jefe:
			tid = "lr_jefe_" + _jefe_id
		if _hoja(tid, "death") == null:
			d["t"] = 99.0
			continue
		## Los jefes caen más despacio (su muerte se ve entera).
		var dur: float = 2.6 if jefe else 1.6
		_anim = "death"
		_anim_t = float(d["t"]) * (0.65 if jefe else 1.0)
		_anim_bucle = false
		var a: float = clampf(dur - float(d["t"]), 0.0, 1.0)
		_sprite(tid, float(d["x"]), float(info["alto"]) * (1.15 if jefe else 1.0), int(d["lado"]) < 0, Color(1, 1, 1, a), float(d["y"]))
	_anim = ""
	_anim_bucle = true
	_muertes = _muertes.filter(func(m: Variant) -> bool: return float((m as Dictionary)["t"]) < (2.6 if str((m as Dictionary)["tipo"]) == "jefe" else 1.6))


func _dibujar_coste() -> void:
	pass


# ------------------------------------------------------------------ luz y noche

## Agua a los pies del reino: refleja el mundo (cielo, muros, gente y monstruos) con ondas y brillos.
func _montar_agua() -> void:
	var vid: String = str(datos_valle["id"])
	if vid == "desierto":
		return
	_agua = ColorRect.new()
	_agua.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_agua.z_index = 5
	_agua.position = Vector2(0, Y_AGUA)
	_agua.size = Vector2(ANCHO, ALTO - Y_AGUA + 20.0)
	var sh: Shader = Shader.new()
	sh.code = SHADER_AGUA
	var mt: ShaderMaterial = ShaderMaterial.new()
	mt.shader = sh
	mt.set_shader_parameter("tinte", Datos.AGUA.get(vid, Color(0.55, 0.72, 0.85)))
	mt.set_shader_parameter("calma", 0.35 if vid == "nieve" else 1.0)
	_agua.material = mt
	add_child(_agua)


func _montar_luz() -> void:
	var capa: CanvasLayer = CanvasLayer.new()
	capa.layer = 1
	add_child(capa)
	_luz = ColorRect.new()
	_luz.size = Vector2(ANCHO, ALTO)
	_luz.set_anchors_preset(Control.PRESET_FULL_RECT)
	_luz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh: Shader = Shader.new()
	sh.code = SHADER_LUZ
	_mat_luz = ShaderMaterial.new()
	_mat_luz.shader = sh
	_luz.material = _mat_luz
	capa.add_child(_luz)


func _oscuridad() -> float:
	var l: Dictionary = Datos.LUNAS[luna_hoy if fase == "noche" or fase == "alba" else luna] as Dictionary
	var maxo: float = float(l["oscuridad"])
	var f: float = t_fase / _duracion_fase()
	match fase:
		"tarde":
			return maxo * f
		"noche":
			return maxo
		"alba":
			return maxo * (1.0 - f)
	return 0.0


func _actualizar_luz() -> void:
	var osc: float = _oscuridad()
	var es_roja: bool = (fase == "noche" or fase == "alba") and luna_hoy == "roja"
	## El bosque profundo y el antiguo están en penumbra también de día.
	osc = maxf(osc, Atmosfera.sombra_lugar(cam) * (1.0 if fase == "dia" else 1.15))
	var col: Color = Color(0.25, 0.02, 0.04, osc) if es_roja else Color(0.02, 0.03, 0.12, osc)
	_mat_luz.set_shader_parameter("noche", col)
	var luces: Array = []
	var vs: Vector2 = get_viewport_rect().size
	var k: float = float(get_window().size.x) / vs.x if get_window() != null and vs.x > 0.0 else 1.0
	var mk: Callable = func(x: float, y: float, r: float, i: float) -> void:
		var sx: float = _sx(x)
		if sx > -r and sx < ANCHO + r and luces.size() < 24:
			## FRAGCOORD va de abajo arriba en algunos backends: se calcula en píxeles de ventana.
			luces.append(Vector4(sx * k, (ALTO - y) * k if false else y * k, r * k, i))
	mk.call(float(reina["x"]) + int(reina["dir"]) * 30.0, S - 118.0, 300.0, 1.0)
	var nh: int = nivel_hoguera()
	mk.call(0.0, S - 70.0, 360.0 + nh * 70.0 + sin(tiempo * 9.0) * 12.0, 1.0)
	for s: Variant in sitios:
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == "torre" and int(d["nivel"]) > 0:
			mk.call(float(d["x"]), S - 270.0, 220.0, 0.85)
		elif str(d["tipo"]) == "muro" and int(d["nivel"]) >= 2:
			mk.call(float(d["x"]), S - 150.0, 160.0, 0.7)
		elif str(d["tipo"]) == "grieta" and not bool(d["cerrada"]):
			mk.call(float(d["x"]), S - 120.0, 260.0, 0.6)
	if mercader:
		mk.call(90.0, S - 80.0, 170.0, 0.8)
	for dd: Variant in atm.decor:
		var de: Dictionary = dd as Dictionary
		if Atmosfera.LUZ_DECOR.has(str(de["id"])) and absf(float(de["x"]) - cam) < ANCHO and _tex.get(str(de["id"])) != null:
			mk.call(float(de["x"]), S - float(de["alto"]) * 0.55, float(de["alto"]) * 1.4, 0.75)
	_mat_luz.set_shader_parameter("luces", luces)
	_mat_luz.set_shader_parameter("n_luces", luces.size())


# ------------------------------------------------------------------ partículas y textos

func _chispas(p: Vector2, c: Color, n: int) -> void:
	if bot:
		return
	for i: int in n:
		var a: float = rng.randf_range(-PI, 0.0)
		_particulas.append({"p": p, "v": Vector2(cos(a), sin(a)) * rng.randf_range(80, 220), "t": 0.5, "c": c, "r": 3.0, "g": 500.0, "mundo": true})


func _actualizar_particulas(dt: float) -> void:
	for q: Variant in _particulas:
		var d: Dictionary = q as Dictionary
		d["v"] = (d["v"] as Vector2) + Vector2(0, float(d.get("g", 0.0)) * dt)
		d["p"] = (d["p"] as Vector2) + (d["v"] as Vector2) * dt
		d["t"] = float(d["t"]) - dt
	_particulas = _particulas.filter(func(q: Variant) -> bool: return float((q as Dictionary)["t"]) > 0.0)
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		d2["t"] = float(d2["t"]) - dt
		d2["y"] = float(d2["y"]) - 30.0 * dt
	_textos = _textos.filter(func(q: Variant) -> bool: return float((q as Dictionary)["t"]) > 0.0)


func _dibujar_particulas() -> void:
	for q: Variant in _particulas:
		var d: Dictionary = q as Dictionary
		var c: Color = d["c"] as Color
		c.a = (d["c"] as Color).a * clampf(float(d["t"]) * 2.0, 0.0, 1.0)
		var p: Vector2 = d["p"] as Vector2
		draw_circle(Vector2(_sx(p.x), p.y), float(d["r"]), c)
	var f: Font = Estilo.fuente()
	for t: Variant in _textos:
		var d2: Dictionary = t as Dictionary
		var c2: Color = d2["c"] as Color
		c2.a = clampf(float(d2["t"]) * 2.0, 0.0, 1.0)
		var pos: Vector2 = Vector2(_sx(float(d2["x"])) - 200.0, float(d2["y"]))
		## Salto al aparecer: empieza grande y se asienta.
		var base_t: int = 34 if d2.has("pop") else 24
		var tam: int = int(base_t * (1.0 + 0.7 * clampf((float(d2["t"]) - 0.62) / 0.18, 0.0, 1.0)))
		draw_string_outline(f, pos, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 400, tam, 6, Color(0, 0, 0, c2.a * 0.8))
		draw_string(f, pos, str(d2["s"]), HORIZONTAL_ALIGNMENT_CENTER, 400, tam, c2)


func _texto(s: String, p: Vector2, c: Color) -> void:
	if bot:
		return
	_textos.append({"s": s, "x": p.x, "y": p.y, "c": c, "t": 1.4})


# ------------------------------------------------------------------ HUD

func _hacer_hud() -> void:
	_hud = CanvasLayer.new()
	_hud.layer = 2
	add_child(_hud)
	_raiz = Control.new()
	_raiz.set_anchors_preset(Control.PRESET_FULL_RECT)
	_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(_raiz)
	_l_brasas = Estilo.etiqueta("", 34, Color("ffcf7a"), HORIZONTAL_ALIGNMENT_LEFT)
	_l_brasas.position = Vector2(28, 16)
	_l_brasas.size = Vector2(400, 48)
	_raiz.add_child(_l_brasas)
	_l_dia = Estilo.etiqueta("", 26, Estilo.TEXTO)
	_l_dia.position = Vector2(390, 10)
	_anclas.append([_l_dia, 390, "c"])
	_l_dia.size = Vector2(500, 40)
	_raiz.add_child(_l_dia)
	_barra_dia = Estilo.barra(Color("ffcf7a"), 10.0)
	_barra_dia.position = Vector2(440, 52)
	_anclas.append([_barra_dia, 440, "c"])
	_barra_dia.size = Vector2(400, 10)
	_barra_dia.max_value = 1.0
	_raiz.add_child(_barra_dia)
	_mini = Control.new()
	_mini.position = Vector2(340, 70)
	_anclas.append([_mini, 340, "c"])
	_mini.size = Vector2(600, 30)
	_mini.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mini.draw.connect(_dibujar_mini)
	_raiz.add_child(_mini)
	_l_aviso = Estilo.etiqueta("", 30, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_aviso.position = Vector2(240, 112)
	_anclas.append([_l_aviso, 240, "c"])
	_l_aviso.size = Vector2(800, 120)
	_l_aviso.modulate.a = 0.0
	_raiz.add_child(_l_aviso)
	_l_guia = Estilo.etiqueta("", 22, Color(1.0, 0.92, 0.75), HORIZONTAL_ALIGNMENT_CENTER, true)
	_l_guia.position = Vector2(240, 560)
	_anclas.append([_l_guia, 240, "c"])
	_l_guia.size = Vector2(800, 50)
	_l_guia.add_theme_constant_override("outline_size", 8)
	_l_guia.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	_l_guia.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_raiz.add_child(_l_guia)
	_b_accion = Estilo.boton("", true, 84)
	_b_accion.position = Vector2(440, 616)
	_anclas.append([_b_accion, 440, "c"])
	_b_accion.size = Vector2(400, 84)
	_b_accion.add_theme_font_size_override("font_size", 24)
	_b_accion.pressed.connect(func() -> void: accion())
	_b_accion.visible = false
	_raiz.add_child(_b_accion)
	_b_destello = Estilo.boton("", false, 76)
	_b_destello.position = Vector2(24, 70)
	_b_destello.size = Vector2(170, 64)
	_b_destello.add_theme_font_size_override("font_size", 19)
	_b_destello.pressed.connect(func() -> void: destello())
	_raiz.add_child(_b_destello)
	_b_cuerno = Estilo.boton("", false, 76)
	_b_cuerno.position = Vector2(24, 142)
	_b_cuerno.size = Vector2(170, 64)
	_b_cuerno.add_theme_font_size_override("font_size", 19)
	_b_cuerno.pressed.connect(func() -> void: cuerno())
	_raiz.add_child(_b_cuerno)
	_barra_jefe = Estilo.barra(Color("d42a2a"), 22.0)
	_barra_jefe.position = Vector2(340, 232)
	_anclas.append([_barra_jefe, 340, "c"])
	_barra_jefe.size = Vector2(600, 22)
	_barra_jefe.visible = false
	_barra_jefe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var nj: Label = Estilo.etiqueta("", 24, Color("ffd2b0"))
	nj.name = "Nombre"
	nj.position = Vector2(0, -34)
	nj.size = Vector2(600, 32)
	nj.add_theme_constant_override("outline_size", 8)
	_barra_jefe.add_child(nj)
	_raiz.add_child(_barra_jefe)
	_b_montura = Estilo.boton("", false, 76)
	_b_montura.position = Vector2(24, 214)
	_b_montura.size = Vector2(170, 64)
	_b_montura.add_theme_font_size_override("font_size", 19)
	_b_montura.pressed.connect(func() -> void: poder_montura())
	_b_montura.visible = montura != ""
	_raiz.add_child(_b_montura)
	## Retratos de los héroes: se llenan de noche; al tocarlos lanzan su definitiva.
	for i: int in 3:
		var bh: Button = Estilo.boton("", false, 92)
		bh.position = Vector2(1150, 100 + i * 104)
		_anclas.append([bh, 1150.0, "d"])
		bh.size = Vector2(116, 92)
		bh.visible = false
		bh.clip_contents = true
		var rt: TextureRect = TextureRect.new()
		rt.name = "Retrato"
		rt.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		rt.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		rt.position = Vector2(8, 6)
		rt.size = Vector2(100, 66)
		rt.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bh.add_child(rt)
		var pb: ProgressBar = Estilo.barra(Color(1.0, 0.45, 0.35), 10.0)
		pb.name = "Carga"
		pb.position = Vector2(8, 74)
		pb.size = Vector2(100, 10)
		pb.max_value = 100.0
		pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bh.add_child(pb)
		var ln: Label = Estilo.etiqueta("", 16, Color("ffe2a0"), HORIZONTAL_ALIGNMENT_RIGHT)
		ln.name = "Nivel"
		ln.position = Vector2(8, 2)
		ln.size = Vector2(98, 22)
		ln.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bh.add_child(ln)
		var idx: int = i
		bh.pressed.connect(func() -> void:
			var hs: Array = _heroes_vivos()
			if idx < hs.size():
				definitiva(hs[idx] as Dictionary))
		_raiz.add_child(bh)
		_b_heroes.append(bh)
	var bp: Button = Estilo.boton("II", false, 72)
	bp.position = Vector2(1150, 14)
	_anclas.append([bp, 1150.0, "d"])
	bp.size = Vector2(116, 72)
	bp.pressed.connect(abrir_pausa)
	_raiz.add_child(bp)
	for lado: int in [-1, 1]:
		var fl: Label = Estilo.etiqueta("‹‹" if lado < 0 else "››", 64, Color(1, 1, 1, 0.22))
		fl.position = Vector2(20 if lado < 0 else 1160, 560)
		if lado > 0:
			_anclas.append([fl, 1160.0, "d"])
		fl.size = Vector2(100, 90)
		fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_raiz.add_child(fl)


## Entrada de jefe de película: franjas negras, la ilustración del jefe que se acerca despacio y su nombre.
func _cinematica_jefe() -> void:
	var img: String = "esc_jefe_" + _jefe_id
	if _tex_fx(img) == null:
		return
	pausa = true
	var capa: Control = Control.new()
	capa.set_anchors_preset(Control.PRESET_FULL_RECT)
	capa.mouse_filter = Control.MOUSE_FILTER_STOP
	_raiz.add_child(capa)
	var negro: ColorRect = ColorRect.new()
	negro.color = Color(0, 0, 0, 1)
	negro.set_anchors_preset(Control.PRESET_FULL_RECT)
	capa.add_child(negro)
	var tr: TextureRect = TextureRect.new()
	tr.texture = _tex_fx(img)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	tr.size = Vector2(ANCHO, ALTO * 0.78)
	tr.position = Vector2(0, ALTO * 0.11)
	tr.pivot_offset = tr.size / 2.0
	tr.modulate.a = 0.0
	capa.add_child(tr)
	var j: Dictionary = Datos.JEFES[_jefe_id] as Dictionary
	var nom: Label = Estilo.etiqueta(Idioma.t(str(j["nombre"])), 64, Color("ffd2b0"))
	nom.add_theme_constant_override("outline_size", 14)
	nom.add_theme_color_override("font_outline_color", Color(0.15, 0, 0, 0.95))
	nom.position = Vector2(0, ALTO * 0.66)
	nom.size = Vector2(ANCHO, 90)
	nom.modulate.a = 0.0
	capa.add_child(nom)
	var sub: Label = Estilo.etiqueta("— %s —" % Idioma.t(str(datos_valle["nombre"])), 28, Color(1.0, 0.55, 0.45))
	sub.position = Vector2(0, ALTO * 0.66 + 84.0)
	sub.size = Vector2(ANCHO, 44)
	sub.modulate.a = 0.0
	capa.add_child(sub)
	Audio.play("ui_big", 0.0, 0.0, 0.3)
	Juice.vibrate(120)
	var tw: Tween = capa.create_tween()
	tw.tween_property(tr, "modulate:a", 1.0, 0.5)
	tw.parallel().tween_property(tr, "scale", Vector2(1.12, 1.12), 3.4).from(Vector2.ONE)
	tw.parallel().tween_property(nom, "modulate:a", 1.0, 0.5).set_delay(0.6)
	tw.parallel().tween_property(sub, "modulate:a", 1.0, 0.5).set_delay(1.0)
	tw.tween_interval(1.4)
	tw.tween_property(capa, "modulate:a", 0.0, 0.5)
	var cerrar: Callable = func() -> void:
		if is_instance_valid(capa):
			capa.queue_free()
			pausa = false
	tw.tween_callback(cerrar)
	capa.gui_input.connect(func(e: InputEvent) -> void:
		if e is InputEventMouseButton and (e as InputEventMouseButton).pressed or e is InputEventScreenTouch and (e as InputEventScreenTouch).pressed:
			tw.kill()
			cerrar.call())


## Lámina del capítulo al empezar un valle: la ilustración de su jefe, el nombre y la historia.
func _capitulo() -> void:
	var img: String = "esc_jefe_" + str(datos_valle["id"])
	if _tex_fx(img) == null or valle >= Datos.CAPITULOS.size():
		return
	pausa = true
	var capa: Control = Control.new()
	capa.name = "Capitulo"
	capa.set_anchors_preset(Control.PRESET_FULL_RECT)
	capa.mouse_filter = Control.MOUSE_FILTER_STOP
	_raiz.add_child(capa)
	var negro: ColorRect = ColorRect.new()
	negro.color = Color(0.02, 0.0, 0.01, 1.0)
	negro.set_anchors_preset(Control.PRESET_FULL_RECT)
	capa.add_child(negro)
	var tr: TextureRect = TextureRect.new()
	tr.texture = _tex_fx(img)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	tr.size = Vector2(ANCHO, ALTO)
	tr.pivot_offset = tr.size / 2.0
	tr.modulate = Color(0.55, 0.5, 0.5, 0.0)
	capa.add_child(tr)
	var cap: Label = Estilo.etiqueta(Idioma.t("Capítulo %d") % (valle + 1), 30, Color(1.0, 0.55, 0.45))
	cap.position = Vector2(0, ALTO * 0.2)
	cap.size = Vector2(ANCHO, 44)
	capa.add_child(cap)
	var nom: Label = Estilo.etiqueta(Idioma.t(str(datos_valle["nombre"])), 62, Color("ffe7c2"))
	nom.add_theme_constant_override("outline_size", 14)
	nom.add_theme_color_override("font_outline_color", Color(0.15, 0, 0, 0.95))
	nom.position = Vector2(0, ALTO * 0.2 + 44.0)
	nom.size = Vector2(ANCHO, 90)
	capa.add_child(nom)
	var txt: Label = Estilo.etiqueta(Idioma.t(str(Datos.CAPITULOS[valle])), 26, Color("f3e3c8"), HORIZONTAL_ALIGNMENT_CENTER, true)
	txt.add_theme_constant_override("outline_size", 8)
	txt.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	txt.position = Vector2(ANCHO / 2.0 - 420.0, ALTO * 0.2 + 150.0)
	txt.size = Vector2(840, 200)
	txt.visible_ratio = 0.0
	capa.add_child(txt)
	var toca: Label = Estilo.etiqueta(Idioma.t("Toca para empezar"), 22, Color(1, 1, 1, 0.7))
	toca.position = Vector2(0, ALTO - 70.0)
	toca.size = Vector2(ANCHO, 40)
	toca.modulate.a = 0.0
	capa.add_child(toca)
	Audio.play_track("capitulo", false)
	var tw: Tween = capa.create_tween()
	tw.tween_property(tr, "modulate:a", 1.0, 0.8)
	tw.parallel().tween_property(tr, "scale", Vector2(1.08, 1.08), 9.0).from(Vector2.ONE)
	tw.parallel().tween_property(txt, "visible_ratio", 1.0, 4.0).set_delay(0.6)
	tw.parallel().tween_property(toca, "modulate:a", 1.0, 0.5).set_delay(2.0)
	capa.gui_input.connect(func(e: InputEvent) -> void:
		if (e is InputEventMouseButton and (e as InputEventMouseButton).pressed) or (e is InputEventScreenTouch and (e as InputEventScreenTouch).pressed):
			if txt.visible_ratio < 1.0:
				txt.visible_ratio = 1.0
				return
			tw.kill()
			pausa = false
			_pista = ""
			_pista_fase()
			var tf: Tween = capa.create_tween()
			tf.tween_property(capa, "modulate:a", 0.0, 0.4)
			tf.tween_callback(capa.queue_free))


func _heroes_vivos() -> Array:
	var out: Array = []
	for g: Variant in gente:
		if str((g as Dictionary)["oficio"]) == "heroe":
			out.append(g)
			if out.size() >= 3:
				break
	return out


func _colocar_hud() -> void:
	for a: Variant in _anclas:
		var c: Control = (a as Array)[0] as Control
		if not is_instance_valid(c):
			continue
		var bx: float = float((a as Array)[1])
		c.position.x = bx + (ANCHO - 1280.0) * (0.5 if str((a as Array)[2]) == "c" else 1.0)
		if c is Label and c.size.y > 60.0 and str((a as Array)[2]) == "c" and false:
			pass
	if _luz != null:
		_luz.size = Vector2(ANCHO, ALTO)
	if _agua != null:
		_agua.size = Vector2(ANCHO, ALTO - Y_AGUA + 20.0)


func _hud_refrescar() -> void:
	_l_brasas.text = "● %d / %d" % [brasas, MAX_BRASAS]
	_b_destello.text = Idioma.t("Destello") if cd_destello <= 0.0 else "%d s" % ceili(cd_destello)
	_b_destello.disabled = cd_destello > 0.0
	_b_cuerno.text = Idioma.t("Cuerno") if cd_cuerno <= 0.0 else "%d s" % ceili(cd_cuerno)
	_b_cuerno.disabled = cd_cuerno > 0.0
	if montura != "":
		_b_montura.text = Idioma.t(str((Datos.PODER_MONTURA[montura] as Dictionary)["nombre"])) if cd_montura <= 0.0 else "%d s" % ceili(cd_montura)
		_b_montura.disabled = cd_montura > 0.0
	var jefe_vivo: Dictionary = {}
	for c: Variant in criaturas:
		if str((c as Dictionary)["tipo"]) == "jefe":
			jefe_vivo = c as Dictionary
	_barra_jefe.visible = not jefe_vivo.is_empty()
	if _barra_jefe.visible:
		_barra_jefe.max_value = float(jefe_vivo["hpmax"])
		_barra_jefe.value = float(jefe_vivo["hp"])
		var fz: String = Idioma.t("Furia final") if bool(jefe_vivo.get("fase3", false)) else (Idioma.t("Enfurecido") if bool(jefe_vivo.get("fase2", false)) else "")
		(_barra_jefe.get_node("Nombre") as Label).text = Idioma.t(str((Datos.JEFES[_jefe_id] as Dictionary)["nombre"])) + (("  ·  " + fz) if fz != "" else "")
	var hs: Array = _heroes_vivos()
	for i: int in _b_heroes.size():
		var bh: Button = _b_heroes[i] as Button
		bh.visible = i < hs.size()
		if not bh.visible:
			continue
		var hp: Dictionary = hs[i] as Dictionary
		var hid: String = str(hp.get("heroe", "caballero"))
		var rt: TextureRect = bh.get_node("Retrato") as TextureRect
		var idr: String = "lr_retrato_" + hid
		if rt.get_meta("id", "") != idr:
			rt.set_meta("id", idr)
			rt.texture = _tex_fx(idr) if _tex_fx(idr) != null else Estilo.tex(str((Datos.HEROES[hid] as Dictionary)["tex"]))
		var carga: float = float(hp.get("carga", 0.0))
		(bh.get_node("Carga") as ProgressBar).value = carga
		(bh.get_node("Nivel") as Label).text = Idioma.t("Nv %d") % Estado.nivel_heroe(hid)
		bh.disabled = carga < 100.0
		bh.modulate = Color(1.25 + 0.25 * sin(tiempo * 6.0), 1.1, 0.95) if carga >= 100.0 else Color.WHITE
	var l: Dictionary = Datos.LUNAS[luna if fase == "dia" or fase == "tarde" else luna_hoy] as Dictionary
	var nombre_fase: String = {"dia": Idioma.t("Día"), "tarde": Idioma.t("Atardecer"), "noche": Idioma.t("Noche"), "alba": Idioma.t("Alba")}[fase]
	_l_dia.text = "%s %d   ·   %s" % [nombre_fase, dia, Idioma.t(str(l["nombre"]))]
	if clima != "despejado" and (fase == "noche" or fase == "alba"):
		_l_dia.text += "   ·   " + Idioma.t(str((Datos.CLIMAS[clima] as Dictionary)["nombre"]))
	_l_dia.add_theme_color_override("font_color", (l["color"] as Color).lerp(Estilo.TEXTO, 0.4))
	_barra_dia.value = 1.0 - t_fase / _duracion_fase()
	var guia: String = _guia() if dia <= 4 and valle == 0 else ""
	_l_guia.text = guia
	_l_guia.visible = guia != ""
	_l_guia.modulate.a = 0.75 + 0.25 * sin(tiempo * 3.0)
	var o: Dictionary = {}
	if not _sitio_cerca.is_empty():
		o = opcion(_sitio_cerca) if str(_sitio_cerca["tipo"]) != "mercader" else opcion({"tipo": "mercader"})
	_b_accion.visible = not o.is_empty()
	if not o.is_empty():
		var coste: int = int(o["coste"])
		_b_accion.text = str(o["texto"]) + (("   ● %d" % coste) if coste > 0 else "")
		_b_accion.disabled = coste < 0 or brasas < coste


## Mapa del valle: fuego, muros por nivel, torres, grietas, sombras (rojo) y la reina (oro).
func _dibujar_mini() -> void:
	var w: float = _mini.size.x
	var k: float = w / (Datos.BORDE * 2.0)
	var y: float = 15.0
	_mini.draw_rect(Rect2(0, 4, w, 22), Color(0.05, 0.03, 0.04, 0.6))
	_mini.draw_line(Vector2(0, y + 6), Vector2(w, y + 6), Color(0.4, 0.33, 0.25, 0.8), 2.0)
	var vx0: float = (cam - ANCHO / 2.0 + Datos.BORDE) * k
	_mini.draw_rect(Rect2(vx0, 4, ANCHO * k, 22), Color(1, 1, 1, 0.08))
	_mini.draw_rect(Rect2(vx0, 4, ANCHO * k, 22), Color(1, 1, 1, 0.25), false, 1.0)
	for st: Variant in sitios:
		var d: Dictionary = st as Dictionary
		var mx: float = (float(d["x"]) + Datos.BORDE) * k
		match str(d["tipo"]):
			"hoguera":
				_mini.draw_circle(Vector2(mx, y + 2), 5.0, Color(1.0, 0.55, 0.15))
			"muro":
				if int(d["nivel"]) > 0:
					_mini.draw_rect(Rect2(mx - 2, y + 6 - 6 - int(d["nivel"]) * 3, 4, 6 + int(d["nivel"]) * 3), Color(0.75, 0.7, 0.6))
			"torre":
				if int(d["nivel"]) > 0:
					_mini.draw_rect(Rect2(mx - 1.5, y - 8, 3, 14), Color(0.6, 0.45, 0.3))
			"grieta":
				_mini.draw_circle(Vector2(mx, y + 2), 5.0, Color(0.9, 0.1, 0.1) if not bool(d["cerrada"]) else Color(0.4, 0.4, 0.4))
			"cofre":
				if not bool(d["abierto"]):
					_mini.draw_rect(Rect2(mx - 2, y + 2, 4, 4), Color(0.9, 0.75, 0.3))
	for c: Variant in criaturas:
		_mini.draw_circle(Vector2((float((c as Dictionary)["x"]) + Datos.BORDE) * k, y + 4), 2.0, Color(1.0, 0.2, 0.15))
	_mini.draw_circle(Vector2((float(reina["x"]) + Datos.BORDE) * k, y + 2), 4.0, Color("ffcf7a"))
	_mini.draw_arc(Vector2((float(reina["x"]) + Datos.BORDE) * k, y + 2), 6.0, 0.0, TAU, 12, Color(1, 1, 1, 0.7), 1.0)


## Qué conviene hacer ahora (solo los primeros días del primer valle).
func _guia() -> String:
	if fase == "noche" or fase == "tarde":
		return Idioma.t("Vuelve junto al fuego: las sombras vienen de los extremos.")
	var aldeanos: int = contar("aldeano")
	var cons: int = contar("constructor")
	var arq: int = contar("arquero")
	if aldeanos + cons + arq < 3:
		return Idioma.t("Cabalga hasta un campamento (‹‹ o ››) y recluta vagabundos.")
	if cons == 0 and int(herramientas["constructor"]) == 0:
		return Idioma.t("Compra martillos en el puesto de la derecha del fuego.")
	if arq == 0 and int(herramientas["arquero"]) == 0:
		return Idioma.t("Compra arcos en el puesto de la izquierda del fuego.")
	if muro_exterior(-1).is_empty() or muro_exterior(1).is_empty():
		return Idioma.t("Levanta una empalizada a cada lado antes de que anochezca.")
	if brasas < 4:
		return Idioma.t("Abre los cofres y recoge las brasas de los ciervos y las granjas.")
	return Idioma.t("Aviva la hoguera para desbloquear torres, granjas y más.")


func _avisar(s: String) -> void:
	if bot or _l_aviso == null:
		return
	_l_aviso.text = s
	var tw: Tween = _l_aviso.create_tween()
	tw.tween_property(_l_aviso, "modulate:a", 1.0, 0.25)
	tw.tween_interval(2.6)
	tw.tween_property(_l_aviso, "modulate:a", 0.0, 0.6)


func _pista_fase() -> void:
	var p: String = "dia"
	## Cada valle tiene su música de día (si está en el manifiesto).
	var propia: String = "dia_" + str(datos_valle["id"])
	if (Kit.assets.get("musica", {}) as Dictionary).has(propia):
		p = propia
	if fase == "noche" or fase == "tarde":
		p = "luna_roja" if luna == "roja" or luna_hoy == "roja" else "noche"
	if p != _pista:
		_pista = p
		Audio.play_track(p)


func abrir_pausa() -> void:
	if not _modal.is_empty() or not vivo:
		return
	pausa = true
	_modal = Estilo.modal(_raiz, Idioma.t("Pausa"), 640.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Arqueros %d · Constructores %d · Granjeros %d · Lanceros %d") % [contar("arquero"), contar("constructor"), contar("granjero"), contar("lancero")], 21, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	if Estado.n("reserva") > 0:
		var br: Button = Estilo.boton(Idioma.t("Sacar brasas de la reserva (%d)") % Estado.n("reserva"), false, 72)
		br.pressed.connect(func() -> void:
			var cuanto: int = mini(Estado.n("reserva"), MAX_BRASAS - brasas)
			brasas += cuanto
			Estado.d["reserva"] = Estado.n("reserva") - cuanto
			Estado.guardar()
			br.queue_free())
		vb.add_child(br)
	var bc: Button = Estilo.boton(Idioma.t("Seguir"), true, 80)
	bc.pressed.connect(_cerrar_modal)
	vb.add_child(bc)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 72)
	ba.pressed.connect(func() -> void: Consejo.ajustes(_raiz))
	vb.add_child(ba)
	var bs: Button = Estilo.boton(Idioma.t("Guardar y salir"), false, 72)
	bs.pressed.connect(func() -> void: Kit.change_scene(MAIN))
	vb.add_child(bs)


func _cerrar_modal() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and vivo and not bot and _modal.is_empty():
		abrir_pausa()

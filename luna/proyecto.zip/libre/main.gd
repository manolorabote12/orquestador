extends Control
## Portada de Bajo la Luna Roja: continuar, empezar valle, valles, tienda y ajustes.

const JUEGO: String = "res://libre/juego.tscn"

var _modal: Dictionary = {}
var _t: float = 0.0
var _titulo: Label


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	var cobrado: int = Estado.cobrar_monedero()
	Audio.play_track("menu")
	Estilo.fondo_cubrir(self, "lr_titulo", 1.03)
	var vel: ColorRect = ColorRect.new()
	vel.size = Vector2(1280, 720)
	vel.color = Color(0.03, 0.01, 0.02, 0.25)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	_titulo = Estilo.etiqueta(Idioma.t("Bajo la Luna Roja"), 76, Color("ffe7c2"))
	_titulo.position = Vector2(0, 30)
	_titulo.size = Vector2(1280, 100)
	_titulo.add_theme_constant_override("outline_size", 14)
	_titulo.add_theme_color_override("font_outline_color", Color(0.25, 0.02, 0.02, 0.9))
	add_child(_titulo)
	var sub: Label = Estilo.etiqueta(Idioma.t("De día construyes. De noche, resistes."), 28, Color("f3d9b0"))
	sub.position = Vector2(0, 122)
	sub.size = Vector2(1280, 40)
	sub.add_theme_constant_override("outline_size", 8)
	sub.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	add_child(sub)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.position = Vector2(860, 250)
	vb.size = Vector2(380, 440)
	vb.add_theme_constant_override("separation", 12)
	add_child(vb)
	var v: int = Estado.valle_actual()
	var nombre_valle: String = Idioma.t(str((Datos.VALLES[v] as Dictionary)["nombre"])) if v < Datos.VALLES.size() else Idioma.t("Luna eterna")
	if Estado.hay_guardada():
		var g: Dictionary = Estado.d["guardada"] as Dictionary
		var bc: Button = Estilo.boton(Idioma.t("Continuar · día %d") % int(g.get("dia", 1)), true, 88)
		bc.add_theme_font_size_override("font_size", 30)
		bc.pressed.connect(func() -> void: jugar(false))
		vb.add_child(bc)
		Estilo.pulso(bc)
		var bn: Button = Estilo.boton(Idioma.t("Empezar el valle de nuevo"), false, 70)
		bn.add_theme_font_size_override("font_size", 22)
		bn.pressed.connect(func() -> void:
			Estilo.confirmar(self, Idioma.t("¿Empezar de nuevo?"), Idioma.t("Perderás el progreso de este valle."), Idioma.t("Sí"), Idioma.t("No"), func() -> void: jugar(true)))
		vb.add_child(bn)
	else:
		var bj: Button = Estilo.boton(Idioma.t("Jugar"), true, 92)
		bj.add_theme_font_size_override("font_size", 36)
		bj.pressed.connect(func() -> void: jugar(true))
		vb.add_child(bj)
		Estilo.pulso(bj)
	var bv: Button = Estilo.boton(Idioma.t("Valles"), false, 70)
	bv.pressed.connect(abrir_valles)
	vb.add_child(bv)
	if Store.available() or Store.showcase():
		var bt: Button = Estilo.boton(Idioma.t("Tienda"), false, 70)
		bt.pressed.connect(abrir_tienda)
		vb.add_child(bt)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 70)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	vb.add_child(ba)
	var info: Label = Estilo.etiqueta(nombre_valle + "\n" + Idioma.t("Mejor racha: %d noches   ·   Valles liberados: %d") % [Estado.n("mejor_noche"), Estado.n("valles_ganados")], 22, Color("f3d9b0"), HORIZONTAL_ALIGNMENT_LEFT, true)
	info.position = Vector2(40, 620)
	info.size = Vector2(760, 80)
	info.add_theme_constant_override("outline_size", 8)
	info.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	add_child(info)
	if cobrado > 0:
		Estilo.confirmar(self, Idioma.t("¡Gracias!"), Idioma.t("Han llegado %d brasas a tu reserva.") % cobrado, Idioma.t("Vale"), Idioma.t("Cerrar"), func() -> void: pass)


func _process(dt: float) -> void:
	_t += dt
	_titulo.modulate = Color(1, 0.92 + 0.08 * sin(_t * 1.5), 0.92 + 0.08 * sin(_t * 1.5))


func jugar(nuevo: bool) -> void:
	if nuevo:
		Estado.d["guardada"] = {}
		Estado.guardar()
	Estado.partida = {"nuevo": nuevo}
	Kit.change_scene(JUEGO)


func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


func abrir_valles() -> void:
	_modal = Estilo.modal(self, Idioma.t("Valles"), 760.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	for i: int in Datos.VALLES.size():
		var va: Dictionary = Datos.VALLES[i] as Dictionary
		var libre: bool = Estado.n("valles_ganados") > i
		var actual: bool = Estado.valle_actual() == i
		var t: String = ("✓ " if libre else ("» " if actual else "· ")) + Idioma.t(str(va["nombre"]))
		var l: Label = Estilo.etiqueta(t, 26, Estilo.VERDE if libre else (Estilo.ORO if actual else Estilo.NIEBLA), HORIZONTAL_ALIGNMENT_LEFT)
		vb.add_child(l)
		if actual or libre:
			var d: Label = Estilo.etiqueta(Idioma.t(str(va["texto"])), 19, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
			d.custom_minimum_size = Vector2(680, 0)
			vb.add_child(d)
	vb.add_child(Estilo.etiqueta(Idioma.t("Libera los tres y llegará la Luna eterna: noches sin fin."), 19, Estilo.NIEBLA))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_tienda() -> void:
	_modal = Estilo.modal(self, Idioma.t("Tienda"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var ps: Dictionary = Store.products()
	for id: Variant in ps.keys():
		var pid: String = str(id)
		var kind: String = str((ps[pid] as Dictionary).get("kind", ""))
		if kind in ["pass", "vip"] or Store.owns(pid) or (kind in ["no_ads", "bundle"] and Store.no_ads()):
			continue
		var b: Button = Estilo.boton("%s   ·   %s" % [Idioma.t(Store.label(pid)), Store.price(pid)], false, 72)
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(func() -> void: Store.buy(pid))
		vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)

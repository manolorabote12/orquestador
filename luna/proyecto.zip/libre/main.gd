extends Control
## Portada de Bajo la Luna Roja: continuar, empezar valle, valles, tienda y ajustes.

const JUEGO: String = "res://libre/juego.tscn"

var _modal: Dictionary = {}
var _t: float = 0.0
var _titulo: Label
var _brillo: Node2D
var _brasas: Array = []


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	Estado.cargar()
	var cobrado: int = Estado.cobrar_monedero()
	Audio.play_track("menu")
	var W: float = get_viewport_rect().size.x
	Estilo.fondo_cubrir(self, "lr_titulo", 1.03)
	var vel: ColorRect = ColorRect.new()
	vel.size = Vector2(W, 720)
	vel.color = Color(0.03, 0.01, 0.02, 0.25)
	vel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vel)
	## Brasas que suben y un latido rojo sobre la portada.
	_brillo = Node2D.new()
	_brillo.draw.connect(_dibujar_brillo)
	add_child(_brillo)
	for i: int in 40:
		_brasas.append(Vector3(randf() * W, randf() * 720.0, randf_range(0.4, 1.0)))
	_titulo = Estilo.etiqueta(Idioma.t("Bajo la Luna Roja"), 76, Color("ffe7c2"))
	_titulo.position = Vector2(0, 30)
	_titulo.size = Vector2(W, 100)
	_titulo.add_theme_constant_override("outline_size", 14)
	_titulo.add_theme_color_override("font_outline_color", Color(0.25, 0.02, 0.02, 0.9))
	add_child(_titulo)
	var sub: Label = Estilo.etiqueta(Idioma.t("De día construyes. De noche, resistes."), 28, Color("f3d9b0"))
	sub.position = Vector2(0, 122)
	sub.size = Vector2(W, 40)
	sub.add_theme_constant_override("outline_size", 8)
	sub.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	add_child(sub)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.position = Vector2(W - 480.0, 230)
	vb.size = Vector2(450, 440)
	vb.add_theme_constant_override("separation", 12)
	add_child(vb)
	var v: int = Estado.valle_actual()
	var nombre_valle: String = Idioma.t(str((Datos.VALLES[v] as Dictionary)["nombre"])) if v < Datos.VALLES.size() else Idioma.t("Luna eterna")
	if Estado.hay_guardada():
		var g: Dictionary = Estado.d["guardada"] as Dictionary
		var bc: Button = Estilo.boton(Idioma.t("Continuar · día %d") % int(g.get("dia", 1)), true, 88)
		bc.add_theme_font_size_override("font_size", 30)
		bc.pressed.connect(func() -> void: jugar(false))
		vb.add_child(bc)
		Estilo.pulso(bc)
		var bn: Button = Estilo.boton(Idioma.t("Empezar el valle de nuevo"), false, 70)
		bn.add_theme_font_size_override("font_size", 22)
		bn.pressed.connect(func() -> void:
			Estilo.confirmar(self, Idioma.t("¿Empezar de nuevo?"), Idioma.t("Perderás el progreso de este valle."), Idioma.t("Sí"), Idioma.t("No"), func() -> void: jugar(true)))
		vb.add_child(bn)
	else:
		var bj: Button = Estilo.boton(Idioma.t("Jugar"), true, 92)
		bj.add_theme_font_size_override("font_size", 36)
		bj.pressed.connect(func() -> void: jugar(true))
		vb.add_child(bj)
		Estilo.pulso(bj)
	## Menú secundario en rejilla de dos columnas (caben todos en pantallas bajas).
	var grid: GridContainer = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	vb.add_child(grid)
	var opciones: Array = [
		[Idioma.t("Reto del día") + (" ✓" if Estado.reto_hecho() else " !"), abrir_reto],
		[Idioma.t("Mapa"), abrir_mapa],
		[Idioma.t("Héroes"), abrir_heroes],
		[Idioma.t("Altar") + " ◆%d" % Estado.n("fragmentos"), abrir_altar],
		[Idioma.t("Bestiario"), abrir_bestiario],
		[Idioma.t("Logros") + " %d/%d" % [(Estado.d["logros"] as Array).size(), Datos.LOGROS.size()], abrir_logros],
	]
	if Store.available() or Store.showcase():
		opciones.append([Idioma.t("Tienda"), abrir_tienda])
	for o: Variant in opciones:
		var bo: Button = Estilo.boton(str((o as Array)[0]), false, 64)
		bo.custom_minimum_size = Vector2(220, 64)
		bo.add_theme_font_size_override("font_size", 20 if str((o as Array)[0]).length() <= 9 else 17)
		bo.clip_text = true
		bo.pressed.connect((o as Array)[1] as Callable)
		grid.add_child(bo)
	var ba: Button = Estilo.boton(Idioma.t("Ajustes"), false, 60)
	ba.position = Vector2(W - 190, 18)
	ba.size = Vector2(170, 60)
	ba.add_theme_font_size_override("font_size", 20)
	ba.pressed.connect(func() -> void: Consejo.ajustes(self))
	add_child(ba)
	var info: Label = Estilo.etiqueta(nombre_valle + "\n" + Idioma.t("Mejor racha: %d noches   ·   Valles liberados: %d") % [Estado.n("mejor_noche"), Estado.n("valles_ganados")], 22, Color("f3d9b0"), HORIZONTAL_ALIGNMENT_LEFT, true)
	info.position = Vector2(40, 620)
	info.size = Vector2(760, 80)
	info.add_theme_constant_override("outline_size", 8)
	info.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	add_child(info)
	if cobrado > 0:
		Estilo.confirmar(self, Idioma.t("¡Gracias!"), Idioma.t("Han llegado %d brasas a tu reserva.") % cobrado, Idioma.t("Vale"), Idioma.t("Cerrar"), func() -> void: pass)


func _dibujar_brillo() -> void:
	_brillo.draw_circle(Vector2(640, 330), 380.0 + 20.0 * sin(_t * 1.2), Color(0.8, 0.05, 0.05, 0.05 + 0.03 * sin(_t * 1.2)))
	for b: Vector3 in _brasas:
		var a: float = 0.5 + 0.5 * sin(_t * 3.0 + b.x)
		_brillo.draw_circle(Vector2(b.x + sin(_t + b.y * 0.01) * 12.0, b.y), 2.5 * b.z, Color(1.0, 0.55, 0.15, a * b.z))
		_brillo.draw_circle(Vector2(b.x + sin(_t + b.y * 0.01) * 12.0, b.y), 6.0 * b.z, Color(1.0, 0.4, 0.1, a * b.z * 0.2))


func _process(dt: float) -> void:
	_t += dt
	for i: int in _brasas.size():
		var b: Vector3 = _brasas[i]
		b.y -= dt * 40.0 * b.z
		if b.y < -10.0:
			b = Vector3(randf() * get_viewport_rect().size.x, 730.0, randf_range(0.4, 1.0))
		_brasas[i] = b
	_brillo.queue_redraw()
	_titulo.modulate = Color(1, 0.92 + 0.08 * sin(_t * 1.5), 0.92 + 0.08 * sin(_t * 1.5))


func jugar(nuevo: bool) -> void:
	if nuevo:
		Estado.d["guardada"] = {}
		Estado.guardar()
	Estado.partida = {"nuevo": nuevo}
	Kit.change_scene(JUEGO)


func _cerrar() -> void:
	Estilo.cerrar(_modal)
	_modal = {}


## Mapa del reino (v6): el pergamino pintado con los seis valles unidos por el camino. Los liberados
## brillan en verde, el actual late en rojo bajo la luna y los demás esperan en la niebla.
## Sitio de cada valle sobre la ilustración del mapa (proporción de la imagen: bosque, lago, volcán, nieve, dunas, castillo).
const PUNTOS_MAPA: Array = [Vector2(0.17, 0.68), Vector2(0.31, 0.37), Vector2(0.61, 0.33), Vector2(0.8, 0.36), Vector2(0.6, 0.6), Vector2(0.83, 0.72)]
var _mapa: Control = null


func abrir_mapa() -> void:
	if _mapa != null:
		return
	var W: float = get_viewport_rect().size.x
	var H: float = get_viewport_rect().size.y
	_mapa = Control.new()
	_mapa.set_anchors_preset(Control.PRESET_FULL_RECT)
	_mapa.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_mapa)
	var fondo: ColorRect = ColorRect.new()
	fondo.color = Color(0.03, 0.01, 0.02, 1.0)
	fondo.set_anchors_preset(Control.PRESET_FULL_RECT)
	_mapa.add_child(fondo)
	var id_mapa: String = "lr_mapa" if Estilo.existe("lr_mapa") else "lr_titulo"
	var bg: TextureRect = Estilo.fondo_cubrir(_mapa, id_mapa, 1.0)
	if id_mapa != "lr_mapa":
		bg.modulate = Color(0.55, 0.45, 0.45)
	## La imagen cubre la pantalla (se recorta lo que sobra): los puntos siguen a la imagen, no a la pantalla.
	var esc_m: float = maxf(W / 1280.0, H / 720.0)
	var off_m: Vector2 = Vector2((W - 1280.0 * esc_m) / 2.0, (H - 720.0 * esc_m) / 2.0)
	var en_mapa: Callable = func(p: Vector2) -> Vector2: return (off_m + Vector2(p.x * 1280.0, p.y * 720.0) * esc_m).clamp(Vector2(80, 90), Vector2(W - 130, H - 140))
	var camino: Line2D = Line2D.new()
	camino.width = 6.0
	camino.default_color = Color(1.0, 0.85, 0.55, 0.55)
	camino.joint_mode = Line2D.LINE_JOINT_ROUND
	for p: Variant in PUNTOS_MAPA:
		camino.add_point(en_mapa.call(p as Vector2))
	_mapa.add_child(camino)
	var titulo: Label = Estilo.etiqueta(Idioma.t("El reino bajo la Luna Roja"), 46, Color("ffe7c2"))
	titulo.position = Vector2(0, 18)
	titulo.size = Vector2(W, 64)
	titulo.add_theme_constant_override("outline_size", 12)
	titulo.add_theme_color_override("font_outline_color", Color(0.2, 0.02, 0.02, 0.9))
	_mapa.add_child(titulo)
	var ganados: int = Estado.n("valles_ganados")
	var jv: Array = Estado.d["jefes_valle"] as Array
	for i: int in Datos.VALLES.size():
		var va: Dictionary = Datos.VALLES[i] as Dictionary
		var pos: Vector2 = en_mapa.call(PUNTOS_MAPA[i] as Vector2)
		var libre: bool = ganados > i
		var actual: bool = Estado.valle_actual() == i
		var b: Button = Estilo.boton("✓" if libre else (str(i + 1) if actual else "?"), actual, 84)
		b.size = Vector2(84, 84)
		b.position = pos - Vector2(42, 42)
		b.add_theme_font_size_override("font_size", 34)
		if not libre and not actual:
			b.modulate = Color(0.55, 0.55, 0.6, 0.85)
		elif libre:
			b.modulate = Color(0.75, 1.15, 0.8)
		else:
			Estilo.pulso(b)
		var idx: int = i
		b.pressed.connect(func() -> void: _ficha_valle(idx))
		_mapa.add_child(b)
		var nl: Label = Estilo.etiqueta(Idioma.t(str(va["nombre"])), 22, Color("ffe7c2") if libre or actual else Color(0.75, 0.72, 0.7))
		nl.position = pos + Vector2(-130, 46)
		nl.size = Vector2(260, 30)
		nl.add_theme_constant_override("outline_size", 8)
		nl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
		_mapa.add_child(nl)
		if jv.has(str(va["id"])):
			var cr: Label = Estilo.etiqueta(Idioma.t("Jefe vencido"), 17, Color(1.0, 0.55, 0.5))
			cr.position = pos + Vector2(-130, 72)
			cr.size = Vector2(260, 24)
			cr.add_theme_constant_override("outline_size", 6)
			_mapa.add_child(cr)
	var bc: Button = Estilo.boton(Idioma.t("Volver"), false, 70)
	bc.position = Vector2(W - 210, H - 92)
	bc.size = Vector2(180, 70)
	bc.pressed.connect(func() -> void:
		_mapa.queue_free()
		_mapa = null)
	_mapa.add_child(bc)
	_mapa.modulate.a = 0.0
	_mapa.create_tween().tween_property(_mapa, "modulate:a", 1.0, 0.35)


func _ficha_valle(i: int) -> void:
	var va: Dictionary = Datos.VALLES[i] as Dictionary
	var libre: bool = Estado.n("valles_ganados") > i
	var actual: bool = Estado.valle_actual() == i
	_modal = Estilo.modal(self, Idioma.t(str(va["nombre"])), 720.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var img: String = "esc_jefe_" + str(va["id"])
	if Estilo.existe(img) and (libre or actual):
		var tr: TextureRect = Estilo.sprite(img, Vector2(640, 300))
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		tr.clip_contents = true
		vb.add_child(tr)
	if libre or actual:
		var d: Label = Estilo.etiqueta(Idioma.t(str(va["texto"])), 21, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
		d.custom_minimum_size = Vector2(640, 0)
		vb.add_child(d)
		var hv: Array = Datos.HEROES_VALLE[i] as Array
		var nombres: Array[String] = []
		for h: Variant in hv:
			nombres.append(str(Idioma.t(str((Datos.HEROES[str(h)] as Dictionary)["nombre"]))))
		vb.add_child(Estilo.etiqueta(Idioma.t("Jefe: %s") % Idioma.t(str((Datos.JEFES[str(va["id"])] as Dictionary)["nombre"])), 22, Color(1.0, 0.55, 0.5)))
		vb.add_child(Estilo.etiqueta(Idioma.t("Héroes por rescatar: %s") % ", ".join(nombres), 20, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, true))
	else:
		vb.add_child(Estilo.etiqueta(Idioma.t("La niebla cubre este valle. Libera los anteriores para llegar hasta él."), 22, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	if actual:
		var bj: Button = Estilo.boton(Idioma.t("Continuar") if Estado.hay_guardada() else Idioma.t("Jugar"), true, 80)
		bj.pressed.connect(func() -> void: jugar(not Estado.hay_guardada()))
		vb.add_child(bj)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), false, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


## Salón de los héroes: nivel, experiencia, habilidad, talento y definitiva de cada uno.
func abrir_heroes() -> void:
	_modal = Estilo.modal(self, Idioma.t("Salón de los héroes"), 900.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(860, 470)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lista.add_theme_constant_override("separation", 14)
	sc.add_child(lista)
	for id: Variant in Datos.HEROES.keys():
		var hid: String = str(id)
		var h: Dictionary = Datos.HEROES[hid] as Dictionary
		var v6: Dictionary = Datos.HEROES_V6[hid] as Dictionary
		var nv: int = Estado.nivel_heroe(hid)
		var fila: HBoxContainer = HBoxContainer.new()
		fila.add_theme_constant_override("separation", 16)
		lista.add_child(fila)
		var ret: String = "lr_retrato_" + hid if Estilo.existe("lr_retrato_" + hid) else str(h["tex"])
		var tr: TextureRect = Estilo.sprite(ret, Vector2(130, 150))
		tr.custom_minimum_size = Vector2(130, 150)
		fila.add_child(tr)
		var col: VBoxContainer = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		fila.add_child(col)
		col.add_child(Estilo.etiqueta("%s   ·   %s" % [Idioma.t(str(h["nombre"])), Idioma.t("Nivel %d") % nv], 24, v6["col"] as Color, HORIZONTAL_ALIGNMENT_LEFT))
		var sig: int = int(Datos.XP_NIVEL[mini(nv, Datos.XP_NIVEL.size() - 1)])
		var pb: ProgressBar = Estilo.barra(v6["col"] as Color, 10.0)
		pb.max_value = maxf(1.0, float(sig))
		pb.value = float(Estado.xp_heroe(hid))
		pb.custom_minimum_size = Vector2(500, 10)
		col.add_child(pb)
		var lin: Array[String] = [
			Idioma.t("Habilidad: %s") % Idioma.t(str(h["hab"])),
			(Idioma.t("Talento: %s — %s") % [Idioma.t(str(v6["talento"])), Idioma.t(str(v6["talento_texto"]))]) if nv >= 3 else Idioma.t("Talento: se aprende a nivel 3"),
			Idioma.t("Definitiva: %s — %s") % [Idioma.t(str(v6["def"])), Idioma.t(str(v6["def_texto"]))]]
		for t: String in lin:
			var l: Label = Estilo.etiqueta(t, 18, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
			l.custom_minimum_size = Vector2(680, 0)
			col.add_child(l)
	vb.add_child(Estilo.etiqueta(Idioma.t("Los héroes ganan experiencia cada noche que sobreviven. Sus retratos se llenan de noche: tócalos para lanzar su definitiva."), 18, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_CENTER, true))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


## Bestiario: las criaturas que ya has visto y los jefes que has vencido.
func abrir_bestiario() -> void:
	_modal = Estilo.modal(self, Idioma.t("Bestiario"), 900.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(860, 470)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var grid: GridContainer = GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	sc.add_child(grid)
	var vistos: Array = Estado.d.get("vistos", []) as Array
	var jv: Array = Estado.d["jefes_valle"] as Array
	var fichas: Array = []
	for id: Variant in Datos.BESTIARIO.keys():
		fichas.append([str((Datos.CRIATURAS[str(id)] as Dictionary)["tex"]), (Datos.BESTIARIO[id] as Array)[0], (Datos.BESTIARIO[id] as Array)[1], vistos.has(str(id))])
	for va: Variant in Datos.VALLES:
		var jid: String = str((va as Dictionary)["id"])
		fichas.append(["lr_jefe_" + jid, (Datos.JEFES[jid] as Dictionary)["nombre"], Idioma.t("Jefe de %s") % Idioma.t(str((va as Dictionary)["nombre"])), jv.has(jid)])
	for f: Variant in fichas:
		var fa: Array = f as Array
		var visto: bool = bool(fa[3])
		var caja: VBoxContainer = VBoxContainer.new()
		caja.custom_minimum_size = Vector2(205, 0)
		grid.add_child(caja)
		var tex_id: String = str(fa[0]) if Estilo.existe(str(fa[0])) else "lr_jefe"
		var tr: TextureRect = Estilo.sprite(tex_id, Vector2(205, 150))
		tr.custom_minimum_size = Vector2(205, 150)
		if not visto:
			tr.modulate = Color(0, 0, 0, 0.75)
		caja.add_child(tr)
		caja.add_child(Estilo.etiqueta(Idioma.t(str(fa[1])) if visto else "???", 19, Estilo.ORO if visto else Estilo.NIEBLA))
		var d: Label = Estilo.etiqueta(Idioma.t(str(fa[2])) if visto else Idioma.t("Aún no lo has visto."), 15, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
		d.custom_minimum_size = Vector2(205, 0)
		caja.add_child(d)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_valles() -> void:
	_modal = Estilo.modal(self, Idioma.t("Valles"), 760.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	for i: int in Datos.VALLES.size():
		var va: Dictionary = Datos.VALLES[i] as Dictionary
		var libre: bool = Estado.n("valles_ganados") > i
		var actual: bool = Estado.valle_actual() == i
		var t: String = ("✓ " if libre else ("» " if actual else "· ")) + Idioma.t(str(va["nombre"]))
		var l: Label = Estilo.etiqueta(t, 26, Estilo.VERDE if libre else (Estilo.ORO if actual else Estilo.NIEBLA), HORIZONTAL_ALIGNMENT_LEFT)
		vb.add_child(l)
		if actual or libre:
			var d: Label = Estilo.etiqueta(Idioma.t(str(va["texto"])), 19, Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true)
			d.custom_minimum_size = Vector2(680, 0)
			vb.add_child(d)
	vb.add_child(Estilo.etiqueta(Idioma.t("Libera los seis y llegará la Luna eterna: noches sin fin."), 19, Estilo.NIEBLA))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_altar() -> void:
	_modal = Estilo.modal(self, Idioma.t("Altar de la Luna"), 820.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t("Fragmentos de luna: ◆ %d   (jefes, grietas y valles liberados)") % Estado.n("fragmentos"), 22, Color(1.0, 0.5, 0.5), HORIZONTAL_ALIGNMENT_CENTER, true))
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(780, 440)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.add_theme_constant_override("separation", 12)
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(lista)
	for id: String in Datos.MEJORAS.keys():
		var m: Dictionary = Datos.MEJORAS[id] as Dictionary
		var fila: HBoxContainer = HBoxContainer.new()
		fila.add_theme_constant_override("separation", 10)
		lista.add_child(fila)
		var nv: int = Estado.mejora(id)
		var tot: int = (m["costes"] as Array).size()
		var l: Label = Estilo.etiqueta("%s  %s\n%s" % [Idioma.t(str(m["nombre"])), "●".repeat(nv) + "○".repeat(tot - nv), Idioma.t(str(m["texto"]))], 20, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
		l.custom_minimum_size = Vector2(560, 0)
		fila.add_child(l)
		var c: int = Estado.coste_mejora(id)
		var b: Button = Estilo.boton(Idioma.t("Máximo") if c < 0 else "◆ %d" % c, false, 60)
		b.custom_minimum_size = Vector2(150, 60)
		b.disabled = c < 0 or Estado.n("fragmentos") < c
		b.pressed.connect(func() -> void:
			if Estado.comprar_mejora(id):
				Audio.play("ui_reward")
				_cerrar()
				abrir_altar())
		fila.add_child(b)
	lista.add_child(Estilo.etiqueta(Idioma.t("Monturas"), 26, Color(1.0, 0.8, 0.5), HORIZONTAL_ALIGNMENT_CENTER, true))
	for mv: Variant in Datos.MONTURAS:
		var md: Dictionary = mv as Dictionary
		var mid: String = str(md["id"])
		var fila2: HBoxContainer = HBoxContainer.new()
		fila2.add_theme_constant_override("separation", 10)
		lista.add_child(fila2)
		if mid != "":
			var tr: TextureRect = TextureRect.new()
			tr.texture = Estilo.tex("lr_montura_" + mid)
			tr.custom_minimum_size = Vector2(90, 70)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			fila2.add_child(tr)
		var bloqueada: bool = Estado.n("valles_ganados") < int(md["valles"])
		var txt: String = Idioma.t(str(md["texto"])) if not bloqueada else Idioma.t("Libera %d valles para desbloquearla.") % int(md["valles"])
		var pm: Dictionary = Datos.PODER_MONTURA.get(str(md["id"]), {}) as Dictionary
		if not bloqueada and str(pm.get("nombre", "")) != "":
			txt += "\n" + Idioma.t("Poder: %s — %s") % [Idioma.t(str(pm["nombre"])), Idioma.t(str(pm["texto"]))]
		var l2: Label = Estilo.etiqueta("%s
%s" % [Idioma.t(str(md["nombre"])), txt], 20, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_LEFT, true)
		l2.custom_minimum_size = Vector2(470 if mid != "" else 560, 0)
		fila2.add_child(l2)
		var montada: bool = Estado.montura() == mid
		var tiene: bool = Estado.tiene_montura(mid)
		var b2: Button = Estilo.boton(Idioma.t("Montada") if montada else Idioma.t("Montar") if tiene else "◆ %d" % int(md["coste"]), false, 60)
		b2.custom_minimum_size = Vector2(150, 60)
		b2.disabled = montada or bloqueada or (not tiene and Estado.n("fragmentos") < int(md["coste"]))
		b2.pressed.connect(func() -> void:
			if Estado.elegir_montura(mid):
				Audio.play("ui_reward")
				if mid != "" and Estado.logro("montura").size() > 0:
					pass
				_cerrar()
				abrir_altar())
		fila2.add_child(b2)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 64)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_logros() -> void:
	_modal = Estilo.modal(self, Idioma.t("Logros"), 860.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var sc: ScrollContainer = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(780, 470)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var lista: VBoxContainer = VBoxContainer.new()
	lista.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(lista)
	var tengo: Array = Estado.d["logros"] as Array
	for l: Variant in Datos.LOGROS:
		var d: Dictionary = l as Dictionary
		var hecho: bool = tengo.has(str(d["id"]))
		lista.add_child(Estilo.etiqueta(("✓ " if hecho else "· ") + Idioma.t(str(d["nombre"])) + " — " + Idioma.t(str(d["texto"])) + "   ◆%d" % int(d["premio"]), 20,
			Estilo.VERDE if hecho else Estilo.NIEBLA, HORIZONTAL_ALIGNMENT_LEFT, true))
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 64)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


func abrir_tienda() -> void:
	_modal = Estilo.modal(self, Idioma.t("Tienda"), 620.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	var ps: Dictionary = Store.products()
	for id: Variant in ps.keys():
		var pid: String = str(id)
		var kind: String = str((ps[pid] as Dictionary).get("kind", ""))
		if kind in ["pass", "vip"] or Store.owns(pid) or (kind in ["no_ads", "bundle"] and Store.no_ads()):
			continue
		var b: Button = Estilo.boton("%s   ·   %s" % [Idioma.t(Store.label(pid)), Store.price(pid)], false, 72)
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(func() -> void: Store.buy(pid))
		vb.add_child(b)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), true, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)


## v8: el reto de la luna. Uno al día, el mismo para todos; la racha da más fragmentos.
func abrir_reto() -> void:
	var r: Dictionary = Estado.reto_hoy()
	var m: Dictionary = r["mod"] as Dictionary
	_modal = Estilo.modal(self, Idioma.t("Reto de la luna"), 760.0)
	var vb: VBoxContainer = _modal["vb"] as VBoxContainer
	vb.add_child(Estilo.etiqueta(Idioma.t(str(m["nombre"])), 34, Estilo.ORO))
	var t: Label = Estilo.etiqueta(Idioma.t(str(m["texto"])), 22, Estilo.TEXTO, HORIZONTAL_ALIGNMENT_CENTER, true)
	t.custom_minimum_size = Vector2(680, 0)
	vb.add_child(t)
	vb.add_child(Estilo.etiqueta(Idioma.t("Valle: %s   ·   Aguanta %d noches") % [Idioma.t(str((Datos.VALLES[int(r["valle"])] as Dictionary)["nombre"])), Datos.RETO_NOCHES], 22, Estilo.NIEBLA))
	var racha: int = Estado.racha_reto()
	vb.add_child(Estilo.etiqueta(Idioma.t("Racha: %d días   ·   Premio: %d fragmentos") % [racha, 3 + mini(racha, 4)], 22, Estilo.ORO))
	if Estado.reto_hecho():
		vb.add_child(Estilo.etiqueta(Idioma.t("Hoy ya lo has superado. Puedes repetirlo por gusto."), 20, Estilo.VERDE))
	var bj: Button = Estilo.boton(Idioma.t("Aceptar el reto"), true, 84)
	bj.pressed.connect(func() -> void:
		Estado.partida = {"nuevo": true, "reto": true}
		Kit.change_scene(JUEGO))
	vb.add_child(bj)
	var bc: Button = Estilo.boton(Idioma.t("Cerrar"), false, 70)
	bc.pressed.connect(_cerrar)
	vb.add_child(bc)

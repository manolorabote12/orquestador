class_name Atmosfera
extends RefCounted
## Luna v7, «Atmósfera»: el valle por zonas como en los grandes juegos de reinos. Del pueblo salen prados
## verdes, luego un bosque claro con rayos de sol y el bosque profundo que se va oscureciendo; pasada la grieta,
## el lago, los acantilados con montañas gigantes al fondo y el bosque antiguo con ruinas. Cada zona tiene su
## capa pintada de fondo, su decorado, su fauna y su luz. Se dibuja desde juego.gd (j) con sus funciones.

## Zonas a lo largo del camino (distancia al centro, igual a los dos lados).
const ZONAS: Array = [
	{"id": "pueblo", "desde": 0.0},
	{"id": "prado", "desde": 700.0},
	{"id": "bosque", "desde": 2000.0},
	{"id": "profundo", "desde": 2700.0},
	{"id": "lago", "desde": 3700.0},
	{"id": "montana", "desde": 5300.0},
	{"id": "antiguo", "desde": 7600.0},
]

## Qué capa pintada de fondo (lr_bio_*) va en cada zona y en qué valles encaja (no hay prados en el desierto).
const CAPA_ZONA: Dictionary = {
	"prado": "lr_bio_prado_medio", "bosque": "lr_bio_bosque_medio", "profundo": "lr_bio_bosque_medio",
	"lago": "lr_bio_lago_lejos", "montana": "lr_bio_montana_medio", "antiguo": "lr_bio_antiguo_medio",
}
const ZONAS_VALLE: Dictionary = {
	"ciervo": ["prado", "bosque", "profundo", "lago", "montana", "antiguo"],
	"cienaga": ["bosque", "profundo", "lago", "antiguo"],
	"ceniza": ["montana", "antiguo"],
	"nieve": ["bosque", "profundo", "lago", "montana"],
	"desierto": ["montana"],
	"ruinas": ["bosque", "profundo", "montana", "antiguo"],
}
## Tinte de las capas de zona en cada valle (que el prado del pantano sea verdoso y el de la nieve, frío).
const TINTE_VALLE: Dictionary = {
	"ciervo": Color(1, 1, 1), "cienaga": Color(0.75, 0.9, 0.8), "ceniza": Color(0.85, 0.6, 0.55),
	"nieve": Color(0.85, 0.92, 1.1), "desierto": Color(1.1, 0.85, 0.6), "ruinas": Color(0.8, 0.78, 0.9),
}
## Decorado de cada zona: [id, alto en pantalla, densidad (1 = uno cada ~600 px)].
const DECOR: Dictionary = {
	"prado": [["lr_d_flores", 70.0, 1.6], ["lr_d_roca_musgo", 90.0, 0.6], ["lr_d_carro", 110.0, 0.25], ["lr_d_espantapajaros", 170.0, 0.25],
		["lr_d_colmenas", 100.0, 0.25], ["lr_d_valla", 70.0, 0.5], ["lr_d_pozo", 160.0, 0.15], ["lr_d_pajar", 110.0, 0.35]],
	"bosque": [["lr_d_arbusto", 90.0, 1.0], ["lr_d_tocon", 70.0, 0.6], ["lr_d_tronco", 70.0, 0.5], ["lr_d_setas", 60.0, 0.5],
		["lr_d_tienda", 120.0, 0.12], ["lr_d_arbol_gigante", 520.0, 0.25]],
	"profundo": [["lr_d_arbol_gigante", 560.0, 0.5], ["lr_d_setas", 70.0, 1.2], ["lr_d_tronco", 80.0, 0.6], ["lr_d_huesos", 70.0, 0.3],
		["lr_d_arbusto", 100.0, 0.8], ["lr_d_cristales", 90.0, 0.3]],
	"lago": [["lr_d_juncos", 110.0, 1.4], ["lr_d_barca", 70.0, 0.2], ["lr_d_embarcadero", 90.0, 0.15], ["lr_d_roca_musgo", 80.0, 0.5],
		["lr_d_pino", 420.0, 0.4]],
	"montana": [["lr_d_pino", 460.0, 0.8], ["lr_d_roca_grande", 180.0, 0.6], ["lr_d_cascada", 420.0, 0.15], ["lr_d_puente", 110.0, 0.12],
		["lr_d_menhir", 190.0, 0.25]],
	"antiguo": [["lr_d_arbol_gigante", 600.0, 0.5], ["lr_d_columna", 220.0, 0.6], ["lr_d_arco", 260.0, 0.3], ["lr_d_estatua_caida", 120.0, 0.3],
		["lr_d_tumba", 100.0, 0.5], ["lr_d_altar_cristal", 150.0, 0.2], ["lr_d_farol_piedra", 120.0, 0.4], ["lr_d_menhir", 200.0, 0.3],
		["lr_d_cristales", 100.0, 0.4]],
	"pueblo": [["lr_d_antorcha", 150.0, 0.5], ["lr_d_carro_mercader", 130.0, 0.15], ["lr_d_pajar", 100.0, 0.3]],
}
## Decorados que dan luz de noche (y su color).
const LUZ_DECOR: Dictionary = {
	"lr_d_setas": Color(0.4, 0.75, 1.0), "lr_d_cristales": Color(0.8, 0.45, 1.0), "lr_d_altar_cristal": Color(0.4, 0.8, 1.0),
	"lr_d_farol_piedra": Color(1.0, 0.75, 0.4), "lr_d_antorcha": Color(1.0, 0.6, 0.25), "lr_d_menhir": Color(0.45, 1.0, 0.8),
}

var decor: Array = []
var fauna: Array = []
var vid: String = "ciervo"


static func zona_en(x: float) -> String:
	var ax: float = absf(x)
	var z: String = "pueblo"
	for zd: Variant in ZONAS:
		if ax >= float((zd as Dictionary)["desde"]):
			z = str((zd as Dictionary)["id"])
	return z


## Peso (0..1) de una zona en una x: transición suave de 500 px entre zonas.
static func peso_zona(x: float, z: String) -> float:
	var ax: float = absf(x)
	for i: int in ZONAS.size():
		var zd: Dictionary = ZONAS[i] as Dictionary
		if str(zd["id"]) != z:
			continue
		var a: float = float(zd["desde"])
		var b: float = float((ZONAS[i + 1] as Dictionary)["desde"]) if i + 1 < ZONAS.size() else 99999.0
		return clampf((ax - a + 250.0) / 500.0, 0.0, 1.0) * clampf((b - ax + 250.0) / 500.0, 0.0, 1.0)
	return 0.0


## Oscuridad propia del lugar (de día también): el bosque profundo y el antiguo son sombríos.
static func sombra_lugar(x: float) -> float:
	return 0.5 * peso_zona(x, "profundo") + 0.38 * peso_zona(x, "antiguo") + 0.12 * peso_zona(x, "bosque")


## Reparte el decorado y la fauna al empezar el valle (siempre igual en el mismo valle).
func preparar(valle_id: String, borde: float, evitar: Array) -> void:
	vid = valle_id
	decor.clear()
	fauna.clear()
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = hash(valle_id) + 77
	var permitidas: Array = (ZONAS_VALLE.get(vid, []) as Array) + ["pueblo"]
	for lado: int in [-1, 1]:
		var x: float = 250.0
		while x < borde - 100.0:
			var z: String = zona_en(x)
			x += r.randf_range(110.0, 260.0)
			if not permitidas.has(z):
				continue
			var cerca: bool = false
			for e: Variant in evitar:
				if absf(absf(x) - float(e)) < 140.0:
					cerca = true
			if cerca:
				continue
			for dd: Variant in DECOR.get(z, []) as Array:
				var da: Array = dd as Array
				if r.randf() < float(da[2]) * 0.22:
					decor.append({"id": str(da[0]), "x": x * lado + r.randf_range(-30, 30), "alto": float(da[1]) * r.randf_range(0.85, 1.15),
						"flip": r.randf() < 0.5, "fondo": float(da[1]) > 300.0 or r.randf() < 0.35})
					break
			## Fauna: cuervos en prados y bosques, conejos en el prado, garzas... y peces en el agua del lago.
			if r.randf() < 0.06 and z in ["prado", "bosque", "lago", "montana"]:
				fauna.append({"tipo": "cuervo", "x": x * lado, "y": 0.0, "vuela": false, "t": r.randf() * 5.0, "dir": lado})
			if r.randf() < 0.04 and z in ["prado", "bosque"]:
				fauna.append({"tipo": "conejo", "x": x * lado, "y": 0.0, "huye": 0.0, "t": r.randf() * 5.0, "dir": -lado})
	decor.sort_custom(func(a: Variant, b: Variant) -> bool: return bool((a as Dictionary)["fondo"]) and not bool((b as Dictionary)["fondo"]))


# ------------------------------------------------------------------ dibujo

## Montañas gigantes al fondo (detrás de todo) y la capa de la zona por la que pasa la cámara.
func fondo(j: Node2D, aire: Color, noche: float) -> void:
	var t: Color = TINTE_VALLE.get(vid, Color.WHITE) as Color
	var amb: Color = j.get("_amb") as Color
	var cam: float = float(j.get("cam"))
	var S: float = Datos.SUELO
	## Montañas: lo que más impresiona al salir del bosque.
	var wm: float = 0.35 + 0.65 * maxf(peso_zona(cam, "montana"), peso_zona(cam, "lago"))
	if (ZONAS_VALLE.get(vid, []) as Array).has("montana"):
		var mc: Color = Color(t.r * amb.r, t.g * amb.g, t.b * amb.b).lerp(aire, 0.45)
		mc.a = wm
		j.call("_capa_pintada", "lr_bio_montana_lejos", 0.05, 460.0, S - 60.0, mc)


func zona_medio(j: Node2D, noche: float) -> void:
	var t: Color = TINTE_VALLE.get(vid, Color.WHITE) as Color
	var amb: Color = j.get("_amb") as Color
	var cam: float = float(j.get("cam"))
	var S: float = Datos.SUELO
	var vistas: Dictionary = {}
	for z: Variant in ZONAS_VALLE.get(vid, []) as Array:
		var id: String = str(CAPA_ZONA.get(str(z), ""))
		var w: float = peso_zona(cam, str(z))
		if id == "" or w <= 0.01:
			continue
		vistas[id] = maxf(float(vistas.get(id, 0.0)), w)
	for id: Variant in vistas.keys():
		var oscuro: float = 0.15 + 0.25 * noche + (0.25 if str(id) == "lr_bio_bosque_medio" and peso_zona(cam, "profundo") > 0.3 else 0.0)
		var c: Color = Color(t.r * amb.r, t.g * amb.g, t.b * amb.b).darkened(oscuro)
		c.a = float(vistas[id])
		j.call("_capa_pintada", str(id), 0.5, 340.0 if str(id) != "lr_bio_lago_lejos" else 260.0, S + 12.0, c)


## Rayos de sol entre los árboles (de día, en el bosque).
func rayos(j: Node2D, noche: float) -> void:
	var cam: float = float(j.get("cam"))
	var w: float = maxf(peso_zona(cam, "bosque"), peso_zona(cam, "profundo") * 0.8) * (1.0 - noche)
	if w <= 0.02:
		return
	var tiempo: float = float(j.get("tiempo"))
	for i: int in 6:
		var x0: float = fposmod(i * 263.0 - cam * 0.3, 1600.0) - 160.0
		var a: float = (0.05 + 0.03 * sin(tiempo * 0.6 + i * 1.7)) * w
		j.draw_colored_polygon(PackedVector2Array([Vector2(x0, -20), Vector2(x0 + 70, -20), Vector2(x0 + 260, Datos.SUELO), Vector2(x0 + 120, Datos.SUELO)]),
			Color(1.0, 0.93, 0.7, a))


func dibujar_decor(j: Node2D, delante: bool) -> void:
	var cam: float = float(j.get("cam"))
	var noche: float = float(j.call("_oscuridad"))
	var tinte: Color = TINTE_VALLE.get(vid, Color.WHITE) as Color
	for dd: Variant in decor:
		var d: Dictionary = dd as Dictionary
		if bool(d["fondo"]) == delante:
			continue
		var x: float = float(d["x"])
		if absf(x - cam) > 900.0:
			continue
		var id: String = str(d["id"])
		if (j.get("_tex") as Dictionary).get(id) == null:
			continue
		var col: Color = tinte.darkened((0.3 if bool(d["fondo"]) else 0.05) + sombra_lugar(x) * 0.4)
		## Lo que brilla se dibuja con su halo (de noche se nota mucho).
		if LUZ_DECOR.has(id):
			var lc: Color = LUZ_DECOR[id] as Color
			var sx: float = j.call("_sx", x)
			var r: float = float(d["alto"]) * 0.6
			j.draw_circle(Vector2(sx, Datos.SUELO - float(d["alto"]) * 0.55), r, Color(lc, 0.08 + 0.22 * noche))
			col = Color(1.15, 1.1, 1.1)
		j.call("_sprite", id, x, float(d["alto"]), bool(d["flip"]), col)


## Primer plano: ramas que cuelgan y hierba alta que pasan por delante (más rápido que el mundo).
func primer_plano(j: Node2D, noche: float) -> void:
	var cam: float = float(j.get("cam"))
	var S: float = Datos.SUELO
	var oscuro: Color = Color(0.08, 0.07, 0.09).lerp(Color(0.02, 0.02, 0.05), noche)
	var wb: float = maxf(peso_zona(cam, "bosque"), maxf(peso_zona(cam, "profundo"), peso_zona(cam, "antiguo")))
	if wb > 0.02:
		var tx: Texture2D = (j.get("_tex") as Dictionary).get("lr_cerca_ramas") as Texture2D
		if tx != null:
			var c: Color = oscuro
			c.a = 0.92 * wb
			_franja(j, tx, cam * 1.35, 0.0, 230.0, c, false)
	var hierba: String = "lr_cerca_juncos" if peso_zona(cam, "lago") > 0.5 else ("lr_cerca_helechos" if wb > 0.5 else "lr_cerca_hierba")
	var th: Texture2D = (j.get("_tex") as Dictionary).get(hierba) as Texture2D
	if th != null and (ZONAS_VALLE.get(vid, []) as Array).size() > 1:
		var c2: Color = oscuro.lerp(Color(0.18, 0.2, 0.12), 0.4 * (1.0 - noche))
		c2.a = 0.95 * (1.0 - peso_zona(cam, "pueblo"))
		_franja(j, th, cam * 1.5, float(j.get("ALTO")) - 120.0, 130.0, c2, true)


func _franja(j: Node2D, tx: Texture2D, off: float, y: float, alto: float, c: Color, pie: bool) -> void:
	if c.a <= 0.01:
		return
	var ts: Vector2 = tx.get_size()
	var ancho: float = alto * ts.x / ts.y
	var x0: float = -fposmod(off, ancho)
	while x0 < 1400.0:
		j.draw_texture_rect(tx, Rect2(x0, y, ancho + 1.0, alto), false, c)
		x0 += ancho


## Cuervos que levantan el vuelo cuando pasa la reina y conejos que huyen.
func fauna_paso(j: Node2D, dt: float) -> void:
	var rx: float = float((j.get("reina") as Dictionary)["x"])
	for ff: Variant in fauna:
		var f: Dictionary = ff as Dictionary
		f["t"] = float(f["t"]) + dt
		match str(f["tipo"]):
			"cuervo":
				if not bool(f["vuela"]) and absf(float(f["x"]) - rx) < 230.0:
					f["vuela"] = true
					f["vx"] = signf(float(f["x"]) - rx) * randf_range(160.0, 240.0)
					if not bool(j.get("bot")):
						Audio.play("ui_swoosh", 0.3, -16.0, 1.6)
				if bool(f["vuela"]):
					f["x"] = float(f["x"]) + float(f["vx"]) * dt
					f["y"] = float(f["y"]) - 140.0 * dt
					if float(f["y"]) < -700.0:
						## Vuelve a posarse lejos, para la próxima vez.
						f["vuela"] = false
						f["y"] = 0.0
						f["x"] = float(f["x"]) + signf(float(f["vx"])) * 900.0
			"conejo":
				if absf(float(f["x"]) - rx) < 260.0:
					f["huye"] = 1.5
					f["dir"] = int(signf(float(f["x"]) - rx))
				if float(f["huye"]) > 0.0:
					f["huye"] = float(f["huye"]) - dt
					f["x"] = float(f["x"]) + int(f["dir"]) * 260.0 * dt


func dibujar_fauna(j: Node2D) -> void:
	var cam: float = float(j.get("cam"))
	var S: float = Datos.SUELO
	for ff: Variant in fauna:
		var f: Dictionary = ff as Dictionary
		var x: float = float(f["x"])
		if absf(x - cam) > 800.0:
			continue
		match str(f["tipo"]):
			"cuervo":
				var aleteo: float = absf(sin(float(f["t"]) * 16.0)) if bool(f["vuela"]) else 1.0
				var esc: Vector2 = Vector2(1.0, 0.45 + 0.55 * aleteo) if bool(f["vuela"]) else Vector2(0.8, 0.8)
				j.call("_sprite", "lr_f_pajaro", x, 34.0, float(f.get("vx", -1.0)) < 0.0, Color.WHITE, S + 2.0 + float(f["y"]) - (0.0 if bool(f["vuela"]) else absf(sin(float(f["t"]) * 2.0)) * 2.0), 0.0, esc)
			"conejo":
				if (j.get("_tex") as Dictionary).get("lr_f_conejo") == null:
					continue
				var salto: float = absf(sin(float(f["t"]) * 12.0)) * 18.0 if float(f["huye"]) > 0.0 else 0.0
				j.call("_sprite", "lr_f_conejo", x, 34.0, int(f["dir"]) < 0, Color.WHITE, S + 2.0 - salto)


## De noche: búhos en las ramas, murciélagos en el bosque y ojos rojos entre los árboles del bosque profundo.
func noche_viva(j: Node2D, noche: float) -> void:
	if noche < 0.2:
		return
	var cam: float = float(j.get("cam"))
	var tiempo: float = float(j.get("tiempo"))
	var S: float = Datos.SUELO
	var wb: float = maxf(peso_zona(cam, "profundo"), peso_zona(cam, "antiguo"))
	if wb > 0.05:
		for i: int in 9:
			var ex: float = fposmod(i * 311.0 - cam * 0.6, 1500.0) - 100.0
			var ey: float = S - 90.0 - fposmod(i * 53.0, 160.0)
			var parpadeo: float = 1.0 if fmod(tiempo + i * 1.3, 5.0) > 0.25 else 0.0
			var a: float = noche * wb * parpadeo * (0.5 + 0.5 * sin(tiempo * 0.7 + i))
			j.draw_circle(Vector2(ex, ey), 2.6, Color(1.0, 0.15, 0.1, a))
			j.draw_circle(Vector2(ex + 11.0, ey), 2.6, Color(1.0, 0.15, 0.1, a))
			j.draw_circle(Vector2(ex + 5.5, ey), 12.0, Color(1.0, 0.1, 0.05, a * 0.12))
		var tm: Texture2D = (j.get("_tex") as Dictionary).get("lr_f_murcielago") as Texture2D
		if tm != null:
			for i: int in 5:
				var bx: float = fposmod(tiempo * (90.0 + i * 25.0) + i * 300.0, 1500.0) - 100.0
				var by: float = 180.0 + i * 40.0 + sin(tiempo * 3.0 + i) * 40.0
				var al: float = 0.5 + 0.5 * absf(sin(tiempo * 14.0 + i))
				j.draw_texture_rect(tm, Rect2(bx, by, 46.0, 30.0 * al), false, Color(0.5, 0.45, 0.55, noche * wb))

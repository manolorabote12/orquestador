extends RefCounted
## Bot de Bajo la Luna Roja: juega el valle de verdad sin pantalla. Cabalga hasta el sitio que más falta
## hace, paga, recoge brasas del suelo y por la noche se queda junto al fuego. Asalta las grietas cuando
## tiene soldados. Dice cuántos días tarda en liberar cada valle y de qué cae.

const MAX_DIAS: int = 45


static func jugar(tree: SceneTree) -> Dictionary:
	var res: Array = []
	var t0: int = Time.get_ticks_msec()
	for v: int in 6:
		for intento: int in 1:
			## Mejoras del Altar que tendría un jugador real al llegar a ese valle (por fragmentos ganados antes).
			Estado.d["mejoras"] = {} if v < 3 else {"bolsa": 1, "inicio": 2, "farol": 1, "muros": 2, "fuerza_heroes": 1, "arqueros": 1}
			Estado.partida = {"bot": true, "semilla": 500 + v * 13 + intento * 7, "valle": v}
			tree.change_scene_to_file("res://libre/juego.tscn")
			for _i: int in 3:
				await tree.process_frame
			var j: Node = tree.current_scene
			if j == null or not j.has_method("paso"):
				return {"ok": false, "error": "no cargo el valle"}
			var pasos: int = 0
			while bool(j.get("vivo")) and not bool(j.get("ganado")) and int(j.get("dia")) <= MAX_DIAS:
				if pasos % 2 == 0:
					_decidir(j)
				j.call("paso", 1.0 / 30.0)
				pasos += 1
				if pasos % 900 == 0:
					await tree.process_frame
			var st: Dictionary = j.get("stats") as Dictionary
			res.append({"valle": v, "ganado": bool(j.get("ganado")), "dias": int(j.get("dia")), "causa": str(j.get("causa")),
				"gente": (j.get("gente") as Array).size(), "abatidas": int(st["abatidas"]), "obras": int(st["construidos"]), "perdidos": int(st["perdidos"])})
	var ganados: int = res.filter(func(r: Variant) -> bool: return bool((r as Dictionary)["ganado"])).size()
	return {"ok": ganados >= 4, "partidas": res, "ganados": ganados, "segundos": (Time.get_ticks_msec() - t0) / 1000.0}


static func _ir(j: Node, x: float) -> bool:
	var rx: float = float((j.get("reina") as Dictionary)["x"])
	if absf(rx - x) < 45.0:
		j.call("mover", 0)
		return true
	j.call("mover", 1 if x > rx else -1)
	return false


static func _decidir(j: Node) -> void:
	var fase: String = str(j.get("fase"))
	var rx: float = float((j.get("reina") as Dictionary)["x"])
	var brasas: int = int(j.get("brasas"))
	## De noche: al fuego, y habilidades si las sombras se acercan.
	if fase == "noche" or fase == "tarde" and float(j.get("t_fase")) > 4.0:
		_ir(j, 0.0)
		var cerca: int = 0
		for c: Variant in (j.get("criaturas") as Array):
			if absf(float((c as Dictionary)["x"]) - rx) < 300.0:
				cerca += 1
		if cerca > 0:
			j.call("destello")
		if (j.get("criaturas") as Array).size() > 6:
			j.call("cuerno")
		return
	## Brasas por el suelo cerca: a por ellas.
	for b: Variant in (j.get("suelo_brasas") as Array):
		var bx: float = float((b as Dictionary)["x"])
		if absf(bx - rx) < 600.0 and int(j.get("brasas")) < 40:
			_ir(j, bx)
			return
	var obj: Dictionary = _objetivo(j, brasas)
	if obj.is_empty():
		_ir(j, 0.0)
		return
	if _ir(j, float(obj["x"])):
		j.call("accion")


static func _sitio(j: Node, tipo: String, lado: int = 0) -> Dictionary:
	for s: Variant in (j.get("sitios") as Array):
		var d: Dictionary = s as Dictionary
		if str(d["tipo"]) == tipo and (lado == 0 or int(d["lado"]) == lado):
			return d
	return {}


static func _puede(j: Node, s: Dictionary, brasas: int) -> bool:
	if s.is_empty():
		return false
	var o: Dictionary = j.call("opcion", s) as Dictionary
	return not o.is_empty() and int(o["coste"]) >= 0 and int(o["coste"]) <= brasas


static func _objetivo(j: Node, brasas: int) -> Dictionary:
	var dia: int = int(j.get("dia"))
	var aldeanos: int = int(j.call("contar", "aldeano"))
	var herr: Dictionary = j.get("herramientas") as Dictionary
	var herr_total: int = 0
	for k: String in herr.keys():
		herr_total += int(herr[k])
	var hog: int = int(j.call("nivel_hoguera"))
	var lista: Array = []
	## 1. Gente
	if aldeanos + herr_total < 2:
		for lado: int in [-1, 1]:
			lista.append(_sitio(j, "campamento", lado))
	## 2. Herramientas para los aldeanos que esperan
	if aldeanos > herr_total:
		var cons: int = int(j.call("contar", "constructor"))
		var arq: int = int(j.call("contar", "arquero"))
		var gra: int = int(j.call("contar", "granjero"))
		var lan: int = int(j.call("contar", "lancero"))
		var granjas: int = (j.get("sitios") as Array).filter(func(s: Variant) -> bool: return str((s as Dictionary)["tipo"]) == "granja" and int((s as Dictionary)["nivel"]) > 0).size()
		if cons < 2 or (cons < 3 and dia > 5):
			lista.append(_sitio(j, "tienda_constructor"))
		elif gra < granjas:
			lista.append(_sitio(j, "tienda_granjero"))
		elif hog >= 3 and lan < arq / 2 + 1:
			lista.append(_sitio(j, "tienda_lancero"))
		else:
			lista.append(_sitio(j, "tienda_arquero"))
	## 3. Cofres al principio
	for lado: int in [-1, 1]:
		var c: Dictionary = _sitio(j, "cofre", lado)
		if not c.is_empty() and not bool(c["abierto"]) and brasas < 10:
			lista.append(c)
	## 4. Obras por orden: muros, hoguera, granjas, torres, más muros
	var orden: Array = []
	for s: Variant in (j.get("sitios") as Array):
		var d: Dictionary = s as Dictionary
		var t: String = str(d["tipo"])
		var prio: float = 99.0
		match t:
			"muro":
				prio = 1.0 + absf(float(d["x"])) / 600.0 + int(d["nivel"]) * 2.5
				if int(d["nivel"]) > 0 and float(d["hp"]) < 0.5 * float([0.0, 40.0, 110.0, 220.0][int(d["nivel"])]):
					prio = 0.5
			"hoguera":
				prio = 2.5 + int(d["nivel"]) * 3.0
			"granja":
				prio = 3.0
			"torre":
				prio = 4.0 + absf(float(d["x"])) / 800.0
			"santuario":
				prio = 2.2
			"catapulta":
				prio = 3.6
			"grieta":
				if dia >= 6 and str(j.get("fase")) == "dia" and float(j.get("t_fase")) < 25.0:
					prio = 0.8
		if prio < 99.0:
			orden.append([prio, d])
	orden.sort_custom(func(a: Variant, b: Variant) -> bool: return float((a as Array)[0]) < float((b as Array)[0]))
	for o: Variant in orden:
		lista.append((o as Array)[1])
	if j.get("mercader") and brasas >= 8:
		lista.push_front({"tipo": "mercader", "x": 90.0})
	for s: Variant in lista:
		var d2: Dictionary = s as Dictionary
		if d2.is_empty():
			continue
		if str(d2["tipo"]) == "mercader" or _puede(j, d2, brasas):
			return d2
	return {}

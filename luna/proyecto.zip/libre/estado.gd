class_name Estado
extends RefCounted
## Guardado de Bajo la Luna Roja: valle en curso, partida al último amanecer, récords y ajustes.

const CLAVE: String = "luna"

static var d: Dictionary = {}
static var _cargado: bool = false
## Paso entre escenas: {"nuevo": true} empieza el valle de cero; {"bot": true, "semilla": n} para el bot.
static var partida: Dictionary = {}


static func cargar() -> void:
	if _cargado:
		return
	_cargado = true
	Idioma.iniciar()
	var v: Variant = Save.get_setting(CLAVE, {})
	d = (v as Dictionary).duplicate(true) if v is Dictionary else {}
	var base: Dictionary = {"valle": 0, "valles_ganados": 0, "mejor_noche": 0, "eterna_record": 0, "guardada": {}, "consejos": {},
		"partidas": 0, "noches_total": 0, "jefes": 0, "regalo": -1,
		"fragmentos": 0, "mejoras": {}, "logros": [], "abatidas_total": 0}
	for k: String in base.keys():
		if not d.has(k):
			d[k] = base[k]


static func guardar() -> void:
	Save.set_setting(CLAVE, d)


static func n(k: String) -> int:
	return int(d.get(k, 0))


static func dia_de_hoy() -> int:
	var t: Dictionary = Time.get_date_dict_from_system()
	return int(t["year"]) * 10000 + int(t["month"]) * 100 + int(t["day"])


static func hay_guardada() -> bool:
	return not (d["guardada"] as Dictionary).is_empty()


## Valle del modo campaña (0..2) o 3 = Luna eterna (sin fin).
static func valle_actual() -> int:
	return n("valle")


static func mejora(id: String) -> int:
	return int((d["mejoras"] as Dictionary).get(id, 0))


static func coste_mejora(id: String) -> int:
	var c: Array = (Datos.MEJORAS[id] as Dictionary)["costes"] as Array
	return -1 if mejora(id) >= c.size() else int(c[mejora(id)])


static func comprar_mejora(id: String) -> bool:
	var c: int = coste_mejora(id)
	if c < 0 or n("fragmentos") < c:
		return false
	d["fragmentos"] = n("fragmentos") - c
	(d["mejoras"] as Dictionary)[id] = mejora(id) + 1
	guardar()
	return true


## Logro: si es nuevo, lo marca, da fragmentos y devuelve su ficha (o {}).
static func logro(id: String) -> Dictionary:
	if (d["logros"] as Array).has(id):
		return {}
	for l: Variant in Datos.LOGROS:
		if str((l as Dictionary)["id"]) == id:
			(d["logros"] as Array).append(id)
			d["fragmentos"] = n("fragmentos") + int((l as Dictionary)["premio"])
			guardar()
			return l as Dictionary
	return {}


static func ganar_valle() -> void:
	d["valles_ganados"] = maxi(n("valles_ganados"), n("valle") + 1)
	d["valle"] = mini(n("valle") + 1, Datos.VALLES.size())
	d["guardada"] = {}
	guardar()


## Compras con dinero real (tienda del kit) llegan al monedero: se guardan como brasas de reserva.
static func cobrar_monedero() -> int:
	var w: int = Save.wallet()
	if w <= 0:
		return 0
	Save.add_wallet(-w)
	d["reserva"] = n("reserva") + w
	guardar()
	return w

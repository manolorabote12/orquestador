class_name Datos
extends RefCounted
## Bajo la Luna Roja: valles, lunas, criaturas, oficios y sitios donde construir.

## Duración de cada parte del día (segundos de juego).
const T_DIA: float = 75.0
const T_TARDE: float = 10.0
const T_NOCHE: float = 55.0
const T_ALBA: float = 6.0

const SUELO: float = 600.0
const BORDE: float = 7400.0
## Las grietas están a medio camino: más allá queda tierra salvaje (lagos, ruinas, monumentos, cofres).
const X_GRIETA: float = 3450.0

## Valles de la campaña: cada uno con su paisaje y criaturas más duras.
const VALLES: Array = [
	{"id": "ciervo", "nombre": "El Valle del Ciervo", "tinte": Color(1, 1, 1), "suelo": Color("2b2a1e"), "hierba": Color("4f6b33"),
		"fuerza": 1.0, "brasas": 12, "texto": "Un valle verde, un fuego y una corona. Las sombras todavía no saben que has llegado."},
	{"id": "cienaga", "nombre": "La Ciénaga Gris", "tinte": Color(0.82, 0.9, 0.86), "suelo": Color("23271f"), "hierba": Color("3d5644"),
		"fuerza": 1.42, "brasas": 14, "texto": "La niebla tapa las grietas. Aquí las sombras salen antes y vuelven más."},
	{"id": "ceniza", "nombre": "Los Picos de Ceniza", "tinte": Color(1.0, 0.86, 0.8), "suelo": Color("2a1f1c"), "hierba": Color("5a4334"),
		"fuerza": 1.95, "brasas": 16, "texto": "Aquí nació la Luna Roja. Cierra las dos grietas y el valle volverá a dormir."},
	{"id": "nieve", "nombre": "El Bosque Helado", "tinte": Color(0.88, 0.94, 1.08), "suelo": Color("d8dde6"), "hierba": Color("eef3fa"),
		"fuerza": 1.95, "brasas": 20, "texto": "La nieve no deja huellas. Los lobos de escarcha cazan en manada."},
	{"id": "desierto", "nombre": "El Cañón Dorado", "tinte": Color(1.08, 0.98, 0.86), "suelo": Color("8a6a3c"), "hierba": Color("a8864a"),
		"fuerza": 2.2, "brasas": 22, "texto": "Bajo la arena duermen escorpiones de sombra. De noche, despiertan."},
	{"id": "ruinas", "nombre": "Las Ruinas del Rey", "tinte": Color(0.9, 0.86, 1.02), "suelo": Color("2b2733"), "hierba": Color("3f4a3a"),
		"fuerza": 2.5, "brasas": 24, "texto": "Aquí cayó el último rey. Sus espectros todavía defienden el castillo, pero no a ti."},
]

## Lunas: cambian cada noche. «roja» toca cada 5 noches.
const LUNAS: Dictionary = {
	"llena": {"nombre": "Luna llena", "texto": "Más sombras, pero tus arqueros ven más lejos.", "cantidad": 1.3, "vista": 1.25, "oscuridad": 0.62, "color": Color("dfe6ff")},
	"nueva": {"nombre": "Luna nueva", "texto": "Noche cerrada: no verás las sombras hasta tenerlas encima.", "cantidad": 1.0, "vista": 0.75, "oscuridad": 0.86, "color": Color("3a3f55")},
	"creciente": {"nombre": "Luna creciente", "texto": "Una noche normal. O eso parece.", "cantidad": 1.0, "vista": 1.0, "oscuridad": 0.72, "color": Color("f2e6b8")},
	"azul": {"nombre": "Luna azul", "texto": "Noche tranquila. Un mercader fantasma ronda el valle.", "cantidad": 0.5, "vista": 1.1, "oscuridad": 0.66, "color": Color("8fc4ff")},
	"roja": {"nombre": "Luna roja", "texto": "La gran marea de sombras. Y algo enorme viene con ellas.", "cantidad": 2.2, "vista": 1.0, "oscuridad": 0.7, "color": Color("ff3b3b")},
}

## Criaturas: vida, daño, velocidad (px/s), alto al dibujar. «vuela» pasa por encima de los muros.
const CRIATURAS: Dictionary = {
	"sombra": {"hp": 7.0, "dano": 2.0, "vel": 95.0, "alto": 74.0, "tex": "lr_sombra", "desde": 1},
	"ahogado": {"hp": 11.0, "dano": 3.0, "vel": 75.0, "alto": 98.0, "tex": "lr_ahogado", "desde": 1},
	"golem": {"hp": 75.0, "dano": 14.0, "vel": 45.0, "alto": 170.0, "tex": "lr_golem", "desde": 4},
	"lobo": {"hp": 9.0, "dano": 3.0, "vel": 118.0, "alto": 80.0, "tex": "lr_lobo", "desde": 1},
	"escorpion": {"hp": 55.0, "dano": 11.0, "vel": 70.0, "alto": 100.0, "tex": "lr_escorpion", "desde": 4},
	"espectro": {"hp": 16.0, "dano": 4.0, "vel": 90.0, "alto": 120.0, "tex": "lr_espectro", "desde": 6, "vuela": true},
	"bruto": {"hp": 45.0, "dano": 9.0, "vel": 55.0, "alto": 150.0, "tex": "lr_bruto", "desde": 4},
	"alado": {"hp": 9.0, "dano": 2.0, "vel": 120.0, "alto": 70.0, "tex": "lr_alado", "desde": 6, "vuela": true},
	"jefe": {"hp": 320.0, "dano": 22.0, "vel": 40.0, "alto": 250.0, "tex": "lr_jefe", "desde": 99},
}

## Oficios: lo que cuesta la herramienta y su textura.
const OFICIOS: Dictionary = {
	"arquero": {"nombre": "Arquero", "coste": 2, "tex": "lr_arquero", "texto": "Caza ciervos de día y dispara a las sombras de noche."},
	"constructor": {"nombre": "Constructor", "coste": 2, "tex": "lr_constructor", "texto": "Levanta muros, torres y granjas."},
	"granjero": {"nombre": "Granjero", "coste": 3, "tex": "lr_granjero", "texto": "Trabaja las granjas: da brasas cada día."},
	"lancero": {"nombre": "Lancero", "coste": 4, "tex": "lr_lancero", "texto": "Guarda los muros y asalta las grietas."},
}

## Sitios: dónde se puede construir. x es la distancia al fuego (se ponen a los dos lados).
## «nivel_hoguera» = nivel del fuego que hace falta. «niveles» = coste de cada nivel.
const SITIOS: Array = [
	{"tipo": "hoguera", "x": 0.0, "niveles": [0, 6, 12], "doble": false},
	{"tipo": "tienda_arquero", "x": -150.0, "niveles": [2], "doble": false},
	{"tipo": "tienda_constructor", "x": 150.0, "niveles": [2], "doble": false},
	{"tipo": "tienda_granjero", "x": -280.0, "niveles": [3], "doble": false, "nivel_hoguera": 2},
	{"tipo": "tienda_lancero", "x": 280.0, "niveles": [4], "doble": false, "nivel_hoguera": 3},
	{"tipo": "granja", "x": 420.0, "niveles": [4], "doble": true, "nivel_hoguera": 2},
	{"tipo": "muro", "x": 640.0, "niveles": [3, 6, 10], "doble": true},
	{"tipo": "torre", "x": 820.0, "niveles": [6], "doble": true, "nivel_hoguera": 2},
	{"tipo": "muro", "x": 1150.0, "niveles": [4, 7, 12], "doble": true, "nivel_hoguera": 2},
	{"tipo": "torre", "x": 1350.0, "niveles": [7], "doble": true, "nivel_hoguera": 3},
	{"tipo": "muro", "x": 1750.0, "niveles": [5, 8, 14], "doble": true, "nivel_hoguera": 3},
	{"tipo": "campamento", "x": 2300.0, "niveles": [], "doble": true},
	{"tipo": "cofre", "x": 1000.0, "niveles": [], "doble": true},
	{"tipo": "cofre", "x": 2800.0, "niveles": [], "doble": true},
	{"tipo": "grieta", "x": 3450.0, "niveles": [6], "doble": true},
	{"tipo": "santuario", "x": 1550.0, "niveles": [10], "doble": true},
	{"tipo": "catapulta", "x": 980.0, "niveles": [9], "doble": true, "nivel_hoguera": 3},
	{"tipo": "cofre", "x": 4700.0, "niveles": [], "doble": true},
	{"tipo": "cofre", "x": 6500.0, "niveles": [], "doble": true},
	{"tipo": "campamento", "x": 5600.0, "niveles": [], "doble": true},
]

## Monumentos del paisaje (decorado del mundo): uno distinto cada tramo, según el valle.
const HITOS: Dictionary = {
	"ciervo": ["lr_hito_molino", "lr_hito_estatua_rey", "lr_hito_obelisco", "lr_hito_arco", "lr_hito_torre", "lr_hito_estatua_angel"],
	"cienaga": ["lr_hito_barco", "lr_hito_monolito", "lr_hito_torre", "lr_hito_monolito", "lr_hito_arco", "lr_hito_obelisco"],
	"ceniza": ["lr_hito_obelisco", "lr_hito_monolito", "lr_hito_torre", "lr_hito_estatua_rey", "lr_hito_monolito", "lr_hito_arco"],
	"nieve": ["lr_hito_estatua_angel", "lr_hito_obelisco", "lr_hito_torre", "lr_hito_monolito", "lr_hito_molino", "lr_hito_estatua_rey"],
	"desierto": ["lr_hito_obelisco", "lr_hito_arco", "lr_hito_barco", "lr_hito_estatua_rey", "lr_hito_monolito", "lr_hito_torre"],
	"ruinas": ["lr_hito_estatua_rey", "lr_hito_arco", "lr_hito_monolito", "lr_hito_estatua_angel", "lr_hito_torre", "lr_hito_obelisco"],
}
const X_HITOS: Array = [2050.0, 2650.0, 4100.0, 5000.0, 5900.0, 6900.0]

## Agua del primer plano (refleja el mundo, como un río a los pies del reino). Color por valle.
const AGUA: Dictionary = {
	"ciervo": Color(0.55, 0.72, 0.85), "cienaga": Color(0.45, 0.6, 0.5), "ceniza": Color(1.0, 0.45, 0.25),
	"nieve": Color(0.75, 0.88, 1.0), "desierto": Color(0.5, 0.75, 0.8), "ruinas": Color(0.6, 0.55, 0.85),
}

## Héroes: se rescatan en los santuarios. Pelean solos y usan su habilidad cada cierto tiempo.
const HEROES: Dictionary = {
	"caballero": {"nombre": "Caballero de la Aurora", "tex": "lr_caballero", "dano": 8.0, "alcance": 95.0, "cd": 0.8, "hab_cd": 12.0,
		"hab": "Embestida de la aurora", "texto": "Pelea en el muro y lanza una onda que empuja a las sombras.", "asalto": 15.0},
	"bruja": {"nombre": "Bruja de la Ciénaga", "tex": "lr_bruja", "dano": 9.0, "alcance": 460.0, "cd": 2.6, "hab_cd": 14.0,
		"hab": "Hoguera verde", "texto": "Lanza bolas de fuego verde y, a veces, una gran llamarada.", "asalto": 10.0},
	"monje": {"nombre": "Monje del Alba", "tex": "lr_monje", "dano": 6.0, "alcance": 90.0, "cd": 0.45, "hab_cd": 11.0,
		"hab": "Torbellino", "texto": "Golpea muy rápido y gira su bastón aturdiendo a todo lo que tiene cerca.", "asalto": 12.0},
	"ingeniera": {"nombre": "Ingeniera Brasa", "tex": "lr_ingeniera", "dano": 7.0, "alcance": 540.0, "cd": 1.2, "hab_cd": 13.0,
		"hab": "Bomba de brasas", "texto": "Su ballesta atraviesa sombras y lanza una bomba que lo arrasa todo.", "asalto": 14.0},
	"druida": {"nombre": "Druida del Roble", "tex": "lr_druida", "dano": 5.0, "alcance": 420.0, "cd": 1.6, "hab_cd": 15.0,
		"hab": "Raíces", "texto": "Repara el muro más castigado y atrapa a las sombras con raíces.", "asalto": 9.0},
	"cazadora": {"nombre": "Cazadora de Estrellas", "tex": "lr_cazadora", "dano": 4.0, "alcance": 620.0, "cd": 0.55, "hab_cd": 10.0,
		"hab": "Lluvia de estrellas", "texto": "Dispara sin parar y hace caer flechas de estrellas.", "asalto": 8.0},
}
## Qué héroe espera en cada santuario (izquierda, derecha) en cada valle.
const HEROES_VALLE: Array = [["caballero", "cazadora"], ["bruja", "caballero"], ["cazadora", "bruja"], ["monje", "caballero"],
	["ingeniera", "cazadora"], ["druida", "bruja"]]

## Criaturas propias de cada valle: sustituyen a algunas sombras o brutos.
const VARIANTES: Array = [{}, {"sombra": "ahogado"}, {"bruto": "golem"}, {"sombra": "lobo"}, {"bruto": "escorpion"}, {"alado": "espectro"}]
## Árbol de cada valle.
const ARBOLES: Array = ["lr_arbol", "lr_arbol_muerto", "lr_arbol_quemado", "lr_arbol_nieve", "lr_arbol_desierto", "lr_arbol_ruinas"]

## Altar de la Luna: mejoras permanentes que se compran con fragmentos de luna.
const MEJORAS: Dictionary = {
	"bolsa": {"nombre": "Bolsa grande", "texto": "+10 brasas de capacidad", "costes": [3, 6]},
	"inicio": {"nombre": "Brasas de herencia", "texto": "+4 brasas al empezar un valle", "costes": [2, 4, 6]},
	"farol": {"nombre": "Farol bendito", "texto": "El destello recarga antes y llega más lejos", "costes": [4, 8]},
	"muros": {"nombre": "Muros reforzados", "texto": "+25% de vida en todos los muros", "costes": [4, 8]},
	"heroes": {"nombre": "Héroes leales", "texto": "Rescatar héroes cuesta la mitad", "costes": [6]},
	"fuerza_heroes": {"nombre": "Héroes legendarios", "texto": "+20% de daño de los héroes", "costes": [5, 9, 14]},
	"catapultas": {"nombre": "Piedra de luna", "texto": "+25% de daño de las catapultas", "costes": [4, 8]},
	"granjas": {"nombre": "Tierra fértil", "texto": "Las granjas dan brasas más a menudo", "costes": [3, 6]},
	"cuerno": {"nombre": "Cuerno de los reyes", "texto": "El cuerno dura más y recarga antes", "costes": [5, 10]},
	"arqueros": {"nombre": "Flechas de plata", "texto": "+20% de daño de los arqueros", "costes": [3, 6, 10]},
}

## Jefe de cada valle: sale en las noches de luna roja con su propia habilidad y una segunda fase al 50%.
const JEFES: Dictionary = {
	"ciervo": {"nombre": "El Ciervo Corrupto", "hab": "carga", "cd": 7.0, "aviso": "¡Embiste!"},
	"cienaga": {"nombre": "La Bruja del Pantano", "hab": "invoca", "cd": 9.0, "aviso": "¡Los ahogados despiertan!"},
	"ceniza": {"nombre": "El Dragón de Lava", "hab": "fuego", "cd": 6.5, "aviso": "¡Lluvia de fuego!"},
	"nieve": {"nombre": "El Rey Lobo de Escarcha", "hab": "hielo", "cd": 7.5, "aviso": "¡Aliento helado!"},
	"desierto": {"nombre": "El Emperador Escorpión", "hab": "enterrar", "cd": 9.0, "aviso": "¡Se hunde en la arena!"},
	"ruinas": {"nombre": "El Rey Caído", "hab": "espectros", "cd": 8.0, "aviso": "¡Llama a su guardia!"},
}

## Monturas de la reina: se compran en el altar con fragmentos tras liberar valles.
const MONTURAS: Array = [
	{"id": "", "nombre": "A pie", "texto": "Sin montura.", "coste": 0, "valles": 0},
	{"id": "caballo", "nombre": "Corcel de guerra", "texto": "+40% de velocidad.", "coste": 6, "valles": 1},
	{"id": "oso", "nombre": "Oso acorazado", "texto": "Los golpes te quitan la mitad de brasas y el oso aturde al atacante.", "coste": 10, "valles": 2},
	{"id": "grifo", "nombre": "Grifo blanco", "texto": "+25% de velocidad, atrae brasas desde el doble de lejos y el destello recarga antes.", "coste": 16, "valles": 4},
]

const VIDA_MURO: Array = [0.0, 40.0, 110.0, 220.0]
const TRABAJO_MURO: Array = [0.0, 4.0, 7.0, 10.0]

const NOMBRES_SITIO: Dictionary = {
	"hoguera": "Hoguera real", "tienda_arquero": "Arcos", "tienda_constructor": "Martillos", "tienda_granjero": "Guadañas",
	"tienda_lancero": "Lanzas", "granja": "Granja", "muro": "Muro", "torre": "Torre de arqueros", "campamento": "Campamento",
	"cofre": "Cofre", "grieta": "Grieta de sombras", "santuario": "Santuario", "catapulta": "Catapulta",
}
const NOMBRES_MURO: Array = ["", "Empalizada", "Muro de piedra", "Muralla"]


## Logros: cada uno da fragmentos de luna la primera vez.
const LOGROS: Array = [
	{"id": "muro", "nombre": "Primera piedra", "texto": "Levanta tu primer muro.", "premio": 1},
	{"id": "heroe", "nombre": "Aliados", "texto": "Rescata a un héroe.", "premio": 1},
	{"id": "noche10", "nombre": "Diez noches", "texto": "Aguanta 10 noches en un valle.", "premio": 2},
	{"id": "jefes6", "nombre": "Cazarreyes", "texto": "Derrota al jefe de los seis valles.", "premio": 8},
	{"id": "montura", "nombre": "Jinete", "texto": "Consigue una montura.", "premio": 2},
	{"id": "jefe", "nombre": "Matagigantes", "texto": "Derrota a un monstruo de la Luna Roja.", "premio": 2},
	{"id": "grieta", "nombre": "Sellado", "texto": "Cierra una grieta.", "premio": 1},
	{"id": "valle1", "nombre": "Valle libre", "texto": "Libera tu primer valle.", "premio": 2},
	{"id": "valle3", "nombre": "La mitad del reino", "texto": "Libera tres valles.", "premio": 3},
	{"id": "valle6", "nombre": "Reina de la Luna", "texto": "Libera los seis valles.", "premio": 5},
	{"id": "sombras500", "nombre": "Cazadora de sombras", "texto": "Abate 500 sombras en total.", "premio": 2},
	{"id": "sombras3000", "nombre": "Leyenda", "texto": "Abate 3000 sombras en total.", "premio": 4},
	{"id": "muralla", "nombre": "Muralla", "texto": "Construye una muralla de nivel 3.", "premio": 2},
	{"id": "catapulta", "nombre": "Ingeniería", "texto": "Construye una catapulta.", "premio": 1},
	{"id": "tres_heroes", "nombre": "Compañía", "texto": "Ten dos héroes a la vez.", "premio": 2},
	{"id": "eterna20", "nombre": "Luna eterna", "texto": "Aguanta 20 noches en la Luna eterna.", "premio": 5},
	{"id": "sin_muros", "nombre": "Valiente", "texto": "Sobrevive una Luna Roja sin perder ningún muro.", "premio": 3},
]

class_name Datos
extends RefCounted
## Bajo la Luna Roja: valles, lunas, criaturas, oficios y sitios donde construir.

## Duración de cada parte del día (segundos de juego).
const T_DIA: float = 75.0
const T_TARDE: float = 10.0
const T_NOCHE: float = 55.0
const T_ALBA: float = 6.0

const SUELO: float = 600.0
const BORDE: float = 3700.0

## Valles de la campaña: cada uno con su paisaje y criaturas más duras.
const VALLES: Array = [
	{"id": "ciervo", "nombre": "El Valle del Ciervo", "tinte": Color(1, 1, 1), "suelo": Color("2b2a1e"), "hierba": Color("4f6b33"),
		"fuerza": 1.0, "brasas": 12, "texto": "Un valle verde, un fuego y una corona. Las sombras todavía no saben que has llegado."},
	{"id": "cienaga", "nombre": "La Ciénaga Gris", "tinte": Color(0.82, 0.9, 0.86), "suelo": Color("23271f"), "hierba": Color("3d5644"),
		"fuerza": 1.3, "brasas": 14, "texto": "La niebla tapa las grietas. Aquí las sombras salen antes y vuelven más."},
	{"id": "ceniza", "nombre": "Los Picos de Ceniza", "tinte": Color(1.0, 0.86, 0.8), "suelo": Color("2a1f1c"), "hierba": Color("5a4334"),
		"fuerza": 1.65, "brasas": 16, "texto": "Aquí nació la Luna Roja. Cierra las dos grietas y el valle volverá a dormir."},
]

## Lunas: cambian cada noche. «roja» toca cada 5 noches.
const LUNAS: Dictionary = {
	"llena": {"nombre": "Luna llena", "texto": "Más sombras, pero tus arqueros ven más lejos.", "cantidad": 1.3, "vista": 1.25, "oscuridad": 0.62, "color": Color("dfe6ff")},
	"nueva": {"nombre": "Luna nueva", "texto": "Noche cerrada: no verás las sombras hasta tenerlas encima.", "cantidad": 1.0, "vista": 0.75, "oscuridad": 0.86, "color": Color("3a3f55")},
	"creciente": {"nombre": "Luna creciente", "texto": "Una noche normal. O eso parece.", "cantidad": 1.0, "vista": 1.0, "oscuridad": 0.72, "color": Color("f2e6b8")},
	"azul": {"nombre": "Luna azul", "texto": "Noche tranquila. Un mercader fantasma ronda el valle.", "cantidad": 0.5, "vista": 1.1, "oscuridad": 0.66, "color": Color("8fc4ff")},
	"roja": {"nombre": "Luna roja", "texto": "La gran marea de sombras. Y algo enorme viene con ellas.", "cantidad": 2.2, "vista": 1.0, "oscuridad": 0.7, "color": Color("ff3b3b")},
}

## Criaturas: vida, daño, velocidad (px/s), alto al dibujar. «vuela» pasa por encima de los muros.
const CRIATURAS: Dictionary = {
	"sombra": {"hp": 7.0, "dano": 2.0, "vel": 95.0, "alto": 74.0, "tex": "lr_sombra", "desde": 1},
	"bruto": {"hp": 45.0, "dano": 9.0, "vel": 55.0, "alto": 150.0, "tex": "lr_bruto", "desde": 4},
	"alado": {"hp": 9.0, "dano": 2.0, "vel": 120.0, "alto": 70.0, "tex": "lr_alado", "desde": 6, "vuela": true},
	"jefe": {"hp": 320.0, "dano": 22.0, "vel": 40.0, "alto": 250.0, "tex": "lr_jefe", "desde": 99},
}

## Oficios: lo que cuesta la herramienta y su textura.
const OFICIOS: Dictionary = {
	"arquero": {"nombre": "Arquero", "coste": 2, "tex": "lr_arquero", "texto": "Caza ciervos de día y dispara a las sombras de noche."},
	"constructor": {"nombre": "Constructor", "coste": 2, "tex": "lr_constructor", "texto": "Levanta muros, torres y granjas."},
	"granjero": {"nombre": "Granjero", "coste": 3, "tex": "lr_granjero", "texto": "Trabaja las granjas: da brasas cada día."},
	"lancero": {"nombre": "Lancero", "coste": 4, "tex": "lr_lancero", "texto": "Guarda los muros y asalta las grietas."},
}

## Sitios: dónde se puede construir. x es la distancia al fuego (se ponen a los dos lados).
## «nivel_hoguera» = nivel del fuego que hace falta. «niveles» = coste de cada nivel.
const SITIOS: Array = [
	{"tipo": "hoguera", "x": 0.0, "niveles": [0, 6, 12], "doble": false},
	{"tipo": "tienda_arquero", "x": -150.0, "niveles": [2], "doble": false},
	{"tipo": "tienda_constructor", "x": 150.0, "niveles": [2], "doble": false},
	{"tipo": "tienda_granjero", "x": -280.0, "niveles": [3], "doble": false, "nivel_hoguera": 2},
	{"tipo": "tienda_lancero", "x": 280.0, "niveles": [4], "doble": false, "nivel_hoguera": 3},
	{"tipo": "granja", "x": 420.0, "niveles": [4], "doble": true, "nivel_hoguera": 2},
	{"tipo": "muro", "x": 640.0, "niveles": [3, 6, 10], "doble": true},
	{"tipo": "torre", "x": 820.0, "niveles": [6], "doble": true, "nivel_hoguera": 2},
	{"tipo": "muro", "x": 1150.0, "niveles": [4, 7, 12], "doble": true, "nivel_hoguera": 2},
	{"tipo": "torre", "x": 1350.0, "niveles": [7], "doble": true, "nivel_hoguera": 3},
	{"tipo": "muro", "x": 1750.0, "niveles": [5, 8, 14], "doble": true, "nivel_hoguera": 3},
	{"tipo": "campamento", "x": 2300.0, "niveles": [], "doble": true},
	{"tipo": "cofre", "x": 1000.0, "niveles": [], "doble": true},
	{"tipo": "cofre", "x": 2800.0, "niveles": [], "doble": true},
	{"tipo": "grieta", "x": 3450.0, "niveles": [6], "doble": true},
]

const VIDA_MURO: Array = [0.0, 40.0, 110.0, 220.0]
const TRABAJO_MURO: Array = [0.0, 4.0, 7.0, 10.0]

const NOMBRES_SITIO: Dictionary = {
	"hoguera": "Hoguera real", "tienda_arquero": "Arcos", "tienda_constructor": "Martillos", "tienda_granjero": "Guadañas",
	"tienda_lancero": "Lanzas", "granja": "Granja", "muro": "Muro", "torre": "Torre de arqueros", "campamento": "Campamento",
	"cofre": "Cofre", "grieta": "Grieta de sombras",
}
const NOMBRES_MURO: Array = ["", "Empalizada", "Muro de piedra", "Muralla"]

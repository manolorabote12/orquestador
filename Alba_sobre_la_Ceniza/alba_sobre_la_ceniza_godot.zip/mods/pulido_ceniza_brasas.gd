extends "res://kit/mod_base.gd"

const LAVA: Color = Color(1.0, 0.45, 0.12)
const GOLD: Color = Color(1.0, 0.86, 0.45)
const LIGHT: Color = Color(1.0, 0.97, 0.85)
const ASH: Color = Color(0.62, 0.58, 0.58)

var _embers: CanvasLayer = null
var _cool: float = 0.0
var _streak: int = 0


func _center() -> Vector2:
	var p: Node2D = player()
	if p != null:
		return p.position
	return get_viewport().get_visible_rect().size * 0.5


func _clear_embers() -> void:
	if _embers != null and is_instance_valid(_embers):
		_embers.queue_free()
	_embers = null


func _make_embers() -> void:
	_clear_embers()
	_embers = CanvasLayer.new()
	_embers.layer = 4
	add_child(_embers)
	var size: Vector2 = get_viewport().get_visible_rect().size
	for i in range(16):
		var e: ColorRect = ColorRect.new()
		var s: float = randf_range(2.0, 5.0)
		e.size = Vector2(s, s)
		e.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var c: Color = LAVA if i % 3 == 0 else ASH
		c.a = randf_range(0.25, 0.5)
		e.color = c
		var x0: float = randf_range(0.0, size.x)
		e.position = Vector2(x0, size.y + 10.0)
		_embers.add_child(e)
		var dur: float = randf_range(7.0, 14.0)
		var ty: Tween = e.create_tween()
		ty.set_loops()
		ty.tween_property(e, "position:y", -20.0, dur).from(size.y + 10.0).set_delay(randf_range(0.0, 0.1))
		var tx: Tween = e.create_tween()
		tx.set_loops()
		var sway: float = randf_range(15.0, 40.0)
		tx.tween_property(e, "position:x", x0 + sway, dur * 0.25).from(x0).set_trans(Tween.TRANS_SINE)
		tx.tween_property(e, "position:x", x0 - sway, dur * 0.25).set_trans(Tween.TRANS_SINE)


func on_level_start() -> void:
	_streak = 0
	_cool = 0.0
	_make_embers()
	toast("\u00a1Alba sobre la Ceniza!", GOLD)
	flash_screen(Color(1.0, 0.9, 0.6, 0.25), 0.25)
	burst(_center(), GOLD, 18)
	play_sound("coin", 1.1)


func on_tick(delta: float) -> void:
	if _cool > 0.0:
		_cool -= delta


func on_event(event_name: String, data: Dictionary) -> void:
	if event_name == "build_done":
		burst(_center(), LIGHT, 20)
		shake(2.5)
		if _cool <= 0.0:
			toast("\u00a1Obra terminada!", LIGHT)
			_cool = 1.2
		play_sound("coin", 1.2)
	elif event_name == "battle":
		var win: bool = bool(data.get("win", false))
		if win:
			_streak += 1
			burst(_center(), GOLD, 26)
			shake(4.0)
			flash_screen(Color(1.0, 0.85, 0.4, 0.22), 0.15)
			if _streak >= 2:
				toast("\u00a1Racha de %d victorias!" % _streak, LAVA)
			else:
				toast("\u00a1Victoria! La luz avanza", GOLD)
			_cool = 1.2
			play_sound("coin", 1.0)
		else:
			_streak = 0
			burst(_center(), ASH, 14)
			shake(3.0)
			flash_screen(Color(0.5, 0.15, 0.1, 0.18), 0.15)
			toast("Reagrupa a tus tropas", ASH)
			_cool = 1.2
	elif event_name == "level_complete":
		burst(_center(), GOLD, 40)
		burst(_center(), LIGHT, 30)
		shake(5.0)
		flash_screen(Color(1.0, 0.95, 0.75, 0.5), 0.4)
		toast("\u00a1La ceniza se disipa!", GOLD)
		play_sound("coin", 1.3)
		_clear_embers()

extends "res://kit/mod_base.gd"

# Pulido cosmetico: motas de luz que barren la ceniza + efectos en momentos clave.

const GOLD: Color = Color(1.0, 0.85, 0.35)
const WHITE_LIGHT: Color = Color(1.0, 0.97, 0.85)
const EMBER: Color = Color(1.0, 0.45, 0.2)
const ELF_GREEN: Color = Color(0.55, 0.95, 0.6)

const MOTE_COUNT: int = 16

var _fx_layer: CanvasLayer = null
var _motes: Array = []
var _time: float = 0.0
var _last_fx: float = -10.0
var _win_streak: int = 0
var _build_count: int = 0


func _screen() -> Vector2:
	return get_viewport().get_visible_rect().size


func _ensure_motes() -> void:
	if _fx_layer != null and is_instance_valid(_fx_layer):
		return
	_fx_layer = CanvasLayer.new()
	_fx_layer.layer = 4
	add_child(_fx_layer)
	_motes.clear()
	var size: Vector2 = _screen()
	for i in range(MOTE_COUNT):
		var m: Polygon2D = Polygon2D.new()
		var r: float = 2.0 + float(i % 3)
		m.polygon = PackedVector2Array([Vector2(0, -r), Vector2(r, 0), Vector2(0, r), Vector2(-r, 0)])
		var warm: bool = i % 4 == 0
		var c: Color = EMBER if warm else WHITE_LIGHT
		c.a = 0.22 + 0.04 * float(i % 4)
		m.color = c
		m.position = Vector2(fmod(float(i) * 97.0, maxf(size.x, 1.0)), fmod(float(i) * 53.0, maxf(size.y, 1.0)))
		m.set_meta("spd", 12.0 + float((i * 7) % 20))
		m.set_meta("ph", float(i) * 0.9)
		_fx_layer.add_child(m)
		_motes.append(m)


func _can_fx(gap: float) -> bool:
	if _time - _last_fx < gap:
		return false
	_last_fx = _time
	return true


func on_level_start() -> void:
	_ensure_motes()
	_win_streak = 0
	_build_count = 0
	var size: Vector2 = _screen()
	_last_fx = _time
	burst(Vector2(size.x * 0.5, size.y * 0.4), GOLD, 22)
	flash_screen(Color(1.0, 0.95, 0.8, 0.25), 0.3)
	toast("\u00a1Alba sobre la Ceniza!", GOLD)
	play_sound("click", 1.2)


func on_event(event_name: String, data: Dictionary) -> void:
	var size: Vector2 = _screen()
	var center: Vector2 = Vector2(size.x * 0.5, size.y * 0.45)
	if event_name == "battle":
		var win: bool = bool(data.get("win", false))
		if win:
			_win_streak += 1
			burst(center, GOLD, 30)
			burst(center, WHITE_LIGHT, 16)
			shake(4.0)
			flash_screen(Color(1.0, 0.95, 0.7, 0.3), 0.2)
			if _win_streak >= 2:
				toast("\u00a1Racha de %d victorias!" % _win_streak, ELF_GREEN)
			else:
				toast("\u00a1Victoria!", GOLD)
			play_sound("win", 1.1)
		else:
			_win_streak = 0
			burst(center, EMBER, 14)
			shake(3.0)
			toast("Reag\u00fapate, Ilvaris", Color(1.0, 0.6, 0.45))
	elif event_name == "build_done":
		_build_count += 1
		burst(Vector2(size.x * 0.5, size.y * 0.55), ELF_GREEN, 18)
		if _can_fx(0.8):
			var phrases: Array = ["\u00a1Obra lista!", "\u00a1Piedra blanca!", "\u00a1La ciudad crece!"]
			toast(String(phrases[_build_count % phrases.size()]), WHITE_LIGHT)
			play_sound("coin", 1.15)
	elif event_name == "level_complete":
		burst(center, GOLD, 40)
		burst(Vector2(size.x * 0.3, size.y * 0.5), WHITE_LIGHT, 24)
		burst(Vector2(size.x * 0.7, size.y * 0.5), ELF_GREEN, 24)
		shake(6.0)
		flash_screen(Color(1.0, 1.0, 0.9, 0.5), 0.5)
		toast("\u00a1La luz vence a la ceniza!", GOLD)
		play_sound("win", 1.0)


func on_tick(delta: float) -> void:
	_time += delta
	if _fx_layer == null or not is_instance_valid(_fx_layer):
		return
	var size: Vector2 = _screen()
	for m in _motes:
		var mote: Polygon2D = m as Polygon2D
		if mote == null or not is_instance_valid(mote):
			continue
		var spd: float = float(mote.get_meta("spd"))
		var ph: float = float(mote.get_meta("ph"))
		mote.position.y -= spd * delta
		mote.position.x += sin(_time * 0.8 + ph) * 8.0 * delta
		mote.rotation += delta * 0.5
		if mote.position.y < -10.0:
			mote.position.y = size.y + 10.0
			mote.position.x = fmod(absf(mote.position.x) + 61.0, maxf(size.x, 1.0))
